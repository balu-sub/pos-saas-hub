import React, { useState, useEffect } from 'react';
import { POSProvider, usePOS } from './context/POSContext';
import { PeripheralProvider, usePeripherals } from './context/PeripheralContext';
import { VirtualKeyboardProvider } from './context/VirtualKeyboardContext';
import { LanguageProvider } from './context/LanguageContext';
import { TopNavBar } from './components/navigation/TopNavBar';
import { BottomStatusBar } from './components/navigation/BottomStatusBar';
import { SideNavBar } from './components/navigation/SideNavBar';
import { RegisterScreen } from './components/register/RegisterScreen';
import { MatrixInventoryScreen } from './components/inventory/MatrixInventoryScreen';
import { ReconciliationScreen } from './components/reconciliation/ReconciliationScreen';
import { ReplenishmentScreen } from './components/replenishment/ReplenishmentScreen';
import { AnalyticsScreen } from './components/analytics/AnalyticsScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';
import { SplitTenderModal } from './components/checkout/SplitTenderModal';
import { KioskPaymentModal } from './components/kiosk/KioskPaymentModal';
import { CustomerKioskTotemScreen } from './components/kiosk/CustomerKioskTotemScreen';
import { ReceiptModal } from './components/checkout/ReceiptModal';
import { PinLockModal } from './components/modals/PinLockModal';
import { KeyboardHelpModal } from './components/modals/KeyboardHelpModal';
import { AICameraVisionModal } from './components/modals/AICameraVisionModal';
import { AIVoiceInputModal } from './components/modals/AIVoiceInputModal';
import { BarcodeScannerModal } from './components/modals/BarcodeScannerModal';
import { VirtualKeyboardDrawer } from './components/modals/VirtualKeyboardDrawer';
import { DuplicateReceiptModal } from './components/modals/DuplicateReceiptModal';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { AuthProvider, useAuth } from './context/AuthContext';
import { UpdateProvider } from './context/UpdateContext';
import { UpdateModal } from './components/modals/UpdateModal';
import { HomePage } from './components/home/HomePage';
import { CustomerPortal } from './components/customer/CustomerPortal';
import { SaasHubScreen } from './components/saas/SaasHubScreen';

const POSAppContent: React.FC = () => {
  const { isAuthorizedForSimulation, setCurrentView } = useAuth();
  const {
    activeTab,
    cart,
    setIsCheckoutOpen,
    setIsReceiptOpen,
    currentOperator,
  } = usePOS();

  const handleExitApp = () => {
    if (isAuthorizedForSimulation) {
      setCurrentView('saas_hub');
      return;
    }
    try {
      window.close();
    } catch {
      // browser may block window.close
    }
    setTimeout(() => {
      setCurrentView('home');
    }, 150);
  };

  const isKiosk = currentOperator?.userRole === 'Customer Kiosk';

  const {
    setIsAICameraModalOpen,
    setIsAIVoiceModalOpen,
    setIsBarcodeScannerModalOpen,
    kickOpenDrawer,
    tareScale,
  } = usePeripherals();

  const [isKeyboardHelpOpen, setIsKeyboardHelpOpen] = useState(false);
  const [isPinLockOpen, setIsPinLockOpen] = useState(false);
  const [isDuplicateReceiptOpen, setIsDuplicateReceiptOpen] = useState(false);

  // isSidebarHidden: completely hides/shows entire menu (toggled by top header hamburger)
  const [isSidebarHidden, setIsSidebarHidden] = useState(() => {
    try {
      return localStorage.getItem('alfa_pos_sidebar_hidden') === 'true';
    } catch {
      return false;
    }
  });

  // isSidebarCollapsed: hides menu text and shows menu icons only (toggled by menu arrow icon)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    try {
      return localStorage.getItem('alfa_pos_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleSidebarHidden = () => {
    setIsSidebarHidden((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('alfa_pos_sidebar_hidden', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const toggleSidebarCollapsed = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('alfa_pos_sidebar_collapsed', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Global Hardware Hotkeys Handler (F12, F2, F3, F4, F6, F7, F8, Escape, Ctrl+B)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // In Customer Kiosk mode, only allow express checkout and cancel/escape
      if (isKiosk) {
        if (e.key === 'F12') {
          e.preventDefault();
          if (cart.length > 0) {
            setIsCheckoutOpen(true);
          }
        } else if (e.key === 'Escape') {
          setIsCheckoutOpen(false);
          setIsReceiptOpen(false);
        }
        return;
      }

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        toggleSidebarHidden();
      } else if (e.key === 'F12') {
        e.preventDefault();
        if (cart.length > 0) {
          setIsCheckoutOpen(true);
        }
      } else if (e.key === 'F2') {
        e.preventDefault();
        setIsAICameraModalOpen(true);
      } else if (e.key === 'F3') {
        e.preventDefault();
        setIsAIVoiceModalOpen(true);
      } else if (e.key === 'F4') {
        e.preventDefault();
        setIsBarcodeScannerModalOpen(true);
      } else if (e.key === 'F6') {
        e.preventDefault();
        tareScale();
      } else if (e.key === 'F7') {
        e.preventDefault();
        setIsDuplicateReceiptOpen(true);
      } else if (e.key === 'F8') {
        e.preventDefault();
        kickOpenDrawer();
      } else if (e.key === 'Escape') {
        setIsCheckoutOpen(false);
        setIsReceiptOpen(false);
        setIsKeyboardHelpOpen(false);
        setIsPinLockOpen(false);
        setIsDuplicateReceiptOpen(false);
        setIsAICameraModalOpen(false);
        setIsAIVoiceModalOpen(false);
        setIsBarcodeScannerModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isKiosk,
    cart.length,
    setIsCheckoutOpen,
    setIsReceiptOpen,
    setIsAICameraModalOpen,
    setIsAIVoiceModalOpen,
    setIsBarcodeScannerModalOpen,
    kickOpenDrawer,
    tareScale,
  ]);

  return (
    <div className="min-h-screen h-[100dvh] w-full max-w-[100vw] overflow-hidden flex flex-col bg-[#F4F4F5] text-[#09090B]">
      {isKiosk ? (
        /* Dedicated Full-Screen Customer Kiosk Totem Experience (Light Mode) */
        <ErrorBoundary fallbackTitle="Customer Kiosk Screen Recovered">
          <CustomerKioskTotemScreen onOpenStaffExit={() => setIsPinLockOpen(true)} />
        </ErrorBoundary>
      ) : (
        <>
          {/* Fixed Top Bar */}
          <TopNavBar
            onOpenKeyboardHelp={() => setIsKeyboardHelpOpen(true)}
            onOpenPinModal={() => setIsPinLockOpen(true)}
            isSidebarHidden={isSidebarHidden}
            onToggleSidebar={toggleSidebarHidden}
          />

          {/* Main App Canvas */}
          <div className="flex-1 flex overflow-hidden min-h-0">
            {/* Side Navigation */}
            <SideNavBar
              onOpenPinModal={() => setIsPinLockOpen(true)}
              onOpenSupportModal={() => setIsKeyboardHelpOpen(true)}
              onExitApp={handleExitApp}
              isSidebarHidden={isSidebarHidden}
              isSidebarCollapsed={isSidebarCollapsed}
              onToggleCollapse={toggleSidebarCollapsed}
            />

            {/* Dynamic Route Content */}
            <div className="flex-1 flex flex-col min-h-0 min-w-0 overflow-hidden h-full">
              {activeTab === 'register' && (
                <RegisterScreen onOpenDuplicateReceipt={() => setIsDuplicateReceiptOpen(true)} />
              )}
              {activeTab === 'inventory' && <MatrixInventoryScreen />}
              {activeTab === 'reconciliation' && <ReconciliationScreen />}
              {activeTab === 'replenishment' && <ReplenishmentScreen />}
              {activeTab === 'analytics' && <AnalyticsScreen />}
              {activeTab === 'settings' && <SettingsScreen />}
            </div>
          </div>

          {/* Discrete Bottom System & Device Status Strip (Alternative 2) */}
          <BottomStatusBar />
        </>
      )}

      {/* Split-Tender Payment Modal (Cashier) or Express Payment Modal (Customer Kiosk) */}
      {isKiosk ? <KioskPaymentModal /> : <SplitTenderModal />}

      {/* Thermal Receipt Print Modal */}
      <ReceiptModal />

      {/* Duplicate / Search Past Invoices Modal */}
      <DuplicateReceiptModal
        isOpen={isDuplicateReceiptOpen}
        onClose={() => setIsDuplicateReceiptOpen(false)}
      />

      {/* Cashier PIN Lock Modal */}
      <PinLockModal
        isOpen={isPinLockOpen}
        onClose={() => setIsPinLockOpen(false)}
      />

      {/* Keyboard Shortcuts Reference Modal */}
      <KeyboardHelpModal
        isOpen={isKeyboardHelpOpen}
        onClose={() => setIsKeyboardHelpOpen(false)}
      />

      {/* AI Vision Camera Produce Recognition Modal [F2] */}
      <AICameraVisionModal />

      {/* AI Multilingual Voice Produce Ordering Modal [F3] */}
      <AIVoiceInputModal />

      {/* Barcode Scanner Setup / Test Modal [F4] */}
      <BarcodeScannerModal />

      {/* On-Screen Touch Virtual Keyboard & Numeric Keypad Drawer */}
      <VirtualKeyboardDrawer />

      {/* Over-The-Air Software Update Modal */}
      <UpdateModal />
    </div>
  );
};

const RootAppRouter: React.FC = () => {
  const { currentView } = useAuth();

  const urlParams = new URLSearchParams(window.location.search);
  const isExplicitLanding = urlParams.get('view') === 'landing';
  if (isExplicitLanding && currentView === 'home') {
    return <HomePage />;
  }

  if (currentView === 'saas_hub') {
    return <SaasHubScreen />;
  }

  if (currentView === 'customer_portal') {
    return <CustomerPortal />;
  }

  // Primary Retail Counter Billing Terminal View (Default & Fallback)
  return (
    <LanguageProvider>
      <VirtualKeyboardProvider>
        <PeripheralProvider>
          <UpdateProvider>
            <POSProvider>
              <POSAppContent />
            </POSProvider>
          </UpdateProvider>
        </PeripheralProvider>
      </VirtualKeyboardProvider>
    </LanguageProvider>
  );
};

export function App() {
  return (
    <ErrorBoundary fallbackTitle="Terminal POS System Recovered">
      <AuthProvider>
        <RootAppRouter />
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;
