import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Ensure local billing terminal always boots into fresh billing counter UI and clears stale cache
try {
  if (localStorage.getItem('plannest_current_view') === 'home') {
    localStorage.removeItem('plannest_current_view');
  }
} catch {
  // ignore
}

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then((registrations) => {
    for (const r of registrations) {
      r.unregister();
    }
  }).catch(() => {});
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
