export type DatabaseDriverType = 'sqlite' | 'mysql' | 'supabase';

export interface DatabaseConfig {
  driver: DatabaseDriverType;
  storeId?: string;
  supabase?: {
    host: string;
    port: number;
    user: string;
    password?: string;
    database: string;
    ssl: boolean;
  };
  mysql: {
    host: string;
    port: number;
    user: string;
    password?: string;
    database: string;
    ssl: boolean;
  };
}

export interface DatabaseStatus {
  driver: DatabaseDriverType;
  driverName: string;
  connected: boolean;
  isOnline: boolean;
  activeTarget: string;
  sqliteFile: string;
  productCount: number;
  variantCount: number;
  lastChecked: string;
  storeId?: string;
  supabaseConfigured?: boolean;
  mysqlConfigured: boolean;
  mysqlDetails?: {
    host: string;
    port: number;
    user: string;
    database: string;
    ssl: boolean;
  };
}
