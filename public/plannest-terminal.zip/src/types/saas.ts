export type UserRole = 'staff' | 'customer';
export type UserPrivileges = 'super_admin' | 'staff' | 'customer';

export interface SaasUser {
  id: string;
  uuid?: string;
  email: string;
  businessName: string;
  phone?: string;
  role: UserRole;
  privileges: UserPrivileges;
  trialStartsAt?: string;
  trialEndsAt?: string;
  isPaid: boolean;
  planTier: 'trial' | 'local_starter' | 'pro' | 'enterprise';
}

export interface SaasLicense {
  licenseKey: string;
  token: string;
  status: 'active' | 'expired' | 'revoked';
  expiresAt: string;
  planTier: string;
  hardwareUuid?: string;
}

export interface TerminalTelemetry {
  id: string;
  user_id?: string;
  terminal_name: string;
  os_type: string;
  machine_uuid: string;
  cpu_usage: number;
  memory_mb: number;
  scale_status: 'online' | 'offline' | 'standby';
  printer_status: 'ready' | 'offline' | 'low_paper';
  local_ip: string;
  installer_used: 'bat' | 'ps1' | 'sh' | 'url';
  license_status: 'active' | 'expired' | 'revoked';
  last_ping: string;
}

export interface PosRelease {
  id: string;
  version: string;
  release_name: string;
  channel: 'stable' | 'beta' | 'nightly';
  release_date: string;
  changelog: string;
  min_os_version: string;
  is_current_stable: boolean | number;
  rollout_percentage: number;
  total_downloads: number;
}

export interface PurchaserFeedback {
  id: string;
  user_id?: string;
  purchaser_email: string;
  business_name: string;
  rating: number;
  category: string;
  message: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'pending' | 'in_review' | 'resolved';
  created_at: string;
}

export interface DiagnosticTestItem {
  name: string;
  type: 'database' | 'security' | 'telemetry' | 'packaging' | 'cloud';
  passed: boolean;
  latencyMs: number;
  detail: string;
}

export interface DiagnosticReport {
  overallStatus: 'HEALTHY' | 'DEGRADED';
  totalDurationMs: number;
  timestamp: string;
  tests: DiagnosticTestItem[];
}

export type DeploymentModel = 'plan_a' | 'plan_b' | 'plan_c';

export interface DeploymentWizardState {
  model: DeploymentModel;
  businessName: string;
  ownerEmail: string;
  phone: string;
  city: string;
  subdomain: string;
  storeCount: number;
  dbChoice: 'sqlite' | 'mysql' | 'cloudsql';
}
