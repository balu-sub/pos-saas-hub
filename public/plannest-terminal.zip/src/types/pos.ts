export interface ProductAttribute {
  id: string;
  name: string; // e.g. "Pack Size", "Weight", "Type"
  values: string[]; // e.g. ["500g", "1kg", "5kg", "25kg"]
}

export interface ProductVariant {
  id: string;
  productId: string;
  sku: string;
  barcode: string;
  name: string;
  unit: string; // e.g. "kg", "g", "pc", "pack", "L", "ml"
  attributes: { [key: string]: string }; // e.g. { Weight: "1kg" }
  mrp: number; // Maximum Retail Price (Rs.)
  price: number; // Selling Price (Rs.)
  cost: number; // COGS / Purchase Cost (Rs.)
  costPrice?: number;
  sellingPrice?: number;
  marginPercent: number;
  onHand: number;
  available: number;
  reserved: number;
  reorderLevel: number;
  image?: string;
  imageUrl?: string;
  version?: number;
  isParent?: boolean;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  brand: string;
  unit: string; // "kg", "g", "pc", "pack", "L", "bunch"
  baseSku: string;
  baseBarcode: string;
  basePrice: number; // Selling Price (Rs.)
  baseMrp: number; // MRP (Rs.)
  baseCost: number; // Cost (Rs.)
  price?: number;
  costPrice?: number;
  sellingPrice?: number;
  sku?: string;
  barcode?: string;
  searchKeywords?: string[];
  tamilName?: string;
  hindiName?: string;
  taxRate?: number;
  image: string;
  imageUrl?: string;
  imagePath?: string; // Stored path / filename for database synchronization
  taxable: boolean;
  gstRate: number; // 0%, 5%, 12%, 18% (e.g. fresh veggies 0%, packaged 5%)
  attributes: ProductAttribute[];
  variants: ProductVariant[];
  status: 'active' | 'draft' | 'archived' | 'inactive';
  updated_at?: string;
  dailyConsumptionRate: number; // ADC: Average Daily Consumption (kg or packs/day)
  leadTimeDays: number;
  supplierId: string;
  totalOnHand: number;
  totalAvailable: number;
  // Offer / Promotional Period Fields
  isOfferActive?: boolean;
  offerType?: 'percentage' | 'flat'; // 'percentage' e.g. 15 (15% off) or 'flat' e.g. 20 (₹20 off)
  offerValue?: number;
  offerTitle?: string; // e.g. "Offer of the Day", "Weekend Super Saver", "Daily Flash Deal"
  offerStartDate?: string; // YYYY-MM-DD
  offerEndDate?: string; // YYYY-MM-DD
}

export interface CartItemModifier {
  id: string;
  name: string;
  priceDelta: number;
}

export interface CartItem {
  id: string; // unique cart line id
  productId: string;
  variantId: string;
  productName: string;
  sku: string;
  barcode: string;
  unit: string;
  image?: string;
  mrp: number;
  unitPrice: number;
  quantity: number;
  discountAmount: number; // discount in Rs.
  discountPercent: number;
  modifiers: CartItemModifier[];
  appliedTaxRate: number; // GST rate e.g. 0.05
  packSize?: string;
  weight?: string;
  notes?: string;
  offerTitle?: string;
  originalPrice?: number;
}

export type CartLine = CartItem;

export type TenderType = 'cash' | 'upi' | 'card' | 'store_credit' | 'redeem';

export interface CashDenominationBreakdown {
  bills?: {
    d2000?: number;
    d500?: number;
    d200?: number;
    d100?: number;
    d50?: number;
    d20?: number;
    d10?: number;
    unknown?: number;
  };
  coins?: number;
  unknown?: number;
}

export interface PaymentSplit {
  id: string;
  tenderType: TenderType;
  method?: string;
  amount: number;
  reference?: string; // e.g. "GPay / Paytm Ref #74892", "HDFC Card *4829"
  timestamp: string;
  status: 'pending' | 'completed' | 'voided';
  denominations?: CashDenominationBreakdown;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  loyaltyPoints: number;
  isLoyaltyMember?: boolean;
  loyaltyJoinedDate?: string;
  loyaltyExpiryDate?: string;
  storeCredit: number;
  totalSpent: number;
  memberTier: 'Regular' | 'Silver' | 'Gold' | 'VIP';
  recentPurchasesCount: number;
}

export interface OutletProfile {
  outletName: string;
  branchName: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  email: string;
  gstin: string;
  panNumber: string;
  fssaiLicense: string;
  currencySymbol: string;
  receiptHeaderNote: string;
  receiptFooterNote: string;
  returnTerms: string;
  // Bill Numbering & Invoice Sequence Rules
  billPrefix?: string;
  billSuffix?: string;
  billStartNumber?: number;
  billIncrementStep?: number;
  billNextSequence?: number;
  billNumberPadding?: number;
  billResetFrequency?: 'never' | 'daily' | 'monthly' | 'yearly';
  billLastResetDate?: string;
  // Print on Bill Visibility Checkboxes
  printBranch?: boolean;
  printAddress?: boolean;
  printPhone?: boolean;
  printEmail?: boolean;
  printGstin?: boolean;
  printPan?: boolean;
  printFssai?: boolean;
  printHeaderNote?: boolean;
  printReturnTerms?: boolean;
}

export interface LoyaltyProgramConfig {
  enabled: boolean;
  spendAmountPerPoint: number; // e.g. 100 or 200 (₹100 or ₹200 = 1 point)
  pointsEarnedPerSpend: number; // 1 point
  pointRedemptionValue: number; // e.g. 1 or 2 (1 point = ₹1 or ₹2 discount)
  minPointsToRedeem: number; // e.g. 10 points
  expiryPeriodDays: number; // e.g. 90, 180, 365, or 0 for no expiry
  autoEnrollOnRegistration: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  terminalId: string;
  cashierId: string;
  cashierName: string;
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  items: CartItem[];
  subtotal: number;
  taxAmount: number;
  taxRate: number;
  discountTotal: number;
  loyaltyPointsEarned?: number;
  loyaltyPointsRedeemed?: number;
  loyaltyDiscountAmount?: number;
  total: number;
  payments: PaymentSplit[];
  amountPaid: number;
  changeDue: number;
  status: 'completed' | 'parked' | 'refunded' | 'voided';
  createdAt: string;
  synced: boolean;
  notes?: string;
}

export interface ShiftDenominations {
  bills: {
    d2000: number;
    d500: number;
    d200: number;
    d100: number;
    d50: number;
    d20: number;
    d10: number;
    unknown?: number; // Unknown or unclassified cash in Rs.
  };
  coins: number; // Total combined rupee value of loose coins in cash drawer
}

export interface ShiftRecord {
  id: string;
  shiftId: string;
  terminalId: string;
  operatorId: string;
  operatorName: string;
  openedAt: string;
  closedAt?: string;
  openingFloat: number;
  cashSales: number;
  upiSales: number;
  cardSales: number;
  cashRefunds: number;
  midShiftDrops: number;
  paidInOut: number;
  expectedBalance: number;
  actualCounted: number;
  variance: number;
  denominations: ShiftDenominations;
  notes: string;
  status: 'open' | 'closed';
  supervisorOverride?: boolean;
}

export interface InventoryLedgerEntry {
  id: string;
  sku: string;
  variantId: string;
  productName: string;
  delta: number; // + or - (qty / weight in kg)
  balanceAfter: number;
  mutationType: 'SALE' | 'RETURN' | 'GOODS_RECEIPT' | 'ADJUSTMENT' | 'DAMAGE_WASTAGE';
  referenceId: string; // Order ID or PO ID
  operator: string;
  timestamp: string;
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  contactEmail: string;
  phone: string;
  leadTimeDays: number;
  rating: number;
  paymentTerms: string;
  marketType: 'Mandi Trader' | 'FMCG Distributor' | 'Dairy Co-op' | 'Farmer Producer Group';
}

export interface PurchaseOrderItem {
  id?: string;
  sku: string;
  productName: string;
  variantId: string;
  quantityOrdered: number;
  quantityReceived: number;
  quantityPending?: number;
  unit: string;
  unitCost: number;
  totalCost: number;
  disposition?: 'ACCEPT' | 'HOLD' | 'REJECT';
  holdReason?: string;
  isNonPoItem?: boolean;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseOrderItem[];
  totalAmount: number;
  status: 'DRAFT' | 'ISSUED' | 'PARTIALLY_RECEIVED' | 'FULFILLED' | 'CANCELLED';
  createdAt: string;
  expectedDelivery: string;
  aiSuggested?: boolean;
  aiReason?: string;
  safetyStockTrigger?: number;
}

export interface ThreeWayMatchRecord {
  id: string;
  poId: string;
  poNumber: string;
  grnNumber: string; // Goods Received Note
  invoiceNumber: string;
  supplierName: string;
  poAmount: number;
  grnReceivedAmount: number;
  invoiceAmount: number;
  discrepancyAmount: number;
  status: 'MATCHED' | 'DISCREPANCY_ALERT' | 'RESOLVED';
  discrepancyNote?: string;
  timestamp: string;
  matchedAt?: string;
}

export interface SyncQueueItem {
  id: string;
  entityType: 'ORDER' | 'INVENTORY_MUTATION' | 'SHIFT' | 'CUSTOMER' | 'PRODUCT';
  entityId: string;
  payload: any;
  action: 'CREATE' | 'UPDATE' | 'DELETE';
  version: number;
  createdAt: string;
  syncedAt?: string;
  status: 'pending' | 'syncing' | 'synced' | 'conflict';
  syncDirection: 'LOCAL_TO_CLOUD';
  retryCount: number;
}

export type UserRole = 'Admin' | 'Supervisor' | 'Staff' | 'Customer Kiosk';

export interface Operator {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  userRole: UserRole;
  roleTitle: string;
  role: string;
  initials: string;
  pin: string;
  status: 'active' | 'inactive';
  createdAt?: string;
  lastLogin?: string;
}

export const DEFAULT_OPERATORS: Operator[] = [
  {
    id: 'emp_03',
    name: 'Ramesh Mandi',
    email: 'ramesh.mandi@freshmart.in',
    phone: '+91 98765 43210',
    userRole: 'Admin',
    roleTitle: 'Store Owner / General Manager',
    role: 'Admin (Full Access & User Mgmt)',
    initials: 'RM',
    pin: '0000',
    status: 'active',
    createdAt: '2026-01-01',
  },
  {
    id: 'emp_02',
    name: 'Pooja Verma',
    email: 'pooja.verma@freshmart.in',
    phone: '+91 98451 22334',
    userRole: 'Supervisor',
    roleTitle: 'Produce Floor Supervisor',
    role: 'Supervisor (Catalog & Inventory)',
    initials: 'PV',
    pin: '8888',
    status: 'active',
    createdAt: '2026-01-15',
  },
  {
    id: 'emp_01',
    name: 'Rahul Cashier',
    email: 'rahul.cashier@freshmart.in',
    phone: '+91 98112 33445',
    userRole: 'Staff',
    roleTitle: 'POS Billing Cashier',
    role: 'Staff (POS, PO, GRN & Reports)',
    initials: 'RC',
    pin: '1234',
    status: 'active',
    createdAt: '2026-02-01',
  },
  {
    id: 'kiosk_01',
    name: 'Customer Kiosk',
    email: 'kiosk@freshmart.in',
    phone: '+91 90000 00000',
    userRole: 'Customer Kiosk',
    roleTitle: 'Self-Service Customer Kiosk',
    role: 'Customer Kiosk (Self-Service Ordering & Express Checkout)',
    initials: 'CK',
    pin: '9999',
    status: 'active',
    createdAt: '2026-03-01',
  },
];
