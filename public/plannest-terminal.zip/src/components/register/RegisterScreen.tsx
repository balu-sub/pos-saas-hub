import React, { useState, useMemo, useRef, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { useLanguage } from '../../context/LanguageContext';
import { Product, ProductVariant, Customer } from '../../types/pos';
import { playBarcodeBeep, playKeypadClick, playSuccessChime } from '../../utils/audio';
import { NumpadSkuModal } from './NumpadSkuModal';
import { getProductImageUrl, handleProductImageError } from '../../utils/productImages';
import { getActiveOfferProducts, getProductOfferInfo, isOfferActive } from '../../utils/offers';
import { sanitizeQuantityInput, isDiscreteUnit, sanitizeCurrencyInput } from '../../utils/unitQuantity';
import { filterAndSortProducts } from '../../utils/productSearch';
import { generateCustomerDirectoryPDF } from '../../utils/pdfExport';
import { triggerHaptic } from '../../utils/tabletUtils';

interface RegisterScreenProps {
  onOpenDuplicateReceipt?: () => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({ onOpenDuplicateReceipt }) => {
  const {
    products,
    categories,
    cart,
    addToCart,
    updateQuantity,
    setQuantityDirect,
    removeFromCart,
    clearCart,
    subtotal,
    taxAmount,
    taxRate,
    totalDue,
    itemCount,
    selectedCustomer,
    setSelectedCustomer,
    customers,
    setIsCheckoutOpen,
    parkedOrders,
    parkCurrentOrder,
    retrieveParkedOrder,
    deleteParkedOrder,
    scanBarcode,
    lastScannedCode,
    refreshProducts,
    isLoadingProducts,
    updateProductOffer,
    updateCustomerCredit,
    saveNewCustomer,
    loyaltyConfig,
    loyaltyRedeemedPoints,
    loyaltyDiscountAmount,
    outletProfile,
    lastCompletedOrder,
    setIsReceiptOpen,
    currentOperator,
  } = usePOS();
  const { getItemName, getCategoryName, getOfferTitle, isTamil, isHindi, isSecondaryLanguage } = useLanguage();

  const isKiosk = currentOperator?.userRole === 'Customer Kiosk';

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
  const [customerFilter, setCustomerFilter] = useState('');
  const [isParkedModalOpen, setIsParkedModalOpen] = useState(false);
  const [isNumpadOpen, setIsNumpadOpen] = useState(false);
  const [selectedVariantModal, setSelectedVariantModal] = useState<Product | null>(null);
  const [quickWeightModal, setQuickWeightModal] = useState<{ product: Product; variant?: ProductVariant } | null>(null);
  const [customWeightInput, setCustomWeightInput] = useState('1.00');

  // Deletion Confirmation States
  const [deletingParkedOrder, setDeletingParkedOrder] = useState<any | null>(null);
  const [isConfirmClearCartOpen, setIsConfirmClearCartOpen] = useState(false);

  // Cart direct quantity string buffer for typing
  const [editingQty, setEditingQty] = useState<{ [lineId: string]: string }>({});

  // Khata Credit Quick Adjust Modal
  const [isKhataModalOpen, setIsKhataModalOpen] = useState(false);
  const [khataCustomer, setKhataCustomer] = useState<Customer | null>(null);
  const [khataAmountInput, setKhataAmountInput] = useState('');
  const [khataAdjustmentMode, setKhataAdjustmentMode] = useState<'add' | 'set'>('add');

  // New Customer Quick Modal
  const [isNewCustomerModalOpen, setIsNewCustomerModalOpen] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustCredit, setNewCustCredit] = useState('0');
  const [newCustIsLoyalty, setNewCustIsLoyalty] = useState(true);

  // Handle direct cart quantity typing according to unit constraints
  const handleCartQtyChange = (lineId: string, rawVal: string, unit?: string) => {
    const sanitized = sanitizeQuantityInput(rawVal, unit);
    setEditingQty((prev) => ({ ...prev, [lineId]: sanitized }));

    if (sanitized !== '' && !isNaN(Number(sanitized))) {
      const num = parseFloat(sanitized);
      if (num > 0) {
        setQuantityDirect(lineId, num);
      }
    }
  };

  const handleCartQtyBlur = (lineId: string, fallbackQty: number, unit?: string) => {
    const rawVal = editingQty[lineId];
    if (rawVal === undefined) return;

    if (rawVal === '' || isNaN(Number(rawVal)) || parseFloat(rawVal) <= 0) {
      setQuantityDirect(lineId, fallbackQty > 0 ? fallbackQty : 1);
    } else {
      setQuantityDirect(lineId, parseFloat(rawVal));
    }
    setEditingQty((prev) => {
      const next = { ...prev };
      delete next[lineId];
      return next;
    });
  };

  const handleSaveKhataCredit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!khataCustomer) return;
    const val = parseFloat(khataAmountInput) || 0;
    const finalCredit =
      khataAdjustmentMode === 'add'
        ? Number((khataCustomer.storeCredit + val).toFixed(2))
        : Number(val.toFixed(2));

    await updateCustomerCredit(khataCustomer.id, finalCredit);
    playSuccessChime();
    setIsKhataModalOpen(false);
    setKhataCustomer(null);
    setKhataAmountInput('');
  };

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;
    const initCredit = parseFloat(newCustCredit) || 0;
    
    let expiryDate: string | undefined = undefined;
    if (loyaltyConfig.enabled && loyaltyConfig.expiryPeriodDays > 0) {
      const exp = new Date();
      exp.setDate(exp.getDate() + loyaltyConfig.expiryPeriodDays);
      expiryDate = exp.toISOString().split('T')[0];
    }

    const created = await saveNewCustomer({
      name: newCustName.trim(),
      phone: newCustPhone.trim(),
      storeCredit: initCredit,
      loyaltyPoints: 0,
      isLoyaltyMember: newCustIsLoyalty,
      loyaltyExpiryDate: expiryDate,
      memberTier: 'Regular',
    });
    setSelectedCustomer(created);
    setIsNewCustomerModalOpen(false);
    setNewCustName('');
    setNewCustPhone('');
    setNewCustCredit('0');
    setNewCustIsLoyalty(loyaltyConfig.autoEnrollOnRegistration ?? true);
    setIsCustomerDropdownOpen(false);
  };

  // Active Offer Products
  const offerProducts = useMemo(() => {
    return getActiveOfferProducts(products);
  }, [products]);

  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // Global F2 keyboard shortcut to open Numpad SKU Entry
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        setIsNumpadOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, []);

  // Filter products by category and search with prefix priority and alphabetical sorting
  const filteredProducts = useMemo(() => {
    return filterAndSortProducts(
      products,
      searchQuery,
      selectedCategory,
      selectedCategory === '__OFFERS__',
      isOfferActive
    );
  }, [products, selectedCategory, searchQuery]);

  // Handle clicking a product card
  const handleProductClick = (prod: Product) => {
    if (prod.variants.length > 1) {
      setSelectedVariantModal(prod);
    } else {
      addToCart(prod, prod.variants[0], 1);
    }
  };

  const handleApplyCustomWeight = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickWeightModal) {
      const qty = parseFloat(customWeightInput) || 1;
      addToCart(quickWeightModal.product, quickWeightModal.variant, qty);
      setQuickWeightModal(null);
    }
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden select-none bg-[#F4F4F5]">
      {/* LEFT / CENTER: Product Grid & Barcode Terminal Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden border-r border-[#D4D4D8]">
        {/* Fast Scanner Bar & Barcode Quick Simulators */}
        <div className="p-3 bg-white border-b border-[#D4D4D8] flex flex-col gap-2.5">
          {/* Row 1: Fast Scanner & Search Bar + Numpad SKU Button */}
          <div className="flex items-center gap-2.5 w-full">
            <div className="relative flex-1 min-w-[240px]">
              <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#00478c] text-[22px] pointer-events-none">
                search
              </span>
              <input
                ref={barcodeInputRef}
                type="text"
                data-keyboard="qwerty"
                data-title="Search Catalog, SKU, or Barcode"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && searchQuery.trim()) {
                    const scanned = scanBarcode(searchQuery.trim());
                    if (scanned) setSearchQuery('');
                  }
                }}
                placeholder="Search Item Name, SKU, Barcode, or Tamil / Tanglish..."
                className="w-full bg-[#f8f9fa] border-2 border-[#00478c]/30 rounded-lg pl-11 pr-10 py-2.5 text-base font-semibold text-[#09090B] placeholder:text-gray-400 placeholder:font-normal focus:bg-white focus:border-[#00478c] focus:ring-2 focus:ring-[#00478c]/20 focus:outline-none shadow-xs transition-all h-[46px]"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100 cursor-pointer transition-colors"
                  title="Clear Search"
                >
                  <span className="material-symbols-outlined text-[20px]">cancel</span>
                </button>
              )}
            </div>

            {/* Search Past Invoices & Print Duplicate Receipt [F7] (Hidden in Kiosk mode) */}
            {!isKiosk && onOpenDuplicateReceipt && (
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  onOpenDuplicateReceipt();
                }}
                className="px-3 py-2.5 bg-white hover:bg-blue-50 text-[#00478c] border border-blue-200 hover:border-[#00478c] rounded-lg font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer shrink-0 active:scale-95 h-[46px]"
                title="Search Past Customer Bills & Print Duplicate Receipt [F7]"
              >
                <span className="material-symbols-outlined text-blue-700 text-[19px]">receipt_long</span>
                <span className="whitespace-nowrap hidden lg:inline">Duplicate Bill [F7]</span>
              </button>
            )}

            {/* Numpad SKU Entry Trigger Button */}
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setIsNumpadOpen(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-[#00478c] to-[#005eb7] hover:from-[#00366c] hover:to-[#00478c] text-white rounded-lg font-bold text-xs flex items-center gap-2 shadow-sm transition-all cursor-pointer shrink-0 active:scale-95 h-[46px]"
              title="Open Numeric Keypad for fast SKU entry & selection (Shortcut: F2)"
            >
              <span className="material-symbols-outlined text-amber-300 text-[20px]">dialpad</span>
              <span className="whitespace-nowrap">Numpad SKU [F2]</span>
            </button>
          </div>

          {/* Row 2: Offers of the Day & Limited Period Deals Bar (Scrollable row) */}
          {offerProducts.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] py-1 bg-amber-50/60 px-2 rounded-lg border border-amber-200/80 scrollbar-thin">
              <div className="flex items-center gap-1 shrink-0 px-2 py-1 bg-gradient-to-r from-amber-500 to-rose-500 text-white rounded font-bold text-[10px] tracking-wide uppercase shadow-2xs">
                <span className="material-symbols-outlined text-[14px] animate-pulse">local_fire_department</span>
                <span>
                  {isTamil
                    ? `ஆஃபர்கள் (${offerProducts.length}):`
                    : isHindi
                    ? `ऑफर (${offerProducts.length}):`
                    : `Offers (${offerProducts.length}):`}
                </span>
              </div>

              {offerProducts.slice(0, 10).map((p) => {
                const variant = p.variants[0];
                const offerInfo = getProductOfferInfo(p, variant);
                const basePrice = variant?.price ?? p.basePrice ?? 0;

                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      addToCart(p, variant?.id);
                    }}
                    className="px-2.5 py-1 bg-white hover:bg-rose-50 text-rose-900 border border-rose-300 rounded-md font-medium shrink-0 transition-all cursor-pointer active:scale-95 flex items-center gap-1.5 shadow-2xs group"
                    title={`Quick Add ${p.name} - ${offerInfo.offerTitle} (${offerInfo.badgeLabel})`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping shrink-0" />
                    <span className="font-bold text-gray-900 group-hover:text-[#00478c] truncate max-w-[120px]">
                      +{getItemName(p)}
                    </span>
                    <span className="px-1 py-0.2 bg-rose-600 text-white font-black text-[9px] rounded shrink-0">
                      {offerInfo.badgeLabel}
                    </span>
                    <span className="font-bold text-emerald-700 shrink-0">
                      Rs.{offerInfo.discountedPrice.toFixed(0)}
                    </span>
                    <span className="text-[10px] text-gray-400 line-through shrink-0">
                      Rs.{basePrice.toFixed(0)}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Row 3: Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {/* Category Filter Pills */}
            <button
              onClick={() => {
                playKeypadClick();
                setSelectedCategory('All');
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === 'All'
                  ? 'bg-[#00478c] text-white shadow-xs'
                  : 'bg-[#F4F4F5] text-[#5c403c] hover:bg-[#E4E4E7]'
              }`}
            >
              {getCategoryName('All Items')} ({products.length})
            </button>

            {categories.filter((c) => c !== 'All Items' && c !== 'All' && c !== '__OFFERS__').map((cat) => {
              const count = products.filter((p) => p.category.toLowerCase() === cat.toLowerCase()).length;
              return (
                <button
                  key={cat}
                  onClick={() => {
                    playKeypadClick();
                    setSelectedCategory(cat);
                  }}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory.toLowerCase() === cat.toLowerCase()
                      ? 'bg-[#00478c] text-white shadow-xs'
                      : 'bg-[#F4F4F5] text-[#5c403c] hover:bg-[#E4E4E7]'
                  }`}
                >
                  {getCategoryName(cat)} {count > 0 && <span className="text-[10px] opacity-80">({count})</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {filteredProducts.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-[#5c403c]">
              <span className="material-symbols-outlined text-4xl mb-2">
                {selectedCategory === '__OFFERS__' ? 'local_offer' : 'search_off'}
              </span>
              <p className="text-sm font-medium">
                {selectedCategory === '__OFFERS__'
                  ? 'No promotional offers active at this time'
                  : 'No grocery or vegetable items found'}
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setSearchQuery('');
                }}
                className="mt-3 text-xs text-[#00478c] font-bold hover:underline"
              >
                Clear Search &amp; Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
              {filteredProducts.map((prod) => {
                const primaryVariant = prod.variants[0];
                const baseSellingPrice = primaryVariant?.price || prod.basePrice || 0;
                const mrp = primaryVariant?.mrp || prod.baseMrp || baseSellingPrice;
                const stock = prod.totalOnHand;
                const isLowStock = stock <= (primaryVariant?.reorderLevel || 10);
                const offerInfo = getProductOfferInfo(prod, primaryVariant);
                const effectivePrice = offerInfo.hasOffer ? offerInfo.discountedPrice : baseSellingPrice;
                const hasDiscount = mrp > effectivePrice || offerInfo.hasOffer;

                return (
                  <div
                    key={prod.id}
                    onClick={() => handleProductClick(prod)}
                    className={`bg-white rounded-lg border transition-all cursor-pointer flex flex-col overflow-hidden group relative active:scale-[0.98] ${
                      offerInfo.hasOffer
                        ? 'border-rose-300 ring-1 ring-rose-200 hover:border-rose-500 hover:shadow-lg'
                        : 'border-[#D4D4D8] hover:border-[#00478c] hover:shadow-md'
                    }`}
                  >
                    {/* Image / Thumbnail */}
                    <div className="relative h-28 w-full bg-[#f8f9fa] overflow-hidden flex items-center justify-center">
                      {getProductImageUrl(prod, primaryVariant) ? (
                        <img
                          src={getProductImageUrl(prod, primaryVariant)}
                          alt={prod.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                          onError={(e) => handleProductImageError(e, prod)}
                        />
                      ) : null}

                      <div
                        className={`img-fallback ${
                          getProductImageUrl(prod, primaryVariant) ? 'hidden' : ''
                        } flex flex-col items-center justify-center w-full h-full bg-gradient-to-br from-blue-50 via-emerald-50 to-slate-100 text-[#00478c] p-2 select-none`}
                      >
                        <span className="material-symbols-outlined text-[28px] opacity-70 text-[#00478c]">
                          {prod.category.toLowerCase().includes('fruit')
                            ? 'nutrition'
                            : prod.category.toLowerCase().includes('veg')
                            ? 'spa'
                            : prod.category.toLowerCase().includes('bev')
                            ? 'local_cafe'
                            : prod.category.toLowerCase().includes('dairy')
                            ? 'bakery_dining'
                            : prod.category.toLowerCase().includes('snack')
                            ? 'cookie'
                            : 'shopping_bag'}
                        </span>
                        <span className="text-[10px] font-bold text-[#334155] mt-1 max-w-[95%] truncate text-center">
                          {prod.name}
                        </span>
                      </div>

                      {/* Low Stock Badge */}
                      {isLowStock && (
                        <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 bg-amber-500 text-white font-bold text-[9px] rounded uppercase tracking-wider shadow-xs">
                          Low: {stock} {prod.unit}
                        </div>
                      )}

                      {/* Multi-variant indicator */}
                      {prod.variants.length > 1 && (
                        <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 bg-[#00478c] text-white font-bold text-[9px] rounded shadow-xs">
                          {prod.variants.length} Sizes
                        </div>
                      )}

                      {/* Promotional Offer Glow Badge (Top/Bottom) */}
                      {offerInfo.hasOffer ? (
                        <div className="absolute bottom-1 left-1.5 px-2 py-0.5 bg-gradient-to-r from-rose-600 to-amber-600 text-white font-black text-[10px] rounded shadow-sm flex items-center gap-1 animate-pulse">
                          <span className="material-symbols-outlined text-[12px]">local_fire_department</span>
                          <span>{offerInfo.badgeLabel}</span>
                        </div>
                      ) : (
                        hasDiscount && (
                          <div className="absolute bottom-1 left-1.5 px-1.5 py-0.2 bg-emerald-600 text-white font-black text-[9px] rounded">
                            {Math.round(((mrp - effectivePrice) / mrp) * 100)}% OFF
                          </div>
                        )
                      )}
                    </div>

                    {/* Product Details */}
                    <div className="p-2.5 flex-1 flex flex-col justify-between">
                      <div>
                        {/* Category & SKU Pill */}
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-[10px] text-gray-500 uppercase font-bold tracking-wider truncate">
                            {getCategoryName(prod.category)}
                          </span>
                          <span
                            className="text-[10px] font-mono font-bold text-[#00478c] bg-blue-50 border border-blue-200/80 px-1.5 py-0.5 rounded shrink-0 shadow-2xs"
                            title={`SKU: ${primaryVariant?.sku || prod.baseSku}`}
                          >
                            {((primaryVariant?.sku || prod.baseSku || prod.id).match(/\d+/)?.[0] || '0000').slice(-4).padStart(4, '0')}
                          </span>
                        </div>

                        {/* Primary Product Name */}
                        <h4 className="font-bold text-[12px] sm:text-[12.5px] text-[#09090B] leading-tight group-hover:text-[#00478c] break-words line-clamp-2">
                          {getItemName(prod)}
                        </h4>

                        {/* Secondary English Reference Subtitle (when Tamil/Hindi selected) */}
                        {isSecondaryLanguage && (
                          <div
                            className="text-[10px] sm:text-[10.5px] text-gray-500 font-medium leading-tight mt-0.5 break-words line-clamp-2"
                            title={prod.name}
                          >
                            {prod.name}
                          </div>
                        )}

                        {/* Offer Tagline / Title */}
                        {offerInfo.hasOffer && (
                          <div className="mt-1 flex items-start gap-1 text-[9.5px] sm:text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200 w-full">
                            <span className="material-symbols-outlined text-[12px] text-rose-600 shrink-0 mt-0.5">bolt</span>
                            <span className="leading-tight break-words">{getOfferTitle(offerInfo.offerTitle)}</span>
                          </div>
                        )}
                      </div>

                      <div className="mt-2 pt-1.5 border-t border-gray-100">
                        {/* Struck-through Price (MRP or Regular Price) */}
                        {offerInfo.hasOffer ? (
                          <div className="flex items-center flex-wrap gap-x-1.5 gap-y-0.5 text-[10px] text-gray-400 font-tabular-numeric leading-tight">
                            <span className="line-through">Reg: ₹{baseSellingPrice.toFixed(0)}</span>
                            {mrp > baseSellingPrice && (
                              <span className="line-through text-gray-300">MRP ₹{mrp.toFixed(0)}</span>
                            )}
                          </div>
                        ) : hasDiscount ? (
                          <div className="text-[10px] text-gray-400 line-through font-tabular-numeric leading-tight">
                            MRP ₹{mrp.toFixed(0)}
                          </div>
                        ) : (
                          <div className="text-[10px] text-transparent leading-tight select-none pointer-events-none">
                            &nbsp;
                          </div>
                        )}

                        {/* Selling Price & Unit in single clean line */}
                        <div className="flex items-baseline justify-between gap-1 mt-0.5">
                          <span
                            className={`text-sm sm:text-base font-extrabold font-tabular-numeric whitespace-nowrap ${
                              offerInfo.hasOffer ? 'text-rose-700' : 'text-[#00478c]'
                            }`}
                          >
                            Rs. {effectivePrice.toFixed(2)}
                          </span>
                          <span className="text-[11px] text-gray-600 font-bold whitespace-nowrap shrink-0">
                            / {primaryVariant?.attributes?.['Weight Pack'] || primaryVariant?.attributes?.['Pack Size'] || prod.unit}
                          </span>
                        </div>

                        {/* Tablet Quick Produce Weighing Chips for kg produce */}
                        {prod.unit?.toLowerCase() === 'kg' && prod.variants.length <= 1 && (
                          <div className="mt-1.5 pt-1 border-t border-gray-100 flex items-center justify-between gap-1">
                            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-tight">
                              Quick:
                            </span>
                            <div className="flex items-center gap-1">
                              {[
                                { label: '¼kg', qty: 0.25 },
                                { label: '½kg', qty: 0.5 },
                                { label: '1kg', qty: 1 },
                                { label: '2kg', qty: 2 },
                              ].map((chip) => (
                                <button
                                  key={chip.label}
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    triggerHaptic('light');
                                    addToCart(prod, primaryVariant, chip.qty);
                                  }}
                                  className="px-1.5 py-0.5 rounded bg-blue-50 hover:bg-blue-100 active:bg-[#00478c] active:text-white border border-blue-200 text-[#00478c] text-[10px] font-bold transition-all cursor-pointer select-none"
                                  title={`Tap to add ${chip.label} directly to cart`}
                                >
                                  {chip.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* RIGHT: Current Cart / Active Billing Slip Area */}
      <div className="w-full md:w-[380px] lg:w-[420px] bg-white flex flex-col h-full shadow-lg border-l border-[#D4D4D8]">
        {/* Cart Header: Customer Selector & Held Orders (Cashier) OR Kiosk Basket Header (Kiosk) */}
        {isKiosk ? (
          <div className="p-3 bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-[#D4D4D8] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00478c] text-[22px]">
                shopping_cart
              </span>
              <div>
                <div className="text-xs font-black text-[#00478c] uppercase tracking-wider">
                  Self-Service Cart
                </div>
                <div className="text-[10px] text-gray-500 font-medium">
                  Add items • Proceed to Express Pay
                </div>
              </div>
            </div>
            <span className="px-2.5 py-1 bg-white border border-blue-200 rounded-full text-xs font-extrabold text-[#00478c]">
              {itemCount} {itemCount === 1 ? 'item' : 'items'}
            </span>
          </div>
        ) : (
          <div className="p-3 bg-[#F4F4F5] border-b border-[#D4D4D8] flex items-center justify-between gap-2">
            {/* Customer Selection Dropdown */}
            <div className="relative flex-1">
              <button
                onClick={() => setIsCustomerDropdownOpen(!isCustomerDropdownOpen)}
                className="w-full flex items-center justify-between px-3 py-1.5 bg-white border border-[#D4D4D8] rounded text-left hover:border-[#00478c] transition-colors cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-2 truncate min-w-0">
                  <span className="material-symbols-outlined text-[#00478c] text-[18px] shrink-0">
                    person
                  </span>
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-xs font-bold text-[#09090B] truncate">
                      {selectedCustomer ? selectedCustomer.name : 'Walk-in Retail Customer'}
                    </span>
                    {selectedCustomer && (
                      <div className="flex items-center gap-1 shrink-0">
                        <span
                          className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded shrink-0 ${
                            selectedCustomer.storeCredit > 0
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : selectedCustomer.storeCredit < 0
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : 'bg-gray-100 text-gray-700 border border-gray-300'
                          }`}
                          title={`Khata Balance: ${outletProfile?.currencySymbol || 'Rs.'} ${selectedCustomer.storeCredit.toFixed(2)}`}
                        >
                          Khata: {outletProfile?.currencySymbol || 'Rs.'} {selectedCustomer.storeCredit.toFixed(2)}
                        </span>

                        {(selectedCustomer.isLoyaltyMember ?? true) && loyaltyConfig.enabled && (
                          <span
                            className="text-[10px] font-extrabold px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 border border-amber-300 shrink-0 flex items-center gap-0.5"
                            title={`Loyalty Points: ${selectedCustomer.loyaltyPoints || 0} pts (Tier: ${selectedCustomer.memberTier || 'Member'})`}
                          >
                            ⭐ {selectedCustomer.loyaltyPoints || 0} pts
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                <span className="material-symbols-outlined text-gray-500 text-[18px] shrink-0">
                  arrow_drop_down
                </span>
              </button>

              {isCustomerDropdownOpen && (
                <div className="absolute left-0 top-full mt-1 w-80 sm:w-96 bg-white border border-[#D4D4D8] rounded-lg shadow-xl py-1 z-50 industrial-shadow animate-in fade-in flex flex-col max-h-96">
                  {/* Search & Actions Bar */}
                  <div className="p-2 border-b border-gray-100 flex items-center gap-2">
                    <div className="relative flex-1">
                      <span className="material-symbols-outlined absolute left-2 top-1.5 text-gray-400 text-[16px]">
                        search
                      </span>
                      <input
                        type="text"
                        value={customerFilter}
                        onChange={(e) => setCustomerFilter(e.target.value)}
                        placeholder="Search customer name or phone..."
                        className="w-full bg-[#f8f9fa] border border-gray-200 rounded pl-7 pr-2 py-1 text-xs text-[#09090B] focus:bg-white focus:border-[#00478c] focus:outline-none"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        generateCustomerDirectoryPDF(customers, outletProfile);
                      }}
                      className="p-1.5 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded text-xs font-bold flex items-center justify-center shrink-0 cursor-pointer shadow-2xs transition-colors"
                      title="Export Customers Directory & Purchase Records (PDF)"
                    >
                      <span className="material-symbols-outlined text-[16px]">upload</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsCustomerDropdownOpen(false);
                        setIsNewCustomerModalOpen(true);
                      }}
                      className="px-2 py-1 bg-[#00478c] text-white hover:bg-[#00366c] text-[11px] font-bold rounded flex items-center gap-0.5 shrink-0 cursor-pointer shadow-2xs transition-colors"
                      title="Add New Customer"
                    >
                      <span className="material-symbols-outlined text-[13px]">add</span>
                      <span>+ New</span>
                    </button>
                  </div>

                  <div className="overflow-y-auto flex-1 divide-y divide-gray-100">
                    <div
                      onClick={() => {
                        setSelectedCustomer(null);
                        setIsCustomerDropdownOpen(false);
                      }}
                      className="px-3 py-2 text-xs hover:bg-[#F4F4F5] cursor-pointer font-semibold text-[#5c403c] flex items-center justify-between"
                    >
                      <span>Walk-in Retail Customer (Default)</span>
                      <span className="text-[10px] text-gray-400">Cash / UPI</span>
                    </div>

                    {customers
                      .filter(
                        (c) =>
                          customerFilter === '' ||
                          c.name.toLowerCase().includes(customerFilter.toLowerCase()) ||
                          c.phone.includes(customerFilter)
                      )
                      .map((c) => (
                        <div
                          key={c.id}
                          className="px-3 py-2 hover:bg-blue-50/70 flex items-center justify-between text-xs transition-colors"
                        >
                          <div
                            onClick={() => {
                              setSelectedCustomer(c);
                              setIsCustomerDropdownOpen(false);
                            }}
                            className="flex-1 cursor-pointer min-w-0 pr-2"
                          >
                            <div className="font-bold text-[#09090B] truncate flex items-center justify-between gap-1.5">
                              <span className="truncate">{c.name}</span>
                              {(c.isLoyaltyMember ?? true) && loyaltyConfig.enabled && (
                                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 border border-amber-300 shrink-0">
                                  ⭐ {c.loyaltyPoints || 0} pts
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-gray-500 flex items-center gap-1.5 mt-0.5">
                              <span className="text-gray-600 font-medium">{c.phone}</span>
                              <span>•</span>
                              <span>{c.memberTier || 'Member'}</span>
                              <span>•</span>
                              <span
                                className={`font-bold ${
                                  c.storeCredit > 0
                                    ? 'text-emerald-700'
                                    : c.storeCredit < 0
                                    ? 'text-rose-700'
                                    : 'text-gray-600'
                                }`}
                              >
                                Khata: {outletProfile?.currencySymbol || 'Rs.'} {c.storeCredit.toFixed(2)}
                              </span>
                            </div>
                          </div>

                          {/* Direct Khata Top-up / Settle Trigger */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setKhataCustomer(c);
                              setKhataAmountInput('');
                              setKhataAdjustmentMode('add');
                              setIsKhataModalOpen(true);
                            }}
                            className="p-1 text-[#00478c] hover:bg-blue-100 rounded text-[11px] font-bold flex items-center gap-0.5 shrink-0 cursor-pointer"
                            title="Add / Settle Khata Credit"
                          >
                            <span className="material-symbols-outlined text-[15px]">account_balance_wallet</span>
                            <span>Khata</span>
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>

            {/* Held / Parked Orders Button */}
            <button
              onClick={() => setIsParkedModalOpen(true)}
              className={`px-2.5 py-1.5 rounded border text-xs font-bold flex items-center gap-1 transition-colors shrink-0 ${
                parkedOrders.length > 0
                  ? 'bg-amber-500 text-white border-amber-600 shadow-xs animate-pulse'
                  : 'bg-white border-[#D4D4D8] text-[#5c403c] hover:bg-[#E4E4E7]'
              }`}
              title="View Parked / Held Baskets"
            >
              <span className="material-symbols-outlined text-[16px]">pause_circle</span>
              <span>{parkedOrders.length} Held</span>
            </button>
          </div>
        )}

        {/* Cart Item Line List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#5c403c]">
              <div className="w-12 h-12 rounded-full bg-[#F4F4F5] flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-2xl text-gray-400">
                  shopping_cart
                </span>
              </div>
              <p className="text-sm font-bold text-[#09090B]">Basket is Empty</p>
              <p className="text-xs text-gray-500 mt-1 max-w-[200px]">
                Scan barcode, type SKU, or tap items from the grocery catalog to add
              </p>
            </div>
          ) : (
            cart.map((line) => {
              const lineTotal = line.unitPrice * line.quantity;
              const hasDiscount = line.discountPercent > 0 || line.discountAmount > 0 || (line.originalPrice && line.originalPrice > line.unitPrice);
              const originalTotal = (line.originalPrice || line.unitPrice) * line.quantity;
              const discountedTotal = Math.max(0, lineTotal * (1 - (line.discountPercent || 0) / 100) - (line.discountAmount || 0));
              const savings = originalTotal - discountedTotal;
              const isDiscrete = isDiscreteUnit(line.unit);

              return (
                <div
                  key={line.id}
                  className="p-2.5 bg-[#F4F4F5] border border-[#D4D4D8] rounded-lg flex flex-col gap-2 hover:border-[#00478c] transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-xs text-[#09090B] truncate flex items-center gap-1.5">
                        <span>{getItemName(line.productName)}</span>
                        {isTamil && line.productName !== getItemName(line.productName) && (
                          <span className="text-[10px] text-gray-400 font-normal truncate">
                            ({line.productName})
                          </span>
                        )}
                        {line.offerTitle && (
                          <span className="px-1.5 py-0.2 bg-rose-100 text-rose-800 border border-rose-200 font-bold text-[9px] rounded uppercase">
                            🔥 {line.offerTitle}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-[#5c403c] font-tabular-numeric flex items-center gap-1.5 flex-wrap">
                        <span>{line.packSize ? `Pack: ${line.packSize}` : ''} • Rs. {line.unitPrice.toFixed(2)} / {line.unit || 'unit'}</span>
                        {line.originalPrice && line.originalPrice > line.unitPrice && (
                          <span className="text-gray-400 line-through text-[10px]">
                            Reg: Rs.{line.originalPrice.toFixed(2)}
                          </span>
                        )}
                        {savings > 0 && (
                          <span className="text-emerald-700 font-bold text-[10px] bg-emerald-50 px-1 rounded">
                            Saved Rs.{savings.toFixed(0)}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => removeFromCart(line.id)}
                      className="text-gray-400 hover:text-[#ba1a1a] p-0.5 rounded cursor-pointer"
                      title="Remove item"
                    >
                      <span className="material-symbols-outlined text-[16px]">close</span>
                    </button>
                  </div>

                  {/* Quantity Direct Typing Input & Price Total */}
                  <div className="flex items-center justify-between pt-1 border-t border-[#e2e2e5]">
                    {/* Tablet Touch-Friendly Quantity Stepper with Direct Input */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          triggerHaptic('light');
                          const step = isDiscrete ? 1 : 0.25;
                          if (line.quantity > step) {
                            updateQuantity(line.id, -step);
                          } else {
                            removeFromCart(line.id);
                          }
                        }}
                        className="w-7 h-7 flex items-center justify-center rounded bg-gray-100 hover:bg-gray-200 active:bg-gray-300 text-gray-700 font-extrabold text-sm select-none cursor-pointer border border-gray-300 shadow-2xs"
                        title="Decrease quantity"
                      >
                        -
                      </button>

                      <div className="relative flex items-center">
                        <input
                          type="text"
                          inputMode={isDiscrete ? "numeric" : "decimal"}
                          data-keyboard="numpad"
                          data-title={`Qty for ${line.productName}`}
                          data-unit={line.unit || 'unit'}
                          data-discrete={isDiscrete ? "true" : "false"}
                          value={editingQty[line.id] !== undefined ? editingQty[line.id] : String(line.quantity)}
                          onChange={(e) => handleCartQtyChange(line.id, e.target.value, line.unit)}
                          onBlur={() => handleCartQtyBlur(line.id, line.quantity, line.unit)}
                          onFocus={(e) => e.target.select()}
                          placeholder="1"
                          className="w-14 h-7 px-1 text-center font-bold text-xs text-[#09090B] bg-white border border-[#D4D4D8] rounded focus:border-[#00478c] focus:ring-1 focus:ring-[#00478c] focus:outline-none font-tabular-numeric transition-colors"
                          title={isDiscrete ? "Whole numbers only for this unit" : "Up to 3 decimal places allowed (e.g. 1.250 kg)"}
                        />
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          triggerHaptic('light');
                          const step = isDiscrete ? 1 : 0.25;
                          updateQuantity(line.id, step);
                        }}
                        className="w-7 h-7 flex items-center justify-center rounded bg-gray-100 hover:bg-gray-200 active:bg-gray-300 text-gray-700 font-extrabold text-sm select-none cursor-pointer border border-gray-300 shadow-2xs"
                        title="Increase quantity"
                      >
                        +
                      </button>

                      <span className="text-[10px] font-bold text-gray-600 uppercase ml-0.5">
                        {line.unit || 'unit'}
                      </span>
                    </div>

                    {/* Total Amount in Rs. */}
                    <div className="text-right">
                      {hasDiscount && originalTotal > discountedTotal && (
                        <div className="text-[10px] text-gray-400 line-through font-tabular-numeric">
                          Rs. {originalTotal.toFixed(2)}
                        </div>
                      )}
                      <div className="text-sm font-bold text-[#09090B] font-tabular-numeric">
                        Rs. {discountedTotal.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Cart Bottom Summary & Checkout Trigger */}
        <div className="p-4 bg-[#F4F4F5] border-t border-[#D4D4D8] space-y-3">
          {/* Summary Breakdown */}
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between text-[#5c403c]">
              <span>Items Total ({itemCount} units)</span>
              <span className="font-bold text-[#09090B] font-tabular-numeric">
                Rs. {subtotal.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-[#5c403c]">
              <span>GST / Taxes ({(taxRate * 100).toFixed(0)}%)</span>
              <span className="font-bold text-[#09090B] font-tabular-numeric">
                Rs. {taxAmount.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-base font-extrabold text-[#09090B] pt-2 border-t border-[#D4D4D8]">
              <span>TOTAL PAYABLE</span>
              <span className="text-[#00478c] font-tabular-numeric text-lg">
                Rs. {totalDue.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Action Row */}
          {isKiosk ? (
            <button
              onClick={() => {
                if (cart.length > 0) {
                  setIsConfirmClearCartOpen(true);
                }
              }}
              disabled={cart.length === 0}
              className="w-full py-2.5 px-3 bg-white border border-[#D4D4D8] hover:bg-[#ffdad6] hover:text-[#ba1a1a] text-[#5c403c] rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer shadow-2xs"
            >
              <span className="material-symbols-outlined text-[16px]">delete_sweep</span>
              Reset / Clear Cart
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => parkCurrentOrder()}
                disabled={cart.length === 0}
                className="py-2 px-3 bg-white border border-[#D4D4D8] hover:bg-[#E4E4E7] text-[#09090B] rounded font-bold text-xs flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <span className="material-symbols-outlined text-[16px]">pause</span>
                Hold / Park
              </button>
              <button
                onClick={() => {
                  if (cart.length > 0) {
                    setIsConfirmClearCartOpen(true);
                  }
                }}
                disabled={cart.length === 0}
                className="py-2 px-3 bg-white border border-[#D4D4D8] hover:bg-[#ffdad6] hover:text-[#ba1a1a] text-[#5c403c] rounded font-bold text-xs flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">delete_sweep</span>
                Clear All
              </button>
            </div>
          )}

          {/* Big Pay / Split-Tender Button */}
          {cart.length === 0 && lastCompletedOrder ? (
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                playSuccessChime();
                setIsReceiptOpen(true);
              }}
              className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white rounded-lg font-extrabold text-sm flex items-center justify-center gap-2 industrial-shadow transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">receipt_long</span>
              <span>
                {isKiosk
                  ? 'PRINT / VIEW LAST RECEIPT & TOKEN'
                  : `VIEW LAST RECEIPT (Bill #${lastCompletedOrder.orderNumber})`}
              </span>
            </button>
          ) : (
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                playKeypadClick();
                setIsCheckoutOpen(true);
              }}
              disabled={cart.length === 0}
              className="w-full py-3.5 bg-[#00478c] hover:bg-[#005eb7] active:bg-[#00366c] text-white rounded-lg font-extrabold text-sm flex items-center justify-center gap-2 industrial-shadow transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">
                {isKiosk ? 'contactless' : 'payments'}
              </span>
              <span>
                {isKiosk
                  ? `CHECKOUT & PAY • Rs. ${totalDue.toFixed(2)}`
                  : `PROCEED TO PAY [F12] • Rs. ${totalDue.toFixed(2)}`}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* VARIANT PICKER MODAL */}
      {selectedVariantModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setSelectedVariantModal(null)}
          />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-md p-5 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B]">{selectedVariantModal.name}</h3>
                <p className="text-xs text-[#5c403c]">Select weight pack or quantity variant</p>
              </div>
              <button
                onClick={() => setSelectedVariantModal(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-2">
              {selectedVariantModal.variants.map((v) => {
                const packLabel = v.attributes?.['Weight Pack'] || v.attributes?.['Pack Size'] || v.attributes?.['Bag Size'] || v.name;
                return (
                  <div
                    key={v.id}
                    onClick={() => {
                      addToCart(selectedVariantModal, v, 1);
                      setSelectedVariantModal(null);
                    }}
                    className="p-3 bg-[#F4F4F5] hover:bg-blue-50 border border-[#D4D4D8] hover:border-[#00478c] rounded-lg cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <div className="font-bold text-sm text-[#09090B]">{packLabel}</div>
                      <div className="text-xs text-[#5c403c] font-tabular-numeric">
                        SKU: {v.sku} • Stock: {v.onHand} {v.unit}
                      </div>
                    </div>
                    <div className="text-right">
                      {v.mrp > v.price && (
                        <div className="text-xs text-gray-400 line-through">
                          Rs. {v.mrp.toFixed(2)}
                        </div>
                      )}
                      <div className="text-base font-bold text-[#00478c] font-tabular-numeric">
                        Rs. {v.price.toFixed(2)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* PARKED / HELD BASKETS MODAL */}
      {isParkedModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setIsParkedModalOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-lg p-5 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-amber-500">pause_circle</span>
                <h3 className="font-bold text-base text-[#09090B]">
                  Held Customer Baskets ({parkedOrders.length})
                </h3>
              </div>
              <button
                onClick={() => setIsParkedModalOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="max-h-80 overflow-y-auto space-y-2.5">
              {parkedOrders.length === 0 ? (
                <div className="text-center py-8 text-gray-500 text-sm">
                  No orders currently on hold
                </div>
              ) : (
                parkedOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="p-3 bg-[#F4F4F5] border border-[#D4D4D8] rounded-lg flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="font-bold text-xs text-[#09090B]">
                        {ord.orderNumber} • {ord.customerName || 'Walk-in Customer'}
                      </div>
                      <div className="text-[11px] text-[#5c403c]">
                        {ord.items.length} items • Held at {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <div className="text-xs font-bold text-[#00478c] mt-0.5">
                        Rs. {ord.total.toFixed(2)}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          retrieveParkedOrder(ord.id);
                          setIsParkedModalOpen(false);
                        }}
                        className="px-3 py-1.5 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7]"
                      >
                        Resume Sale
                      </button>
                      <button
                        onClick={() => setDeletingParkedOrder(ord)}
                        className="p-1.5 text-gray-400 hover:text-red-600 rounded cursor-pointer"
                        title="Delete Held Basket"
                      >
                        <span className="material-symbols-outlined text-[18px]">delete</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* QUICK KHATA CREDIT ADJUSTMENT / SETTLE MODAL */}
      {isKhataModalOpen && khataCustomer && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-4 bg-[#00478c] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-amber-300">account_balance_wallet</span>
                <div>
                  <h3 className="font-bold text-sm">Khata Credit & Settle Account</h3>
                  <p className="text-[11px] text-blue-100">{khataCustomer.name} ({khataCustomer.phone})</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsKhataModalOpen(false)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveKhataCredit} className="p-5 space-y-4">
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-between">
                <span className="text-xs font-medium text-gray-600">Current Khata Balance:</span>
                <span className="text-base font-extrabold text-[#00478c] font-tabular-numeric">
                  Rs. {khataCustomer.storeCredit.toFixed(2)}
                </span>
              </div>

              {/* Mode Selection */}
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1.5">Action Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setKhataAdjustmentMode('add')}
                    className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                      khataAdjustmentMode === 'add'
                        ? 'bg-[#00478c] text-white border-[#00478c] shadow-xs'
                        : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    + Add / Top-Up Credit
                  </button>
                  <button
                    type="button"
                    onClick={() => setKhataAdjustmentMode('set')}
                    className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                      khataAdjustmentMode === 'set'
                        ? 'bg-[#00478c] text-white border-[#00478c] shadow-xs'
                        : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Set Exact Balance
                  </button>
                </div>
              </div>

              {/* Amount Input */}
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">
                  {khataAdjustmentMode === 'add' ? 'Amount to Add (Rs.)' : 'New Balance Amount (Rs.)'}
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  autoFocus
                  required
                  value={khataAmountInput}
                  onChange={(e) => setKhataAmountInput(sanitizeCurrencyInput(e.target.value))}
                  placeholder="0.00"
                  className="w-full text-lg font-bold px-3 py-2 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none font-tabular-numeric"
                />
              </div>

              {/* Quick Suggestion Chips */}
              {khataAdjustmentMode === 'add' && (
                <div className="flex gap-2">
                  {[100, 200, 500, 1000, 2000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setKhataAmountInput(String(amt))}
                      className="px-2.5 py-1 bg-gray-100 hover:bg-blue-50 text-[#00478c] text-xs font-bold rounded border border-gray-200 cursor-pointer"
                    >
                      +{amt}
                    </button>
                  ))}
                </div>
              )}

              <div className="flex gap-2 pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsKhataModalOpen(false)}
                  className="flex-1 py-2 border border-gray-300 text-gray-700 font-bold text-xs rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-sm cursor-pointer"
                >
                  Confirm &amp; Update Khata
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK NEW CUSTOMER CREATION MODAL */}
      {isNewCustomerModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-4 bg-[#00478c] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined">person_add</span>
                <h3 className="font-bold text-sm">Add New Khata / Loyalty Customer</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsNewCustomerModalOpen(false)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  autoFocus
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full text-sm px-3 py-2 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Mobile / Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full text-sm px-3 py-2 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">
                  Initial Khata Store Credit ({outletProfile?.currencySymbol || 'Rs.'})
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={newCustCredit}
                  onChange={(e) => setNewCustCredit(sanitizeCurrencyInput(e.target.value))}
                  placeholder="0.00"
                  className="w-full text-sm font-bold px-3 py-2 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none font-tabular-numeric"
                />
              </div>

              {loyaltyConfig.enabled && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-amber-600 text-lg">loyalty</span>
                    <div>
                      <div className="text-xs font-bold text-gray-800">Enroll in Fresh Rewards Loyalty</div>
                      <div className="text-[10px] text-gray-500">Earn {loyaltyConfig.pointsEarnedPerSpend} pt on every {outletProfile?.currencySymbol || 'Rs.'}{loyaltyConfig.spendAmountPerPoint} spent</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={newCustIsLoyalty}
                    onChange={(e) => setNewCustIsLoyalty(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 accent-amber-600 cursor-pointer"
                  />
                </div>
              )}

              <div className="flex gap-2 pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsNewCustomerModalOpen(false)}
                  className="flex-1 py-2 border border-gray-300 text-gray-700 font-bold text-xs rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#00478c] hover:bg-[#00366c] text-white font-bold text-xs rounded-lg shadow-sm cursor-pointer"
                >
                  Save &amp; Select Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM CLEAR CART MODAL */}
      {isConfirmClearCartOpen && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-200 animate-in fade-in">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-2xl">remove_shopping_cart</span>
              </div>
              <div>
                <h3 className="font-bold text-base text-[#09090B]">Clear Active Cart?</h3>
                <p className="text-[11px] text-gray-500">Remove all current items</p>
              </div>
            </div>
            <p className="text-xs text-gray-700 leading-relaxed mb-4">
              Are you sure you want to discard all <strong>{cart.length} item(s)</strong> (Total: <strong>Rs. {totalDue.toFixed(2)}</strong>) from the active register basket?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsConfirmClearCartOpen(false)}
                className="px-3.5 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  clearCart();
                  setIsConfirmClearCartOpen(false);
                }}
                className="px-4 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">delete_sweep</span>
                Clear All Items
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE HELD ORDER MODAL */}
      {deletingParkedOrder && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-gray-200 animate-in fade-in">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-2xl">delete_forever</span>
              </div>
              <div>
                <h3 className="font-bold text-base text-[#09090B]">Delete Held Bill?</h3>
                <p className="text-[11px] text-gray-500">Cannot be recovered once discarded</p>
              </div>
            </div>
            <p className="text-xs text-gray-700 leading-relaxed mb-4">
              Are you sure you want to permanently delete held sale <strong>{deletingParkedOrder.orderNumber}</strong> ({deletingParkedOrder.items?.length || 0} items • <strong>Rs. {deletingParkedOrder.total?.toFixed(2)}</strong>)?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeletingParkedOrder(null)}
                className="px-3.5 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteParkedOrder(deletingParkedOrder.id);
                  setDeletingParkedOrder(null);
                }}
                className="px-4 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">delete</span>
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FLOATING NUMPAD TRIGGER (Touchscreen / Fast Access) */}
      <button
        onClick={() => {
          playKeypadClick();
          setIsNumpadOpen(true);
        }}
        className="fixed bottom-4 left-4 z-40 bg-[#00478c] hover:bg-[#005eb7] text-white px-3.5 py-2.5 rounded-full shadow-lg flex items-center gap-2 border-2 border-white cursor-pointer active:scale-95 transition-all md:hidden"
        title="Open Numpad SKU Entry"
      >
        <span className="material-symbols-outlined text-amber-300 text-[20px]">dialpad</span>
        <span className="font-bold text-xs">SKU Numpad</span>
      </button>

      {/* NUMPAD SKU MODAL */}
      <NumpadSkuModal
        isOpen={isNumpadOpen}
        onClose={() => setIsNumpadOpen(false)}
        products={products}
        onAddToCart={(prod, vId, qty) => addToCart(prod, vId, qty)}
      />
    </div>
  );
};
