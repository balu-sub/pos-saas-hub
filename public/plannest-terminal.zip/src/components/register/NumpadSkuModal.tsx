import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Product, ProductVariant } from '../../types/pos';
import { playBarcodeBeep, playKeypadClick, playWarningTone } from '../../utils/audio';

interface NumpadSkuModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddToCart: (product: Product, variantId?: string, quantity?: number) => void;
}

export const NumpadSkuModal: React.FC<NumpadSkuModalProps> = ({
  isOpen,
  onClose,
  products,
  onAddToCart,
}) => {
  const [typedSku, setTypedSku] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [selectedVariantId, setSelectedVariantId] = useState<string>('');
  const [lastAddedMessage, setLastAddedMessage] = useState<string | null>(null);
  const [showCheatsheet, setShowCheatsheet] = useState(false);

  const inputDisplayRef = useRef<HTMLDivElement>(null);

  // Normalize SKU helper: removes leading zeros from numeric strings
  const normalizeDigits = (str: string) => {
    const digits = str.replace(/\D/g, '');
    return digits.replace(/^0+/, '') || '0';
  };

  // Find matching products with SKU matching
  const matchingResults = useMemo(() => {
    const query = typedSku.trim();
    if (!query) return [];

    const queryLower = query.toLowerCase();
    const queryDigits = query.replace(/\D/g, '');
    const queryNormalized = normalizeDigits(query);

    const results: Array<{
      product: Product;
      variant: ProductVariant;
      matchScore: number;
      matchReason: string;
      skuCode: string;
    }> = [];

    products.forEach((prod, pIdx) => {
      const seqSkuNum = (pIdx + 1).toString();
      const seqSkuPadded = seqSkuNum.padStart(3, '0');

      prod.variants.forEach((v) => {
        let score = 0;
        let reason = '';

        const vSku = v.sku || prod.baseSku || '';
        const vSkuLower = vSku.toLowerCase();
        const vBarcode = v.barcode || prod.baseBarcode || '';
        const vDigits = vSku.replace(/\D/g, '');
        const vNormalized = normalizeDigits(vDigits);
        const bDigits = vBarcode.replace(/\D/g, '');
        const bNormalized = normalizeDigits(bDigits);

        // 1. Exact match on SKU or Barcode
        if (vSkuLower === queryLower || vBarcode === query) {
          score = 100;
          reason = 'Exact SKU match';
        }
        // 2. Direct match with leading zeros left out (e.g. typed "1" for "001" or "01", or typed "001" for "1")
        else if (queryDigits && vDigits && (vDigits === queryDigits || vNormalized === queryNormalized)) {
          score = 90;
          reason = `SKU code match (${vSku})`;
        }
        // 3. Sequential SKU Index match (e.g. typing "1", "01", "001" matches Item #1)
        else if (
          query === seqSkuNum ||
          query === seqSkuPadded ||
          (queryDigits && queryNormalized === seqSkuNum)
        ) {
          score = 85;
          reason = `SKU Item #${seqSkuPadded}`;
        }
        // 4. Barcode partial / tail match (e.g. last 4-6 digits of barcode)
        else if (queryDigits.length >= 2 && (vBarcode.endsWith(queryDigits) || bNormalized.endsWith(queryNormalized))) {
          score = 75;
          reason = 'Barcode code match';
        }
        // 5. SKU contains query
        else if (vSkuLower.includes(queryLower) || prod.baseSku?.toLowerCase().includes(queryLower)) {
          score = 65;
          reason = 'SKU contains term';
        }
        // 6. Name match
        else if (prod.name.toLowerCase().includes(queryLower) || v.name.toLowerCase().includes(queryLower)) {
          score = 50;
          reason = 'Name match';
        }

        if (score > 0) {
          results.push({
            product: prod,
            variant: v,
            matchScore: score,
            matchReason: reason,
            skuCode: vSku || seqSkuPadded,
          });
        }
      });
    });

    // Sort by best score first
    results.sort((a, b) => b.matchScore - a.matchScore);
    return results;
  }, [typedSku, products]);

  // Primary selected match
  const bestMatch = matchingResults[0] || null;

  // Sync selected variant when best match changes
  useEffect(() => {
    if (bestMatch) {
      setSelectedVariantId(bestMatch.variant.id);
    } else {
      setSelectedVariantId('');
    }
  }, [bestMatch]);

  // Keypad click handler
  const handleKeyClick = (key: string) => {
    playKeypadClick();
    if (key === 'CLEAR') {
      setTypedSku('');
      setQuantity(1);
    } else if (key === 'BACKSPACE') {
      setTypedSku((prev) => prev.slice(0, -1));
    } else if (key === '00') {
      setTypedSku((prev) => prev + '00');
    } else {
      setTypedSku((prev) => prev + key);
    }
  };

  // Add current match to cart
  const handleCommitItem = (prod?: Product, variantId?: string, qty?: number) => {
    const targetProduct = prod || bestMatch?.product;
    const targetVariantId = variantId || selectedVariantId || targetProduct?.variants[0]?.id;
    const targetQty = qty || quantity || 1;

    if (!targetProduct) {
      playWarningTone();
      return;
    }

    const matchedVariant = targetProduct.variants.find((v) => v.id === targetVariantId) || targetProduct.variants[0];
    onAddToCart(targetProduct, targetVariantId, targetQty);
    playBarcodeBeep();

    const cleanName = targetProduct.name.replace(/\s*\(\s*\)/g, '').trim();
    setLastAddedMessage(`Added ${targetQty}x ${cleanName} (Rs. ${(matchedVariant.price * targetQty).toFixed(2)}) to basket!`);

    // Reset input for next entry while preserving fast typing
    setTypedSku('');
    setQuantity(1);

    setTimeout(() => {
      setLastAddedMessage((prev) => (prev?.includes(cleanName) ? null : prev));
    }, 2800);
  };

  // Keyboard events listener for physical numpads
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an explicit text input
      if (
        document.activeElement?.tagName === 'INPUT' &&
        (document.activeElement as HTMLInputElement).type === 'text' &&
        document.activeElement.id !== 'numpad-dummy'
      ) {
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        playKeypadClick();
        setTypedSku((prev) => prev + e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        playKeypadClick();
        setTypedSku((prev) => prev.slice(0, -1));
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (bestMatch) {
          handleCommitItem();
        }
      } else if (e.key === '*' || e.key === 'x' || e.key === 'X') {
        e.preventDefault();
        // If they type e.g. "3*" it sets quantity to typed digits
        if (typedSku && !isNaN(Number(typedSku))) {
          const newQty = Math.max(1, parseFloat(typedSku));
          setQuantity(newQty);
          setTypedSku('');
        }
      } else if (e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        setTypedSku('');
        setQuantity(1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, bestMatch, typedSku, quantity]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-4 animate-in fade-in select-none">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative z-50 bg-white rounded-2xl border border-gray-200 w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-[#00478c] text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-amber-300 text-[24px]">dialpad</span>
            <div>
              <h2 className="font-bold text-base tracking-wide flex items-center gap-2">
                Numpad SKU Entry
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded font-mono font-normal">
                  Fast SKU Selection
                </span>
              </h2>
              <p className="text-[11px] text-blue-100">
                Type SKU code (e.g. <span className="font-mono font-bold">1</span>, <span className="font-mono font-bold">01</span>, <span className="font-mono font-bold">001</span>, or <span className="font-mono font-bold">101</span>) and press Enter to add to basket
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCheatsheet(!showCheatsheet)}
              className="px-2.5 py-1 bg-white/15 hover:bg-white/25 rounded text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
              title="Show SKU cheat sheet directory"
            >
              <span className="material-symbols-outlined text-[16px]">list_alt</span>
              <span>{showCheatsheet ? 'Keypad' : 'SKU List'}</span>
            </button>
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
            >
              <span className="material-symbols-outlined text-[22px]">close</span>
            </button>
          </div>
        </div>

        {/* Notification banner when item is added */}
        {lastAddedMessage && (
          <div className="bg-emerald-600 text-white px-4 py-1.5 text-xs font-bold flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">check_circle</span>
              <span>{lastAddedMessage}</span>
            </div>
            <span className="text-[10px] uppercase tracking-wider opacity-80">Ready for next SKU</span>
          </div>
        )}

        <div className="p-4 flex-1 overflow-y-auto space-y-4 bg-gray-50/50">
          {showCheatsheet ? (
            /* SKU Cheatsheet Table */
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-xs">
              <div className="p-3 bg-gray-100 border-b border-gray-200 flex items-center justify-between">
                <span className="text-xs font-bold text-gray-800">
                  Quick SKU Directory ({products.length} Products)
                </span>
                <span className="text-[11px] text-gray-500">Tap any item to enter SKU code</span>
              </div>
              <div className="max-h-[380px] overflow-y-auto divide-y divide-gray-100">
                {products.map((p, idx) => {
                  const seqSku = (idx + 1).toString().padStart(3, '0');
                  const primaryV = p.variants[0];
                  const displaySku = primaryV?.sku || p.baseSku || seqSku;
                  return (
                    <div
                      key={p.id}
                      onClick={() => {
                        setTypedSku(seqSku);
                        setShowCheatsheet(false);
                      }}
                      className="p-2.5 hover:bg-blue-50/60 cursor-pointer flex items-center justify-between text-xs transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-12 h-7 bg-[#00478c]/10 text-[#00478c] rounded font-mono font-bold text-center flex items-center justify-center text-xs">
                          {displaySku}
                        </span>
                        <div>
                          <div className="font-bold text-gray-900">{p.name}</div>
                          <div className="text-[10px] text-gray-500 font-mono">
                            SKU: {displaySku} • Barcode: {primaryV?.barcode || p.baseBarcode}
                          </div>
                        </div>
                      </div>
                      <div className="text-right font-bold text-[#00478c] font-tabular-numeric">
                        Rs. {(primaryV?.price || p.basePrice).toFixed(2)} / {p.unit}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-stretch">
              {/* LEFT COLUMN: Live Matched Item & Other Matching Results (Dynamic side) */}
              <div className="md:col-span-6 flex flex-col gap-3 min-h-[380px]">
                {/* Live Match Card */}
                <div className="bg-white rounded-xl border border-gray-300 p-3.5 shadow-xs flex-1 flex flex-col justify-between">
                  {bestMatch ? (
                    <div className="space-y-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="inline-block px-2 py-0.5 bg-blue-100 text-[#00478c] rounded text-[10px] font-bold uppercase tracking-wider mb-1">
                            {bestMatch.matchReason}
                          </span>
                          <h3 className="font-bold text-base text-gray-900 leading-tight">
                            {bestMatch.product.name}
                          </h3>
                          <div className="text-[11px] text-gray-500 font-mono mt-0.5">
                            SKU: <span className="text-gray-800 font-bold">{bestMatch.variant.sku || bestMatch.product.baseSku}</span>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-[10px] uppercase text-gray-400 font-bold">Unit Price</div>
                          <div className="text-lg font-extrabold text-[#00478c] font-tabular-numeric">
                            Rs. {bestMatch.variant.price.toFixed(2)}
                          </div>
                          <div className="text-[10px] text-gray-500">/ {bestMatch.variant.unit || bestMatch.product.unit}</div>
                        </div>
                      </div>

                      {/* Variant Selector if multiple sizes exist */}
                      {bestMatch.product.variants.length > 1 && (
                        <div className="pt-2 border-t border-gray-100">
                          <label className="text-[10px] font-bold text-gray-500 uppercase block mb-1">
                            Select Pack / Variant:
                          </label>
                          <div className="flex flex-wrap gap-1.5">
                            {bestMatch.product.variants.map((v) => {
                              const isSelected = selectedVariantId === v.id;
                              return (
                                <button
                                  key={v.id}
                                  type="button"
                                  onClick={() => setSelectedVariantId(v.id)}
                                  className={`px-2.5 py-1 rounded text-xs font-semibold border transition-all cursor-pointer ${
                                    isSelected
                                      ? 'bg-[#00478c] text-white border-[#00478c] shadow-xs'
                                      : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                                  }`}
                                >
                                  {v.attributes?.['Weight Pack'] || v.attributes?.['Pack Size'] || v.name} (Rs. {v.price})
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Quantity & Estimated Line Total */}
                      <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5">
                          <span className="text-gray-500 font-medium">Qty:</span>
                          <div className="flex items-center border border-gray-300 rounded bg-gray-50">
                            <button
                              type="button"
                              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                              className="px-2.5 py-0.5 hover:bg-gray-200 font-bold text-gray-700 rounded-l"
                            >
                              -
                            </button>
                            <span className="px-2 font-bold font-mono text-gray-900">{quantity}</span>
                            <button
                              type="button"
                              onClick={() => setQuantity((q) => q + 1)}
                              className="px-2.5 py-0.5 hover:bg-gray-200 font-bold text-gray-700 rounded-r"
                            >
                              +
                            </button>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-gray-500 mr-1.5">Line Total:</span>
                          <span className="font-extrabold text-base text-[#00478c] font-tabular-numeric">
                            Rs. {(bestMatch.variant.price * quantity).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-full min-h-[140px] flex flex-col items-center justify-center text-center py-6 text-gray-400">
                      <span className="material-symbols-outlined text-[36px] text-gray-300 mb-1">
                        dialpad
                      </span>
                      <p className="text-xs font-bold text-gray-600">
                        {typedSku ? 'No SKU code matches' : 'Ready for SKU code'}
                      </p>
                      <p className="text-[11px] text-gray-400 mt-0.5 max-w-[220px]">
                        Type SKU on the numpad (e.g. 1, 01, 001, 101)
                      </p>
                    </div>
                  )}
                </div>

                {/* Candidate matching items list */}
                <div className="bg-white rounded-xl border border-gray-200 p-2.5 shadow-xs flex-1 flex flex-col min-h-[140px]">
                  <div className="flex items-center justify-between pb-1.5 border-b border-gray-100 mb-1.5">
                    <span className="text-[11px] font-bold text-gray-600 uppercase">
                      Matching Catalog ({matchingResults.length})
                    </span>
                    <span className="text-[10px] text-gray-400">Tap to add directly</span>
                  </div>
                  <div className="overflow-y-auto max-h-[130px] space-y-1 pr-1 scrollbar-thin">
                    {matchingResults.length === 0 ? (
                      <div className="text-center py-4 text-gray-400 text-xs italic">
                        Type digits to filter store catalog
                      </div>
                    ) : (
                      matchingResults.map((res, i) => (
                        <div
                          key={res.variant.id + i}
                          onClick={() => handleCommitItem(res.product, res.variant.id)}
                          className="px-2.5 py-1.5 bg-gray-50 hover:bg-blue-50 border border-gray-200/80 rounded-lg text-xs flex items-center justify-between cursor-pointer transition-colors"
                        >
                          <div className="flex items-center gap-2 min-w-0 pr-2">
                            <span className="w-10 h-5 bg-[#00478c]/10 text-[#00478c] rounded text-[10px] font-mono font-bold flex items-center justify-center shrink-0">
                              {res.skuCode}
                            </span>
                            <span className="font-bold text-gray-800 truncate text-[11px]">
                              {res.product.name}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0 font-tabular-numeric">
                            <span className="text-gray-500 text-[11px]">
                              Rs. {res.variant.price}
                            </span>
                            <span className="text-emerald-700 font-bold text-[10px] bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                              + Add
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN: Stationary Digital Display & Touch Numpad (Fixed Layout) */}
              <div className="md:col-span-6 space-y-3 flex flex-col">
                {/* Stationary Digital Code Input Display */}
                <div
                  ref={inputDisplayRef}
                  className="bg-[#09090B] text-emerald-400 rounded-xl p-3 shadow-inner border-2 border-gray-800 flex flex-col justify-between h-[84px]"
                >
                  <div className="flex items-center justify-between text-[10px] text-gray-400 uppercase tracking-widest font-bold">
                    <span>SKU CODE</span>
                    <span className="text-amber-400 font-mono">QTY: {quantity}x</span>
                  </div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-3xl font-mono font-black tracking-widest text-emerald-400 flex items-center">
                      {typedSku || <span className="text-gray-600 font-normal text-2xl">_ _ _</span>}
                    </span>
                    {typedSku && (
                      <span className="text-[10px] font-mono text-gray-400 bg-gray-800 px-1.5 py-0.5 rounded">
                        Norm: {normalizeDigits(typedSku)}
                      </span>
                    )}
                  </div>
                  <div className="text-[9px] text-gray-500 flex items-center justify-between">
                    <span>0-tolerant (1 = 01 = 001)</span>
                    <span className="font-mono text-gray-400">
                      {matchingResults.length} match{matchingResults.length !== 1 ? 'es' : ''}
                    </span>
                  </div>
                </div>

                {/* Quick Multiplier Pill Buttons */}
                <div className="flex items-center gap-1 overflow-x-auto text-xs">
                  <span className="text-[11px] text-gray-500 font-bold shrink-0">Qty:</span>
                  {[1, 2, 3, 5, 10].map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setQuantity(q)}
                      className={`flex-1 py-1 rounded text-xs font-bold border transition-colors cursor-pointer text-center ${
                        quantity === q
                          ? 'bg-[#00478c] text-white border-[#00478c]'
                          : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                      }`}
                    >
                      {q}x
                    </button>
                  ))}
                </div>

                {/* Stationary Touch Numpad Grid */}
                <div className="grid grid-cols-3 gap-2">
                  {/* Row 1 */}
                  {['7', '8', '9'].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleKeyClick(num)}
                      className="h-13 bg-white hover:bg-gray-100 active:bg-gray-200 border-2 border-gray-200 active:border-[#00478c] rounded-xl font-bold font-mono text-2xl text-gray-800 shadow-xs flex items-center justify-center transition-all cursor-pointer active:scale-95"
                    >
                      {num}
                    </button>
                  ))}

                  {/* Row 2 */}
                  {['4', '5', '6'].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleKeyClick(num)}
                      className="h-13 bg-white hover:bg-gray-100 active:bg-gray-200 border-2 border-gray-200 active:border-[#00478c] rounded-xl font-bold font-mono text-2xl text-gray-800 shadow-xs flex items-center justify-center transition-all cursor-pointer active:scale-95"
                    >
                      {num}
                    </button>
                  ))}

                  {/* Row 3 */}
                  {['1', '2', '3'].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleKeyClick(num)}
                      className="h-13 bg-white hover:bg-gray-100 active:bg-gray-200 border-2 border-gray-200 active:border-[#00478c] rounded-xl font-bold font-mono text-2xl text-gray-800 shadow-xs flex items-center justify-center transition-all cursor-pointer active:scale-95"
                    >
                      {num}
                    </button>
                  ))}

                  {/* Row 4 */}
                  <button
                    type="button"
                    onClick={() => handleKeyClick('0')}
                    className="h-13 bg-white hover:bg-gray-100 active:bg-gray-200 border-2 border-gray-200 active:border-[#00478c] rounded-xl font-bold font-mono text-2xl text-gray-800 shadow-xs flex items-center justify-center transition-all cursor-pointer active:scale-95"
                  >
                    0
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeyClick('00')}
                    className="h-13 bg-white hover:bg-gray-100 active:bg-gray-200 border-2 border-gray-200 active:border-[#00478c] rounded-xl font-bold font-mono text-xl text-gray-800 shadow-xs flex items-center justify-center transition-all cursor-pointer active:scale-95"
                  >
                    00
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeyClick('BACKSPACE')}
                    className="h-13 bg-amber-50 hover:bg-amber-100 active:bg-amber-200 border-2 border-amber-200 rounded-xl font-bold text-amber-800 shadow-xs flex items-center justify-center transition-all cursor-pointer active:scale-95"
                    title="Backspace"
                  >
                    <span className="material-symbols-outlined text-[24px]">backspace</span>
                  </button>
                </div>

                {/* Stationary Bottom Control Row */}
                <div className="grid grid-cols-3 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => handleKeyClick('CLEAR')}
                    className="h-12 bg-red-50 hover:bg-red-100 active:bg-red-200 border border-red-200 rounded-xl font-bold text-red-700 text-sm shadow-xs flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95"
                  >
                    <span className="material-symbols-outlined text-[18px]">clear_all</span>
                    <span>Clear (C)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCommitItem()}
                    disabled={!bestMatch}
                    className="col-span-2 h-12 bg-[#00478c] hover:bg-[#005eb7] active:bg-[#00366c] disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl font-extrabold text-sm shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
                  >
                    <span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
                    <span>ADD TO BASKET [ENTER]</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="bg-gray-100 px-4 py-2 border-t border-gray-200 flex items-center justify-between text-[11px] text-gray-600">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[16px] text-gray-500">keyboard</span>
            <span>Keyboard shortcuts: <strong className="font-mono">0-9</strong> = Type • <strong className="font-mono">Enter</strong> = Add • <strong className="font-mono">Esc</strong> = Close</span>
          </div>
          <button
            onClick={onClose}
            className="font-bold text-gray-700 hover:text-gray-900 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
