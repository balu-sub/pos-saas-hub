import React, { useState, useMemo, useRef, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { Product, ProductVariant } from '../../types/pos';
import { BarcodeLabelPrintModal } from './BarcodeLabelPrintModal';
import { ImageLibraryModal } from '../modals/ImageLibraryModal';
import { UserManagementTab } from '../admin/UserManagementTab';
import { LoyaltyProgramTab } from '../settings/LoyaltyProgramTab';
import { OutletProfileTab } from '../settings/OutletProfileTab';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';
import { exportToCSV, CSVColumn } from '../../utils/csvExport';
import { apiClient } from '../../services/apiClient';
import { getProductImageUrl, handleProductImageError } from '../../utils/productImages';
import { getActiveOfferProducts, getProductOfferInfo, isOfferActive } from '../../utils/offers';
import { filterAndSortProducts } from '../../utils/productSearch';

const IMAGE_PRESETS = [
  { name: 'Indian Apple', path: '/images/products/indian_apple.jpg', url: '/images/products/indian_apple.jpg' },
  { name: 'USA Apple', path: '/images/products/usa_apple.jpg', url: '/images/products/usa_apple.jpg' },
  { name: 'Fresh Tomato', path: '/images/products/tomato.jpg', url: '/images/products/tomato.jpg' },
  { name: 'Farm Potato', path: '/images/products/potatoes.jpg', url: '/images/products/potatoes.jpg' },
  { name: 'Red Onion', path: '/images/products/onion.jpg', url: '/images/products/onion.jpg' },
  { name: 'Green Chillies', path: '/images/products/green_chillies.jpg', url: '/images/products/green_chillies.jpg' },
  { name: 'Fresh Orange', path: '/images/products/oranges.jpg', url: '/images/products/oranges.jpg' },
  { name: 'Yellow Banana', path: '/images/products/yellow_bananas.jpg', url: '/images/products/yellow_bananas.jpg' },
  { name: 'Mango', path: '/images/products/mangoes.jpg', url: '/images/products/mangoes.jpg' },
  { name: 'Watermelon', path: '/images/products/watermelons.jpg', url: '/images/products/watermelons.jpg' },
  { name: 'Paneer', path: '/images/products/paneer.jpg', url: '/images/products/paneer.jpg' },
  { name: 'Fresh Butter', path: '/images/products/butter.jpg', url: '/images/products/butter.jpg' },
  { name: 'Pure Oil', path: '/images/products/oil.jpg', url: '/images/products/oil.jpg' },
  { name: 'Garlic', path: '/images/products/garlic.jpg', url: '/images/products/garlic.jpg' },
  { name: 'Ginger', path: '/images/products/ginger.jpg', url: '/images/products/ginger.jpg' },
  { name: 'Diamond Tea', path: '/images/products/diamond_tea.jpg', url: '/images/products/diamond_tea.jpg' },
  { name: 'Toor Dal', path: '/images/products/toor_dal.jpg', url: '/images/products/toor_dal.jpg' },
  { name: 'Avocado', path: '/images/products/avocados.jpg', url: '/images/products/avocados.jpg' },
];

// Helper to calculate the next unique sequential SKU-XXXX and PROD-XXXX
export function getNextSequentialSku(products: Product[]): { sku: string; prodId: string; seq: number } {
  let maxNum = 0;
  for (const p of products) {
    const idMatch = (p.id || '').match(/\d+/);
    if (idMatch) maxNum = Math.max(maxNum, parseInt(idMatch[0], 10));
    const skuMatch = (p.baseSku || '').match(/\d+/);
    if (skuMatch) maxNum = Math.max(maxNum, parseInt(skuMatch[0], 10));
    if (Array.isArray(p.variants)) {
      for (const v of p.variants) {
        const vSkuMatch = (v.sku || '').match(/\d+/);
        if (vSkuMatch) maxNum = Math.max(maxNum, parseInt(vSkuMatch[0], 10));
      }
    }
  }

  let nextSeq = maxNum + 1;
  while (
    products.some(
      (p) =>
        p.baseSku === `SKU-${String(nextSeq).padStart(4, '0')}` ||
        p.variants?.some((v) => v.sku === `SKU-${String(nextSeq).padStart(4, '0')}`)
    )
  ) {
    nextSeq++;
  }

  const padded = String(nextSeq).padStart(4, '0');
  return {
    sku: `SKU-${padded}`,
    prodId: `PROD-${padded}`,
    seq: nextSeq,
  };
}

export const MatrixInventoryScreen: React.FC = () => {
  const {
    products,
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
    createProductWithVariants,
    updateProduct,
    deleteProduct,
    updateProductStock,
    refreshProducts,
    isLoadingProducts,
    isDbConnected,
    currentOperator,
    canManageCatalog,
    canManageUsers,
    updateProductOffer,
  } = usePOS();

  const [adminSubTab, setAdminSubTab] = useState<'catalog' | 'loyalty' | 'outlet' | 'users'>(() => {
    try {
      const saved = localStorage.getItem('alfa_pos_admin_subtab');
      if (saved === 'users' || saved === 'catalog' || saved === 'loyalty' || saved === 'outlet') return saved as any;
    } catch {}
    return 'catalog';
  });

  useEffect(() => {
    try {
      localStorage.setItem('alfa_pos_admin_subtab', adminSubTab);
    } catch {}
  }, [adminSubTab]);

  const [notificationNotice, setNotificationNotice] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [onlyActiveOffers, setOnlyActiveOffers] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  const [isImageLibraryOpen, setIsImageLibraryOpen] = useState(false);
  const [imageLibraryTarget, setImageLibraryTarget] = useState<'add' | 'edit'>('add');
  const [isScanningBarcode, setIsScanningBarcode] = useState<'add' | 'edit' | null>(null);
  const [newProdStatus, setNewProdStatus] = useState<'active' | 'inactive'>('active');
  const [editStatus, setEditStatus] = useState<'active' | 'inactive'>('active');

  // Quick Offer Modal State
  const [quickOfferProduct, setQuickOfferProduct] = useState<Product | null>(null);
  const [offerFormType, setOfferFormType] = useState<'percentage' | 'flat'>('percentage');
  const [offerFormValue, setOfferFormValue] = useState<string>('20');
  const [offerFormTitle, setOfferFormTitle] = useState<string>('Offer of the Day');
  const [offerFormPeriod, setOfferFormPeriod] = useState<'today' | '3days' | '7days' | 'custom'>('today');
  const [offerFormStartDate, setOfferFormStartDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [offerFormEndDate, setOfferFormEndDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [isSavingOffer, setIsSavingOffer] = useState(false);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Barcode Scanner Listener for Modal
  useEffect(() => {
    if (!isScanningBarcode) return;
    let buffer = '';
    let lastKeyTime = Date.now();

    const handleKeyDown = (e: KeyboardEvent) => {
      const now = Date.now();
      const diff = now - lastKeyTime;
      lastKeyTime = now;

      if (e.key === 'Enter') {
        if (buffer.trim()) {
          playBarcodeBeep();
          if (isScanningBarcode === 'add') {
            setNewProdBarcode(buffer.trim());
          } else {
            setEditBarcode(buffer.trim());
          }
          buffer = '';
          setIsScanningBarcode(null);
        }
        return;
      }

      if (e.key.length === 1) {
        if (diff > 120) {
          buffer = e.key;
        } else {
          buffer += e.key;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isScanningBarcode]);

  // Sync with Cloud Handler
  const handleSyncWithCloud = async () => {
    playKeypadClick();
    setIsSyncing(true);
    setNotificationNotice('⏳ Syncing catalogue with cloud (latest records win)...');
    try {
      await apiClient.syncNow();
      await refreshProducts(true);
      playSuccessChime();
      const timeStr = new Date().toLocaleTimeString();
      setLastSyncTime(timeStr);
      setNotificationNotice(`✅ Synchronized with Cloud at ${timeStr}. Latest updates merged!`);
      setTimeout(() => setNotificationNotice(null), 4000);
    } catch (err: any) {
      console.error('Cloud sync error:', err);
      setNotificationNotice(`⚠️ Sync note: ${err?.message || 'Check connection'}`);
      setTimeout(() => setNotificationNotice(null), 4000);
    } finally {
      setIsSyncing(false);
    }
  };

  // Toggle Active / Inactive Status Handler
  const handleToggleStatus = async (productId: string, currentStatus?: string) => {
    playKeypadClick();
    const nextStatus = currentStatus === 'inactive' ? 'active' : 'inactive';
    try {
      await apiClient.toggleProductStatus(productId, nextStatus);
      await refreshProducts(true);
      playSuccessChime();
      setNotificationNotice(`Status updated: ${nextStatus.toUpperCase()}`);
      setTimeout(() => setNotificationNotice(null), 2500);
    } catch (err: any) {
      console.error('Toggle status error:', err);
    }
  };

  // Category Manager Modal States
  const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<string | null>(null);
  const [reassignTargetCategory, setReassignTargetCategory] = useState<string>('Fresh Vegetables');
  const [editingCategoryName, setEditingCategoryName] = useState<{ oldName: string; newName: string } | null>(null);
  const [newCategoryManagerInput, setNewCategoryManagerInput] = useState('');
  const [isDeletingCategory, setIsDeletingCategory] = useState(false);

  const [selectedProductForPrint, setSelectedProductForPrint] = useState<{
    product: Product;
    variant?: ProductVariant;
  } | null>(null);

  // New Product Form State
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState(categories[0] || 'Fresh Vegetables');
  const [isCustomCategoryActive, setIsCustomCategoryActive] = useState(false);
  const [customCategoryInput, setCustomCategoryInput] = useState('');
  const [newProdBrand, setNewProdBrand] = useState('Farm Fresh Mandi');
  const [newProdUnit, setNewProdUnit] = useState('kg');
  const [newProdSku, setNewProdSku] = useState('');
  const [newProdBarcode, setNewProdBarcode] = useState('');
  const [newProdPrice, setNewProdPrice] = useState('40.00');
  const [newProdMrp, setNewProdMrp] = useState('50.00');
  const [newProdCost, setNewProdCost] = useState('28.00');
  const [newProdStock, setNewProdStock] = useState('50');
  const [newProdReorder, setNewProdReorder] = useState('10');
  const [newProdGst, setNewProdGst] = useState('0'); // 0%, 5%, 12%, 18%

  // Image upload and storage states (Add Modal)
  const [imagePreview, setImagePreview] = useState<string>('https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=500&auto=format&fit=crop&q=80');
  const [imageDbPath, setImageDbPath] = useState<string>('/images/products/tomatoes_hybrid.jpg');
  const [uploadedFileName, setUploadedFileName] = useState<string>('tomatoes_hybrid.jpg');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Edit Product Form State
  const [editName, setEditName] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [isEditCustomCategory, setIsEditCustomCategory] = useState(false);
  const [editCustomCategoryInput, setEditCustomCategoryInput] = useState('');
  const [editBrand, setEditBrand] = useState('');
  const [editUnit, setEditUnit] = useState('kg');
  const [editSku, setEditSku] = useState('');
  const [editBarcode, setEditBarcode] = useState('');
  const [editPrice, setEditPrice] = useState('');
  const [editMrp, setEditMrp] = useState('');
  const [editCost, setEditCost] = useState('');
  const [editStock, setEditStock] = useState('');
  const [editReorder, setEditReorder] = useState('');
  const [editGst, setEditGst] = useState('0');
  const [editImagePreview, setEditImagePreview] = useState('');
  const [editImageDbPath, setEditImageDbPath] = useState('');
  const editFileInputRef = useRef<HTMLInputElement>(null);

  // Stock Adjustment inline modal
  const [adjustStockModal, setAdjustStockModal] = useState<{
    product: Product;
    variant: ProductVariant;
  } | null>(null);
  const [adjustDelta, setAdjustDelta] = useState('10');
  const [adjustReason, setAdjustReason] = useState<'GOODS_RECEIPT' | 'DAMAGE_WASTAGE' | 'ADJUSTMENT'>('GOODS_RECEIPT');

  // Pagination State
  const [pageSize, setPageSize] = useState<number | 'All'>(25);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Deals & Promotions Manager State
  const [isDealsManagerOpen, setIsDealsManagerOpen] = useState(false);
  const [dealSearchQuery, setDealSearchQuery] = useState('');

  // Count active offers
  const activeOfferCount = useMemo(() => {
    return products.filter(isOfferActive).length;
  }, [products]);

  // Open Quick Offer Modal for a product
  const handleOpenOfferModal = (prod: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    playKeypadClick();
    setQuickOfferProduct(prod);
    setOfferFormType(prod.offerType || 'percentage');
    setOfferFormValue((prod.offerValue !== undefined && prod.offerValue > 0 ? prod.offerValue : 20).toString());
    setOfferFormTitle(prod.offerTitle || 'Offer of the Day');
    setOfferFormStartDate(prod.offerStartDate ? prod.offerStartDate.split('T')[0] : new Date().toISOString().split('T')[0]);
    setOfferFormEndDate(prod.offerEndDate ? prod.offerEndDate.split('T')[0] : new Date().toISOString().split('T')[0]);
  };

  // Submit Quick Offer
  const handleSaveOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickOfferProduct) return;
    setIsSavingOffer(true);
    try {
      let start: string | null = null;
      let end: string | null = null;
      const today = new Date();

      if (offerFormPeriod === 'today') {
        const startD = new Date(today);
        startD.setHours(0, 0, 0, 0);
        const endD = new Date(today);
        endD.setHours(23, 59, 59, 999);
        start = startD.toISOString();
        end = endD.toISOString();
      } else if (offerFormPeriod === '3days') {
        const startD = new Date(today);
        startD.setHours(0, 0, 0, 0);
        const endD = new Date(today);
        endD.setDate(endD.getDate() + 3);
        endD.setHours(23, 59, 59, 999);
        start = startD.toISOString();
        end = endD.toISOString();
      } else if (offerFormPeriod === '7days') {
        const startD = new Date(today);
        startD.setHours(0, 0, 0, 0);
        const endD = new Date(today);
        endD.setDate(endD.getDate() + 7);
        endD.setHours(23, 59, 59, 999);
        start = startD.toISOString();
        end = endD.toISOString();
      } else {
        if (offerFormStartDate) start = new Date(offerFormStartDate).toISOString();
        if (offerFormEndDate) {
          const endD = new Date(offerFormEndDate);
          endD.setHours(23, 59, 59, 999);
          end = endD.toISOString();
        }
      }

      await updateProductOffer(quickOfferProduct.id, {
        isOfferActive: true,
        offerType: offerFormType,
        offerValue: parseFloat(offerFormValue) || 0,
        offerTitle: offerFormTitle.trim() || 'Offer of the Day',
        offerStartDate: start,
        offerEndDate: end,
      });

      playSuccessChime();
      setNotificationNotice(`Promotional deal activated for "${quickOfferProduct.name}"!`);
      setTimeout(() => setNotificationNotice(null), 3500);
      setQuickOfferProduct(null);
    } catch (err) {
      console.error('Error saving offer:', err);
    } finally {
      setIsSavingOffer(false);
    }
  };

  // Remove / Deactivate Offer
  const handleRemoveOffer = async () => {
    if (!quickOfferProduct) return;
    if (!confirm(`Are you sure you want to deactivate and remove the active promotional deal on "${quickOfferProduct.name}"?`)) {
      return;
    }
    setIsSavingOffer(true);
    try {
      await updateProductOffer(quickOfferProduct.id, {
        isOfferActive: false,
        offerType: 'percentage',
        offerValue: 0,
        offerTitle: 'Offer of the Day',
        offerStartDate: null,
        offerEndDate: null,
      });
      playSuccessChime();
      setNotificationNotice(`Offer deactivated for "${quickOfferProduct.name}"`);
      setTimeout(() => setNotificationNotice(null), 3000);
      setQuickOfferProduct(null);
    } catch (err) {
      console.error('Error removing offer:', err);
    } finally {
      setIsSavingOffer(false);
    }
  };

  // Category Manager Actions
  const handleAddCategoryFromManager = (e: React.FormEvent) => {
    e.preventDefault();
    const cat = newCategoryManagerInput.trim();
    if (!cat) return;
    if (categories.includes(cat)) {
      alert('This category already exists.');
      return;
    }
    addCategory(cat);
    setNewCategoryManagerInput('');
    setNotificationNotice(`✓ Added new category "${cat}"`);
    setTimeout(() => setNotificationNotice(null), 3000);
  };

  const handleSaveRenameCategory = async (oldName: string) => {
    if (!editingCategoryName || !editingCategoryName.newName.trim()) {
      setEditingCategoryName(null);
      return;
    }
    const newName = editingCategoryName.newName.trim();
    if (newName === oldName) {
      setEditingCategoryName(null);
      return;
    }
    await updateCategory(oldName, newName);
    setEditingCategoryName(null);
    setNotificationNotice(`✓ Renamed category to "${newName}"`);
    setTimeout(() => setNotificationNotice(null), 3000);
  };

  const handleConfirmDeleteCategory = async () => {
    if (!categoryToDelete) return;
    setIsDeletingCategory(true);
    try {
      const catName = categoryToDelete;
      const fallback = reassignTargetCategory || 'Fresh Vegetables';
      await deleteCategory(catName, fallback);
      setCategoryToDelete(null);
      setNotificationNotice(`✓ Category "${catName}" deleted. Products reassigned to "${fallback}".`);
      setTimeout(() => setNotificationNotice(null), 4000);
    } catch (err: any) {
      console.error('Error deleting category:', err);
      setNotificationNotice(`Error deleting category: ${err.message}`);
    } finally {
      setIsDeletingCategory(false);
    }
  };

  // Filter products with prefix priority and alphabetical sorting
  const filteredProducts = useMemo(() => {
    return filterAndSortProducts(
      products,
      searchQuery,
      selectedCategory,
      onlyActiveOffers,
      isOfferActive
    );
  }, [products, selectedCategory, searchQuery, onlyActiveOffers]);

  // Filter by Active / Inactive status
  const statusFilteredProducts = useMemo(() => {
    return filteredProducts.filter((p) => {
      if (statusFilter === 'active') return p.status !== 'inactive';
      if (statusFilter === 'inactive') return p.status === 'inactive';
      return true;
    });
  }, [filteredProducts, statusFilter]);

  // Status counts
  const activeCount = useMemo(() => products.filter((p) => p.status !== 'inactive').length, [products]);
  const inactiveCount = useMemo(() => products.filter((p) => p.status === 'inactive').length, [products]);

  // Reset page to 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, selectedCategory, pageSize, statusFilter]);

  // Paginated slice of products
  const totalItems = statusFilteredProducts.length;
  const effectivePageSize = pageSize === 'All' ? totalItems || 1 : pageSize;
  const totalPages = Math.max(1, Math.ceil(totalItems / effectivePageSize));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  
  const paginatedProducts = useMemo(() => {
    if (pageSize === 'All') return statusFilteredProducts;
    const start = (safeCurrentPage - 1) * pageSize;
    return statusFilteredProducts.slice(start, start + pageSize);
  }, [statusFilteredProducts, pageSize, safeCurrentPage]);

  const startIndex = totalItems === 0 ? 0 : (safeCurrentPage - 1) * (pageSize === 'All' ? totalItems : pageSize) + 1;
  const endIndex = pageSize === 'All' ? totalItems : Math.min(safeCurrentPage * pageSize, totalItems);

  const lowStockCount = useMemo(() => {
    return products.filter((p) => p.totalOnHand <= (p.variants[0]?.reorderLevel || 10)).length;
  }, [products]);

  // Open Edit Modal and prefill form
  const handleOpenEditModal = (prod: Product) => {
    playKeypadClick();
    setEditingProduct(prod);
    const variant = prod.variants[0];

    setEditName(prod.name);
    setEditCategory(prod.category || 'Fresh Vegetables');
    setIsEditCustomCategory(false);
    setEditCustomCategoryInput('');
    setEditBrand(prod.brand || 'Amma & Appa Kadai');
    setEditUnit(prod.unit || variant?.unit || 'kg');
    setEditStatus(prod.status === 'inactive' ? 'inactive' : 'active');
    setEditSku(variant?.sku || prod.baseSku || '');
    setEditBarcode(variant?.barcode || prod.baseBarcode || '');
    setEditPrice((variant?.price ?? prod.basePrice ?? 0).toString());
    setEditMrp((variant?.mrp ?? prod.baseMrp ?? prod.basePrice ?? 0).toString());
    setEditCost((variant?.cost ?? prod.baseCost ?? 0).toString());
    setEditStock((prod.totalOnHand ?? variant?.onHand ?? 50).toString());
    setEditReorder((variant?.reorderLevel ?? 10).toString());
    setEditGst(((prod.gstRate ?? 0) * 100).toString());
    const bestImg = getProductImageUrl(prod, variant);
    setEditImagePreview(bestImg);
    setEditImageDbPath(prod.imagePath || prod.imageUrl || prod.image || bestImg);
  };

  // Submit Edit Product
  const handleEditProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !editName.trim()) return;

    setIsSaving(true);
    try {
      let finalCat = editCategory;
      if (isEditCustomCategory && editCustomCategoryInput.trim()) {
        finalCat = editCustomCategoryInput.trim();
        addCategory(finalCat);
      }

      const price = parseFloat(editPrice) || 0;
      const mrp = parseFloat(editMrp) || price;
      const cost = parseFloat(editCost) || 0;
      const stock = parseInt(editStock, 10) || 0;
      const reorder = parseInt(editReorder, 10) || 10;
      const gstRate = (parseFloat(editGst) || 0) / 100;

      const primaryVar = editingProduct.variants[0] || {
        id: `var_${editingProduct.id}`,
        productId: editingProduct.id,
        sku: editSku,
        barcode: editBarcode,
        name: editName,
        unit: editUnit,
        attributes: { 'Pack Size': editUnit },
        mrp,
        price,
        cost,
        marginPercent: mrp > 0 ? Number((((price - cost) / price) * 100).toFixed(1)) : 25,
        onHand: stock,
        available: stock,
        reserved: 0,
        reorderLevel: reorder,
        isParent: true,
        image: editImagePreview,
        version: 1,
      };

      const updatedVariant: ProductVariant = {
        ...primaryVar,
        sku: editSku || primaryVar.sku,
        barcode: editBarcode || primaryVar.barcode,
        name: editName,
        unit: editUnit,
        mrp,
        price,
        cost,
        marginPercent: mrp > 0 ? Number((((price - cost) / price) * 100).toFixed(1)) : 25,
        onHand: stock,
        available: stock,
        reorderLevel: reorder,
        image: editImagePreview,
      };

      const updatedProduct: Product = {
        ...editingProduct,
        name: editName,
        category: finalCat,
        brand: editBrand,
        unit: editUnit,
        baseSku: editSku || editingProduct.baseSku,
        baseBarcode: editBarcode || editingProduct.baseBarcode,
        basePrice: price,
        baseMrp: mrp,
        baseCost: cost,
        image: editImagePreview,
        imageUrl: editImagePreview,
        imagePath: editImageDbPath,
        gstRate,
        taxable: gstRate > 0,
        totalOnHand: stock,
        totalAvailable: stock,
        variants: [updatedVariant, ...editingProduct.variants.slice(1)],
      };

      await updateProduct(updatedProduct);
      setEditingProduct(null);
      setNotificationNotice(`✓ Updated "${updatedProduct.name}" in catalog`);
      setTimeout(() => setNotificationNotice(null), 3500);
    } catch (err: any) {
      console.error('Error updating product:', err);
      setNotificationNotice(`Error updating item: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Confirm Delete Product
  const handleConfirmDelete = async () => {
    if (!deletingProduct) return;
    setIsDeleting(true);
    try {
      const prodName = deletingProduct.name;
      await deleteProduct(deletingProduct.id);
      setDeletingProduct(null);
      setNotificationNotice(`✓ Deleted "${prodName}" from database`);
      setTimeout(() => setNotificationNotice(null), 3500);
    } catch (err: any) {
      console.error('Error deleting product:', err);
      setNotificationNotice(`Error deleting item: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle Image File Upload (Add Modal - saves directly to local disk /public/images/products/)
  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFileName(file.name);
      const reader = new FileReader();
      reader.onload = async () => {
        if (reader.result) {
          const base64Data = reader.result as string;
          setImagePreview(base64Data);
          try {
            const res = await apiClient.uploadImage(base64Data, file.name, newProdSku || 'product');
            if (res.imageUrl) {
              setImagePreview(res.imageUrl);
              setImageDbPath(res.imageUrl);
            }
          } catch (err) {
            console.warn('Local image save fallback (stored as base64):', err);
            setImageDbPath(base64Data);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Image File Upload (Edit Modal - saves directly to local disk /public/images/products/)
  const handleEditImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async () => {
        if (reader.result) {
          const base64Data = reader.result as string;
          setEditImagePreview(base64Data);
          try {
            const res = await apiClient.uploadImage(base64Data, file.name, editSku || editingProduct?.baseSku || 'product');
            if (res.imageUrl) {
              setEditImagePreview(res.imageUrl);
              setEditImageDbPath(res.imageUrl);
            }
          } catch (err) {
            console.warn('Local image save fallback (stored as base64):', err);
            setEditImageDbPath(base64Data);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit Add Product Form
  const handleAddProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) return;

    setIsSaving(true);
    try {
      let finalCategory = newProdCategory;
      if (isCustomCategoryActive && customCategoryInput.trim()) {
        finalCategory = customCategoryInput.trim();
        addCategory(finalCategory);
      }

      const price = parseFloat(newProdPrice) || 0;
      const mrp = parseFloat(newProdMrp) || price;
      const cost = parseFloat(newProdCost) || price * 0.7;
      const initialStock = parseInt(newProdStock, 10) || 0;
      const reorder = parseInt(newProdReorder, 10) || 10;

      // Standardize SKU format to SKU-XXXX (4-digit zero-padded) and ensure uniqueness
      let sku = newProdSku.trim().toUpperCase();
      if (!sku) {
        sku = getNextSequentialSku(products).sku;
      } else if (!/^SKU-\d{4}$/.test(sku)) {
        const numMatch = sku.match(/\d+/);
        if (numMatch) {
          sku = `SKU-${numMatch[0].padStart(4, '0')}`;
        } else {
          sku = getNextSequentialSku(products).sku;
        }
      }

      // If SKU conflict exists with an existing product, find next unique SKU-XXXX
      const isConflict = products.some(
        (p) => p.baseSku?.toUpperCase() === sku || p.variants?.some((v) => v.sku?.toUpperCase() === sku)
      );
      if (isConflict) {
        sku = getNextSequentialSku(products).sku;
      }

      const skuNumericPart = sku.replace('SKU-', '');
      const barcode = newProdBarcode.trim() || `890${skuNumericPart.padStart(7, '0')}`;
      const gstRate = (parseFloat(newProdGst) || 0) / 100;

      const defaultImage = imagePreview || '/images/products/default_product.jpg';
      const finalDbPath = imageDbPath || defaultImage;

      const productId = `PROD-${skuNumericPart}`;
      const variantId = `VAR-${productId}-1`;

      const newVariant: ProductVariant = {
        id: variantId,
        productId,
        sku,
        barcode,
        name: `${newProdName} - ${newProdUnit}`,
        unit: newProdUnit,
        attributes: { 'Pack Size': `1 ${newProdUnit}` },
        mrp,
        price,
        cost,
        marginPercent: mrp > 0 ? Number((((price - cost) / price) * 100).toFixed(1)) : 25,
        onHand: initialStock,
        available: initialStock,
        reserved: 0,
        reorderLevel: reorder,
        isParent: true,
        image: defaultImage,
        version: 1,
      };

      const newProduct: Product = {
        id: productId,
        name: newProdName,
        description: `${newProdName} (${newProdBrand}) - Fresh store stock.`,
        category: finalCategory,
        brand: newProdBrand,
        unit: newProdUnit,
        baseSku: sku,
        baseBarcode: barcode,
        basePrice: price,
        baseMrp: mrp,
        baseCost: cost,
        image: defaultImage,
        imageUrl: defaultImage,
        imagePath: finalDbPath,
        taxable: gstRate > 0,
        gstRate,
        attributes: [{ id: `attr_${Date.now()}`, name: 'Pack Size', values: [`1 ${newProdUnit}`] }],
        variants: [newVariant],
        status: 'active',
        dailyConsumptionRate: 15.0,
        leadTimeDays: 2,
        supplierId: 'sup_apmc_mandi',
        totalOnHand: initialStock,
        totalAvailable: initialStock,
      };

      await createProductWithVariants(newProduct);
      setIsAddModalOpen(false);

      // Reset Form
      setNewProdName('');
      setIsCustomCategoryActive(false);
      setCustomCategoryInput('');
      setNewProdSku('');
      setNewProdBarcode('');
      setNewProdPrice('40.00');
      setNewProdStock('50');

      setNotificationNotice(`✓ Added "${newProduct.name}" (${sku}) to catalog`);
      setTimeout(() => setNotificationNotice(null), 3500);
    } catch (err: any) {
      console.error('Error adding product:', err);
      setNotificationNotice(`Error adding item: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleStockAdjustmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustStockModal) return;
    const delta = parseInt(adjustDelta, 10) || 0;
    const actualDelta = adjustReason === 'DAMAGE_WASTAGE' ? -Math.abs(delta) : delta;
    await updateProductStock(adjustStockModal.variant.id, actualDelta, adjustReason);
    setAdjustStockModal(null);
    playSuccessChime();
    setNotificationNotice(`✓ Stock adjusted by ${actualDelta > 0 ? '+' : ''}${actualDelta} for ${adjustStockModal.product.name}`);
    setTimeout(() => setNotificationNotice(null), 3000);
  };

  return (
    <div className="flex-1 w-full h-full min-h-0 bg-[#F4F4F5] p-3 sm:p-4 lg:p-5 flex flex-col gap-3 font-sans overflow-hidden">
      {/* Top Fixed Control Area */}
      <div className="shrink-0 flex flex-col gap-2.5">
        {/* Header & Sub-tab Bar */}
        <div className="bg-white p-3 sm:p-3.5 rounded-xl border border-[#D4D4D8] shadow-2xs flex flex-col gap-2.5">
          {/* Top Status & Title Row - Single Line */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2.5 min-w-0 flex-wrap sm:flex-nowrap">
              <div className="w-8 h-8 rounded-lg bg-[#00478c]/10 text-[#00478c] flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-[20px]">admin_panel_settings</span>
              </div>
              <h1 className="text-base sm:text-lg font-extrabold text-[#09090B] tracking-tight whitespace-nowrap">
                Admin &amp; Operations Control
              </h1>
              <span className="px-2 py-0.5 bg-blue-50 border border-blue-200 text-[#00478c] text-[11px] font-bold rounded-full whitespace-nowrap shrink-0">
                {products.length} Products
              </span>
              {isDbConnected && (
                <span className="px-2 py-0.5 bg-emerald-50 border border-emerald-300 text-emerald-800 text-[11px] font-bold rounded-full flex items-center gap-1 whitespace-nowrap shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                  Local DB Active
                </span>
              )}
            </div>

            {/* Operator Role & Identity - Single Line */}
            <div className="text-xs text-[#5c403c] flex items-center gap-1.5 whitespace-nowrap shrink-0 bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-200">
              <span className="material-symbols-outlined text-[15px] text-gray-500">account_circle</span>
              <span>Role: <strong className="text-[#00478c]">{currentOperator.userRole || 'Admin'}</strong> ({currentOperator.name})</span>
              <span className="text-gray-400">•</span>
              <span className="text-gray-600 font-medium">{currentOperator.userRole === 'Staff' ? 'POS & Reporting only' : currentOperator.userRole === 'Supervisor' ? 'Catalog & Operations manager' : 'Full system administrator'}</span>
            </div>
          </div>

          {/* Sub-tab Navigation Bar - Responsive & Scrollable without clipping */}
          <div className="w-full overflow-x-auto pb-0.5 flex items-center gap-1.5 bg-gray-100/90 p-1 rounded-lg border border-gray-200 scrollbar-thin">
            {/* Sub-tab: Catalog */}
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setAdminSubTab('catalog');
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                adminSubTab === 'catalog'
                  ? 'bg-[#00478c] text-white shadow-xs'
                  : 'text-gray-700 hover:text-[#00478c] hover:bg-white/60'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">inventory_2</span>
              <span>Catalog &amp; Stock</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                adminSubTab === 'catalog' ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
              }`}>
                {products.length}
              </span>
            </button>

            {/* Sub-tab: Customer Loyalty Rewards Program */}
            {canManageUsers && (
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setAdminSubTab('loyalty');
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  adminSubTab === 'loyalty'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-amber-900 hover:text-amber-700 hover:bg-white/60'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">loyalty</span>
                <span>Customer Loyalty Program</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  adminSubTab === 'loyalty' ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-900'
                }`}>
                  Rewards
                </span>
              </button>
            )}

            {/* Sub-tab: Outlet Profile & Tax */}
            {canManageUsers && (
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setAdminSubTab('outlet');
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  adminSubTab === 'outlet'
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'text-gray-700 hover:text-blue-700 hover:bg-white/60'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">storefront</span>
                <span>Outlet Profile &amp; GST/PAN</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  adminSubTab === 'outlet' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-800'
                }`}>
                  Store Info
                </span>
              </button>
            )}

            {/* Sub-tab: User Management */}
            {canManageUsers && (
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setAdminSubTab('users');
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  adminSubTab === 'users'
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'text-gray-700 hover:text-purple-700 hover:bg-white/60'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">badge</span>
                <span>User Management</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  adminSubTab === 'users' ? 'bg-white/20 text-white' : 'bg-purple-100 text-purple-800'
                }`}>
                  Admin Only
                </span>
              </button>
            )}

          </div>
        </div>

        {/* Notification Banner */}
        {notificationNotice && (
          <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-3 py-1.5 rounded text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
            <span>{notificationNotice}</span>
          </div>
        )}
      </div>

      {/* Main Content: Loyalty Tab OR Outlet Tab OR User Management Tab OR Database Tab OR Products & Catalog Tab */}
      {canManageUsers && adminSubTab === 'loyalty' ? (
        <div className="flex-1 min-h-0 overflow-y-auto pr-1">
          <LoyaltyProgramTab />
        </div>
      ) : canManageUsers && adminSubTab === 'outlet' ? (
        <div className="flex-1 min-h-0 overflow-y-auto pr-1">
          <OutletProfileTab />
        </div>
      ) : canManageUsers && adminSubTab === 'users' ? (
        <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
          <UserManagementTab />
        </div>
      ) : (
        <div className="flex-1 min-h-0 flex flex-col gap-2.5 overflow-hidden">
          {/* Catalog Toolbar & Actions */}
          <div className="shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-2.5 bg-white p-2.5 rounded-lg border border-[#D4D4D8] shadow-xs">
            <div className="flex items-center gap-2 flex-1 max-w-md">
              <div className="flex-1 flex items-center gap-2 bg-[#F4F4F5] border border-[#D4D4D8] rounded px-2.5 py-1.5 focus-within:border-[#00478c]">
                <span className="material-symbols-outlined text-gray-500 text-[17px]">search</span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search items by name, SKU, or barcode..."
                  className="bg-transparent text-xs text-[#09090B] font-medium outline-none w-full"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="text-gray-400 hover:text-gray-600">
                    <span className="material-symbols-outlined text-[15px]">close</span>
                  </button>
                )}
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="h-8 bg-[#F4F4F5] border border-[#D4D4D8] rounded px-2 text-xs font-semibold text-[#09090B] focus:outline-none focus:border-[#00478c] cursor-pointer"
              >
                <option value="All">All Categories ({products.length})</option>
                {categories.filter((c) => c !== 'All Items' && c !== 'All').map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              {/* Status Filter Pills: All / Active / Inactive */}
              <div className="flex items-center bg-[#F4F4F5] p-0.5 rounded border border-[#D4D4D8]">
                <button
                  type="button"
                  onClick={() => { playKeypadClick(); setStatusFilter('all'); }}
                  className={`px-2 py-1 rounded text-[11px] font-bold transition-all ${
                    statusFilter === 'all' ? 'bg-white text-[#00478c] shadow-xs' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  All ({products.length})
                </button>
                <button
                  type="button"
                  onClick={() => { playKeypadClick(); setStatusFilter('active'); }}
                  className={`px-2 py-1 rounded text-[11px] font-bold transition-all ${
                    statusFilter === 'active' ? 'bg-emerald-600 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Active ({activeCount})
                </button>
                <button
                  type="button"
                  onClick={() => { playKeypadClick(); setStatusFilter('inactive'); }}
                  className={`px-2 py-1 rounded text-[11px] font-bold transition-all ${
                    statusFilter === 'inactive' ? 'bg-gray-700 text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Inactive ({inactiveCount})
                </button>
              </div>

              {/* Toggle Filter: Only Active Deals */}
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setOnlyActiveOffers((prev) => !prev);
                }}
                className={`h-8 px-2.5 rounded text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                  onlyActiveOffers
                    ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white shadow-xs'
                    : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
                }`}
                title="Filter table to only products with active limited deals"
              >
                <span className="material-symbols-outlined text-[15px]">local_fire_department</span>
                <span>🔥 Deals ({activeOfferCount})</span>
              </button>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* CSV Export */}
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  const columns: CSVColumn<Product>[] = [
                    { header: 'Product ID', accessor: (p) => p.id },
                    { header: 'Product Name', accessor: (p) => p.name },
                    { header: 'Category', accessor: (p) => p.category },
                    { header: 'Unit', accessor: (p) => p.unit },
                    { header: 'SKU', accessor: (p) => p.variants[0]?.sku || p.baseSku },
                    { header: 'Barcode', accessor: (p) => p.variants[0]?.barcode || p.baseBarcode || '—' },
                    { header: 'Cost Price (Rs.)', accessor: (p) => (p.variants[0]?.cost || p.baseCost || 0).toFixed(2) },
                    { header: 'MRP (Rs.)', accessor: (p) => (p.variants[0]?.mrp || p.baseMrp || p.basePrice || 0).toFixed(2) },
                    { header: 'Selling Price (Rs.)', accessor: (p) => (p.variants[0]?.price || p.basePrice || 0).toFixed(2) },
                    { header: 'Stock On Hand', accessor: (p) => p.variants[0]?.onHand ?? p.totalOnHand ?? 0 },
                  ];
                  exportToCSV('master_inventory_catalog', products, columns);
                  playSuccessChime();
                  setNotificationNotice(`✓ Exported ${products.length} catalog items CSV`);
                  setTimeout(() => setNotificationNotice(null), 3000);
                }}
                title="Export master catalog CSV"
                className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-bold text-xs flex items-center gap-1 transition-all cursor-pointer shadow-xs"
              >
                <span className="material-symbols-outlined text-[16px]">upload</span>
                <span>Export CSV</span>
              </button>

              {/* Refresh DB */}
              <button
                type="button"
                onClick={async () => {
                  playKeypadClick();
                  await refreshProducts();
                  playSuccessChime();
                  setNotificationNotice(`✓ Refreshed ${products.length} items from database`);
                  setTimeout(() => setNotificationNotice(null), 3000);
                }}
                disabled={isLoadingProducts}
                className="px-2.5 py-1.5 bg-white hover:bg-blue-50 border border-gray-300 hover:border-[#00478c] text-[#00478c] rounded font-bold text-xs flex items-center gap-1 transition-all cursor-pointer disabled:opacity-50"
              >
                <span className={`material-symbols-outlined text-[16px] ${isLoadingProducts ? 'animate-spin' : ''}`}>
                  refresh
                </span>
                <span>{isLoadingProducts ? '...' : 'Reload DB'}</span>
              </button>

              {/* Manage Deals & Promotional Offers Button (Admin/Supervisor) */}
              {canManageCatalog && (
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setIsDealsManagerOpen(true);
                  }}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 hover:border-rose-300 text-rose-800 rounded font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  title="Create, add, and manage promotional deals and discounts"
                >
                  <span className="material-symbols-outlined text-[16px] text-rose-600">local_fire_department</span>
                  <span>Deals &amp; Offers ({activeOfferCount})</span>
                </button>
              )}

              {/* Manage Categories Button */}
              {canManageCatalog && (
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setIsCategoryManagerOpen(true);
                  }}
                  className="px-3 py-1.5 bg-white hover:bg-gray-100 border border-gray-300 hover:border-gray-400 text-gray-800 rounded font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  title="View, Add, Rename, or Delete Categories with confirmation"
                >
                  <span className="material-symbols-outlined text-[16px] text-[#00478c]">category</span>
                  <span>Categories</span>
                </button>
              )}

              {/* Add Item Button (Protected for Admin/Supervisor) */}
              {canManageCatalog ? (
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    const nextInfo = getNextSequentialSku(products);
                    setNewProdSku(nextInfo.sku);
                    setNewProdBarcode(`890${nextInfo.seq.toString().padStart(7, '0')}`);
                    setNewProdName('');
                    setNewProdPrice('40.00');
                    setNewProdMrp('50.00');
                    setNewProdCost('28.00');
                    setNewProdStock('50');
                    setNewProdReorder('10');
                    setImagePreview(null);
                    setImageDbPath(null);
                    setUploadedFileName('');
                    setIsAddModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-[#00478c] hover:bg-[#00366a] text-white rounded font-bold text-xs flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                >
                  <span className="material-symbols-outlined text-[16px]">add_circle</span>
                  <span>Add New Item</span>
                </button>
              ) : (
                <div className="text-[11px] font-bold text-gray-500 bg-gray-100 px-2.5 py-1.5 rounded border border-gray-200 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">lock</span>
                  <span>Add Item (Requires Admin)</span>
                </div>
              )}
            </div>
          </div>

          {/* Catalog Table Container with Dedicated Scrolling */}
          <div className="flex-1 min-h-0 bg-white rounded-lg border border-[#D4D4D8] shadow-xs flex flex-col overflow-hidden">
        {/* Table Scroll Area */}
        <div className="flex-1 min-h-0 overflow-y-auto overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="sticky top-0 bg-[#F4F4F5] z-10 border-b border-[#D4D4D8] shadow-xs">
              <tr className="text-[#5c403c] font-label-caps uppercase font-bold tracking-wider">
                <th className="py-2.5 px-4 bg-[#F4F4F5]">Item Details &amp; Image</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5]">Category</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5]">SKU / Barcode</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-right">Cost (Rs.)</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-right">MRP (Rs.)</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-right">Selling Price</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-center">Status</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-center">Deal / Offer</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-center">Stock On Hand</th>
                <th className="py-2.5 px-4 bg-[#F4F4F5] text-center">Admin Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D4D4D8]">
              {paginatedProducts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-gray-500 font-medium">
                    No matching items found. Click "+ Add New Item" above to create one.
                  </td>
                </tr>
              ) : (
                paginatedProducts.map((prod) => {
                  const variant = prod.variants[0];
                  const onHand = prod.totalOnHand ?? variant?.onHand ?? 0;
                  const isLow = onHand <= (variant?.reorderLevel || 10);
                  const offerInfo = getProductOfferInfo(prod, variant);

                  return (
                    <tr key={prod.id} className="hover:bg-[#F4F4F5]/60 transition-colors">
                      {/* Item Details with Image */}
                      <td className="py-2.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded border border-[#D4D4D8] bg-[#f8f9fa] shrink-0 overflow-hidden flex items-center justify-center relative">
                            {getProductImageUrl(prod, variant) ? (
                              <img
                                src={getProductImageUrl(prod, variant)}
                                alt={prod.name}
                                className="w-full h-full object-cover"
                                onError={(e) => handleProductImageError(e, prod)}
                              />
                            ) : null}
                            <div className={`img-fallback ${getProductImageUrl(prod, variant) ? 'hidden' : ''} flex items-center justify-center w-full h-full bg-slate-100 text-gray-400`}>
                              <span className="material-symbols-outlined text-[18px]">shopping_bag</span>
                            </div>
                          </div>
                          <div>
                            <div className="font-bold text-xs text-[#09090B] flex items-center gap-1.5">
                              {prod.name}
                              <span className="text-[10px] text-gray-400 font-mono">({prod.id})</span>
                            </div>
                            <div className="text-[10px] text-[#5c403c]">
                              {prod.brand || 'Amma & Appa Kadai'} • Unit: {prod.unit || 'kg'}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-2.5 px-4">
                        <span className="px-2 py-0.5 bg-blue-50 text-[#00478c] border border-blue-200 rounded font-semibold text-[11px]">
                          {prod.category}
                        </span>
                      </td>

                      {/* SKU & Barcode */}
                      <td className="py-2.5 px-4 font-tabular-numeric">
                        <div className="font-mono text-gray-800 font-bold">{variant?.sku || prod.baseSku}</div>
                        <div className="font-mono text-[10px] text-gray-500">{variant?.barcode || prod.baseBarcode || '—'}</div>
                      </td>

                      {/* Cost */}
                      <td className="py-2.5 px-4 text-right font-tabular-numeric text-gray-600">
                        Rs. {(variant?.cost || prod.baseCost || 0).toFixed(2)}
                      </td>

                      {/* MRP */}
                      <td className="py-2.5 px-4 text-right font-tabular-numeric text-gray-500">
                        Rs. {(variant?.mrp || prod.baseMrp || prod.basePrice || 0).toFixed(2)}
                      </td>

                      {/* Price */}
                      <td className="py-2.5 px-4 text-right font-tabular-numeric font-bold text-[#00478c] text-xs">
                        Rs. {(variant?.price || prod.basePrice || 0).toFixed(2)}
                      </td>

                      {/* Status Toggle Badge */}
                      <td className="py-2.5 px-4 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(prod.id, prod.status)}
                          title={`Click to toggle status (Currently ${prod.status === 'inactive' ? 'Inactive' : 'Active'})`}
                          className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition-colors cursor-pointer inline-flex items-center gap-1 ${
                            prod.status === 'inactive'
                              ? 'bg-gray-100 text-gray-500 border-gray-300 hover:bg-emerald-50 hover:text-emerald-700'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-gray-100 hover:text-gray-600'
                          }`}
                        >
                          <span className={`w-2 h-2 rounded-full ${prod.status === 'inactive' ? 'bg-gray-400' : 'bg-emerald-500'}`} />
                          <span>{prod.status === 'inactive' ? 'Inactive' : 'Active'}</span>
                        </button>
                      </td>

                      {/* Offer / Deal Column */}
                      <td className="py-2.5 px-4 text-center">
                        {offerInfo.hasOffer ? (
                          <div className="inline-flex flex-col items-center gap-1">
                            <div className="flex items-center gap-1 bg-rose-50 border border-rose-300 px-2 py-0.5 rounded-full text-[10px] font-bold text-rose-800 shadow-2xs">
                              <span className="material-symbols-outlined text-[13px] text-rose-600">local_fire_department</span>
                              <span>{offerInfo.badgeLabel}</span>
                            </div>
                            <div className="text-[10px] font-extrabold text-rose-700 font-tabular-numeric">
                              Rs. {offerInfo.discountedPrice.toFixed(2)}
                            </div>
                            <button
                              onClick={(e) => handleOpenOfferModal(prod, e)}
                              className="text-[10px] text-rose-700 underline hover:text-rose-900 font-semibold cursor-pointer"
                              title="Edit or deactivate offer"
                            >
                              Edit Deal
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={(e) => handleOpenOfferModal(prod, e)}
                            className="px-2 py-1 bg-gray-50 hover:bg-rose-50 border border-dashed border-gray-300 hover:border-rose-400 text-gray-600 hover:text-rose-800 rounded text-[10px] font-bold transition-colors cursor-pointer inline-flex items-center gap-0.5"
                            title="Set limited period discount or Deal of the Day"
                          >
                            <span className="material-symbols-outlined text-[13px]">percent</span>
                            <span>+ Set Deal</span>
                          </button>
                        )}
                      </td>

                      {/* Stock Level */}
                      <td className="py-2.5 px-4 text-center">
                        <div className="inline-flex flex-col items-center">
                          <span
                            className={`px-2 py-0.5 rounded-full font-bold font-tabular-numeric text-[11px] ${
                              isLow
                                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                : 'bg-emerald-100 text-emerald-900'
                            }`}
                          >
                            {onHand} {prod.unit || 'kg'}
                          </span>
                          {isLow && (
                            <span className="text-[9px] text-amber-700 font-bold mt-0.5">
                              Low Stock (&lt;{variant?.reorderLevel || 10})
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Admin Controls: Edit, Delete, Barcode, Stock */}
                      <td className="py-2.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                          {/* EDIT BUTTON */}
                          <button
                            onClick={() => handleOpenEditModal(prod)}
                            className="px-2 py-1 bg-blue-50 hover:bg-[#00478c] text-[#00478c] hover:text-white border border-[#00478c]/30 rounded font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                            title={`Edit ${prod.name}`}
                          >
                            <span className="material-symbols-outlined text-[14px]">edit</span>
                            <span>Edit</span>
                          </button>

                          {/* DELETE BUTTON */}
                          <button
                            onClick={() => {
                              playKeypadClick();
                              setDeletingProduct(prod);
                            }}
                            className="px-2 py-1 bg-red-50 hover:bg-red-600 text-red-600 hover:text-white border border-red-200 rounded font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                            title={`Delete ${prod.name}`}
                          >
                            <span className="material-symbols-outlined text-[14px]">delete</span>
                            <span>Delete</span>
                          </button>

                          {/* Print Barcode Button */}
                          <button
                            onClick={() => {
                              playKeypadClick();
                              setSelectedProductForPrint({ product: prod, variant });
                            }}
                            className="p-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded font-bold transition-colors cursor-pointer"
                            title="Generate and Print Barcode Label"
                          >
                            <span className="material-symbols-outlined text-[15px]">barcode</span>
                          </button>

                          {/* Quick Adjust Stock */}
                          <button
                            onClick={() => {
                              playKeypadClick();
                              setAdjustStockModal({ product: prod, variant });
                            }}
                            className="p-1 px-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded font-semibold text-xs transition-colors cursor-pointer"
                            title="Stock In / Adjustment"
                          >
                            ±
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination & Summary Footer */}
        <div className="p-2.5 bg-[#F4F4F5] border-t border-[#D4D4D8] flex flex-wrap items-center justify-between gap-3 text-xs text-[#5c403c] shrink-0 font-medium select-none">
          <div className="flex items-center gap-2">
            <span>
              Showing <strong className="text-[#09090B]">{startIndex}</strong>–<strong className="text-[#09090B]">{endIndex}</strong> of{' '}
              <strong className="text-[#09090B]">{totalItems}</strong> items
            </span>

            <span className="text-gray-300">|</span>

            {/* Page Size Selector */}
            <div className="flex items-center gap-1.5">
              <span>Per page:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  const val = e.target.value;
                  setPageSize(val === 'All' ? 'All' : parseInt(val, 10));
                }}
                className="h-7 bg-white border border-[#D4D4D8] rounded px-2 text-xs font-semibold text-[#09090B] focus:outline-none cursor-pointer"
              >
                <option value={20}>20</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
                <option value="All">All ({totalItems})</option>
              </select>
            </div>
          </div>

          {/* Page Navigation Controls */}
          {pageSize !== 'All' && totalPages > 1 && (
            <div className="flex items-center gap-1">
              <button
                type="button"
                disabled={safeCurrentPage <= 1}
                onClick={() => {
                  playKeypadClick();
                  setCurrentPage(1);
                }}
                className="px-2 py-1 rounded bg-white border border-[#D4D4D8] hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold"
                title="First Page"
              >
                « First
              </button>
              <button
                type="button"
                disabled={safeCurrentPage <= 1}
                onClick={() => {
                  playKeypadClick();
                  setCurrentPage((p) => Math.max(1, p - 1));
                }}
                className="px-2.5 py-1 rounded bg-white border border-[#D4D4D8] hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold"
                title="Previous Page"
              >
                ‹ Prev
              </button>

              <span className="px-2 py-1 text-xs font-bold text-[#00478c] bg-blue-50 border border-blue-200 rounded">
                Page {safeCurrentPage} of {totalPages}
              </span>

              <button
                type="button"
                disabled={safeCurrentPage >= totalPages}
                onClick={() => {
                  playKeypadClick();
                  setCurrentPage((p) => Math.min(totalPages, p + 1));
                }}
                className="px-2.5 py-1 rounded bg-white border border-[#D4D4D8] hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold"
                title="Next Page"
              >
                Next ›
              </button>
              <button
                type="button"
                disabled={safeCurrentPage >= totalPages}
                onClick={() => {
                  playKeypadClick();
                  setCurrentPage(totalPages);
                }}
                className="px-2 py-1 rounded bg-white border border-[#D4D4D8] hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold"
                title="Last Page"
              >
                Last »
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )}

      {/* EDIT PRODUCT MODAL */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => !isSaving && setEditingProduct(null)} />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-2xl p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c] text-2xl">edit_note</span>
                <div>
                  <h3 className="font-bold text-lg text-[#09090B]">Edit Product &amp; Pricing</h3>
                  <p className="text-xs text-[#5c403c]">Updating {editingProduct.name} ({editingProduct.id})</p>
                </div>
              </div>
              <button
                disabled={isSaving}
                onClick={() => setEditingProduct(null)}
                className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleEditProductSubmit} className="space-y-4 text-xs">
              {/* Product Name */}
              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">ITEM NAME *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-semibold text-[#09090B] focus:border-[#00478c] focus:outline-none"
                />
              </div>

              {/* IMAGE SECTION */}
              <div className="bg-[#fcfdff] p-3.5 rounded-lg border border-[#00478c]/20 space-y-2.5">
                <label className="block font-bold text-[#00478c] uppercase flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">image</span>
                  Product Image / Photo
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <div className="relative w-20 h-20 rounded-lg border-2 border-dashed border-[#00478c]/40 bg-white overflow-hidden shrink-0 flex items-center justify-center shadow-xs">
                    {editImagePreview ? (
                      <img src={editImagePreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <span className="material-symbols-outlined text-3xl text-gray-300">image</span>
                    )}
                  </div>
                  <div className="flex-1 w-full space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        ref={editFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleEditImageFileChange}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setImageLibraryTarget('edit');
                          setIsImageLibraryOpen(true);
                        }}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <span className="material-symbols-outlined text-[16px]">photo_library</span>
                        Select from Image Library
                      </button>
                      <button
                        type="button"
                        onClick={() => editFileInputRef.current?.click()}
                        className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300 rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <span className="material-symbols-outlined text-[16px]">upload_file</span>
                        Upload File
                      </button>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 bg-white border border-[#D4D4D8] rounded px-2.5 py-1 text-[11px] font-mono text-gray-700">
                        <span className="text-[#5c403c] font-sans font-bold text-[10px]">Path:</span>
                        <span className="text-[#00478c] truncate flex-1">{editImageDbPath || editImagePreview || '/images/products/default_product.jpg'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Preset Selector for Edit */}
                <div className="pt-1.5 border-t border-gray-200">
                  <div className="text-[10px] font-bold text-[#5c403c] uppercase mb-1">Or Pick Preset Image:</div>
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {IMAGE_PRESETS.slice(0, 10).map((preset) => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() => {
                          setEditImagePreview(preset.url);
                          setEditImageDbPath(preset.path);
                        }}
                        className={`px-2 py-1 rounded text-[10px] font-semibold whitespace-nowrap border transition-colors cursor-pointer ${
                          editImageDbPath === preset.path || editImagePreview === preset.url
                            ? 'bg-[#00478c] text-white border-[#00478c]'
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                        }`}
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* CATEGORY SELECTION */}
              <div className="bg-blue-50/60 p-3 rounded-lg border border-blue-200 space-y-2">
                <label className="block font-bold text-[#00478c] uppercase">CATEGORY *</label>
                {!isEditCustomCategory ? (
                  <div className="flex gap-2">
                    <select
                      value={editCategory}
                      onChange={(e) => {
                        if (e.target.value === '__ADD_NEW_CATEGORY__') {
                          setIsEditCustomCategory(true);
                          setEditCustomCategoryInput('');
                        } else {
                          setEditCategory(e.target.value);
                        }
                      }}
                      className="flex-1 h-9 bg-white border border-[#00478c]/40 rounded px-3 text-xs font-semibold text-[#09090B] focus:outline-none"
                    >
                      {categories.filter((c) => c !== 'All Items' && c !== 'All').map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                      <option value="__ADD_NEW_CATEGORY__" className="text-[#00478c] font-bold">
                        + Add New Category...
                      </option>
                    </select>
                    <button
                      type="button"
                      onClick={() => setIsEditCustomCategory(true)}
                      className="px-3 py-1.5 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7] cursor-pointer"
                    >
                      + New
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      autoFocus
                      required
                      value={editCustomCategoryInput}
                      onChange={(e) => setEditCustomCategoryInput(e.target.value)}
                      placeholder="Type new category name..."
                      className="flex-1 h-9 bg-white border-2 border-[#00478c] rounded px-3 text-xs font-bold text-[#09090B] focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (editCustomCategoryInput.trim()) {
                          addCategory(editCustomCategoryInput.trim());
                          setEditCategory(editCustomCategoryInput.trim());
                          setIsEditCustomCategory(false);
                        }
                      }}
                      className="px-3 py-1.5 bg-emerald-600 text-white rounded font-bold text-xs hover:bg-emerald-700 cursor-pointer"
                    >
                      Confirm
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditCustomCategory(false)}
                      className="px-2.5 py-1.5 bg-gray-200 text-gray-700 rounded font-medium text-xs hover:bg-gray-300 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>

              {/* Brand & Unit */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">BRAND / SOURCE</label>
                  <input
                    type="text"
                    value={editBrand}
                    onChange={(e) => setEditBrand(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">UNIT OF MEASUREMENT</label>
                  <select
                    value={editUnit}
                    onChange={(e) => setEditUnit(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  >
                    <option value="kg">kg (Kilogram)</option>
                    <option value="g">g (Gram - 250g, 500g)</option>
                    <option value="pack">pack (Packet / Pouch)</option>
                    <option value="pc">pc (Piece / Single Item)</option>
                    <option value="dozen">dozen (12 pcs - Bananas, Eggs)</option>
                    <option value="L">L (Litre - Milk, Oil)</option>
                    <option value="bunch">bunch (Coriander, Methi)</option>
                  </select>
                </div>
              </div>

              {/* SKU & Barcode */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">SKU CODE</label>
                  <input
                    type="text"
                    value={editSku}
                    onChange={(e) => setEditSku(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-mono text-[#09090B]"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-bold text-[#5c403c] uppercase">BARCODE NUMBER</label>
                    <button
                      type="button"
                      onClick={() => setIsScanningBarcode(isScanningBarcode === 'edit' ? null : 'edit')}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                        isScanningBarcode === 'edit'
                          ? 'bg-emerald-600 text-white animate-pulse'
                          : 'bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[13px]">barcode_scanner</span>
                      <span>{isScanningBarcode === 'edit' ? 'Scanning (Scan item)...' : 'Scan'}</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    value={editBarcode}
                    onChange={(e) => setEditBarcode(e.target.value)}
                    placeholder="Scan with scanner or type..."
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-mono text-[#09090B]"
                  />
                </div>
              </div>

              {/* Pricing */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#F4F4F5] p-3 rounded-lg border border-[#D4D4D8]">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">PURCHASE COST (RS.)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={editCost}
                    onChange={(e) => setEditCost(e.target.value)}
                    className="w-full h-9 bg-white border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">MRP (RS.)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={editMrp}
                    onChange={(e) => setEditMrp(e.target.value)}
                    className="w-full h-9 bg-white border border-[#D4D4D8] rounded px-3 text-sm font-bold text-gray-700"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#00478c] mb-1 uppercase">SELLING PRICE (RS.) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value)}
                    className="w-full h-9 bg-white border-2 border-[#00478c] rounded px-3 text-sm font-bold text-[#00478c]"
                  />
                </div>
              </div>

              {/* Stock & GST */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">STORE STOCK (ON HAND)</label>
                  <input
                    type="number"
                    value={editStock}
                    onChange={(e) => setEditStock(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">LOW STOCK ALERT LEVEL</label>
                  <input
                    type="number"
                    value={editReorder}
                    onChange={(e) => setEditReorder(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">GST TAX SLAB</label>
                  <select
                    value={editGst}
                    onChange={(e) => setEditGst(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  >
                    <option value="0">0% (Vegetables / Fresh Milk)</option>
                    <option value="5">5% (Atta / Rice / Dals)</option>
                    <option value="12">12% (Ghee / Namkeen)</option>
                    <option value="18">18% (Packaged Drinks / Cleaning)</option>
                  </select>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-3 pt-3 border-t border-[#D4D4D8]">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 border border-[#D4D4D8] text-gray-700 rounded font-semibold text-xs hover:bg-gray-100 cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7] shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSaving ? (
                    <>
                      <span className="material-symbols-outlined text-[16px] animate-spin">sync</span>
                      <span>Saving Changes...</span>
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[16px]">save</span>
                      <span>Save Changes to Database</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CATEGORY MANAGER MODAL */}
      {isCategoryManagerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setIsCategoryManagerOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-lg p-6 shadow-2xl space-y-4 max-h-[90vh] flex flex-col animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c]">category</span>
                <div>
                  <h3 className="font-bold text-base text-[#09090B]">Manage Product Categories</h3>
                  <p className="text-xs text-gray-500">{categories.filter(c => c !== 'All' && c !== 'All Items').length} active catalog categories</p>
                </div>
              </div>
              <button
                onClick={() => setIsCategoryManagerOpen(false)}
                className="text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {/* Quick Add Category Input */}
            <form onSubmit={handleAddCategoryFromManager} className="flex gap-2 shrink-0">
              <input
                type="text"
                value={newCategoryManagerInput}
                onChange={(e) => setNewCategoryManagerInput(e.target.value)}
                placeholder="Enter new category name..."
                className="flex-1 bg-[#F4F4F5] border border-[#D4D4D8] rounded-lg px-3 py-2 text-xs font-semibold text-[#09090B] focus:bg-white focus:border-[#00478c] outline-none"
              />
              <button
                type="submit"
                disabled={!newCategoryManagerInput.trim()}
                className="px-4 py-2 bg-[#00478c] hover:bg-[#00366a] disabled:opacity-50 text-white rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer transition-all shadow-xs shrink-0"
              >
                <span className="material-symbols-outlined text-[16px]">add</span>
                <span>Add Category</span>
              </button>
            </form>

            {/* Categories List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[220px]">
              {categories
                .filter((c) => c !== 'All' && c !== 'All Items' && c !== '__OFFERS__')
                .map((cat) => {
                  const itemCount = products.filter((p) => p.category === cat).length;
                  const isEditingThis = editingCategoryName?.oldName === cat;

                  return (
                    <div
                      key={cat}
                      className="p-3 bg-[#F4F4F5] hover:bg-gray-100 border border-[#D4D4D8] rounded-lg flex items-center justify-between gap-3 transition-colors"
                    >
                      {isEditingThis ? (
                        <div className="flex items-center gap-2 flex-1">
                          <input
                            type="text"
                            value={editingCategoryName.newName}
                            onChange={(e) =>
                              setEditingCategoryName({ ...editingCategoryName, newName: e.target.value })
                            }
                            autoFocus
                            className="flex-1 bg-white border border-[#00478c] rounded px-2 py-1 text-xs font-bold outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveRenameCategory(cat)}
                            className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold cursor-pointer"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingCategoryName(null)}
                            className="px-2 py-1 text-gray-500 hover:bg-gray-200 rounded text-xs font-bold cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="font-bold text-xs text-[#09090B] truncate">{cat}</span>
                            <span className="text-[11px] px-2 py-0.5 bg-blue-100/80 text-[#00478c] font-bold rounded-full shrink-0">
                              {itemCount} {itemCount === 1 ? 'item' : 'items'}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => setEditingCategoryName({ oldName: cat, newName: cat })}
                              className="p-1 text-gray-500 hover:text-[#00478c] hover:bg-white rounded cursor-pointer"
                              title="Rename Category"
                            >
                              <span className="material-symbols-outlined text-[16px]">edit</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setCategoryToDelete(cat);
                                const otherCat = categories.find((c) => c !== cat && c !== 'All' && c !== 'All Items') || 'Fresh Vegetables';
                                setReassignTargetCategory(otherCat);
                              }}
                              className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                              title={`Delete Category "${cat}"`}
                            >
                              <span className="material-symbols-outlined text-[16px]">delete</span>
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
            </div>

            <div className="pt-3 border-t border-[#D4D4D8] flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => setIsCategoryManagerOpen(false)}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-bold text-xs cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM CATEGORY DELETION MODAL */}
      {categoryToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => !isDeletingCategory && setCategoryToDelete(null)}
          />
          <div className="relative z-60 bg-white rounded-xl border border-red-300 w-full max-w-md p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2.5 bg-red-100 rounded-full shrink-0">
                <span className="material-symbols-outlined text-2xl">delete_forever</span>
              </div>
              <div>
                <h3 className="font-bold text-base text-[#09090B]">Delete Category?</h3>
                <p className="text-xs text-red-600 font-semibold">Requires confirmation and product reassignment</p>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-3.5 space-y-2 text-xs text-gray-800">
              <div>
                <span className="font-bold text-gray-600">Category to Delete:</span>{' '}
                <span className="font-bold text-red-700 text-sm">{categoryToDelete}</span>
              </div>
              <div>
                <span className="font-bold text-gray-600">Affected Items:</span>{' '}
                <span className="font-bold text-[#09090B]">
                  {products.filter((p) => p.category === categoryToDelete).length} item(s) in catalog
                </span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700">
                Reassign existing items to:
              </label>
              <select
                value={reassignTargetCategory}
                onChange={(e) => setReassignTargetCategory(e.target.value)}
                className="w-full bg-[#F4F4F5] border border-[#D4D4D8] rounded-lg px-3 py-2 text-xs font-bold text-[#09090B] focus:bg-white focus:border-[#00478c] outline-none cursor-pointer"
              >
                {categories
                  .filter((c) => c !== categoryToDelete && c !== 'All' && c !== 'All Items' && c !== '__OFFERS__')
                  .map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
              </select>
              <p className="text-[11px] text-gray-500">
                All products previously under "{categoryToDelete}" will be moved safely to this category.
              </p>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeletingCategory}
                onClick={() => setCategoryToDelete(null)}
                className="px-4 py-2 border border-[#D4D4D8] text-gray-700 rounded font-semibold text-xs hover:bg-gray-100 cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeletingCategory}
                onClick={handleConfirmDeleteCategory}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded font-bold text-xs shadow-sm flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeletingCategory ? (
                  <>
                    <span className="material-symbols-outlined text-[16px] animate-spin">sync</span>
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[16px]">delete</span>
                    <span>Confirm Delete Category</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => !isDeleting && setDeletingProduct(null)} />
          <div className="relative z-50 bg-white rounded-lg border border-red-300 w-full max-w-md p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2.5 bg-red-100 rounded-full">
                <span className="material-symbols-outlined text-2xl">delete_forever</span>
              </div>
              <div>
                <h3 className="font-bold text-lg text-[#09090B]">Confirm Item Deletion</h3>
                <p className="text-xs text-red-600 font-semibold">This action cannot be undone</p>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-3.5 space-y-1.5 text-xs text-gray-800">
              <div>
                <span className="font-bold text-gray-600">Item Name:</span>{' '}
                <span className="font-bold text-[#09090B]">{deletingProduct.name}</span>
              </div>
              <div>
                <span className="font-bold text-gray-600">SKU:</span>{' '}
                <span className="font-mono text-gray-700">{deletingProduct.baseSku}</span>
              </div>
              <div>
                <span className="font-bold text-gray-600">Category:</span>{' '}
                <span className="text-gray-700">{deletingProduct.category}</span>
              </div>
              <div>
                <span className="font-bold text-gray-600">Selling Price:</span>{' '}
                <span className="font-bold text-[#00478c]">Rs. {deletingProduct.basePrice}</span>
              </div>
            </div>

            <p className="text-xs text-gray-600">
              Are you sure you want to permanently delete this product and its variants from your local database catalog?
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setDeletingProduct(null)}
                className="px-4 py-2 border border-[#D4D4D8] text-gray-700 rounded font-semibold text-xs hover:bg-gray-100 cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDelete}
                className="px-5 py-2 bg-red-600 text-white rounded font-bold text-xs hover:bg-red-700 shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <span className="material-symbols-outlined text-[16px] animate-spin">sync</span>
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[16px]">delete</span>
                    <span>Delete Permanently</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD NEW PRODUCT MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => !isSaving && setIsAddModalOpen(false)} />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-2xl p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c]">add_box</span>
                <div>
                  <h3 className="font-bold text-lg text-[#09090B]">Add New Product to Catalog</h3>
                  <p className="text-xs text-[#5c403c]">Register item with live local database sync and barcode assignment</p>
                </div>
              </div>
              <button
                disabled={isSaving}
                onClick={() => setIsAddModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleAddProductSubmit} className="space-y-4 text-xs">
              {/* Product Name */}
              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">ITEM NAME *</label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Fresh Desi Tomatoes, Basmati Rice 5kg, Sunflower Oil 1L"
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B] focus:border-[#00478c] focus:outline-none"
                />
              </div>

              {/* IMAGE UPLOAD */}
              <div className="bg-[#fcfdff] p-3.5 rounded-lg border border-[#00478c]/20 space-y-2.5">
                <label className="block font-bold text-[#00478c] uppercase flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">image</span>
                  Product Image Upload / Preset
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <div className="relative w-20 h-20 rounded-lg border-2 border-dashed border-[#00478c]/40 bg-white overflow-hidden shrink-0 flex items-center justify-center shadow-xs">
                    {imagePreview ? (
                      <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <span className="material-symbols-outlined text-3xl text-gray-300">image</span>
                    )}
                  </div>
                  <div className="flex-1 w-full space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageFileChange}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3 py-1.5 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7] flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <span className="material-symbols-outlined text-[16px]">upload_file</span>
                        Upload Photo
                      </button>
                      {uploadedFileName && (
                        <span className="text-[11px] text-gray-600 font-medium truncate max-w-[200px]">
                          ✓ {uploadedFileName}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 bg-white border border-[#D4D4D8] rounded px-2.5 py-1 text-[11px] font-mono text-gray-700">
                      <span className="text-[#5c403c] font-sans font-bold text-[10px]">Path:</span>
                      <span className="text-[#00478c] truncate flex-1">{imageDbPath}</span>
                    </div>
                  </div>
                </div>

                {/* Preset Selector */}
                <div className="pt-1.5 border-t border-gray-200">
                  <div className="text-[10px] font-bold text-[#5c403c] uppercase mb-1">Or Pick Preset Image:</div>
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {IMAGE_PRESETS.slice(0, 8).map((preset) => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() => {
                          setImagePreview(preset.url);
                          setImageDbPath(preset.path);
                          setUploadedFileName(preset.name);
                        }}
                        className={`px-2 py-1 rounded text-[10px] font-semibold whitespace-nowrap border transition-colors cursor-pointer ${
                          imageDbPath === preset.path
                            ? 'bg-[#00478c] text-white border-[#00478c]'
                            : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                        }`}
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* CATEGORY */}
              <div className="bg-blue-50/60 p-3 rounded-lg border border-blue-200 space-y-2">
                <label className="block font-bold text-[#00478c] uppercase">CATEGORY *</label>
                {!isCustomCategoryActive ? (
                  <div className="flex gap-2">
                    <select
                      value={newProdCategory}
                      onChange={(e) => {
                        if (e.target.value === '__ADD_NEW_CATEGORY__') {
                          setIsCustomCategoryActive(true);
                          setCustomCategoryInput('');
                        } else {
                          setIsCustomCategoryActive(false);
                          setNewProdCategory(e.target.value);
                        }
                      }}
                      className="flex-1 h-9 bg-white border border-[#00478c]/40 rounded px-3 text-xs font-semibold text-[#09090B] focus:outline-none cursor-pointer"
                    >
                      {categories.filter((c) => c !== 'All Items' && c !== 'All').map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                      <option value="__ADD_NEW_CATEGORY__" className="text-[#00478c] font-bold">
                        + Add New Category...
                      </option>
                    </select>
                    <button
                      type="button"
                      onClick={() => {
                        setIsCustomCategoryActive(true);
                        setCustomCategoryInput('');
                      }}
                      className="px-3 py-1.5 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7] cursor-pointer"
                    >
                      + New
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      autoFocus
                      required
                      value={customCategoryInput}
                      onChange={(e) => setCustomCategoryInput(e.target.value)}
                      placeholder="Type new category name..."
                      className="flex-1 h-9 bg-white border-2 border-[#00478c] rounded px-3 text-xs font-bold text-[#09090B] focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (customCategoryInput.trim()) {
                          addCategory(customCategoryInput.trim());
                          setNewProdCategory(customCategoryInput.trim());
                          setIsCustomCategoryActive(false);
                        }
                      }}
                      className="px-3 py-1.5 bg-emerald-600 text-white rounded font-bold text-xs hover:bg-emerald-700 cursor-pointer"
                    >
                      Confirm
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsCustomCategoryActive(false)}
                      className="px-2.5 py-1.5 bg-gray-200 text-gray-700 rounded font-medium text-xs hover:bg-gray-300 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>

              {/* Brand & Unit */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">BRAND / SOURCE</label>
                  <input
                    type="text"
                    value={newProdBrand}
                    onChange={(e) => setNewProdBrand(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">UNIT OF MEASUREMENT</label>
                  <select
                    value={newProdUnit}
                    onChange={(e) => setNewProdUnit(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  >
                    <option value="kg">kg (Kilogram)</option>
                    <option value="g">g (Gram - 250g, 500g)</option>
                    <option value="pack">pack (Packet / Pouch)</option>
                    <option value="pc">pc (Piece / Single Item)</option>
                    <option value="dozen">dozen (12 pcs - Bananas, Eggs)</option>
                    <option value="L">L (Litre - Milk, Oil)</option>
                    <option value="bunch">bunch (Coriander, Methi)</option>
                  </select>
                </div>
              </div>

              {/* SKU & Barcode */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-bold text-[#5c403c] uppercase">SKU CODE *</label>
                    <span className="text-[10px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded font-mono font-bold">Format: SKU-XXXX</span>
                  </div>
                  <input
                    type="text"
                    value={newProdSku}
                    onChange={(e) => setNewProdSku(e.target.value)}
                    placeholder="e.g. SKU-0189"
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-mono font-bold text-[#09090B] focus:border-[#00478c] focus:outline-none"
                  />
                  <p className="text-[10px] text-gray-500 mt-1">Unique 4-digit zero-padded item identifier</p>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-bold text-[#5c403c] uppercase">BARCODE NUMBER</label>
                    <span className="text-[10px] text-gray-500 font-mono">EAN / POS</span>
                  </div>
                  <input
                    type="text"
                    value={newProdBarcode}
                    onChange={(e) => setNewProdBarcode(e.target.value)}
                    placeholder="e.g. 8900000189"
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-mono text-[#09090B] focus:border-[#00478c] focus:outline-none"
                  />
                  <p className="text-[10px] text-gray-500 mt-1">Barcode scanner compatible</p>
                </div>
              </div>

              {/* Pricing in Rs. */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#F4F4F5] p-3 rounded-lg border border-[#D4D4D8]">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">PURCHASE COST (RS.)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProdCost}
                    onChange={(e) => setNewProdCost(e.target.value)}
                    className="w-full h-9 bg-white border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">MRP (RS.)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProdMrp}
                    onChange={(e) => setNewProdMrp(e.target.value)}
                    className="w-full h-9 bg-white border border-[#D4D4D8] rounded px-3 text-sm font-bold text-gray-700"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#00478c] mb-1 uppercase">OUR SELLING PRICE (RS.) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(e.target.value)}
                    className="w-full h-9 bg-white border-2 border-[#00478c] rounded px-3 text-sm font-bold text-[#00478c]"
                  />
                </div>
              </div>

              {/* Initial Stock & Reorder Point */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">INITIAL STORE STOCK</label>
                  <input
                    type="number"
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">LOW STOCK ALERT AT</label>
                  <input
                    type="number"
                    value={newProdReorder}
                    onChange={(e) => setNewProdReorder(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#5c403c] mb-1 uppercase">GST TAX SLAB</label>
                  <select
                    value={newProdGst}
                    onChange={(e) => setNewProdGst(e.target.value)}
                    className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm text-[#09090B]"
                  >
                    <option value="0">0% (Fresh Vegetables / Milk)</option>
                    <option value="5">5% (Atta / Rice / Dals)</option>
                    <option value="12">12% (Ghee / Namkeen)</option>
                    <option value="18">18% (Packaged Drinks / Cleaning)</option>
                  </select>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex justify-end gap-3 pt-3 border-t border-[#D4D4D8]">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-[#D4D4D8] text-gray-700 rounded font-semibold text-xs hover:bg-gray-100 cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7] shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSaving ? (
                    <>
                      <span className="material-symbols-outlined text-[16px] animate-spin">sync</span>
                      <span>Adding to DB...</span>
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[16px]">add_circle</span>
                      <span>Save New Product to Database</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STOCK ADJUSTMENT MODAL */}
      {adjustStockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/50" onClick={() => setAdjustStockModal(null)} />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-md p-6 shadow-xl space-y-4 industrial-shadow animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <h3 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c]">swap_vert</span>
                Store Stock Adjustment
              </h3>
              <button onClick={() => setAdjustStockModal(null)} className="text-gray-400 hover:text-gray-600">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="bg-[#F4F4F5] p-3 rounded text-xs space-y-1">
              <div className="font-bold text-[#09090B]">{adjustStockModal.product.name}</div>
              <div className="text-gray-600 font-mono">SKU: {adjustStockModal.variant.sku}</div>
              <div className="font-semibold text-emerald-800">
                Current Stock: {adjustStockModal.variant.onHand} {adjustStockModal.variant.unit}
              </div>
            </div>

            <form onSubmit={handleStockAdjustmentSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#5c403c] mb-1">Reason for Adjustment</label>
                <select
                  value={adjustReason}
                  onChange={(e: any) => setAdjustReason(e.target.value)}
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-xs text-[#09090B]"
                >
                  <option value="GOODS_RECEIPT">Store Receipt (Mandi / Supplier Restock)</option>
                  <option value="DAMAGE_WASTAGE">Spoilage / Rotten / Damage (Deduct Stock)</option>
                  <option value="ADJUSTMENT">Physical Audit Count Adjustment</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#5c403c] mb-1">
                  Quantity ({adjustStockModal.variant.unit})
                </label>
                <input
                  type="number"
                  required
                  value={adjustDelta}
                  onChange={(e) => setAdjustDelta(e.target.value)}
                  placeholder="Enter quantity"
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAdjustStockModal(null)}
                  className="px-3 py-1.5 border border-[#D4D4D8] text-gray-700 rounded font-semibold text-xs hover:bg-gray-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#00478c] text-white rounded font-bold text-xs hover:bg-[#005eb7] cursor-pointer shadow-xs"
                >
                  Apply Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PROMOTIONS & DEALS MANAGER MODAL (ADMIN INVENTORY) */}
      {isDealsManagerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setIsDealsManagerOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl animate-in fade-in overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-[#D4D4D8] flex items-center justify-between bg-gradient-to-r from-rose-50 via-amber-50/50 to-white shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-xs">
                  <span className="material-symbols-outlined text-[22px]">local_fire_department</span>
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                    <span>Promotions &amp; Deals Manager</span>
                    <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-full text-xs font-bold border border-rose-200">
                      {activeOfferCount} Active Deals
                    </span>
                  </h3>
                  <p className="text-xs text-gray-500">
                    Create new discounts and manage promotional deals across all catalog products
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsDealsManagerOpen(false)}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 cursor-pointer"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>

            {/* Search and Filters */}
            <div className="p-3 border-b border-gray-200 bg-gray-50 flex items-center gap-3 shrink-0 flex-wrap">
              <div className="relative flex-1 min-w-[240px]">
                <span className="material-symbols-outlined absolute left-3 top-2 text-gray-400 text-base">
                  search
                </span>
                <input
                  type="text"
                  value={dealSearchQuery}
                  onChange={(e) => setDealSearchQuery(e.target.value)}
                  placeholder="Search catalog by product name, SKU, or category to create or edit deals..."
                  className="w-full bg-white border border-gray-300 rounded-lg pl-9 pr-8 py-1.5 text-xs text-gray-900 focus:border-[#00478c] focus:outline-none"
                />
                {dealSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setDealSearchQuery('')}
                    className="absolute right-2.5 top-2 text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[15px]">close</span>
                  </button>
                )}
              </div>
              <div className="text-xs text-gray-500 font-bold">
                {
                  products.filter((p) => {
                    const q = dealSearchQuery.trim().toLowerCase();
                    if (!q) return true;
                    return (
                      p.name.toLowerCase().includes(q) ||
                      (p.category || '').toLowerCase().includes(q) ||
                      (p.baseSku || '').toLowerCase().includes(q)
                    );
                  }).length
                }{' '}
                Products in Catalog
              </div>
            </div>

            {/* Catalog Deals Grid / Table */}
            <div className="flex-1 overflow-y-auto p-4 divide-y divide-gray-100 space-y-2">
              {(() => {
                const q = dealSearchQuery.trim().toLowerCase();
                const matchedProducts = products.filter((p) => {
                  if (!q) return true;
                  return (
                    p.name.toLowerCase().includes(q) ||
                    (p.category || '').toLowerCase().includes(q) ||
                    (p.baseSku || '').toLowerCase().includes(q)
                  );
                });

                if (matchedProducts.length === 0) {
                  return (
                    <div className="text-center py-12 text-gray-400 text-xs">
                      No products matched "{dealSearchQuery}".
                    </div>
                  );
                }

                return matchedProducts.map((p) => {
                  const hasDeal = isOfferActive(p);
                  const regularPrice = p.variants[0]?.price || p.basePrice || 0;
                  const mrp = p.variants[0]?.mrp || p.baseMrp || p.basePrice || 0;
                  const val = p.offerValue || 0;
                  const disc = p.offerType === 'flat' ? val : (regularPrice * val) / 100;
                  const dealPrice = Math.max(0, regularPrice - disc);
                  const onHand = p.variants[0]?.onHand ?? p.totalOnHand ?? 0;

                  return (
                    <div
                      key={p.id}
                      className={`pt-2.5 pb-2.5 px-3 rounded-lg border transition-all flex items-center justify-between gap-4 flex-wrap ${
                        hasDeal
                          ? 'bg-rose-50/60 border-rose-200'
                          : 'bg-white border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {/* Product Details */}
                      <div className="flex items-center gap-3 min-w-[220px]">
                        <div
                          className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                            hasDeal ? 'bg-rose-500 text-white shadow-xs' : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            {hasDeal ? 'local_fire_department' : 'inventory_2'}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-[#09090B] flex items-center gap-1.5">
                            <span>{p.name}</span>
                            <span className="text-[10px] text-gray-400 font-mono font-normal">
                              ({p.baseSku || p.variants[0]?.sku})
                            </span>
                          </h4>
                          <div className="text-[11px] text-gray-500 flex items-center gap-2 mt-0.5">
                            <span>Cat: {p.category}</span>
                            <span>•</span>
                            <span>Stock: {onHand} {p.unit}</span>
                            <span>•</span>
                            <span>MRP: Rs. {mrp.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Pricing and Deal Info */}
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-[11px] text-gray-500">Regular: Rs. {regularPrice.toFixed(2)}</div>
                          {hasDeal ? (
                            <div className="flex items-center gap-1.5 justify-end">
                              <span className="text-xs font-black text-rose-700">
                                Deal: Rs. {dealPrice.toFixed(2)}
                              </span>
                              <span className="px-1.5 py-0.2 bg-rose-600 text-white text-[10px] font-bold rounded">
                                {p.offerType === 'flat' ? `Rs. ${val} Off` : `${val}% Off`}
                              </span>
                            </div>
                          ) : (
                            <span className="text-[10px] text-gray-400 italic">No Deal Active</span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          {hasDeal ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleOpenOfferModal(p)}
                                className="px-2.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                                title="Edit this active deal"
                              >
                                <span className="material-symbols-outlined text-[14px]">edit</span>
                                <span>Edit Deal</span>
                              </button>
                              <button
                                type="button"
                                onClick={async () => {
                                  if (confirm(`Deactivate deal on ${p.name}?`)) {
                                    await updateProductOffer(p.id, {
                                      isOfferActive: false,
                                      offerType: 'percentage',
                                      offerValue: 0,
                                      offerTitle: 'Offer of the Day',
                                      offerStartDate: null,
                                      offerEndDate: null,
                                    });
                                    setNotificationNotice(`✓ Deactivated deal on ${p.name}`);
                                    setTimeout(() => setNotificationNotice(null), 3000);
                                  }
                                }}
                                className="px-2 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                                title="Deactivate and remove deal"
                              >
                                <span className="material-symbols-outlined text-[14px]">delete</span>
                              </button>
                            </>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleOpenOfferModal(p)}
                              className="px-3 py-1.5 bg-[#00478c] hover:bg-[#00366a] text-white rounded text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                              title="Create a new deal for this product"
                            >
                              <span className="material-symbols-outlined text-[15px]">add_circle</span>
                              <span>+ Create Deal</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-[#D4D4D8] bg-gray-50 flex items-center justify-between text-xs text-gray-500 shrink-0">
              <span>Deals configured here automatically apply at POS checkout and inventory matrix.</span>
              <button
                type="button"
                onClick={() => setIsDealsManagerOpen(false)}
                className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-bold cursor-pointer"
              >
                Close Manager
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUICK OFFER / PROMOTION SETUP MODAL */}
      {quickOfferProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => !isSavingOffer && setQuickOfferProduct(null)}
          />
          <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-lg p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-xs">
                  <span className="material-symbols-outlined text-[20px]">local_fire_department</span>
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#09090B]">Set Promotional Offer</h3>
                  <p className="text-xs text-rose-800 font-semibold">{quickOfferProduct.name}</p>
                </div>
              </div>
              <button
                disabled={isSavingOffer}
                onClick={() => setQuickOfferProduct(null)}
                className="text-gray-400 hover:text-gray-600 disabled:opacity-50 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveOffer} className="space-y-4 text-xs">
              {/* Offer Tagline / Title */}
              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">Offer Title / Tagline</label>
                <div className="grid grid-cols-3 gap-1.5 mb-2">
                  {['Offer of the Day', 'Weekend Special', 'Flash Deal'].map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setOfferFormTitle(t)}
                      className={`py-1 px-2 rounded text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                        offerFormTitle === t
                          ? 'bg-rose-50 border-rose-400 text-rose-800 ring-1 ring-rose-300'
                          : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  required
                  value={offerFormTitle}
                  onChange={(e) => setOfferFormTitle(e.target.value)}
                  placeholder="e.g. Offer of the Day, Festival Mega Saver"
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-semibold text-[#09090B] focus:border-[#00478c] focus:outline-none"
                />
              </div>

              {/* Discount Type & Value */}
              <div className="grid grid-cols-2 gap-3 bg-rose-50/50 p-3 rounded-lg border border-rose-200">
                <div>
                  <label className="block font-bold text-rose-900 mb-1 uppercase">Discount Type</label>
                  <div className="flex bg-white rounded border border-rose-300 p-0.5">
                    <button
                      type="button"
                      onClick={() => setOfferFormType('percentage')}
                      className={`flex-1 py-1 text-center font-bold text-xs rounded transition-colors cursor-pointer ${
                        offerFormType === 'percentage'
                          ? 'bg-rose-600 text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      % Percentage
                    </button>
                    <button
                      type="button"
                      onClick={() => setOfferFormType('flat')}
                      className={`flex-1 py-1 text-center font-bold text-xs rounded transition-colors cursor-pointer ${
                        offerFormType === 'flat'
                          ? 'bg-rose-600 text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      Rs. Flat Off
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-rose-900 mb-1 uppercase">
                    {offerFormType === 'percentage' ? 'Percentage Off (%)' : 'Amount Off (Rs.)'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="1"
                    max={offerFormType === 'percentage' ? '99' : undefined}
                    value={offerFormValue}
                    onChange={(e) => setOfferFormValue(e.target.value)}
                    placeholder={offerFormType === 'percentage' ? 'e.g. 20' : 'e.g. 15'}
                    className="w-full h-8 bg-white border-2 border-rose-400 rounded px-3 text-sm font-bold text-rose-900 focus:outline-none"
                  />
                </div>
              </div>

              {/* Offer Validity Period */}
              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">Promotional Validity Period</label>
                <div className="grid grid-cols-4 gap-1.5 mb-2">
                  <button
                    type="button"
                    onClick={() => setOfferFormPeriod('today')}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                      offerFormPeriod === 'today'
                        ? 'bg-[#00478c] text-white border-[#00478c]'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                    }`}
                  >
                    Today Only
                  </button>
                  <button
                    type="button"
                    onClick={() => setOfferFormPeriod('3days')}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                      offerFormPeriod === '3days'
                        ? 'bg-[#00478c] text-white border-[#00478c]'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                    }`}
                  >
                    3 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setOfferFormPeriod('7days')}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                      offerFormPeriod === '7days'
                        ? 'bg-[#00478c] text-white border-[#00478c]'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                    }`}
                  >
                    7 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setOfferFormPeriod('custom')}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border transition-colors cursor-pointer text-center ${
                      offerFormPeriod === 'custom'
                        ? 'bg-[#00478c] text-white border-[#00478c]'
                        : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-100'
                    }`}
                  >
                    Custom Dates
                  </button>
                </div>

                {offerFormPeriod === 'custom' && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div>
                      <span className="text-[10px] text-gray-600 block mb-0.5">Start Date:</span>
                      <input
                        type="date"
                        value={offerFormStartDate}
                        onChange={(e) => setOfferFormStartDate(e.target.value)}
                        className="w-full h-8 border border-[#D4D4D8] rounded px-2 text-xs"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-600 block mb-0.5">End Date:</span>
                      <input
                        type="date"
                        value={offerFormEndDate}
                        onChange={(e) => setOfferFormEndDate(e.target.value)}
                        className="w-full h-8 border border-[#D4D4D8] rounded px-2 text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Price Calculation Preview */}
              {(() => {
                const regularPrice = quickOfferProduct.variants[0]?.price || quickOfferProduct.basePrice || 0;
                const val = parseFloat(offerFormValue) || 0;
                const disc = offerFormType === 'percentage' ? (regularPrice * val) / 100 : val;
                const finalP = Math.max(0, regularPrice - disc);

                return (
                  <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-300 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-emerald-800 block">Offer Price Preview</span>
                      <div className="flex items-baseline gap-2">
                        <span className="text-base font-extrabold text-emerald-800">
                          Rs. {finalP.toFixed(2)}
                        </span>
                        <span className="text-xs text-gray-400 line-through">
                          Rs. {regularPrice.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="px-2 py-0.5 bg-emerald-600 text-white font-black text-xs rounded">
                        Save Rs. {disc.toFixed(2)} / {quickOfferProduct.unit}
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-[#D4D4D8]">
                {quickOfferProduct.isOfferActive ? (
                  <button
                    type="button"
                    disabled={isSavingOffer}
                    onClick={handleRemoveOffer}
                    className="px-3 py-2 bg-red-50 text-red-700 border border-red-200 rounded font-bold text-xs hover:bg-red-100 cursor-pointer disabled:opacity-50 flex items-center gap-1"
                  >
                    <span className="material-symbols-outlined text-[15px]">delete</span>
                    <span>Deactivate Offer</span>
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={isSavingOffer}
                    onClick={() => setQuickOfferProduct(null)}
                    className="px-4 py-2 border border-[#D4D4D8] text-gray-700 rounded font-semibold text-xs hover:bg-gray-100 cursor-pointer disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingOffer}
                    className="px-5 py-2 bg-gradient-to-r from-rose-600 to-amber-600 text-white rounded font-bold text-xs hover:from-rose-700 hover:to-amber-700 shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {isSavingOffer ? (
                      <>
                        <span className="material-symbols-outlined text-[15px] animate-spin">sync</span>
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <span className="material-symbols-outlined text-[15px]">local_fire_department</span>
                        <span>Activate Promotional Deal</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Barcode Print Modal */}
      {selectedProductForPrint && (
        <BarcodeLabelPrintModal
          isOpen={true}
          product={selectedProductForPrint.product}
          variant={selectedProductForPrint.variant}
          onClose={() => setSelectedProductForPrint(null)}
        />
      )}
      {/* Image Library Gallery Modal */}
      <ImageLibraryModal
        isOpen={isImageLibraryOpen}
        onClose={() => setIsImageLibraryOpen(false)}
        currentImageUrl={imageLibraryTarget === 'add' ? imagePreview || undefined : editImagePreview || undefined}
        onSelectImage={(localUrl, cloudUrl, itemName) => {
          if (imageLibraryTarget === 'add') {
            setImagePreview(localUrl);
            setImageDbPath(localUrl);
            if (!newProdName) setNewProdName(itemName);
          } else {
            setEditImagePreview(localUrl);
            setEditImageDbPath(localUrl);
          }
          setIsImageLibraryOpen(false);
          setNotificationNotice(`📷 Downloaded image for "${itemName}" to local disk`);
          setTimeout(() => setNotificationNotice(null), 3000);
        }}
      />
    </div>
  );
};
