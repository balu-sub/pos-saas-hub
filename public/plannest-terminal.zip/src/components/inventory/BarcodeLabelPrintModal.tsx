import React, { useState } from 'react';
import { Product, ProductVariant } from '../../types/pos';
import { playBarcodeBeep, playKeypadClick, playSuccessChime } from '../../utils/audio';
import { usePeripherals } from '../../context/PeripheralContext';

interface BarcodeLabelPrintModalProps {
  product: Product | null;
  variant?: ProductVariant | null;
  isOpen: boolean;
  onClose: () => void;
}

// Generate deterministic SVG Code-128 / EAN style bars from string with vector coordinates
export const generateBarcodeBars = (code: string) => {
  const cleanCode = (code || '8901201001014').replace(/[^0-9A-Za-z]/g, '');
  const seed = cleanCode.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const bars: { x: number; width: number; isBar: boolean }[] = [];

  let currentX = 8;
  // Start guard bars
  bars.push({ x: currentX, width: 2, isBar: true }); currentX += 4;
  bars.push({ x: currentX, width: 1.5, isBar: true }); currentX += 3.5;

  // Data bars
  for (let i = 0; i < 48; i++) {
    const isBar = (seed * (i + 7) + i * 13) % 7 > 2;
    const width = ((seed + i) % 3) + 1.2;
    if (isBar) {
      bars.push({ x: currentX, width, isBar: true });
    }
    currentX += width + 1.2;
  }

  // Stop guard bars
  bars.push({ x: currentX, width: 2, isBar: true }); currentX += 4;
  bars.push({ x: currentX, width: 1.5, isBar: true }); currentX += 3.5;

  return { bars, totalWidth: Math.ceil(currentX + 8) };
};

export const BarcodeLabelPrintModal: React.FC<BarcodeLabelPrintModalProps> = ({
  product,
  variant,
  isOpen,
  onClose
}) => {
  const { printerConfig } = usePeripherals();
  const [labelQty, setLabelQty] = useState(4);
  const [labelSize, setLabelSize] = useState<'50x25' | '38x25' | 'a4_sheet'>(
    (printerConfig.barcodeLabelSize as any) || '50x25'
  );
  const [includeHindi, setIncludeHindi] = useState(true);
  const [includeMrp, setIncludeMrp] = useState(true);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [packedDate, setPackedDate] = useState(new Date().toLocaleDateString('en-GB'));

  if (!isOpen || !product) return null;

  const targetVariant = variant || product.variants[0];
  const barcode = targetVariant?.barcode || product.baseBarcode || '8901201001014';
  const sku = targetVariant?.sku || product.baseSku;
  const price = targetVariant?.price || product.basePrice;
  const mrp = targetVariant?.mrp || product.baseMrp || price * 1.15;
  const unit = targetVariant?.unit || product.unit;
  const weightPack = targetVariant?.attributes?.['Weight Pack'] || targetVariant?.attributes?.['Pack Size'] || targetVariant?.attributes?.['Bag Size'] || unit;
  const barcodeData = generateBarcodeBars(barcode);

  const handlePrint = () => {
    playSuccessChime();
    window.print();
  };

  const handleDownloadPDF = async () => {
    try {
      setIsGeneratingPdf(true);
      playSuccessChime();
      const { jsPDF } = await import('jspdf');

      const isSingleSticker = labelSize === '50x25' || labelSize === '38x25';
      const w = labelSize === '50x25' ? 50 : labelSize === '38x25' ? 38 : 210;
      const h = labelSize === '50x25' ? 25 : labelSize === '38x25' ? 25 : 297;

      const doc = new jsPDF({
        orientation: isSingleSticker ? 'landscape' : 'portrait',
        unit: 'mm',
        format: isSingleSticker ? [w, h] : 'a4'
      });

      if (isSingleSticker) {
        for (let i = 0; i < labelQty; i++) {
          if (i > 0) doc.addPage([w, h], 'landscape');

          // Outer border
          doc.setDrawColor(0, 0, 0);
          doc.setLineWidth(0.3);
          doc.rect(1, 1, w - 2, h - 2);

          // Store header
          doc.setFontSize(6);
          doc.setFont('helvetica', 'bold');
          doc.text('PLANNEST FRESH GROCERIES', 2, 4);
          doc.setFontSize(5);
          doc.setFont('helvetica', 'normal');
          doc.text(`Pkd: ${packedDate}`, w - 16, 4);

          // Divider
          doc.line(1, 5, w - 1, 5);

          // Product Name
          doc.setFontSize(7.5);
          doc.setFont('helvetica', 'bold');
          doc.text(product.name.slice(0, 22), 2, 8);

          // Unit
          doc.setFontSize(5.5);
          doc.setFont('helvetica', 'normal');
          doc.text(`Unit: ${weightPack}`, 2, 10.5);

          // Draw vector barcode bars
          doc.setFillColor(0, 0, 0);
          const startX = 3;
          const barY = 11.5;
          const barHeight = 5.5;
          const totalScale = (w - 6) / barcodeData.totalWidth;
          barcodeData.bars.forEach((b) => {
            doc.rect(startX + (b.x * totalScale), barY, Math.max(0.2, b.width * totalScale), barHeight, 'F');
          });

          // Barcode Text
          doc.setFontSize(5);
          doc.setFont('courier', 'bold');
          doc.text(barcode, w / 2, 19, { align: 'center' });

          // Divider
          doc.line(1, 20, w - 1, 20);

          // MRP & Price
          if (includeMrp) {
            doc.setFontSize(5.5);
            doc.setFont('helvetica', 'normal');
            doc.text(`MRP: Rs. ${mrp.toFixed(2)}`, 2, 23);
          }
          doc.setFontSize(7.5);
          doc.setFont('helvetica', 'bold');
          doc.text(`PRICE: Rs. ${price.toFixed(2)}`, w - 2, 23, { align: 'right' });
        }
      } else {
        // A4 Sheet: 3 columns x 8 rows = 24 labels per page
        const cols = 3;
        const rows = 8;
        const labelW = 63.5;
        const labelH = 33;
        const marginX = 7;
        const marginY = 15;

        let labelIndex = 0;
        let pageCount = 0;

        while (labelIndex < labelQty) {
          if (pageCount > 0) doc.addPage('a4', 'portrait');
          pageCount++;

          for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
              if (labelIndex >= labelQty) break;

              const x = marginX + c * (labelW + 2.5);
              const y = marginY + r * (labelH + 1.5);

              // Label box
              doc.setDrawColor(180, 180, 180);
              doc.setLineWidth(0.2);
              doc.rect(x, y, labelW, labelH);

              // Header
              doc.setFontSize(7);
              doc.setFont('helvetica', 'bold');
              doc.text('PLANNEST FRESH GROCERIES', x + 2, y + 4);
              doc.setFontSize(6);
              doc.setFont('helvetica', 'normal');
              doc.text(`Pkd: ${packedDate}`, x + labelW - 20, y + 4);

              // Product Name
              doc.setFontSize(8.5);
              doc.setFont('helvetica', 'bold');
              doc.text(product.name.slice(0, 24), x + 2, y + 9);
              doc.setFontSize(6);
              doc.setFont('helvetica', 'normal');
              doc.text(`Net: ${weightPack}`, x + 2, y + 12);

              // Barcode Bars
              doc.setFillColor(0, 0, 0);
              const barStartX = x + 3;
              const barY = y + 13.5;
              const barHeight = 8;
              const totalScale = (labelW - 6) / barcodeData.totalWidth;
              barcodeData.bars.forEach((b) => {
                doc.rect(barStartX + (b.x * totalScale), barY, Math.max(0.25, b.width * totalScale), barHeight, 'F');
              });

              // Barcode Text
              doc.setFontSize(6);
              doc.setFont('courier', 'bold');
              doc.text(barcode, x + (labelW / 2), y + 23.5, { align: 'center' });

              // Price
              doc.setFontSize(6.5);
              doc.setFont('helvetica', 'normal');
              if (includeMrp) doc.text(`MRP: Rs. ${mrp.toFixed(2)}`, x + 2, y + 29);
              doc.setFontSize(8.5);
              doc.setFont('helvetica', 'bold');
              doc.text(`PRICE: Rs. ${price.toFixed(2)}`, x + labelW - 2, y + 29, { align: 'right' });

              labelIndex++;
            }
          }
        }
      }

      doc.save(`${product.name.replace(/[^a-zA-Z0-9]/g, '_')}_barcodes.pdf`);
    } catch (err) {
      console.error('Failed to generate barcode PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center select-none">
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #printable-barcode-container, #printable-barcode-container * {
            visibility: visible !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            color-adjust: exact !important;
          }
          #printable-barcode-container {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: white !important;
            display: flex !important;
            flex-wrap: wrap !important;
            gap: 8px !important;
          }
          .barcode-print-item {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            border: 2px solid #000 !important;
            background: #fff !important;
          }
        }
      `}</style>

      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-[820px] max-w-[95vw] shadow-2xl p-6 flex flex-col max-h-[92vh] overflow-hidden industrial-shadow animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#D4D4D8]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <span className="material-symbols-outlined text-[24px]">barcode_scanner</span>
            </div>
            <div>
              <h3 className="font-bold text-lg text-[#09090B]">Barcode &amp; Price Label Printer</h3>
              <p className="text-xs text-gray-500">
                Print barcode stickers directly to your Windows label printer or download ready-to-print vector PDF
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-red-600 cursor-pointer">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto my-4 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Controls (Left 5 Cols) */}
          <div className="md:col-span-5 space-y-4 text-xs">
            <div className="bg-[#f6f2f7] p-3.5 rounded-lg border border-[#D4D4D8] space-y-2.5">
              <div className="font-bold text-sm text-[#09090B]">{product.name}</div>
              <div className="text-[11px] text-[#5c403c] font-tabular-numeric">
                SKU: <span className="font-bold">{sku}</span> • Barcode: <span className="font-bold">{barcode}</span>
              </div>
              <div className="flex gap-2">
                <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                  Price: Rs. {price.toFixed(2)}
                </span>
                <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded">
                  MRP: Rs. {mrp.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Target Label Printer Indicator */}
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-lg space-y-1">
              <span className="text-[10px] font-bold text-emerald-900 uppercase tracking-wider block">
                TARGET WINDOWS LABEL PRINTER
              </span>
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950">
                <span className="material-symbols-outlined text-[15px] text-emerald-700">print</span>
                <span className="truncate">{printerConfig.selectedBarcodePrinterName || 'System Default Printer'}</span>
              </div>
            </div>

            {/* Label Format */}
            <div>
              <label className="block font-bold text-[#5c403c] mb-1 uppercase tracking-wider">
                LABEL STICKER FORMAT
              </label>
              <select
                value={labelSize}
                onChange={(e) => setLabelSize(e.target.value as any)}
                className="w-full h-9 bg-white border border-[#D4D4D8] rounded px-3 text-[#09090B] font-medium"
              >
                <option value="50x25">50mm × 25mm Thermal Barcode Sticker (Standard)</option>
                <option value="38x25">38mm × 25mm Compact Veggie / Item Tag</option>
                <option value="a4_sheet">A4 Sheet (24 Stickers - 3×8 Grid)</option>
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block font-bold text-[#5c403c] mb-1 uppercase tracking-wider">
                NUMBER OF LABELS TO PRINT
              </label>
              <div className="flex items-center gap-2">
                {[1, 4, 8, 16, 24].map((qty) => (
                  <button
                    key={qty}
                    type="button"
                    onClick={() => {
                      playKeypadClick();
                      setLabelQty(qty);
                    }}
                    className={`px-3 py-1.5 rounded font-bold border transition-colors ${
                      labelQty === qty
                        ? 'bg-[#00478c] text-white border-[#00478c]'
                        : 'bg-white border-[#D4D4D8] text-[#09090B] hover:bg-[#F4F4F5]'
                    }`}
                  >
                    {qty}
                  </button>
                ))}
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={labelQty}
                  onChange={(e) => setLabelQty(parseInt(e.target.value, 10) || 1)}
                  className="w-16 h-8 border border-[#D4D4D8] rounded px-2 text-center font-bold text-[#09090B]"
                />
              </div>
            </div>

            {/* Options */}
            <div className="space-y-2 pt-1 border-t border-[#D4D4D8]">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeHindi}
                  onChange={(e) => setIncludeHindi(e.target.checked)}
                  className="rounded text-[#00478c]"
                />
                <span className="font-medium text-[#09090B]">Include Hindi Item Name</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeMrp}
                  onChange={(e) => setIncludeMrp(e.target.checked)}
                  className="rounded text-[#00478c]"
                />
                <span className="font-medium text-[#09090B]">Show MRP vs Our Price (Discount Hook)</span>
              </label>
            </div>
          </div>

          {/* Label Preview (Right 7 Cols) */}
          <div className="md:col-span-7 bg-[#fbf8fc] border border-[#D4D4D8] rounded-lg p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between pb-2 border-b border-[#D4D4D8]">
              <span className="font-bold text-xs text-[#00478c] uppercase tracking-wider">
                Print Preview (Vector SVG Quality)
              </span>
              <span className="text-[11px] text-[#5c403c]">{labelQty} label(s) in batch</span>
            </div>

            {/* Simulated Label Sheet / Preview */}
            <div id="printable-barcode-container" className="py-4 flex flex-wrap gap-3 items-center justify-center max-h-[300px] overflow-y-auto">
              {Array.from({ length: Math.min(labelQty, 6) }).map((_, idx) => (
                <div
                  key={idx}
                  id={`printable-label-${idx}`}
                  className="barcode-print-item w-[240px] bg-white border-2 border-black rounded p-2.5 shadow-sm text-black flex flex-col justify-between font-sans leading-tight select-text"
                >
                  {/* Store Name Header */}
                  <div className="flex items-center justify-between border-b border-black pb-1">
                    <span className="text-[10px] font-black uppercase tracking-wider text-black">
                      FreshMart Groceries
                    </span>
                    <span className="text-[9px] font-semibold text-black">
                      Pkd: {packedDate}
                    </span>
                  </div>

                  {/* Product Title */}
                  <div className="py-1">
                    <div className="font-bold text-xs text-black line-clamp-1">
                      {product.name}
                    </div>
                    {includeHindi && product.hindiName && (
                      <div className="text-[10px] font-semibold text-gray-800 line-clamp-1">
                        {product.hindiName}
                      </div>
                    )}
                    <div className="text-[10px] text-black font-semibold mt-0.5">
                      Net Wt / Unit: <span className="font-black">{weightPack}</span>
                    </div>
                  </div>

                  {/* Barcode Graphic - True Vector SVG Rendering (Always visible in print & PDF) */}
                  <div className="flex flex-col items-center justify-center py-1 bg-white">
                    <div className="flex items-center justify-center h-8 w-full px-2 overflow-hidden">
                      <svg
                        viewBox={`0 0 ${barcodeData.totalWidth} 40`}
                        className="w-full h-8 max-w-[200px]"
                        preserveAspectRatio="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect x="0" y="0" width={barcodeData.totalWidth} height="40" fill="#FFFFFF" />
                        {barcodeData.bars.map((b, bIdx) => (
                          <rect
                            key={bIdx}
                            x={b.x}
                            y="0"
                            width={b.width}
                            height="40"
                            fill="#000000"
                          />
                        ))}
                      </svg>
                    </div>
                    <div className="font-mono text-[9px] tracking-widest font-black text-black mt-0.5">
                      {barcode}
                    </div>
                  </div>

                  {/* Price Tag Footer */}
                  <div className="border-t border-black pt-1 flex items-baseline justify-between">
                    {includeMrp && (
                      <div className="text-[10px] text-gray-700">
                        MRP: <span className="line-through">Rs. {mrp.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="text-right ml-auto">
                      <span className="text-[10px] font-bold text-black mr-1">OUR PRICE:</span>
                      <span className="text-sm font-extrabold text-black">
                        Rs. {price.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {labelQty > 6 && (
              <div className="text-center text-[11px] text-[#5c403c] italic">
                + {labelQty - 6} more labels will be printed during spool
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 pt-3 border-t border-[#D4D4D8]">
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 py-2.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded-lg font-bold text-xs flex items-center justify-center gap-2 industrial-shadow transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[17px]">print</span>
            <span>Print {labelQty} Labels ({printerConfig.selectedBarcodePrinterName || 'Windows Thermal'})</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPDF}
            disabled={isGeneratingPdf}
            className="py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-2 industrial-shadow transition-all cursor-pointer disabled:opacity-60"
          >
            <span className="material-symbols-outlined text-[17px]">picture_as_pdf</span>
            <span>{isGeneratingPdf ? 'Generating PDF...' : 'Download Barcode PDF'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-[#F4F4F5] hover:bg-[#E4E4E7] text-[#09090B] rounded-lg font-bold text-xs cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
