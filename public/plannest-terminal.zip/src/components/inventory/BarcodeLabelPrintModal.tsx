import React, { useState } from 'react';
import { Product, ProductVariant } from '../../types/pos';
import { playBarcodeBeep, playKeypadClick, playSuccessChime } from '../../utils/audio';

interface BarcodeLabelPrintModalProps {
  product: Product | null;
  variant?: ProductVariant | null;
  isOpen: boolean;
  onClose: () => void;
}

// Generate simple SVG Code-128 / EAN style bars from string for visual representation
export const generateBarcodeBars = (code: string) => {
  const seed = code.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const pattern = [];
  for (let i = 0; i < 48; i++) {
    const isBar = (seed * (i + 7) + i * 13) % 7 > 2;
    const width = ((seed + i) % 3) + 1.2;
    pattern.push({ isBar, width });
  }
  return pattern;
};

export const BarcodeLabelPrintModal: React.FC<BarcodeLabelPrintModalProps> = ({
  product,
  variant,
  isOpen,
  onClose
}) => {
  const [labelQty, setLabelQty] = useState(4);
  const [labelSize, setLabelSize] = useState<'50x25' | '38x25' | 'a4_sheet'>('50x25');
  const [includeHindi, setIncludeHindi] = useState(true);
  const [includeMrp, setIncludeMrp] = useState(true);
  const [packedDate, setPackedDate] = useState(new Date().toLocaleDateString('en-GB'));

  if (!isOpen || !product) return null;

  const targetVariant = variant || product.variants[0];
  const barcode = targetVariant?.barcode || product.baseBarcode || '8901201001014';
  const sku = targetVariant?.sku || product.baseSku;
  const price = targetVariant?.price || product.basePrice;
  const mrp = targetVariant?.mrp || product.baseMrp || price * 1.15;
  const unit = targetVariant?.unit || product.unit;
  const weightPack = targetVariant?.attributes?.['Weight Pack'] || targetVariant?.attributes?.['Pack Size'] || targetVariant?.attributes?.['Bag Size'] || unit;
  const bars = generateBarcodeBars(barcode);

  const handlePrint = () => {
    playSuccessChime();
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center select-none">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-[780px] max-w-[95vw] shadow-2xl p-6 flex flex-col max-h-[92vh] overflow-hidden industrial-shadow animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#D4D4D8]">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00478c]">barcode_scanner</span>
            <div>
              <h3 className="font-bold text-lg text-[#09090B]">Barcode &amp; Price Label Printer</h3>
              <p className="text-xs text-[#5c403c]">
                Thermal sticker &amp; shelf label generator for vegetables and groceries
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#5c403c] hover:text-[#ba1a1a]">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto my-4 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Controls (Left 5 Cols) */}
          <div className="md:col-span-5 space-y-4 text-xs">
            <div className="bg-[#f6f2f7] p-3.5 rounded border border-[#D4D4D8] space-y-3">
              <div className="font-bold text-sm text-[#09090B]">{product.name}</div>
              <div className="text-[11px] text-[#5c403c] font-tabular-numeric">
                SKU: {sku} • Barcode: {barcode}
              </div>
              <div className="flex gap-2">
                <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                  Price: Rs. {price.toFixed(2)}
                </span>
                <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded">
                  MRP: Rs. {mrp.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Label Format */}
            <div>
              <label className="block font-bold text-[#5c403c] mb-1 uppercase tracking-wider">
                LABEL FORMAT / PRINTER
              </label>
              <select
                value={labelSize}
                onChange={(e) => setLabelSize(e.target.value as any)}
                className="w-full h-9 bg-white border border-[#D4D4D8] rounded px-3 text-[#09090B] font-medium"
              >
                <option value="50x25">50mm × 25mm Thermal Barcode Sticker (Standard)</option>
                <option value="38x25">38mm × 25mm Compact Veggie / Item Tag</option>
                <option value="a4_sheet">A4 Sheet (24 Stickers - 3×8 Grid)</option>
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block font-bold text-[#5c403c] mb-1 uppercase tracking-wider">
                NUMBER OF LABELS TO PRINT
              </label>
              <div className="flex items-center gap-2">
                {[1, 4, 8, 16, 24].map((qty) => (
                  <button
                    key={qty}
                    type="button"
                    onClick={() => {
                      playKeypadClick();
                      setLabelQty(qty);
                    }}
                    className={`px-3 py-1.5 rounded font-bold border transition-colors ${
                      labelQty === qty
                        ? 'bg-[#00478c] text-white border-[#00478c]'
                        : 'bg-white border-[#D4D4D8] text-[#09090B] hover:bg-[#F4F4F5]'
                    }`}
                  >
                    {qty}
                  </button>
                ))}
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={labelQty}
                  onChange={(e) => setLabelQty(parseInt(e.target.value, 10) || 1)}
                  className="w-16 h-8 border border-[#D4D4D8] rounded px-2 text-center font-bold text-[#09090B]"
                />
              </div>
            </div>

            {/* Options */}
            <div className="space-y-2 pt-1 border-t border-[#D4D4D8]">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeHindi}
                  onChange={(e) => setIncludeHindi(e.target.checked)}
                  className="rounded text-[#00478c]"
                />
                <span className="font-medium text-[#09090B]">Include Hindi Item Name</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeMrp}
                  onChange={(e) => setIncludeMrp(e.target.checked)}
                  className="rounded text-[#00478c]"
                />
                <span className="font-medium text-[#09090B]">Show MRP vs Our Price (Discount Hook)</span>
              </label>
            </div>
          </div>

          {/* Label Preview (Right 7 Cols) */}
          <div className="md:col-span-7 bg-[#fbf8fc] border border-[#D4D4D8] rounded-lg p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between pb-2 border-b border-[#D4D4D8]">
              <span className="font-bold text-xs text-[#00478c] uppercase tracking-wider">
                Print Preview (Actual Dimensions)
              </span>
              <span className="text-[11px] text-[#5c403c]">{labelQty} label(s) in batch</span>
            </div>

            {/* Simulated Label Sheet / Preview */}
            <div className="py-4 flex flex-wrap gap-3 items-center justify-center max-h-[300px] overflow-y-auto">
              {Array.from({ length: Math.min(labelQty, 6) }).map((_, idx) => (
                <div
                  key={idx}
                  id={`printable-label-${idx}`}
                  className="w-[240px] bg-white border-2 border-black rounded p-2.5 shadow-sm text-black flex flex-col justify-between font-sans leading-tight select-text"
                >
                  {/* Store Name Header */}
                  <div className="flex items-center justify-between border-b border-black pb-1">
                    <span className="text-[10px] font-black uppercase tracking-wider text-black">
                      FreshMart Groceries
                    </span>
                    <span className="text-[9px] font-semibold text-black">
                      Pkd: {packedDate}
                    </span>
                  </div>

                  {/* Product Title */}
                  <div className="py-1">
                    <div className="font-bold text-xs text-black line-clamp-1">
                      {product.name}
                    </div>
                    {includeHindi && product.hindiName && (
                      <div className="text-[10px] font-semibold text-gray-800 line-clamp-1">
                        {product.hindiName}
                      </div>
                    )}
                    <div className="text-[10px] text-black font-semibold mt-0.5">
                      Net Wt / Unit: <span className="font-black">{weightPack}</span>
                    </div>
                  </div>

                  {/* Barcode Graphic */}
                  <div className="flex flex-col items-center justify-center py-1 bg-white">
                    <div className="flex items-center justify-center h-8 gap-[1px] w-full px-2 overflow-hidden">
                      {bars.map((b, bIdx) => (
                        <div
                          key={bIdx}
                          style={{
                            width: `${b.width}px`,
                            backgroundColor: b.isBar ? '#000' : 'transparent',
                            height: '100%'
                          }}
                        />
                      ))}
                    </div>
                    <div className="font-mono text-[9px] tracking-widest font-black text-black mt-0.5">
                      {barcode}
                    </div>
                  </div>

                  {/* Price Tag Footer */}
                  <div className="border-t border-black pt-1 flex items-baseline justify-between">
                    {includeMrp && (
                      <div className="text-[10px] text-gray-700">
                        MRP: <span className="line-through">Rs. {mrp.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="text-right ml-auto">
                      <span className="text-[10px] font-bold text-black mr-1">OUR PRICE:</span>
                      <span className="text-sm font-extrabold text-black">
                        Rs. {price.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {labelQty > 6 && (
              <div className="text-center text-[11px] text-[#5c403c] italic">
                + {labelQty - 6} more labels will be printed during spool
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2 border-t border-[#D4D4D8]">
          <button
            onClick={handlePrint}
            className="flex-1 py-2.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded font-bold text-sm flex items-center justify-center gap-2 industrial-shadow transition-all active:scale-[0.98]"
          >
            <span className="material-symbols-outlined text-[18px]">print</span>
            Print {labelQty} Barcode Labels (Direct Thermal)
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-[#F4F4F5] hover:bg-[#E4E4E7] text-[#09090B] rounded font-bold text-sm"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
