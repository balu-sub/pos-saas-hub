import React, { useEffect, useState, useRef } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useVirtualKeyboard } from '../../context/VirtualKeyboardContext';
import { PWAInstallButton } from '../common/PWAInstallButton';
import {
  toggleFullscreen,
  isFullscreen,
  requestWakeLock,
  releaseWakeLock,
  triggerHaptic,
} from '../../utils/tabletUtils';
import { playBarcodeBeep, playKeypadClick } from '../../utils/audio';
import { apiClient } from '../../services/apiClient';

export const BottomStatusBar: React.FC = () => {
  const {
    isOnline,
    syncQueueCount,
    triggerManualSync,
    refreshProducts,
    isLoadingProducts,
    products,
    currentOperator,
    dbDriver,
    canManageUsers,
    setActiveTab,
  } = usePOS();

  const {
    cameraConfig,
    voiceConfig,
    scaleConfig,
    barcodeConfig,
    printerConfig,
    drawerConfig,
    headerVisibility,
    toggleHeaderVisibility,
    kickOpenDrawer,
    connectScaleWebSerial,
    peripheralsStatus,
  } = usePeripherals();

  const touchKeyboard = useVirtualKeyboard();

  // Fullscreen & Wake Lock State
  const [fullscreenActive, setFullscreenActive] = useState(false);
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const [isHardwareMenuOpen, setIsHardwareMenuOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const hardwareMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setFullscreenActive(isFullscreen());
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (hardwareMenuRef.current && !hardwareMenuRef.current.contains(e.target as Node)) {
        setIsHardwareMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleToggleFullscreen = async () => {
    triggerHaptic('medium');
    playKeypadClick();
    const active = await toggleFullscreen();
    setFullscreenActive(active);
  };

  const handleToggleWakeLock = async () => {
    triggerHaptic('light');
    playKeypadClick();
    if (wakeLockActive) {
      await releaseWakeLock();
      setWakeLockActive(false);
    } else {
      const success = await requestWakeLock();
      setWakeLockActive(success);
    }
  };

  const handleReloadDb = async () => {
    playBarcodeBeep();
    try { await apiClient.syncNow(); } catch { /* offline - reload local data anyway */ }
    await refreshProducts();
    setStatusMessage(`Refreshed ${products.length} items`);
    setTimeout(() => setStatusMessage(null), 2500);
  };

  const attachedCount = peripheralsStatus?.attachedCount ?? 0;

  const isKiosk = currentOperator?.userRole === 'Customer Kiosk';

  return (
    <footer
      id="pos-bottom-status-bar"
      className="w-full h-8 bg-zinc-900 border-t border-zinc-800 text-zinc-300 text-xs px-3 flex items-center justify-between shrink-0 select-none z-30 transition-all font-sans"
    >
      {/* Left: Network Connectivity & Local DB Sync */}
      <div className="flex items-center gap-2.5 shrink-0">
        {/* Network & Cloud Sync Status */}
        <button
          type="button"
          onClick={() => triggerManualSync()}
          title={isOnline ? 'Online • Database Synchronized' : `Offline (${syncQueueCount} sales waiting to sync)`}
          className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer py-0.5 px-1.5 rounded hover:bg-zinc-800"
        >
          <span
            className={`w-2 h-2 rounded-full ${
              isOnline ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.7)]' : 'bg-red-500 animate-ping'
            }`}
          />
          <span className="text-[11px] font-medium tracking-tight">
            {isOnline ? 'Online' : 'Offline'}
          </span>
          {syncQueueCount > 0 && !isKiosk && (
            <span className="bg-red-600 text-white text-[9px] font-bold px-1 rounded-full">
              {syncQueueCount} queued
            </span>
          )}
        </button>

        {!isKiosk && (
          <>
            <span className="text-zinc-600">|</span>

            {/* Database Driver & Refresh DB Button */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleReloadDb}
                disabled={isLoadingProducts}
                title="Reload items, stock & prices directly from local database"
                className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer py-0.5 px-1.5 rounded hover:bg-zinc-800 disabled:opacity-50 text-[11px]"
              >
                <span className={`material-symbols-outlined text-[14px] text-sky-400 ${isLoadingProducts ? 'animate-spin' : ''}`}>
                  refresh
                </span>
                <span className="hidden sm:inline font-medium">
                  {isLoadingProducts ? 'Syncing...' : 'Reload DB'}
                </span>
              </button>
              <span className="text-[10px] text-zinc-400 hidden md:inline font-mono">
                ({products.length} items)
              </span>
            </div>
          </>
        )}

        {statusMessage && (
          <span className="text-emerald-400 text-[11px] font-semibold animate-pulse">
            • {statusMessage}
          </span>
        )}
      </div>

      {/* Center: Hardware & Peripherals Manager & Standard Copyright */}
      <div className="flex items-center gap-2.5 shrink-0">
        {!isKiosk && (
          <div className="hidden lg:flex items-center gap-2">
          <div className="relative" ref={hardwareMenuRef}>
            <button
              type="button"
              onClick={() => setIsHardwareMenuOpen(!isHardwareMenuOpen)}
              title="Hardware Peripherals Status & Diagnostics"
              className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                isHardwareMenuOpen ? 'bg-zinc-700 text-white' : 'hover:bg-zinc-800 text-zinc-300'
              }`}
            >
              <span className={`material-symbols-outlined text-[14px] ${attachedCount > 0 ? 'text-emerald-400' : 'text-zinc-500'}`}>devices</span>
              <span>Peripherals:</span>
              <span className={`bg-zinc-800 font-mono font-bold text-[10px] px-1.5 py-0.2 rounded border ${
                attachedCount > 0 ? 'text-emerald-400 border-zinc-700' : 'text-zinc-400 border-zinc-700'
              }`}>
                {attachedCount}/6 Active
              </span>
            </button>

            {isHardwareMenuOpen && (
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-80 bg-white text-zinc-900 border border-zinc-300 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 font-sans">
                <div className="px-3 py-1.5 border-b border-zinc-200 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px] text-[#00478c]">devices</span>
                    <span className="text-[11px] font-bold text-zinc-900 uppercase tracking-wider">
                      Attached Hardware Diagnostics
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                    attachedCount > 0 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-zinc-100 text-zinc-500 border-zinc-200'
                  }`}>
                    {attachedCount}/6 Connected
                  </span>
                </div>

                <div className="p-2 space-y-1.5 text-xs">
                  {/* Receipt Printer */}
                  <div className="flex items-center justify-between p-1.5 rounded-lg border border-zinc-100 bg-zinc-50/50">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className={`material-symbols-outlined text-[16px] shrink-0 ${peripheralsStatus?.printerReady ? 'text-emerald-600' : 'text-zinc-400'}`}>
                        print
                      </span>
                      <div className="truncate">
                        <div className="font-semibold text-zinc-800 text-[11px] truncate">
                          {peripheralsStatus?.printerReady ? (peripheralsStatus?.activePrinterName || 'Receipt Printer') : 'Receipt Printer'}
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate">
                          {peripheralsStatus?.printerReady ? 'ESC/POS Direct Spooler Ready' : 'No physical spooler detected'}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      peripheralsStatus?.printerReady ? 'bg-emerald-100 text-emerald-800' : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {peripheralsStatus?.printerReady ? 'Active' : 'Offline'}
                    </span>
                  </div>

                  {/* Weighing Scale */}
                  <div className="flex items-center justify-between p-1.5 rounded-lg border border-zinc-100 bg-zinc-50/50">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className={`material-symbols-outlined text-[16px] shrink-0 ${scaleConfig.isConnected ? 'text-emerald-600' : 'text-zinc-400'}`}>
                        scale
                      </span>
                      <div className="truncate">
                        <div className="font-semibold text-zinc-800 text-[11px] truncate">
                          Digital Weighing Scale
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate">
                          {scaleConfig.isConnected
                            ? `Stream: ${(Number(scaleConfig.currentWeight) || 0).toFixed(3)} ${scaleConfig.unit || 'kg'} (${scaleConfig.port || 'COM'} @ ${scaleConfig.baudRate || 9600})`
                            : 'RS-232 / USB Serial Disconnected'}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      scaleConfig.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {scaleConfig.isConnected ? 'Live' : 'Offline'}
                    </span>
                  </div>

                  {/* Barcode Scanner */}
                  <div className="flex items-center justify-between p-1.5 rounded-lg border border-zinc-100 bg-zinc-50/50">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className={`material-symbols-outlined text-[16px] shrink-0 ${peripheralsStatus?.scannerReady ? 'text-emerald-600' : 'text-zinc-400'}`}>
                        barcode_scanner
                      </span>
                      <div className="truncate">
                        <div className="font-semibold text-zinc-800 text-[11px] truncate">
                          Barcode Scanner
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate">
                          {barcodeConfig.lastScannedTime > 0
                            ? `Last code: ${barcodeConfig.lastScannedCode}`
                            : 'USB HID Keyboard Wedge'}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      peripheralsStatus?.scannerReady ? 'bg-emerald-100 text-emerald-800' : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {peripheralsStatus?.scannerReady ? 'Ready' : 'Disabled'}
                    </span>
                  </div>

                  {/* AI Vision Camera */}
                  <div className="flex items-center justify-between p-1.5 rounded-lg border border-zinc-100 bg-zinc-50/50">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className={`material-symbols-outlined text-[16px] shrink-0 ${peripheralsStatus?.cameraReady ? 'text-emerald-600' : 'text-zinc-400'}`}>
                        photo_camera
                      </span>
                      <div className="truncate">
                        <div className="font-semibold text-zinc-800 text-[11px] truncate">
                          AI Camera Vision
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate">
                          {cameraConfig.availableDevices?.length
                            ? `${cameraConfig.availableDevices.length} camera(s) detected`
                            : 'No physical webcam found'}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      peripheralsStatus?.cameraReady ? 'bg-emerald-100 text-emerald-800' : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {peripheralsStatus?.cameraReady ? 'Ready' : 'None'}
                    </span>
                  </div>

                  {/* AI Voice Microphone */}
                  <div className="flex items-center justify-between p-1.5 rounded-lg border border-zinc-100 bg-zinc-50/50">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className={`material-symbols-outlined text-[16px] shrink-0 ${peripheralsStatus?.micReady ? 'text-purple-600' : 'text-zinc-400'}`}>
                        mic
                      </span>
                      <div className="truncate">
                        <div className="font-semibold text-zinc-800 text-[11px] truncate">
                          AI Voice Microphone
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate">
                          {voiceConfig.availableDevices?.length
                            ? `${voiceConfig.availableDevices.length} audio input(s) detected`
                            : 'No physical mic found'}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      peripheralsStatus?.micReady ? 'bg-purple-100 text-purple-800' : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {peripheralsStatus?.micReady ? 'Ready' : 'None'}
                    </span>
                  </div>

                  {/* Cash Drawer */}
                  <div className="flex items-center justify-between p-1.5 rounded-lg border border-zinc-100 bg-zinc-50/50">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className={`material-symbols-outlined text-[16px] shrink-0 ${peripheralsStatus?.drawerReady ? 'text-amber-600' : 'text-zinc-400'}`}>
                        point_of_sale
                      </span>
                      <div className="truncate">
                        <div className="font-semibold text-zinc-800 text-[11px] truncate">
                          Cash Drawer (F8)
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate">
                          {peripheralsStatus?.drawerReady
                            ? 'RJ11 24V Solenoid Trigger Active'
                            : 'Not configured / Disabled'}
                        </div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                      peripheralsStatus?.drawerReady ? 'bg-emerald-100 text-emerald-800' : 'bg-zinc-100 text-zinc-500'
                    }`}>
                      {peripheralsStatus?.drawerReady ? 'Ready' : 'Off'}
                    </span>
                  </div>
                </div>

                <div className="p-2 border-t border-zinc-200 bg-zinc-50 rounded-b-xl space-y-1.5">
                  {!scaleConfig.isConnected && (
                    <button
                      type="button"
                      onClick={async () => {
                        await connectScaleWebSerial();
                      }}
                      className="w-full py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[15px]">cable</span>
                      <span>Connect Weighing Scale (Web Serial)</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('settings');
                      setIsHardwareMenuOpen(false);
                    }}
                    className="w-full py-1.5 px-3 bg-[#00478c] hover:bg-[#005eb7] text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[15px]">settings</span>
                    <span>Configure Hardware &amp; Baud &rarr;</span>
                  </button>
                  <div className="flex items-center justify-between text-[10px] text-zinc-500 px-1 pt-0.5">
                    <span>Physical devices auto-detected</span>
                    <button
                      type="button"
                      onClick={() => setIsHardwareMenuOpen(false)}
                      className="text-[#00478c] hover:underline font-bold"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled
            title="Cash Drawer (Paused / Later)"
            className="flex items-center gap-1 px-1.5 py-0.5 rounded text-zinc-500 opacity-35 text-[11px] cursor-not-allowed select-none"
          >
            <span className="material-symbols-outlined text-[13px]">point_of_sale</span>
            <span>Drawer (Later)</span>
          </button>
        </div>
        )}

        {!isKiosk && <span className="text-zinc-700 hidden lg:inline">|</span>}

        {/* Standard International Copyright Notice: © [Year] [Company] */}
        <span className="text-[11px] text-zinc-400 font-medium tracking-normal select-none">
          © 2026 Plannest{isKiosk ? ' • Self-Service Kiosk' : ''}
        </span>
      </div>

      {/* Right: Device & Tablet Toggles + Admin PWA Install */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Touchscreen Virtual Keyboard Toggle */}
        {touchKeyboard && (
          <button
            type="button"
            onClick={touchKeyboard.toggleTouchKeyboard}
            title={
              touchKeyboard.isTouchKeyboardEnabled
                ? 'Touchscreen On-Screen Keyboard: ON (Click to Disable)'
                : 'Touchscreen On-Screen Keyboard: OFF (Click to Enable)'
            }
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
              touchKeyboard.isTouchKeyboardEnabled
                ? 'bg-amber-500 text-white font-bold'
                : 'hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <span className="material-symbols-outlined text-[14px]">
              {touchKeyboard.isTouchKeyboardEnabled ? 'keyboard' : 'keyboard_off'}
            </span>
            <span className="hidden sm:inline">
              {touchKeyboard.isTouchKeyboardEnabled ? 'Touch ON' : 'Touch OFF'}
            </span>
          </button>
        )}

        {/* Screen Stay Awake (Wake Lock) */}
        <button
          type="button"
          onClick={handleToggleWakeLock}
          title={
            wakeLockActive
              ? 'Screen Stay Awake: ACTIVE (Screen will not dim or sleep)'
              : 'Keep Screen Awake (Prevent tablet sleep)'
          }
          className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
            wakeLockActive
              ? 'bg-amber-400 text-zinc-950 font-bold'
              : 'hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <span className="material-symbols-outlined text-[14px]">
            {wakeLockActive ? 'wb_sunny' : 'light_mode'}
          </span>
          <span className="hidden md:inline">
            {wakeLockActive ? 'Awake' : 'Sleep OK'}
          </span>
        </button>

        {/* Fullscreen Kiosk Mode */}
        <button
          type="button"
          onClick={handleToggleFullscreen}
          title={fullscreenActive ? 'Exit Kiosk Fullscreen' : 'Enter Kiosk Fullscreen [F11]'}
          className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
            fullscreenActive
              ? 'bg-[#00478c] text-white font-bold'
              : 'hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <span className="material-symbols-outlined text-[14px]">
            {fullscreenActive ? 'fullscreen_exit' : 'fullscreen'}
          </span>
          <span className="hidden md:inline">
            {fullscreenActive ? 'Exit Kiosk' : 'Kiosk'}
          </span>
        </button>

        {/* PWA Install Button (For Admin / Super Admin) */}
        {(canManageUsers || currentOperator?.userRole === 'Admin') && (
          <div className="ml-1">
            <PWAInstallButton variant="badge" />
          </div>
        )}
      </div>
    </footer>
  );
};
