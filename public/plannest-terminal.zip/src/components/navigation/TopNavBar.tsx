import React, { useEffect, useState, useRef, memo, useCallback } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { Operator, DEFAULT_OPERATORS } from '../../types/pos';
import { playSuccessChime, playKeypadClick, playWarningTone } from '../../utils/audio';
import { getCustomApiHost } from '../../services/apiClient';
import logoImg from '../../assets/First.png';

export const OPERATORS = DEFAULT_OPERATORS;

interface TopNavBarProps {
  onOpenKeyboardHelp?: () => void;
  onOpenPinModal: () => void;
  isSidebarHidden?: boolean;
  onToggleSidebar?: () => void;
}

// Dedicated clock component to prevent re-rendering the whole header every second
const LiveClock = memo(() => {
  const [time, setTime] = useState(() =>
    new Date().toLocaleTimeString('en-IN', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    })
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(
        new Date().toLocaleTimeString('en-IN', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="font-tabular-numeric text-sm font-bold text-[#09090B] tracking-tight">
      {time} IST
    </div>
  );
});

export const TopNavBar: React.FC<TopNavBarProps> = ({
  onOpenKeyboardHelp,
  onOpenPinModal,
  isSidebarHidden = false,
  onToggleSidebar,
}) => {
  const {
    currentOperator,
    operators,
    switchOperator,
    outletProfile,
    lastCompletedOrder,
    setIsReceiptOpen,
  } = usePOS();

  const { isStaff, isCustomer, isAuthorizedForSimulation, setCurrentView } = useAuth();

  const {
    setIsAICameraModalOpen,
    setIsAIVoiceModalOpen,
    setIsBarcodeScannerModalOpen,
    cameraConfig,
    voiceConfig,
    scaleConfig,
    barcodeConfig,
    printerConfig,
    drawerConfig,
    kickOpenDrawer,
    tareScale,
    headerVisibility,
  } = usePeripherals();

  const { language, setLanguage } = useLanguage();

  const [isOperatorMenuOpen, setIsOperatorMenuOpen] = useState(false);
  const operatorRef = useRef<HTMLDivElement>(null);

  // Operator switch requires PIN modal authentication
  const [pinTargetUser, setPinTargetUser] = useState<Operator | null>(null);
  const [switchPinInput, setSwitchPinInput] = useState('');
  const [switchPinError, setSwitchPinError] = useState('');

  const switchPinInputRef = useRef(switchPinInput);
  useEffect(() => {
    switchPinInputRef.current = switchPinInput;
  }, [switchPinInput]);

  const pinTargetUserRef = useRef(pinTargetUser);
  useEffect(() => {
    pinTargetUserRef.current = pinTargetUser;
  }, [pinTargetUser]);

  const handleSwitchPinInput = useCallback((k: string) => {
    playKeypadClick();
    if (k === 'C') {
      setSwitchPinInput('');
      setSwitchPinError('');
      return;
    }
    if (k === '⌫') {
      setSwitchPinInput((prev) => prev.slice(0, -1));
      setSwitchPinError('');
      return;
    }
    if (/^[0-9]$/.test(k)) {
      const current = switchPinInputRef.current;
      const targetUser = pinTargetUserRef.current;
      if (current.length >= 4) return;
      const next = current + k;
      setSwitchPinInput(next);
      setSwitchPinError('');

      if (next.length === 4 && targetUser) {
        const isAuthorized =
          (targetUser.pin && next === targetUser.pin) ||
          (isAuthorizedForSimulation && (next === '1234' || next === '0000' || next === targetUser.pin));
        if (isAuthorized) {
          playSuccessChime();
          setPinTargetUser(null);
          setSwitchPinInput('');
          setSwitchPinError('');
          // Update operator outside of updater callback
          switchOperator(targetUser);
        } else {
          playWarningTone();
          setSwitchPinError(`Incorrect PIN for ${targetUser.name}`);
          setSwitchPinInput('');
        }
      }
    }
  }, [switchOperator]);

  // Physical keyboard support for PIN input
  useEffect(() => {
    if (!pinTargetUser) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        setPinTargetUser(null);
        setSwitchPinInput('');
        setSwitchPinError('');
        return;
      }

      if (e.key === 'Backspace') {
        e.preventDefault();
        e.stopPropagation();
        handleSwitchPinInput('⌫');
        return;
      }

      if (e.key === 'Delete' || e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        e.stopPropagation();
        handleSwitchPinInput('C');
        return;
      }

      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        e.stopPropagation();
        handleSwitchPinInput(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [pinTargetUser, handleSwitchPinInput]);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (operatorRef.current && !operatorRef.current.contains(e.target as Node)) {
        setIsOperatorMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isKiosk = currentOperator?.userRole === 'Customer Kiosk';

  return (
    <header className="w-full z-40 flex items-center justify-between px-3 md:px-5 bg-white border-b border-[#D4D4D8] h-[68px] md:h-[72px] shrink-0 select-none shadow-2xs">
      {/* Left: Sidebar Toggle, Brand Logo, Name & Single Outlet Badge */}
      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        {!isKiosk && onToggleSidebar && (
          <button
            type="button"
            onClick={onToggleSidebar}
            className={`p-1.5 rounded-lg border transition-all cursor-pointer flex items-center justify-center shrink-0 shadow-2xs ${
              isSidebarHidden
                ? 'bg-blue-50 border-[#00478c] text-[#00478c] hover:bg-blue-100 hover:scale-105'
                : 'bg-[#F4F4F5] border-[#D4D4D8] text-gray-700 hover:bg-gray-200'
            }`}
            title={isSidebarHidden ? 'Show Side Menu (Modules) [Ctrl+B]' : 'Hide Side Menu (Maximize POS Screen Space) [Ctrl+B]'}
          >
            <span className="material-symbols-outlined text-[20px]">
              {isSidebarHidden ? 'menu_open' : 'menu'}
            </span>
          </button>
        )}

        <div className="flex items-center gap-2 shrink-0">
          <img
            src={logoImg}
            alt="Plannest POS Logo"
            className="h-14 md:h-16 w-auto max-w-[180px] object-contain shrink-0"
            loading="eager"
          />
          <span className="font-black text-2xl md:text-3xl tracking-tight text-[#00478c] font-sans leading-none shrink-0">
            POS
          </span>
        </div>

        <div className="h-6 w-px bg-gray-300 mx-0.5 hidden sm:block shrink-0"></div>

        <div className="flex items-center gap-1.5 shrink-0 whitespace-nowrap">
          <span className="font-bold text-sm md:text-base tracking-tight text-[#09090B] font-sans leading-none">
            {outletProfile?.outletName || 'Amma & Appa Kadai'}
          </span>
          {isKiosk && (
            <div className="ml-2 flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-300 text-amber-900 text-xs font-black shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
              <span>SELF-SERVICE KIOSK</span>
            </div>
          )}
          <div className="hidden md:flex items-center gap-1 ml-2">
            <button
              onClick={() => setCurrentView('home')}
              className="px-2 py-0.5 text-xs font-semibold text-gray-700 bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded transition-colors"
              title="Return to Plannest Home Page"
            >
              Home
            </button>
            {isCustomer && (
              <button
                onClick={() => setCurrentView('customer_portal')}
                className="px-2 py-0.5 text-xs font-bold text-white bg-[#00478c] hover:bg-[#003870] rounded transition-colors"
                title="Open Customer Plan & Installation Portal"
              >
                My Plan
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Cashier Operational Toolbar (Camera, Voice, Scanner, Produce Scale, Printer, Drawer) - Hidden in Kiosk Mode */}
      {!isKiosk && (
        <div className="flex items-center gap-1.5 shrink-0">
          {/* AI Camera Vision Scan [F2] - Disabled / Greyed out */}
          {cameraConfig.enabled && headerVisibility.camera && (
            <button
              type="button"
              disabled
              title="AI Visual Produce Scanner (Paused / Coming Soon)"
              className="w-8 h-8 flex items-center justify-center bg-gray-200 border border-gray-300 text-gray-400 opacity-50 rounded-lg cursor-not-allowed shadow-2xs shrink-0 select-none"
            >
              <span className="material-symbols-outlined text-[18px]">photo_camera</span>
            </button>
          )}

          {/* AI Voice Input [F3] - Disabled / Greyed out */}
          {voiceConfig.enabled && headerVisibility.voice && (
            <button
              type="button"
              disabled
              title="AI Voice Ordering (Paused / Coming Soon)"
              className="w-8 h-8 flex items-center justify-center bg-gray-200 border border-gray-300 text-gray-400 opacity-50 rounded-lg cursor-not-allowed shadow-2xs shrink-0 select-none"
            >
              <span className="material-symbols-outlined text-[18px]">mic</span>
            </button>
          )}

          {/* Barcode Scanner Setup & Test [F4] - Icon only */}
          {barcodeConfig.enabled && headerVisibility.scanner && (
            <button
              type="button"
              onClick={() => setIsBarcodeScannerModalOpen(true)}
              title="Barcode Scanner Hardware Test [F4]"
              className="w-8 h-8 flex items-center justify-center bg-white hover:bg-sky-50 border border-gray-300 hover:border-sky-400 text-sky-700 rounded-lg transition-all cursor-pointer shadow-2xs shrink-0"
            >
              <span className="material-symbols-outlined text-[18px]">qr_code_scanner</span>
            </button>
          )}

          {/* Digital Scale Readout Badge - Live weight reading without Tare */}
          {scaleConfig.enabled && headerVisibility.scale && (
            <div
              title={`Weighing Scale Reading: ${scaleConfig.currentWeight.toFixed(3)} ${scaleConfig.unit}${scaleConfig.isConnected ? ' (Live COM Stream)' : ''}`}
              className="flex items-center gap-1.5 h-8 px-2.5 bg-gray-900 text-emerald-400 border border-gray-700 rounded-lg font-mono text-xs font-bold shadow-2xs select-none shrink-0"
            >
              <span className="material-symbols-outlined text-emerald-400 text-[15px]">scale</span>
              <span>{scaleConfig.currentWeight.toFixed(3)} {scaleConfig.unit}</span>
            </div>
          )}

          {/* Thermal Receipt Printer Test / Last Receipt View */}
          {printerConfig.enabled && headerVisibility.printer && (
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                playSuccessChime();
                if (lastCompletedOrder) {
                  setIsReceiptOpen(true);
                } else {
                  try {
                    if (typeof window !== 'undefined' && window.print) {
                      window.print();
                    }
                  } catch (err) {
                    console.warn('Printer test blocked in iframe:', err);
                  }
                }
              }}
              title={lastCompletedOrder ? "View & Print Last Receipt" : "Thermal Printer Test"}
              className="w-8 h-8 flex items-center justify-center bg-white hover:bg-sky-50 border border-gray-300 hover:border-sky-400 text-sky-700 rounded-lg transition-all cursor-pointer shadow-2xs shrink-0"
            >
              <span className="material-symbols-outlined text-[17px]">print</span>
            </button>
          )}

          {/* Cash Drawer Kick */}
          {drawerConfig.enabled && headerVisibility.drawer && (
            <button
              type="button"
              onClick={kickOpenDrawer}
              title="Cash Drawer Kick [F8]"
              className="w-8 h-8 flex items-center justify-center bg-white hover:bg-rose-50 border border-gray-300 hover:border-rose-400 text-rose-700 rounded-lg transition-all cursor-pointer shadow-2xs shrink-0"
            >
              <span className="material-symbols-outlined text-[17px]">point_of_sale</span>
            </button>
          )}
        </div>
      )}

      {/* Right: Language Selector, Clock & Operator Profile */}
      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        {/* Catalog Language Selector */}
        <div className="flex items-center shrink-0">
          <div className="flex items-center gap-1 bg-white border border-gray-300 hover:border-[#00478c] rounded-lg px-2 h-8 shadow-2xs transition-all">
            <span className="material-symbols-outlined text-[16px] text-[#00478c]">
              translate
            </span>
            <select
              value={language}
              onChange={(e) => {
                playKeypadClick();
                setLanguage(e.target.value as 'en' | 'ta' | 'hi');
              }}
              title="Select POS Item & Category Display Language"
              className="bg-transparent text-xs font-bold text-gray-800 outline-none cursor-pointer py-0.5"
            >
              <option value="en">EN</option>
              <option value="ta">தமிழ்</option>
              <option value="hi">हिन्दी</option>
            </select>
          </div>
        </div>

        {/* Divider */}
        <div className="h-5 w-px bg-gray-300 mx-0.5 hidden sm:block"></div>

        {/* Clock & Operator Profile (Always Visible & Neatly Styled) */}
        <div className="flex items-center gap-2 shrink-0" ref={operatorRef}>
          <div className="text-right hidden sm:block leading-tight">
            <LiveClock />
            <div className="text-[10px] font-bold text-gray-500 uppercase tracking-tight flex items-center justify-end gap-1">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  currentOperator.userRole === 'Admin'
                    ? 'bg-purple-600'
                    : currentOperator.userRole === 'Supervisor'
                    ? 'bg-[#00478c]'
                    : currentOperator.userRole === 'Customer Kiosk'
                    ? 'bg-amber-500'
                    : 'bg-emerald-600'
                }`}
              ></span>
              {currentOperator.userRole || 'Cashier'}
            </div>
          </div>

          {/* Operator Avatar Dropdown - Username Always Visible */}
          <div className="relative">
            <button
              onClick={() => setIsOperatorMenuOpen(!isOperatorMenuOpen)}
              className="flex items-center gap-1.5 p-1 pl-1.5 pr-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors border border-gray-300 hover:border-[#00478c] cursor-pointer"
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center font-extrabold text-[11px] text-white shadow-xs shrink-0 ${
                  currentOperator.userRole === 'Admin'
                    ? 'bg-purple-700'
                    : currentOperator.userRole === 'Supervisor'
                    ? 'bg-[#00478c]'
                    : currentOperator.userRole === 'Customer Kiosk'
                    ? 'bg-amber-600'
                    : 'bg-emerald-700'
                }`}
              >
                {currentOperator.initials || currentOperator.name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase()}
              </div>

              <div className="text-left block leading-tight">
                <span className="text-xs font-bold text-[#09090B] block truncate max-w-[100px] sm:max-w-[140px]">
                  {currentOperator.name}
                </span>
                <span className="text-[9px] font-semibold text-[#00478c] block uppercase leading-none">
                  {currentOperator.userRole || 'Staff'}
                </span>
              </div>

              <span className="material-symbols-outlined text-gray-500 text-[16px] shrink-0">
                arrow_drop_down
              </span>
            </button>

            {isOperatorMenuOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-white border border-gray-300 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in">
                <div className="px-3 py-1.5 border-b border-gray-200 text-[10px] font-bold text-gray-500 uppercase tracking-wider flex items-center justify-between">
                  <span>Switch Operator / User</span>
                  <span className="text-gray-400">PIN Login</span>
                </div>

                <div className="max-h-56 overflow-y-auto divide-y divide-gray-100">
                  {(operators || OPERATORS).map((op) => (
                    <button
                      key={op.id}
                      onClick={() => {
                        playKeypadClick();
                        setIsOperatorMenuOpen(false);
                        if (currentOperator.id === op.id) return;
                        if (isAuthorizedForSimulation) {
                          switchOperator(op);
                          return;
                        }
                        setPinTargetUser(op);
                        setSwitchPinInput('');
                        setSwitchPinError('');
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors cursor-pointer ${
                        currentOperator.id === op.id ? 'bg-blue-50 text-[#00478c] font-bold' : 'text-[#09090B]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] text-white ${
                            op.userRole === 'Admin'
                              ? 'bg-purple-700'
                              : op.userRole === 'Supervisor'
                              ? 'bg-[#00478c]'
                              : op.userRole === 'Customer Kiosk'
                              ? 'bg-amber-600'
                              : 'bg-emerald-700'
                          }`}
                        >
                          {op.initials}
                        </div>
                        <div className="truncate">
                          <div className="text-xs font-bold leading-tight truncate">{op.name}</div>
                          <div className="text-[10px] text-gray-500 flex items-center gap-1">
                            <span className="font-semibold">{op.userRole || 'Staff'}</span>
                          </div>
                        </div>
                      </div>
                      {currentOperator.id === op.id && (
                        <span className="material-symbols-outlined text-[#00478c] text-[16px]">check</span>
                      )}
                    </button>
                  ))}
                </div>

                <div className="border-t border-gray-200 my-1"></div>
                <button
                  onClick={() => {
                    onOpenPinModal();
                    setIsOperatorMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-[#00478c] hover:bg-blue-50 flex items-center gap-2 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">lock</span>
                  Enter PIN / Lock Register
                </button>

                <button
                  onClick={() => {
                    setIsOperatorMenuOpen(false);
                    if (isAuthorizedForSimulation) {
                      setCurrentView('saas_hub');
                    } else {
                      try {
                        window.close();
                      } catch {
                        // ignore
                      }
                      setTimeout(() => setCurrentView('home'), 150);
                    }
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 flex items-center gap-2 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">logout</span>
                  Lock / Exit
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Switch Operator PIN Verification Modal */}
      {pinTargetUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center select-none">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => {
              setPinTargetUser(null);
              setSwitchPinInput('');
              setSwitchPinError('');
            }}
          />

          <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-[360px] max-w-[95vw] shadow-2xl p-5 text-center industrial-shadow animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-[#00478c]/15 text-[#00478c] flex items-center justify-center mx-auto mb-2.5">
              <span className="material-symbols-outlined text-2xl">key</span>
            </div>

            <h3 className="text-base font-bold text-[#09090B]">Switch Operator Authorization</h3>
            <p className="text-xs text-gray-600 mt-1">
              Enter 4-digit PIN for <strong>{pinTargetUser.name}</strong> ({pinTargetUser.userRole || 'Operator'})
            </p>

            {/* PIN Circles Display */}
            <div className="flex justify-center gap-3 my-4">
              {[0, 1, 2, 3].map((idx) => (
                <div
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full border-2 transition-all ${
                    switchPinInput.length > idx ? 'bg-[#00478c] border-[#00478c]' : 'border-[#D4D4D8] bg-[#F4F4F5]'
                  }`}
                />
              ))}
            </div>

            {switchPinError && (
              <div className="text-xs text-[#ba1a1a] font-semibold mb-3 bg-[#ffdad6]/60 p-2 rounded-lg flex items-center justify-center gap-1">
                <span className="material-symbols-outlined text-sm">error</span>
                <span>{switchPinError}</span>
              </div>
            )}

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => handleSwitchPinInput(k)}
                  className="h-11 border border-[#D4D4D8] rounded-lg font-tabular-numeric text-base font-bold bg-white hover:bg-[#F4F4F5] active:bg-[#E4E4E7] transition-colors cursor-pointer"
                >
                  {k}
                </button>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-gray-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setPinTargetUser(null);
                  setSwitchPinInput('');
                  setSwitchPinError('');
                }}
                className="px-3 py-1.5 text-xs font-bold text-gray-500 hover:text-gray-800 cursor-pointer"
              >
                Cancel (Esc)
              </button>
              <span className="text-[11px] text-gray-500 font-medium flex items-center gap-1">
                <span className="material-symbols-outlined text-[13px] text-[#00478c]">keyboard</span>
                Physical Numpad / Keys active
              </span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

