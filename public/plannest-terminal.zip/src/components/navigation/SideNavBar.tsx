import React from 'react';
import { usePOS, NavTab } from '../../context/POSContext';
import { useAuth } from '../../context/AuthContext';

interface SideNavBarProps {
  onOpenPinModal?: () => void;
  onOpenSupportModal: () => void;
  onExitApp?: () => void;
  isSidebarHidden?: boolean;
  isSidebarCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const SideNavBar: React.FC<SideNavBarProps> = ({
  onOpenPinModal,
  onOpenSupportModal,
  onExitApp,
  isSidebarHidden = false,
  isSidebarCollapsed = false,
  onToggleCollapse,
}) => {
  const { activeTab, setActiveTab, parkedOrders, currentShift, currentOperator } = usePOS();
  const { isAuthorizedForSimulation, setCurrentView } = useAuth();

  const handleExit = () => {
    if (onExitApp) {
      onExitApp();
      return;
    }
    if (isAuthorizedForSimulation) {
      setCurrentView('saas_hub');
      return;
    }
    try {
      window.close();
    } catch {
      // browser may block window.close
    }
    setTimeout(() => {
      setCurrentView('home');
    }, 150);
  };

  // For Customer Kiosk, hide all navigation menus completely
  if (isSidebarHidden || currentOperator?.userRole === 'Customer Kiosk') {
    return null;
  }

  const navItems: { id: NavTab; label: string; icon: string; badge?: number | string }[] = [
    {
      id: 'register',
      label: 'POS Billing',
      icon: 'point_of_sale',
      badge: parkedOrders.length > 0 ? `${parkedOrders.length}` : undefined,
    },
    { id: 'inventory', label: 'Admin Hub', icon: 'admin_panel_settings' },
    {
      id: 'reconciliation',
      label: 'Cash & UPI Drawer',
      icon: 'payments',
      badge:
        currentShift && Number.isFinite(currentShift.variance) && currentShift.variance !== 0
          ? `${currentShift.variance > 0 ? '+' : '-'}Rs. ${Math.abs(Math.round(currentShift.variance))}`
          : undefined,
    },
    { id: 'replenishment', label: 'Supplier & Replenishment', icon: 'auto_mode' },
    { id: 'analytics', label: 'Store Sales Analytics', icon: 'bar_chart' },
    { id: 'settings', label: 'Peripherals & Hardware', icon: 'settings' },
  ];

  return (
    <nav
      className={`flex flex-col p-3 border-r border-[#D4D4D8] bg-white shrink-0 z-30 hidden md:flex select-none h-full overflow-hidden transition-all duration-200 ${
        isSidebarCollapsed ? 'w-[72px]' : 'w-60 lg:w-64'
      }`}
    >
      {/* Top Header inside SideNavBar with Quick Icon-only Collapse Button */}
      <div
        className={`flex items-center pb-2 mb-1 border-b border-gray-100 ${
          isSidebarCollapsed ? 'justify-center' : 'justify-between'
        }`}
      >
        {!isSidebarCollapsed && (
          <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
            Navigation
          </span>
        )}
        {onToggleCollapse && (
          <button
            type="button"
            onClick={onToggleCollapse}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
            title={
              isSidebarCollapsed
                ? 'Expand menu text labels'
                : 'Hide menu text (Show menu icons only)'
            }
          >
            <span className="material-symbols-outlined text-[18px]">
              {isSidebarCollapsed ? 'keyboard_double_arrow_right' : 'keyboard_double_arrow_left'}
            </span>
          </button>
        )}
      </div>

      {/* Primary Module Links */}
      <div className="flex-1 flex flex-col gap-1.5 mt-2 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              title={isSidebarCollapsed ? item.label : undefined}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150 relative group ${
                isSidebarCollapsed ? 'justify-center' : ''
              } ${
                isActive
                  ? 'bg-[#00478c] text-white font-bold shadow-sm'
                  : 'text-[#5c403c] hover:bg-[#F4F4F5] hover:text-[#09090B]'
              }`}
            >
              <span
                className={`material-symbols-outlined text-[22px] shrink-0 ${
                  isActive ? 'text-white' : 'text-[#5c403c] group-hover:text-[#00478c]'
                }`}
                style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
              >
                {item.icon}
              </span>
              {!isSidebarCollapsed && (
                <span className="font-label-caps text-xs tracking-wider uppercase truncate">
                  {item.label}
                </span>
              )}
              {item.badge && (
                <span
                  className={`${
                    isSidebarCollapsed
                      ? 'absolute -top-1 -right-1 w-4 h-4 rounded-full text-[9px] flex items-center justify-center p-0'
                      : 'ml-auto px-1.5 py-0.5 rounded text-[10px]'
                  } font-bold font-tabular-numeric ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : item.id === 'reconciliation'
                      ? 'bg-[#ffdad6] text-[#ba1a1a]'
                      : 'bg-[#d6e3ff] text-[#00478c]'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Auxiliary Links */}
      <div className="mt-auto border-t border-[#D4D4D8] pt-3 flex flex-col gap-1">
        <button
          onClick={onOpenSupportModal}
          title={isSidebarCollapsed ? 'Help / Guide' : undefined}
          className={`flex items-center gap-3 px-3 py-2 rounded-lg text-left text-[#5c403c] hover:bg-[#F4F4F5] hover:text-[#09090B] transition-colors ${
            isSidebarCollapsed ? 'justify-center' : ''
          }`}
        >
          <span className="material-symbols-outlined text-[20px] shrink-0">help</span>
          {!isSidebarCollapsed && (
            <span className="font-label-caps text-xs tracking-wider uppercase">Help / Guide</span>
          )}
        </button>

        <button
          onClick={handleExit}
          title={isSidebarCollapsed ? 'Lock / Exit' : undefined}
          className={`flex items-center gap-3 px-3 py-2 rounded-lg text-left text-[#ba1a1a] hover:bg-[#ffdad6]/30 transition-colors ${
            isSidebarCollapsed ? 'justify-center' : ''
          }`}
        >
          <span className="material-symbols-outlined text-[20px] shrink-0">logout</span>
          {!isSidebarCollapsed && (
            <span className="font-label-caps text-xs tracking-wider uppercase">Lock / Exit</span>
          )}
        </button>
      </div>
    </nav>
  );
};
