import React, { useState, useEffect, useCallback } from 'react';
import { usePOS } from '../../context/POSContext';
import { apiClient, getCustomApiHost, setCustomApiHost } from '../../services/apiClient';
import { DatabaseConfig, DatabaseDriverType, DatabaseStatus } from '../../types/database';
import { playBarcodeBeep, playSuccessChime, playWarningTone } from '../../utils/audio';
import { triggerHaptic } from '../../utils/tabletUtils';

export const DatabaseSettingsTab: React.FC = () => {
  const { refreshProducts, canManageUsers, isOnline } = usePOS();

  // Status & Config State
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<DatabaseDriverType>('sqlite');

  // MySQL Connection Form
  const [mysqlHost, setMysqlHost] = useState('localhost');
  const [mysqlPort, setMysqlPort] = useState('3306');
  const [mysqlUser, setMysqlUser] = useState('root');
  const [mysqlPassword, setMysqlPassword] = useState('');
  const [mysqlDatabase, setMysqlDatabase] = useState('plannest_pos');
  const [mysqlSsl, setMysqlSsl] = useState(false);

  // Actions in flight
  const [isTestingMysql, setIsTestingMysql] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; version?: string } | null>(null);
  const [isSwitching, setIsSwitching] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);
  const [migrationResult, setMigrationResult] = useState<{ success: boolean; counts?: Record<string, number>; message: string } | null>(null);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Android Tablet Network Mode State
  const [terminalHostInput, setTerminalHostInput] = useState(() => getCustomApiHost());
  const [terminalNetworkMode, setTerminalNetworkMode] = useState<'standalone' | 'lan' | 'cloud'>(() => {
    const host = getCustomApiHost();
    if (!host) return 'standalone';
    if (host.includes('192.168.') || host.includes('10.') || host.includes('172.') || host.includes('localhost')) {
      return 'lan';
    }
    return 'cloud';
  });
  const [isTestingTerminal, setIsTestingTerminal] = useState(false);
  const [terminalTestResult, setTerminalTestResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleTestTerminalConnection = async () => {
    setIsTestingTerminal(true);
    setTerminalTestResult(null);
    triggerHaptic('medium');
    try {
      const hostVal = terminalHostInput.trim();
      if (!hostVal) {
        setTerminalTestResult({
          success: true,
          message: 'Standalone Tablet Mode is verified: Operates completely offline with zero network dependency.',
        });
        playSuccessChime();
        return;
      }
      let target = hostVal;
      if (!target.startsWith('http://') && !target.startsWith('https://')) {
        target = `http://${target}`;
      }
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);
      const res = await fetch(`${target}/api/health`, { signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok) throw new Error(`HTTP ${res.status}: Store server responded with error`);
      const data = await res.json();
      setTerminalTestResult({
        success: true,
        message: `✓ Connected successfully to Store Server! Database: ${data.database || 'Active'}`,
      });
      playSuccessChime();
    } catch (err: any) {
      setTerminalTestResult({
        success: false,
        message: `Could not connect to ${terminalHostInput}: ${err.message}. Check that the Store PC is running and both devices share the same Wi-Fi.`,
      });
      playWarningTone();
    } finally {
      setIsTestingTerminal(false);
    }
  };

  const handleSaveTerminalMode = async (mode: 'standalone' | 'lan' | 'cloud') => {
    triggerHaptic('success');
    setTerminalNetworkMode(mode);
    if (mode === 'standalone') {
      setCustomApiHost(null);
      setTerminalHostInput('');
      setNotice({ type: 'success', text: '✓ Switched to Standalone Tablet Mode (100% offline, local database)' });
      setTimeout(() => setNotice(null), 5000);
    } else {
      const hostVal = terminalHostInput.trim();
      if (!hostVal) {
        setNotice({ type: 'error', text: 'Please enter a valid IP address or server URL' });
        setTimeout(() => setNotice(null), 5000);
        return;
      }
      setCustomApiHost(hostVal);
      setNotice({ type: 'success', text: `✓ Connected tablet terminal to ${hostVal}` });
      setTimeout(() => setNotice(null), 5000);
    }
    await refreshProducts();
  };

  // Load Status
  const loadStatus = useCallback(async () => {
    setIsLoadingStatus(true);
    try {
      const status = await apiClient.getDatabaseStatus();
      setDbStatus(status);
      setSelectedDriver(status.driver || 'sqlite');
      if (status.mysqlDetails) {
        setMysqlHost(status.mysqlDetails.host || 'localhost');
        setMysqlPort(String(status.mysqlDetails.port || 3306));
        setMysqlUser(status.mysqlDetails.user || 'root');
        setMysqlDatabase(status.mysqlDetails.database || 'plannest_pos');
        setMysqlSsl(Boolean(status.mysqlDetails.ssl));
      }
    } catch (err: any) {
      console.warn('Failed to load DB status:', err);
    } finally {
      setIsLoadingStatus(false);
    }
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  // Test MySQL Connection
  const handleTestConnection = async () => {
    setIsTestingMysql(true);
    setTestResult(null);
    try {
      const res = await apiClient.testMysqlConnection({
        host: mysqlHost.trim(),
        port: parseInt(mysqlPort, 10) || 3306,
        user: mysqlUser.trim(),
        password: mysqlPassword,
        database: mysqlDatabase.trim(),
        ssl: mysqlSsl,
      });
      setTestResult(res);
      if (res.success) {
        playSuccessChime();
      } else {
        playWarningTone();
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Connection test failed',
      });
      playWarningTone();
    } finally {
      setIsTestingMysql(false);
    }
  };

  // Switch Active Database Driver
  const handleSwitchDriver = async (targetDriver: DatabaseDriverType) => {
    setIsSwitching(true);
    setNotice(null);
    try {
      const mysqlConfig = targetDriver === 'mysql' ? {
        host: mysqlHost.trim(),
        port: parseInt(mysqlPort, 10) || 3306,
        user: mysqlUser.trim(),
        password: mysqlPassword,
        database: mysqlDatabase.trim(),
        ssl: mysqlSsl,
      } : undefined;

      const res = await apiClient.switchDatabaseDriver(targetDriver, mysqlConfig);
      setSelectedDriver(targetDriver);
      await loadStatus();
      await refreshProducts();
      playSuccessChime();
      setNotice({ type: 'success', text: `✓ ${res.message}` });
      setTimeout(() => setNotice(null), 5000);
    } catch (err: any) {
      playWarningTone();
      setNotice({ type: 'error', text: `Error: ${err.message}` });
    } finally {
      setIsSwitching(false);
    }
  };

  // Migrate Local Data to MySQL
  const handleMigrateData = async () => {
    if (!confirm('This will copy all catalog items, variants, categories, customers, and operators from your Local SQLite database into the configured MySQL database. Continue?')) {
      return;
    }
    setIsMigrating(true);
    setMigrationResult(null);
    try {
      const res = await apiClient.migrateToMysql({
        host: mysqlHost.trim(),
        port: parseInt(mysqlPort, 10) || 3306,
        user: mysqlUser.trim(),
        password: mysqlPassword,
        database: mysqlDatabase.trim(),
        ssl: mysqlSsl,
      });
      setMigrationResult(res);
      playSuccessChime();
      await loadStatus();
    } catch (err: any) {
      playWarningTone();
      setMigrationResult({
        success: false,
        message: err.message || 'Migration failed',
      });
    } finally {
      setIsMigrating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Notice Banner */}
      {notice && (
        <div className={`p-4 rounded-xl text-xs font-bold flex items-center gap-2.5 border ${
          notice.type === 'success'
            ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
            : 'bg-red-50 text-red-900 border-red-300'
        }`}>
          <span className="material-symbols-outlined text-[20px]">
            {notice.type === 'success' ? 'check_circle' : 'error'}
          </span>
          <span>{notice.text}</span>
        </div>
      )}

      {/* Android Tablet Terminal & Multi-Device Network Architecture Card */}
      <div className="bg-white border border-[#D4D4D8] rounded-xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[#00478c] text-[26px]">tablet_android</span>
              <h2 className="text-lg font-black text-[#09090B]">Android Tablet Terminal &amp; Multi-Device Network</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold border flex items-center gap-1.5 bg-blue-50 text-[#00478c] border-blue-200">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                {terminalNetworkMode === 'standalone'
                  ? 'Standalone Tablet (Offline)'
                  : terminalNetworkMode === 'lan'
                  ? 'Store LAN Hub Connected'
                  : 'Cloud SQL Connected'}
              </span>
            </div>
            <p className="text-xs text-[#5c403c] mt-1">
              Configure how this Android Tablet operates: as an independent offline unit for a single shop, or linked over store Wi-Fi / Cloud SQL with other PCs and tablets.
            </p>
          </div>
        </div>

        {/* 3 Terminal Modes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-4">
          {/* Mode 1: Standalone Tablet */}
          <div
            onClick={() => handleSaveTerminalMode('standalone')}
            className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              terminalNetworkMode === 'standalone'
                ? 'border-[#00478c] bg-blue-50/50 shadow-sm'
                : 'border-gray-200 hover:border-gray-300 bg-white'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="material-symbols-outlined text-2xl text-[#00478c]">wifi_off</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  terminalNetworkMode === 'standalone' ? 'bg-[#00478c] text-white' : 'bg-gray-100 text-gray-600'
                }`}>
                  {terminalNetworkMode === 'standalone' ? 'Active' : 'Select'}
                </span>
              </div>
              <h3 className="font-extrabold text-sm text-[#09090B]">1. Standalone Tablet</h3>
              <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                100% offline. Operates using local IndexedDB without requiring any internet, server PC, or Wi-Fi router. Perfect for single counter retail or Mandi stalls.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-gray-100 flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
              <span className="material-symbols-outlined text-[14px]">check</span>
              <span>Zero setup required</span>
            </div>
          </div>

          {/* Mode 2: Local Store LAN Hub */}
          <div
            onClick={() => setTerminalNetworkMode('lan')}
            className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              terminalNetworkMode === 'lan'
                ? 'border-[#00478c] bg-blue-50/50 shadow-sm'
                : 'border-gray-200 hover:border-gray-300 bg-white'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="material-symbols-outlined text-2xl text-[#00478c]">router</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  terminalNetworkMode === 'lan' ? 'bg-[#00478c] text-white' : 'bg-gray-100 text-gray-600'
                }`}>
                  {terminalNetworkMode === 'lan' ? 'Active' : 'Select'}
                </span>
              </div>
              <h3 className="font-extrabold text-sm text-[#09090B]">2. Store Local LAN Hub</h3>
              <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                Connects tablet to your central Store Billing PC over local shop Wi-Fi. Multiple tablets and laptops share the same SQLite/MySQL inventory and bills.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-gray-100 flex items-center gap-1 text-[11px] font-semibold text-blue-700">
              <span className="material-symbols-outlined text-[14px]">sync</span>
              <span>Local Wi-Fi (No Internet needed)</span>
            </div>
          </div>

          {/* Mode 3: Central Cloud SQL Hub */}
          <div
            onClick={() => setTerminalNetworkMode('cloud')}
            className={`p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              terminalNetworkMode === 'cloud'
                ? 'border-[#00478c] bg-blue-50/50 shadow-sm'
                : 'border-gray-200 hover:border-gray-300 bg-white'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="material-symbols-outlined text-2xl text-[#00478c]">cloud_sync</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  terminalNetworkMode === 'cloud' ? 'bg-[#00478c] text-white' : 'bg-gray-100 text-gray-600'
                }`}>
                  {terminalNetworkMode === 'cloud' ? 'Active' : 'Select'}
                </span>
              </div>
              <h3 className="font-extrabold text-sm text-[#09090B]">3. Central Cloud SQL Hub</h3>
              <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                Direct connection to a remote Cloud SQL database cluster or hosted backend API for real-time multi-branch chains across cities.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-gray-100 flex items-center gap-1 text-[11px] font-semibold text-purple-700">
              <span className="material-symbols-outlined text-[14px]">public</span>
              <span>Multi-branch real-time</span>
            </div>
          </div>
        </div>

        {/* Network Host Input Form (for LAN and Cloud) */}
        {terminalNetworkMode !== 'standalone' && (
          <div className="mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">
                {terminalNetworkMode === 'lan' ? 'Store Central PC LAN IP Address / Host' : 'Cloud Server Endpoint URL'}
              </label>
              <div className="flex items-center gap-1.5 text-[11px] text-gray-500">
                <span>Quick Presets:</span>
                <button
                  type="button"
                  onClick={() => setTerminalHostInput('192.168.1.100:3000')}
                  className="px-2 py-0.5 bg-white border border-gray-300 rounded font-mono hover:bg-blue-50 text-[10px] cursor-pointer"
                >
                  192.168.1.100:3000
                </button>
                <button
                  type="button"
                  onClick={() => setTerminalHostInput('localhost:3000')}
                  className="px-2 py-0.5 bg-white border border-gray-300 rounded font-mono hover:bg-blue-50 text-[10px] cursor-pointer"
                >
                  localhost:3000
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2">
              <div className="relative flex-1 w-full">
                <span className="material-symbols-outlined absolute left-3 top-2.5 text-gray-400 text-[18px]">
                  dns
                </span>
                <input
                  type="text"
                  value={terminalHostInput}
                  onChange={(e) => setTerminalHostInput(e.target.value)}
                  placeholder={terminalNetworkMode === 'lan' ? 'e.g. 192.168.1.100:3000 or my-store-pc.local' : 'e.g. https://pos.mychain.com'}
                  className="w-full pl-9 pr-3 py-2 bg-white border border-gray-300 rounded-lg text-xs font-mono font-bold text-[#09090B] focus:border-[#00478c] focus:outline-none shadow-2xs"
                />
              </div>

              <button
                type="button"
                onClick={handleTestTerminalConnection}
                disabled={isTestingTerminal}
                className="w-full sm:w-auto px-4 py-2 bg-white hover:bg-gray-100 border border-gray-300 text-gray-700 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs disabled:opacity-50"
              >
                <span className={`material-symbols-outlined text-[16px] ${isTestingTerminal ? 'animate-spin' : ''}`}>
                  wifi_find
                </span>
                <span>Test Connection</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveTerminalMode(terminalNetworkMode)}
                className="w-full sm:w-auto px-4 py-2 bg-[#00478c] hover:bg-[#00366c] text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
              >
                <span className="material-symbols-outlined text-[16px]">save</span>
                <span>Save &amp; Connect</span>
              </button>
            </div>

            {terminalTestResult && (
              <div className={`p-3 rounded-lg text-xs font-semibold flex items-center gap-2 border ${
                terminalTestResult.success
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                  : 'bg-red-50 text-red-900 border-red-300'
              }`}>
                <span className="material-symbols-outlined text-[18px]">
                  {terminalTestResult.success ? 'check_circle' : 'warning'}
                </span>
                <span>{terminalTestResult.message}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Database Status Overview Card */}
      <div className="bg-white border border-[#D4D4D8] rounded-xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[#00478c] text-[26px]">database</span>
              <h2 className="text-lg font-black text-[#09090B]">Database Engine &amp; Storage Architecture</h2>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                dbStatus?.driver === 'mysql'
                  ? 'bg-blue-50 text-[#00478c] border-blue-200'
                  : 'bg-emerald-50 text-emerald-800 border-emerald-200'
              }`}>
                <span className={`w-2 h-2 rounded-full ${dbStatus?.driver === 'mysql' ? 'bg-[#00478c]' : 'bg-emerald-600'} animate-pulse`}></span>
                {dbStatus?.driver === 'mysql' ? 'MySQL Server Active' : 'Local SQLite Active'}
              </span>
            </div>
            <p className="text-xs text-[#5c403c] mt-1">
              Switch seamlessly between zero-config local embedded storage (SQLite) and a centralized remote MySQL cluster.
            </p>
          </div>

          <button
            type="button"
            onClick={loadStatus}
            disabled={isLoadingStatus}
            className="px-3.5 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-300 text-gray-700 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs self-start sm:self-auto disabled:opacity-50"
          >
            <span className={`material-symbols-outlined text-[16px] ${isLoadingStatus ? 'animate-spin' : ''}`}>
              refresh
            </span>
            <span>Check Status</span>
          </button>
        </div>

        {/* Live Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mt-4">
          <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-200">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block mb-1">Active Engine</span>
            <div className="font-extrabold text-sm text-[#09090B] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#00478c]">
                {dbStatus?.driver === 'mysql' ? 'cloud' : 'hard_drive'}
              </span>
              <span>{dbStatus?.driverName || 'Local Embedded SQLite'}</span>
            </div>
            <span className="text-[10px] text-gray-500 truncate block mt-0.5" title={dbStatus?.activeTarget}>
              Target: {dbStatus?.activeTarget || 'data/plannest_pos.db'}
            </span>
          </div>

          <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-200">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block mb-1">Health &amp; Connection</span>
            <div className="font-extrabold text-sm flex items-center gap-1.5 text-emerald-700">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>Online &amp; Connected</span>
            </div>
            <span className="text-[10px] text-gray-500 block mt-0.5">
              Synced with Dexie IndexedDB cache
            </span>
          </div>

          <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-200">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block mb-1">Active Catalog</span>
            <div className="font-extrabold text-sm text-[#09090B]">
              {dbStatus?.productCount || 0} Products
            </div>
            <span className="text-[10px] text-gray-500 block mt-0.5">
              {dbStatus?.variantCount || 0} SKU Barcode Variants
            </span>
          </div>

          <div className="p-3.5 bg-gray-50 rounded-xl border border-gray-200">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block mb-1">Offline Cache &amp; Fallback</span>
            <div className="font-extrabold text-sm text-emerald-800 flex items-center gap-1">
              <span className="material-symbols-outlined text-[16px]">verified</span>
              <span>IndexedDB Ready</span>
            </div>
            <span className="text-[10px] text-gray-500 block mt-0.5">
              Continues billing even if DB is offline
            </span>
          </div>
        </div>
      </div>

      {/* Engine Selection: SQLite vs MySQL */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* OPTION 1: Local SQLite */}
        <div className={`p-5 rounded-2xl border-2 transition-all flex flex-col justify-between gap-4 ${
          selectedDriver === 'sqlite'
            ? 'border-emerald-600 bg-emerald-50/40 shadow-md'
            : 'border-gray-200 bg-white hover:border-gray-300'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-emerald-100 text-emerald-800 rounded-lg material-symbols-outlined text-[24px]">
                  hard_drive
                </span>
                <div>
                  <h3 className="font-bold text-base text-[#09090B]">1. Local SQLite (Embedded)</h3>
                  <span className="text-[11px] text-emerald-800 font-bold">Recommended for Single Store / Offline POS</span>
                </div>
              </div>
              {dbStatus?.driver === 'sqlite' && (
                <span className="px-2.5 py-1 bg-emerald-600 text-white text-xs font-bold rounded-full flex items-center gap-1 shadow-2xs">
                  <span className="material-symbols-outlined text-[14px]">check</span>
                  Active Now
                </span>
              )}
            </div>

            <ul className="text-xs text-gray-600 space-y-2 mt-3 pl-1">
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span><strong>Zero Configuration:</strong> No external MySQL database server needed.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span><strong>Ultra-Fast Disk I/O:</strong> High speed WAL mode embedded file storage.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span><strong>Auto-Recovery:</strong> Built-in corruption healing and seed integrity checks.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span><strong>Local File:</strong> <code className="bg-gray-100 px-1 py-0.5 rounded text-[11px] text-gray-800 font-mono">data/plannest_pos.db</code></span>
              </li>
            </ul>
          </div>

          <button
            type="button"
            onClick={() => handleSwitchDriver('sqlite')}
            disabled={dbStatus?.driver === 'sqlite' || isSwitching}
            className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-all ${
              dbStatus?.driver === 'sqlite'
                ? 'bg-emerald-100 text-emerald-800 cursor-default font-black'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">
              {dbStatus?.driver === 'sqlite' ? 'check_circle' : 'toggle_on'}
            </span>
            <span>{dbStatus?.driver === 'sqlite' ? 'Current Active Database' : 'Switch to Local SQLite'}</span>
          </button>
        </div>

        {/* OPTION 2: Remote MySQL */}
        <div className={`p-5 rounded-2xl border-2 transition-all flex flex-col justify-between gap-4 ${
          selectedDriver === 'mysql'
            ? 'border-[#00478c] bg-blue-50/40 shadow-md'
            : 'border-gray-200 bg-white hover:border-gray-300'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-blue-100 text-[#00478c] rounded-lg material-symbols-outlined text-[24px]">
                  cloud
                </span>
                <div>
                  <h3 className="font-bold text-base text-[#09090B]">2. Remote MySQL Server</h3>
                  <span className="text-[11px] text-[#00478c] font-bold">Recommended for Multi-Counter / Multi-Store Chain</span>
                </div>
              </div>
              {dbStatus?.driver === 'mysql' && (
                <span className="px-2.5 py-1 bg-[#00478c] text-white text-xs font-bold rounded-full flex items-center gap-1 shadow-2xs">
                  <span className="material-symbols-outlined text-[14px]">check</span>
                  Active Now
                </span>
              )}
            </div>

            <ul className="text-xs text-gray-600 space-y-2 mt-3 pl-1">
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c] text-[16px]">check_circle</span>
                <span><strong>Multi-Terminal Sync:</strong> Live centralized orders, products, and inventory.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c] text-[16px]">check_circle</span>
                <span><strong>Cloud Database Ready:</strong> Supports AWS RDS, Google Cloud SQL, Hostinger, cPanel.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c] text-[16px]">check_circle</span>
                <span><strong>Connection Pooling:</strong> High-concurrency mysql2 pool with auto-reconnect.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c] text-[16px]">check_circle</span>
                <span><strong>Offline Protection:</strong> Dexie IndexedDB maintains cache when offline.</span>
              </li>
            </ul>
          </div>

          <button
            type="button"
            onClick={() => handleSwitchDriver('mysql')}
            disabled={dbStatus?.driver === 'mysql' || isSwitching}
            className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-all ${
              dbStatus?.driver === 'mysql'
                ? 'bg-blue-100 text-[#00478c] cursor-default font-black'
                : 'bg-[#00478c] hover:bg-[#005eb7] text-white'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">
              {dbStatus?.driver === 'mysql' ? 'check_circle' : 'toggle_on'}
            </span>
            <span>{dbStatus?.driver === 'mysql' ? 'Current Active Database' : 'Switch to MySQL Server'}</span>
          </button>
        </div>
      </div>

      {/* MySQL Connection Credentials Configuration */}
      <div className="bg-white border border-[#D4D4D8] rounded-xl p-5 shadow-xs space-y-5">
        <div className="flex items-center justify-between border-b border-gray-200 pb-3">
          <div>
            <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00478c]">tune</span>
              <span>MySQL Server Credentials &amp; Parameters</span>
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Enter your remote MySQL host information below. Test the connection before switching or migrating data.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTestingMysql || !mysqlHost.trim() || !mysqlDatabase.trim()}
              className="px-3.5 py-2 bg-white hover:bg-blue-50 border border-[#00478c] text-[#00478c] rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs disabled:opacity-50"
            >
              <span className={`material-symbols-outlined text-[16px] ${isTestingMysql ? 'animate-spin' : ''}`}>
                network_ping
              </span>
              <span>{isTestingMysql ? 'Testing...' : 'Test Connection'}</span>
            </button>
          </div>
        </div>

        {/* Test Result Message */}
        {testResult && (
          <div className={`p-3.5 rounded-xl border text-xs font-bold flex items-center gap-2.5 ${
            testResult.success
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : 'bg-red-50 text-red-900 border-red-300'
          }`}>
            <span className="material-symbols-outlined text-[18px]">
              {testResult.success ? 'check_circle' : 'error'}
            </span>
            <div className="flex-1">
              <div>{testResult.message}</div>
              {testResult.version && (
                <div className="text-[11px] font-normal text-emerald-700 mt-0.5">Server Engine: {testResult.version}</div>
              )}
            </div>
          </div>
        )}

        {/* Form Fields */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
              HOST / IP ADDRESS
            </label>
            <input
              type="text"
              value={mysqlHost}
              onChange={(e) => setMysqlHost(e.target.value)}
              placeholder="e.g. 192.168.1.100 or db.myretailstore.com"
              className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c] font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
              PORT
            </label>
            <input
              type="number"
              value={mysqlPort}
              onChange={(e) => setMysqlPort(e.target.value)}
              placeholder="3306"
              className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c] font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
              DATABASE NAME
            </label>
            <input
              type="text"
              value={mysqlDatabase}
              onChange={(e) => setMysqlDatabase(e.target.value)}
              placeholder="plannest_pos"
              className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c] font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
              USERNAME
            </label>
            <input
              type="text"
              value={mysqlUser}
              onChange={(e) => setMysqlUser(e.target.value)}
              placeholder="root or pos_admin"
              className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c] font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
              PASSWORD
            </label>
            <input
              type="password"
              value={mysqlPassword}
              onChange={(e) => setMysqlPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c] font-mono"
            />
          </div>

          <div className="flex flex-col justify-center">
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={mysqlSsl}
                onChange={(e) => setMysqlSsl(e.target.checked)}
                className="w-4 h-4 rounded text-[#00478c] border-gray-300 focus:ring-[#00478c]"
              />
              <div>
                <div className="text-xs font-bold text-gray-900">Enable SSL / TLS Encryption</div>
                <div className="text-[10px] text-gray-500">Required for cloud hosts like AWS RDS &amp; Aiven</div>
              </div>
            </label>
          </div>
        </div>

        {/* Migration / Sync Utility */}
        <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 mt-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-amber-100 text-amber-900 rounded-lg material-symbols-outlined text-[24px] shrink-0">
              move_down
            </span>
            <div>
              <h4 className="font-bold text-xs text-amber-950 uppercase tracking-wider">
                One-Click Local Data Migration to MySQL
              </h4>
              <p className="text-xs text-amber-900 mt-0.5">
                Copy all {dbStatus?.productCount || 0} products, SKUs, barcode mappings, customers, categories, and operators into MySQL with automatically created schemas.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleMigrateData}
            disabled={isMigrating || !mysqlHost.trim()}
            className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-2 cursor-pointer shadow-2xs shrink-0 disabled:opacity-50"
          >
            <span className={`material-symbols-outlined text-[16px] ${isMigrating ? 'animate-spin' : ''}`}>
              {isMigrating ? 'sync' : 'upload'}
            </span>
            <span>{isMigrating ? 'Migrating Data...' : 'Migrate Catalog to MySQL'}</span>
          </button>
        </div>

        {/* Migration Output */}
        {migrationResult && (
          <div className={`p-3.5 rounded-xl border text-xs font-bold flex items-center gap-2.5 ${
            migrationResult.success
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : 'bg-red-50 text-red-900 border-red-300'
          }`}>
            <span className="material-symbols-outlined text-[18px]">
              {migrationResult.success ? 'check_circle' : 'error'}
            </span>
            <span>{migrationResult.message}</span>
          </div>
        )}
      </div>
    </div>
  );
};
