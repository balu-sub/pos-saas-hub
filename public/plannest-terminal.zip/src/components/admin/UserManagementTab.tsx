import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { usePOS } from '../../context/POSContext';
import { useAuth } from '../../context/AuthContext';
import { Operator, UserRole, DEFAULT_OPERATORS } from '../../types/pos';
import { playKeypadClick, playSuccessChime, playWarningTone } from '../../utils/audio';

interface UserManagementTabProps {
  onOpenPinModal?: () => void;
}

export const UserManagementTab: React.FC<UserManagementTabProps> = ({ onOpenPinModal }) => {
  const { isAuthorizedForSimulation, isSuperAdmin } = useAuth();
  const isSuperAdminSim = Boolean(isAuthorizedForSimulation || isSuperAdmin);

  const {
    operators,
    currentOperator,
    switchOperator,
    addOperator,
    updateOperator,
    deleteOperator,
    canManageUsers,
  } = usePOS();

  // Active selected user for Master-Detail Editing
  const [selectedUserId, setSelectedUserId] = useState<string>(() => DEFAULT_OPERATORS[0]?.id || 'emp_03');
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | UserRole>('ALL');
  const [notificationNotice, setNotificationNotice] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error'>('success');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const formTopRef = useRef<HTMLDivElement>(null);

  // Edit Form Fields
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('Staff');
  const [editRoleTitle, setEditRoleTitle] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editPin, setEditPin] = useState('');
  const [editStatus, setEditStatus] = useState<'active' | 'inactive'>('active');
  const [editPinVisible, setEditPinVisible] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Add User Drawer / Mode
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('Staff');
  const [newRoleTitle, setNewRoleTitle] = useState('POS Billing Cashier');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newPin, setNewPin] = useState('1234');
  const [newStatus, setNewStatus] = useState<'active' | 'inactive'>('active');
  const [newError, setNewError] = useState<string | null>(null);

  // Delete Confirmation Modal
  const [deletingUser, setDeletingUser] = useState<Operator | null>(null);

  // Switch User PIN Verification State
  const [switchTargetUser, setSwitchTargetUser] = useState<Operator | null>(null);
  const [switchPinInput, setSwitchPinInput] = useState('');
  const [switchPinError, setSwitchPinError] = useState('');

  const switchPinInputRef = useRef(switchPinInput);
  useEffect(() => {
    switchPinInputRef.current = switchPinInput;
  }, [switchPinInput]);

  const switchTargetUserRef = useRef(switchTargetUser);
  useEffect(() => {
    switchTargetUserRef.current = switchTargetUser;
  }, [switchTargetUser]);

  const handleSwitchPinInput = useCallback((k: string) => {
    playKeypadClick();
    if (k === 'C') {
      setSwitchPinInput('');
      setSwitchPinError('');
      return;
    }
    if (k === '⌫') {
      setSwitchPinInput((prev) => prev.slice(0, -1));
      setSwitchPinError('');
      return;
    }
    if (/^[0-9]$/.test(k)) {
      const current = switchPinInputRef.current;
      const targetUser = switchTargetUserRef.current;
      if (current.length >= 4) return;
      const next = current + k;
      setSwitchPinInput(next);
      setSwitchPinError('');

      if (next.length === 4 && targetUser) {
        const isAuthorized =
          (targetUser.pin && next === targetUser.pin) ||
          (isSuperAdminSim && (next === '1234' || next === '0000' || next === targetUser.pin));
        if (isAuthorized) {
          playSuccessChime();
          setSwitchTargetUser(null);
          setSwitchPinInput('');
          setSwitchPinError('');
          switchOperator(targetUser);
          showToast(`Switched active operator to "${targetUser.name}"`);
        } else {
          playWarningTone();
          setSwitchPinError(`Incorrect PIN for ${targetUser.name}`);
          setSwitchPinInput('');
        }
      }
    }
  }, [switchOperator]);

  useEffect(() => {
    if (!switchTargetUser) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        setSwitchTargetUser(null);
        setSwitchPinInput('');
        setSwitchPinError('');
        return;
      }
      if (e.key === 'Backspace') {
        e.preventDefault();
        e.stopPropagation();
        handleSwitchPinInput('⌫');
        return;
      }
      if (e.key === 'Delete' || e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        e.stopPropagation();
        handleSwitchPinInput('C');
        return;
      }
      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        e.stopPropagation();
        handleSwitchPinInput(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [switchTargetUser, handleSwitchPinInput]);

  // Normalized list of users with fallback
  const userList: Operator[] = useMemo(() => {
    const list = Array.isArray(operators) && operators.length > 0 ? operators : DEFAULT_OPERATORS;
    return list.map((op) => ({
      ...op,
      userRole: op.userRole || (op.role?.toLowerCase().includes('admin') ? 'Admin' : op.role?.toLowerCase().includes('supervisor') ? 'Supervisor' : 'Staff'),
      status: op.status || 'active',
      roleTitle: op.roleTitle || (op.userRole === 'Admin' ? 'Store Administrator' : op.userRole === 'Supervisor' ? 'Floor Supervisor' : 'Billing Cashier'),
    }));
  }, [operators]);

  // Ensure an active selected user
  const effectiveSelectedId = useMemo(() => {
    if (selectedUserId && userList.some((u) => u.id === selectedUserId)) {
      return selectedUserId;
    }
    return userList[0]?.id || '';
  }, [selectedUserId, userList]);

  const selectedUser = useMemo(() => {
    return userList.find((u) => u.id === effectiveSelectedId) || userList[0] || null;
  }, [effectiveSelectedId, userList]);

  // Sync form when selectedUser changes (and not creating new)
  React.useEffect(() => {
    if (selectedUser && !isCreatingNew) {
      setEditName(selectedUser.name);
      setEditRole(selectedUser.userRole);
      setEditRoleTitle(selectedUser.roleTitle || '');
      setEditEmail(selectedUser.email || '');
      setEditPhone(selectedUser.phone || '');
      setEditPin(selectedUser.pin || '0000');
      setEditStatus(selectedUser.status || 'active');
      setEditError(null);
    }
  }, [selectedUser, isCreatingNew]);

  // Filtered List
  const filteredUsers = useMemo(() => {
    return userList.filter((u) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        u.name.toLowerCase().includes(q) ||
        (u.email && u.email.toLowerCase().includes(q)) ||
        (u.phone && u.phone.includes(q)) ||
        (u.roleTitle && u.roleTitle.toLowerCase().includes(q)) ||
        u.userRole.toLowerCase().includes(q);

      const matchRole = roleFilter === 'ALL' || u.userRole === roleFilter;
      return matchSearch && matchRole;
    });
  }, [userList, searchQuery, roleFilter]);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    if (type === 'success') {
      playSuccessChime();
    } else {
      playWarningTone();
    }
    setToastType(type);
    setNotificationNotice(msg);
    setTimeout(() => setNotificationNotice(null), 4000);
  };

  const handleSelectUser = (user: Operator) => {
    playKeypadClick();
    setIsCreatingNew(false);
    setSelectedUserId(user.id);
  };

  const handleGeneratePin = (isNew: boolean) => {
    playKeypadClick();
    const pin = Math.floor(1000 + Math.random() * 9000).toString();
    if (isNew) {
      setNewPin(pin);
    } else {
      setEditPin(pin);
    }
  };

  // Save changes to selected user
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      showToast('Please select a user to update.', 'error');
      return;
    }

    const cleanName = editName.trim();
    const cleanPin = editPin.trim();

    if (!cleanName) {
      setEditError('Full Name is required.');
      showToast('⚠️ Full Name is required to save changes.', 'error');
      formTopRef.current?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    if (!/^\d{4}$/.test(cleanPin)) {
      setEditError('PIN must be exactly 4 numeric digits.');
      showToast('⚠️ PIN must be exactly 4 numeric digits.', 'error');
      formTopRef.current?.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    // Protect single Admin (bypassed for Super Admin in simulation)
    if (selectedUser.userRole === 'Admin' && editRole !== 'Admin' && !isSuperAdminSim) {
      const otherAdmins = userList.filter((u) => u.id !== selectedUser.id && u.userRole === 'Admin' && u.status === 'active');
      if (otherAdmins.length === 0) {
        setEditError('At least one active Admin must exist in the system.');
        showToast('⚠️ At least one active Admin must exist.', 'error');
        formTopRef.current?.scrollIntoView({ behavior: 'smooth' });
        return;
      }
    }

    setIsSaving(true);
    setEditError(null);
    try {
      const updated: Operator = {
        ...selectedUser,
        name: cleanName,
        userRole: editRole,
        roleTitle: editRoleTitle.trim() || (editRole === 'Admin' ? 'Store Administrator' : editRole === 'Supervisor' ? 'Floor Supervisor' : 'Billing Cashier'),
        role: editRole === 'Admin' ? 'Admin (Full Access & User Mgmt)' : editRole === 'Supervisor' ? 'Supervisor (Catalog & Inventory)' : 'Staff (POS, PO, GRN & Reports)',
        email: editEmail.trim() || undefined,
        phone: editPhone.trim() || undefined,
        pin: cleanPin,
        status: editStatus,
        initials: cleanName.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase() || 'OP',
      };

      await updateOperator(updated);
      setSelectedUserId(updated.id);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
      showToast(`✓ Updated profile for "${updated.name}"`, 'success');
    } catch (err: any) {
      setEditError(err.message || 'Failed to save user changes');
      showToast(err.message || 'Failed to save user changes', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Create new user
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newName.trim();
    const cleanPin = newPin.trim();

    if (!cleanName) {
      setNewError('Full Name is required.');
      showToast('⚠️ Full Name is required to create user.', 'error');
      return;
    }
    if (!/^\d{4}$/.test(cleanPin)) {
      setNewError('PIN must be exactly 4 numeric digits.');
      showToast('⚠️ PIN must be exactly 4 numeric digits.', 'error');
      return;
    }

    try {
      const newUserId = `op_${Date.now()}`;
      const newOp: Operator = {
        id: newUserId,
        name: cleanName,
        userRole: newRole,
        roleTitle: newRoleTitle.trim() || (newRole === 'Admin' ? 'Store Administrator' : newRole === 'Supervisor' ? 'Floor Supervisor' : 'Billing Cashier'),
        role: newRole === 'Admin' ? 'Admin (Full Access & User Mgmt)' : newRole === 'Supervisor' ? 'Supervisor (Catalog & Inventory)' : 'Staff (POS, PO, GRN & Reports)',
        email: newEmail.trim() || undefined,
        phone: newPhone.trim() || undefined,
        pin: cleanPin,
        status: newStatus,
        initials: cleanName.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase() || 'OP',
      };

      await addOperator(newOp);
      setIsCreatingNew(false);
      setSelectedUserId(newUserId);
      setNewName('');
      setNewEmail('');
      setNewPhone('');
      setNewPin('1234');
      setNewError(null);
      showToast(`✓ Created new user "${newOp.name}"`, 'success');
    } catch (err: any) {
      setNewError(err.message || 'Failed to create user');
      showToast(err.message || 'Failed to create user', 'error');
    }
  };

  // Delete User
  const handleConfirmDelete = async () => {
    if (!deletingUser) return;
    const name = deletingUser.name;
    const success = await deleteOperator(deletingUser.id);
    if (success) {
      setDeletingUser(null);
      if (selectedUserId === deletingUser.id) {
        setSelectedUserId('');
      }
      showToast(`Deleted user "${name}"`);
    } else {
      playWarningTone();
      alert('Cannot delete this user: At least one active Admin must remain.');
      setDeletingUser(null);
    }
  };

  return (
    <div className="flex-1 w-full h-full min-h-0 flex flex-col gap-3 overflow-hidden font-sans">
      {/* Toast Notification */}
      {notificationNotice && (
        <div
          className={`fixed top-16 right-6 z-50 text-white px-4 py-2.5 rounded-lg shadow-xl font-bold text-xs flex items-center gap-2 animate-in fade-in ${
            toastType === 'error' ? 'bg-red-600' : 'bg-[#00478c]'
          }`}
        >
          <span className="material-symbols-outlined text-base">
            {toastType === 'error' ? 'error' : 'check_circle'}
          </span>
          <span>{notificationNotice}</span>
        </div>
      )}

      {/* Non-Admin Banner */}
      {!canManageUsers && (
        <div className="bg-amber-50 border border-amber-300 rounded-xl p-3 flex items-center justify-between gap-3 shrink-0 shadow-2xs">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-amber-600 text-xl">lock</span>
            <div>
              <p className="text-xs font-bold text-amber-950">
                User Management is in View-Only Mode
              </p>
              <p className="text-[11px] text-amber-800">
                Logged in as <strong>{currentOperator.name}</strong> ({currentOperator.userRole}). Admin PIN required to modify user roles and security.
              </p>
            </div>
          </div>
          {onOpenPinModal && (
            <button
              onClick={() => onOpenPinModal()}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-sm">key</span>
              Enter Admin PIN
            </button>
          )}
        </div>
      )}

      {/* Main 2-Column Responsive Workspace */}
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 gap-3.5 overflow-hidden">
        {/* LEFT COLUMN: Users List & Filtering (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col bg-white rounded-xl border border-[#D4D4D8] overflow-hidden shadow-2xs min-h-0">
          {/* Header with Search & Add Button */}
          <div className="p-3 border-b border-gray-200 bg-gray-50 flex flex-col gap-2.5 shrink-0">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#00478c] text-lg">group</span>
                <h3 className="font-extrabold text-sm text-[#09090B]">Team Members ({userList.length})</h3>
              </div>
              <button
                type="button"
                disabled={!canManageUsers}
                onClick={() => {
                  playKeypadClick();
                  setIsCreatingNew(true);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all ${
                  canManageUsers
                    ? 'bg-[#00478c] hover:bg-[#003870] text-white cursor-pointer shadow-xs active:scale-95'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
                title={canManageUsers ? 'Add new user account' : 'Admin role required'}
              >
                <span className="material-symbols-outlined text-sm">person_add</span>
                <span>Add User</span>
              </button>
            </div>

            {/* Search Input */}
            <div className="relative">
              <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 text-base">
                search
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name, role, email or phone..."
                className="w-full pl-8 pr-7 py-1.5 text-xs bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] text-gray-900"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-0.5 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-xs">close</span>
                </button>
              )}
            </div>

            {/* Role Filter Tabs */}
            <div className="flex items-center gap-1 bg-gray-200/70 p-1 rounded-lg">
              {(['ALL', 'Admin', 'Supervisor', 'Staff'] as const).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setRoleFilter(r);
                  }}
                  className={`flex-1 py-1 rounded text-[11px] font-bold transition-all cursor-pointer ${
                    roleFilter === r
                      ? 'bg-white text-[#00478c] shadow-2xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {r === 'ALL' ? 'All' : r}
                </button>
              ))}
            </div>
          </div>

          {/* User List Rows */}
          <div className="flex-1 overflow-y-auto divide-y divide-gray-100 p-1.5">
            {filteredUsers.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <span className="material-symbols-outlined text-3xl text-gray-300 mb-1">person_off</span>
                <p className="text-xs font-semibold">No users matching search</p>
              </div>
            ) : (
              filteredUsers.map((user) => {
                const isSelected = !isCreatingNew && selectedUser?.id === user.id;
                const isCurrent = currentOperator.id === user.id;

                return (
                  <div
                    key={user.id}
                    onClick={() => handleSelectUser(user)}
                    className={`p-2.5 rounded-lg mb-1 flex items-center justify-between gap-2.5 cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-blue-50/80 border-2 border-[#00478c] shadow-2xs'
                        : 'hover:bg-gray-50 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {/* Avatar Badge */}
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center font-extrabold text-xs shrink-0 text-white shadow-2xs ${
                          user.userRole === 'Admin'
                            ? 'bg-purple-700'
                            : user.userRole === 'Supervisor'
                            ? 'bg-[#00478c]'
                            : 'bg-emerald-700'
                        }`}
                      >
                        {user.initials || user.name.substring(0, 2).toUpperCase()}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-xs text-[#09090B] truncate">{user.name}</span>
                          {isCurrent && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold bg-blue-600 text-white uppercase tracking-wider">
                              You
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-gray-500 font-medium">
                          <span
                            className={`font-semibold ${
                              user.userRole === 'Admin'
                                ? 'text-purple-700'
                                : user.userRole === 'Supervisor'
                                ? 'text-[#00478c]'
                                : 'text-emerald-700'
                            }`}
                          >
                            {user.userRole}
                          </span>
                          <span>•</span>
                          <span>{user.roleTitle}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          user.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-gray-200 text-gray-600'
                        }`}
                      >
                        {user.status === 'active' ? 'Active' : 'Locked'}
                      </span>
                      <span className="material-symbols-outlined text-gray-400 text-base">
                        chevron_right
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: User Detail / Edit Panel or Create Form (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col bg-white rounded-xl border border-[#D4D4D8] overflow-hidden shadow-2xs min-h-0">
          {isCreatingNew ? (
            /* CREATE NEW USER VIEW */
            <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
              <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-[#00478c] text-white flex items-center justify-center">
                    <span className="material-symbols-outlined text-base">person_add</span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-[#09090B]">Create New User Account</h3>
                    <p className="text-[11px] text-gray-500">Add an operator to store terminal with assigned role &amp; PIN</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="px-2.5 py-1 text-xs font-bold text-gray-600 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleCreateSubmit} className="p-4 flex-1 flex flex-col justify-between gap-4">
                {newError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-lg flex items-center gap-2">
                    <span className="material-symbols-outlined text-base">error</span>
                    <span>{newError}</span>
                  </div>
                )}

                <div className="space-y-3.5">
                  {/* Full Name & Role */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="e.g. Anand Kumar"
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">System Role *</label>
                      <select
                        value={newRole}
                        onChange={(e) => {
                          const r = e.target.value as UserRole;
                          setNewRole(r);
                          setNewRoleTitle(r === 'Admin' ? 'Store Administrator' : r === 'Supervisor' ? 'Floor Supervisor' : 'POS Billing Cashier');
                        }}
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-semibold cursor-pointer"
                      >
                        <option value="Staff">Staff (POS Billing &amp; Reports)</option>
                        <option value="Supervisor">Supervisor (Catalog, PO, Stock &amp; Settings)</option>
                        <option value="Admin">Admin (Full System &amp; User Management)</option>
                      </select>
                    </div>
                  </div>

                  {/* Role Title */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Job / Designation Title</label>
                    <input
                      type="text"
                      value={newRoleTitle}
                      onChange={(e) => setNewRoleTitle(e.target.value)}
                      placeholder="e.g. Senior Cashier / Inventory Specialist"
                      className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium"
                    />
                  </div>

                  {/* Email & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Email Address</label>
                      <input
                        type="email"
                        value={newEmail}
                        onChange={(e) => setNewEmail(e.target.value)}
                        placeholder="operator@store.com"
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Phone Number</label>
                      <input
                        type="tel"
                        value={newPhone}
                        onChange={(e) => setNewPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium"
                      />
                    </div>
                  </div>

                  {/* PIN & Status */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-gray-700">4-Digit Security PIN *</label>
                        <button
                          type="button"
                          onClick={() => handleGeneratePin(true)}
                          className="text-[11px] font-bold text-[#00478c] hover:underline cursor-pointer"
                        >
                          Generate Random
                        </button>
                      </div>
                      <input
                        type="text"
                        maxLength={4}
                        required
                        value={newPin}
                        onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                        placeholder="4 digits"
                        className="w-full px-3 py-2 text-center text-base font-mono font-bold tracking-widest bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Account Status</label>
                      <select
                        value={newStatus}
                        onChange={(e) => setNewStatus(e.target.value as any)}
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-semibold cursor-pointer"
                      >
                        <option value="active">🟢 Active (Can Login)</option>
                        <option value="inactive">⚪ Inactive / Locked</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-gray-200 flex items-center justify-end gap-2.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsCreatingNew(false)}
                    className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold bg-[#00478c] hover:bg-[#003870] text-white rounded-lg transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-sm">person_add</span>
                    Create User Account
                  </button>
                </div>
              </form>
            </div>
          ) : selectedUser ? (
            /* EDIT / DETAIL VIEW FOR SELECTED USER */
            <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
              {/* Profile Card Header */}
              <div className="p-4 border-b border-gray-200 bg-gray-50/80 flex items-center justify-between flex-wrap gap-3 shrink-0">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-full flex items-center justify-center font-black text-sm text-white shadow-2xs ${
                      selectedUser.userRole === 'Admin'
                        ? 'bg-purple-700 border-2 border-purple-300'
                        : selectedUser.userRole === 'Supervisor'
                        ? 'bg-[#00478c] border-2 border-blue-300'
                        : 'bg-emerald-700 border-2 border-emerald-300'
                    }`}
                  >
                    {selectedUser.initials || selectedUser.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-extrabold text-base text-[#09090B]">{selectedUser.name}</h3>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          selectedUser.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-gray-200 text-gray-700'
                        }`}
                      >
                        {selectedUser.status === 'active' ? 'Active' : 'Locked'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 font-medium">
                      User ID: <span className="font-mono text-gray-700">{selectedUser.id}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Switch to this user */}
                  {currentOperator.id !== selectedUser.id && (
                    <button
                      type="button"
                      onClick={() => {
                        playKeypadClick();
                        if (isSuperAdminSim) {
                          switchOperator(selectedUser);
                          showToast(`Switched active operator to "${selectedUser.name}"`);
                          return;
                        }
                        setSwitchTargetUser(selectedUser);
                        setSwitchPinInput('');
                        setSwitchPinError('');
                      }}
                      className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-[#00478c] rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                      title="Switch active operator session to this user"
                    >
                      <span className="material-symbols-outlined text-sm">switch_account</span>
                      <span>Switch User</span>
                    </button>
                  )}

                  {/* Delete Button */}
                  {canManageUsers && (
                    <button
                      type="button"
                      onClick={() => setDeletingUser(selectedUser)}
                      className="p-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 rounded-lg transition-colors cursor-pointer shadow-2xs"
                      title="Delete this user account"
                    >
                      <span className="material-symbols-outlined text-base">delete</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Edit Form */}
              <form onSubmit={handleSaveEdit} noValidate className="p-4 flex-1 flex flex-col justify-between gap-4">
                <div ref={formTopRef} />
                {editError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-lg flex items-center gap-2">
                    <span className="material-symbols-outlined text-base">error</span>
                    <span>{editError}</span>
                  </div>
                )}

                <div className="space-y-3.5">
                  {/* Full Name & System Role */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Full Name</label>
                      <input
                        type="text"
                        disabled={!canManageUsers}
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium disabled:opacity-60"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">System Role</label>
                      <select
                        disabled={!canManageUsers}
                        value={editRole}
                        onChange={(e) => setEditRole(e.target.value as UserRole)}
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-semibold cursor-pointer disabled:opacity-60"
                      >
                        <option value="Staff">Staff (POS Billing &amp; Reports)</option>
                        <option value="Supervisor">Supervisor (Catalog, PO, Stock &amp; Settings)</option>
                        <option value="Admin">Admin (Full System &amp; User Management)</option>
                      </select>
                    </div>
                  </div>

                  {/* Designation Title */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Job Designation / Title</label>
                    <input
                      type="text"
                      disabled={!canManageUsers}
                      value={editRoleTitle}
                      onChange={(e) => setEditRoleTitle(e.target.value)}
                      placeholder="e.g. Store Manager"
                      className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium disabled:opacity-60"
                    />
                  </div>

                  {/* Email & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Email Address</label>
                      <input
                        type="email"
                        disabled={!canManageUsers}
                        value={editEmail}
                        onChange={(e) => setEditEmail(e.target.value)}
                        placeholder="operator@store.com"
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium disabled:opacity-60"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Phone Number</label>
                      <input
                        type="tel"
                        disabled={!canManageUsers}
                        value={editPhone}
                        onChange={(e) => setEditPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-medium disabled:opacity-60"
                      />
                    </div>
                  </div>

                  {/* PIN & Status Controls */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-gray-700">4-Digit Login PIN</label>
                        {canManageUsers && (
                          <button
                            type="button"
                            onClick={() => handleGeneratePin(false)}
                            className="text-[11px] font-bold text-[#00478c] hover:underline cursor-pointer"
                          >
                            Auto-Generate
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <input
                          type={editPinVisible ? 'text' : 'password'}
                          maxLength={4}
                          disabled={!canManageUsers}
                          value={editPin}
                          onChange={(e) => setEditPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                          className="w-full px-3 py-2 text-center text-base font-mono font-bold tracking-widest bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 disabled:opacity-60"
                        />
                        <button
                          type="button"
                          onClick={() => setEditPinVisible(!editPinVisible)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 p-0.5 cursor-pointer"
                          title={editPinVisible ? 'Hide PIN' : 'Reveal PIN'}
                        >
                          <span className="material-symbols-outlined text-base">
                            {editPinVisible ? 'visibility_off' : 'visibility'}
                          </span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">Account Status</label>
                      <select
                        disabled={!canManageUsers}
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value as any)}
                        className="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] focus:bg-white text-gray-900 font-semibold cursor-pointer disabled:opacity-60"
                      >
                        <option value="active">🟢 Active (Permitted to Login)</option>
                        <option value="inactive">⚪ Inactive (Login Locked)</option>
                      </select>
                    </div>
                  </div>

                  {/* Quick Role Capability Summary Box */}
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 text-xs text-gray-700 space-y-1">
                    <span className="font-bold text-[#09090B] flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm text-[#00478c]">verified_user</span>
                      Active Role Capabilities ({editRole}):
                    </span>
                    <p className="text-[11px] text-gray-600">
                      {editRole === 'Admin' && '✓ Full system control, user creation/deletion, role alteration, PIN reset, hardware setup, catalog management, and POS billing.'}
                      {editRole === 'Supervisor' && '✓ Catalog & pricing updates, PO entry & GRN, cashier shifts & drawer reconciliation, sales reports, and POS billing.'}
                      {editRole === 'Staff' && '✓ POS terminal checkout, scanning & scale weighing, receipt printing, viewing reports, and searching inventory items.'}
                    </p>
                  </div>
                </div>

                {/* Save Changes Footer */}
                {canManageUsers ? (
                  <div className="pt-3 border-t border-gray-200 flex flex-col gap-2.5 shrink-0">
                    {editError && (
                      <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-lg flex items-center gap-2 animate-in fade-in">
                        <span className="material-symbols-outlined text-base text-red-600">error</span>
                        <span className="flex-1">{editError}</span>
                      </div>
                    )}
                    {saveSuccess && (
                      <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-lg flex items-center gap-2 animate-in fade-in">
                        <span className="material-symbols-outlined text-base text-emerald-600">check_circle</span>
                        <span className="flex-1">User profile saved successfully and updated in system!</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => {
                          if (selectedUser) {
                            setEditName(selectedUser.name);
                            setEditRole(selectedUser.userRole);
                            setEditRoleTitle(selectedUser.roleTitle || '');
                            setEditEmail(selectedUser.email || '');
                            setEditPhone(selectedUser.phone || '');
                            setEditPin(selectedUser.pin || '0000');
                            setEditStatus(selectedUser.status || 'active');
                            setEditError(null);
                          }
                        }}
                        className="px-3 py-1.5 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-lg cursor-pointer"
                      >
                        Reset Form
                      </button>
                      <button
                        type="submit"
                        disabled={isSaving}
                        className={`px-5 py-2 text-xs font-bold text-white rounded-lg transition-all shadow-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50 ${
                          saveSuccess ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-[#00478c] hover:bg-[#003870]'
                        }`}
                      >
                        <span className={`material-symbols-outlined text-sm ${isSaving ? 'animate-spin' : ''}`}>
                          {isSaving ? 'sync' : saveSuccess ? 'check_circle' : 'save'}
                        </span>
                        <span>{isSaving ? 'Saving...' : saveSuccess ? 'Saved Successfully!' : 'Save User Changes'}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-2 bg-gray-100 rounded text-center text-xs text-gray-500 font-semibold">
                    Viewing mode only. Admin credentials required to modify user profiles.
                  </div>
                )}
              </form>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-gray-400">
              <span className="material-symbols-outlined text-4xl mb-2">person_search</span>
              <p className="text-sm font-bold text-gray-600">Select an operator from the left</p>
              <p className="text-xs text-gray-400 mt-0.5">or click &quot;Add User&quot; to create a new profile</p>
            </div>
          )}
        </div>
      </div>

      {/* Switch User PIN Verification Modal */}
      {switchTargetUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center select-none p-4">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => {
              setSwitchTargetUser(null);
              setSwitchPinInput('');
              setSwitchPinError('');
            }}
          />

          <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-[360px] max-w-[95vw] shadow-2xl p-5 text-center industrial-shadow animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-[#00478c]/15 text-[#00478c] flex items-center justify-center mx-auto mb-2.5">
              <span className="material-symbols-outlined text-2xl">key</span>
            </div>

            <h3 className="text-base font-bold text-[#09090B]">Operator Login Verification</h3>
            <p className="text-xs text-gray-600 mt-1">
              Enter 4-digit PIN to switch to <strong>{switchTargetUser.name}</strong> ({switchTargetUser.userRole})
            </p>

            {/* PIN Dots Display */}
            <div className="flex justify-center gap-3 my-4">
              {[0, 1, 2, 3].map((idx) => (
                <div
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full border-2 transition-all ${
                    switchPinInput.length > idx ? 'bg-[#00478c] border-[#00478c]' : 'border-[#D4D4D8] bg-[#F4F4F5]'
                  }`}
                />
              ))}
            </div>

            {switchPinError && (
              <div className="text-xs text-[#ba1a1a] font-semibold mb-3 bg-[#ffdad6]/60 p-2 rounded-lg flex items-center justify-center gap-1">
                <span className="material-symbols-outlined text-sm">error</span>
                <span>{switchPinError}</span>
              </div>
            )}

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => handleSwitchPinInput(k)}
                  className="h-11 border border-[#D4D4D8] rounded-lg font-tabular-numeric text-base font-bold bg-white hover:bg-[#F4F4F5] active:bg-[#E4E4E7] transition-colors cursor-pointer"
                >
                  {k}
                </button>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-gray-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setSwitchTargetUser(null);
                  setSwitchPinInput('');
                  setSwitchPinError('');
                }}
                className="px-3 py-1.5 text-xs font-bold text-gray-500 hover:text-gray-800 cursor-pointer"
              >
                Cancel
              </button>
              <span className="text-[11px] text-gray-400 font-mono">PIN Required</span>
            </div>
          </div>
        </div>
      )}

      {/* Delete User Confirmation Modal */}
      {deletingUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-gray-200">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-2xl">warning</span>
              </div>
              <div>
                <h3 className="font-bold text-base text-[#09090B]">Delete User Account?</h3>
                <p className="text-xs text-gray-500">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-gray-700 leading-relaxed">
              Are you sure you want to permanently delete <strong>{deletingUser.name}</strong> ({deletingUser.userRole})? They will immediately lose access to all store registers.
            </p>

            <div className="mt-5 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeletingUser(null)}
                className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg shadow-sm flex items-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">delete_forever</span>
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
