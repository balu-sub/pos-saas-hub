import React, { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../locales/en';
import { RECEIPT_LOCALIZED_LABELS, TENDER_NAME_LOCALIZED } from '../../locales/receiptTranslations';
import { apiClient } from '../../services/apiClient';
import { posDb } from '../../services/db';
import { Order } from '../../types/pos';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';
import { ThermalReceiptTicket } from '../checkout/ThermalReceiptTicket';

interface DuplicateReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDuplicateOrder?: (order: Order) => void;
}

export const DuplicateReceiptModal: React.FC<DuplicateReceiptModalProps> = ({
  isOpen,
  onClose,
  onSelectDuplicateOrder,
}) => {
  const { outletProfile, customers, lastCompletedOrder, loyaltyConfig } = usePOS();
  const { printerConfig } = usePeripherals();
  const { language: headerLanguage } = useLanguage();

  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [receiptLang, setReceiptLang] = useState<LanguageCode>(headerLanguage);
  const [printStatus, setPrintStatus] = useState<'idle' | 'printed'>('idle');

  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      const orderMap = new Map<string, any>();

      // 1. Fetch from server API
      try {
        const apiOrders = await apiClient.getOrders();
        if (Array.isArray(apiOrders)) {
          apiOrders.forEach((o) => {
            const key = o.id || o.orderNumber || o.order_number;
            if (key) orderMap.set(key, o);
          });
        }
      } catch (e) {
        console.warn('API getOrders failed, checking local storages:', e);
      }

      // 2. Fetch from IndexedDB
      try {
        const dbOrders = await posDb.orders.toArray();
        if (Array.isArray(dbOrders)) {
          dbOrders.forEach((o) => {
            const key = o.id || o.orderNumber || (o as any).order_number;
            if (key && !orderMap.has(key)) {
              orderMap.set(key, o);
            }
          });
        }
      } catch (e) {
        console.warn('IndexedDB orders.toArray failed:', e);
      }

      // 3. Check lastCompletedOrder from Context
      if (lastCompletedOrder) {
        const key = lastCompletedOrder.id || lastCompletedOrder.orderNumber;
        if (key && !orderMap.has(key)) {
          orderMap.set(key, lastCompletedOrder);
        }
      }

      // 4. Check localStorage last order
      try {
        const savedLast = localStorage.getItem('alfa_pos_last_order');
        if (savedLast) {
          const parsed = JSON.parse(savedLast);
          const key = parsed?.id || parsed?.orderNumber || parsed?.order_number;
          if (key && !orderMap.has(key)) {
            orderMap.set(key, parsed);
          }
        }
      } catch {}

      // 5. Check localStorage recent orders cache
      try {
        const savedRecent = localStorage.getItem('alfa_pos_recent_orders');
        if (savedRecent) {
          const parsedRecent = JSON.parse(savedRecent);
          if (Array.isArray(parsedRecent)) {
            parsedRecent.forEach((o) => {
              const key = o?.id || o?.orderNumber || o?.order_number;
              if (key && !orderMap.has(key)) {
                orderMap.set(key, o);
              }
            });
          }
        }
      } catch {}

      const allRaw = Array.from(orderMap.values());

      // Normalize all orders into standard Order format
      const mapped: Order[] = allRaw.map((ord) => ({
        id: ord.id || ord.order_number || ord.orderNumber || `ord_${Date.now()}`,
        orderNumber: ord.orderNumber || ord.order_number || ord.id || 'BILL-0001',
        terminalId: ord.terminalId || ord.terminal_id || 'TERM-01',
        cashierId: ord.cashierId || ord.cashier_id || 'OP-01',
        cashierName: ord.cashierName || ord.cashier_name || 'Admin',
        customerId: ord.customerId || ord.customer_id,
        customerName: ord.customerName || ord.customer_name || 'Walk-in Retail Customer',
        customerPhone: ord.customerPhone || ord.customer_phone,
        subtotal: Number(ord.subtotal || ord.total_amount || ord.total || 0),
        discountTotal: Number(ord.discountTotal || ord.discount_total || 0),
        taxAmount: Number(ord.taxAmount || ord.taxTotal || ord.tax_total || 0),
        taxRate: Number(ord.taxRate || 0.05),
        total: Number(ord.total || ord.totalAmount || ord.total_amount || 0),
        amountPaid: Number(ord.amountPaid || ord.total || ord.total_amount || 0),
        changeDue: Number(ord.changeDue || 0),
        status: ord.status || 'completed',
        createdAt: ord.createdAt || ord.created_at || new Date().toISOString(),
        synced: Boolean(ord.synced ?? true),
        payments: typeof ord.payments === 'string'
          ? JSON.parse(ord.payments)
          : ord.payments || (typeof ord.tenders === 'string' ? JSON.parse(ord.tenders) : ord.tenders || []),
        items: typeof ord.items === 'string' ? JSON.parse(ord.items) : ord.items || [],
      }));

      // Sort latest first
      mapped.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setOrders(mapped);
      if (mapped.length > 0) {
        setSelectedOrder((prev) => {
          if (!prev) return mapped[0];
          const exists = mapped.find((m) => m.id === prev.id);
          return exists || mapped[0];
        });
      }
    } catch (err) {
      console.error('Error fetching past orders:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchOrders();
      setReceiptLang(headerLanguage);
      setPrintStatus('idle');
    }
  }, [isOpen, headerLanguage]);

  const filteredOrders = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return orders;
    return orders.filter((o) => {
      const billNo = (o.orderNumber || '').toLowerCase();
      const orderId = (o.id || '').toLowerCase();
      const cName = (o.customerName || '').toLowerCase();
      const cPhone = (o.customerPhone || '').toLowerCase();
      const dateStr = new Date(o.createdAt).toLocaleDateString('en-IN').toLowerCase();
      const amountStr = (o.total || 0).toString();
      const itemNames = (o.items || []).map((it: any) => (it.productName || it.name || '').toLowerCase()).join(' ');

      return (
        billNo.includes(q) ||
        orderId.includes(q) ||
        cName.includes(q) ||
        cPhone.includes(q) ||
        dateStr.includes(q) ||
        amountStr.includes(q) ||
        itemNames.includes(q)
      );
    });
  }, [orders, searchQuery]);

  if (!isOpen) return null;

  const currency = outletProfile?.currencySymbol || 'Rs.';
  const t = RECEIPT_LOCALIZED_LABELS[receiptLang] || RECEIPT_LOCALIZED_LABELS.en;

  const handlePrintThermal = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    playSuccessChime();
    setPrintStatus('printed');

    // 1. Programmatically sync Windows Default Printer to configured printer
    const targetPrinter = printerConfig.selectedPrinterName || 'RETSOL RTP-80';
    try {
      await fetch('/api/system/printers/set-default', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: targetPrinter }),
      });
    } catch (err) {
      console.warn('Printer default sync note:', err);
    }

    // 2. Trigger silent direct print
    setTimeout(() => {
      try {
        if (typeof window !== 'undefined' && window.print) {
          window.print();
        }
      } catch (err) {
        console.warn('System print blocked or unavailable:', err);
      }
    }, 60);
  };

  const selectedCustomer = selectedOrder?.customerId
    ? customers.find((c) => c.id === selectedOrder.customerId)
    : null;
  const totalMrp = (selectedOrder?.items || []).reduce(
    (acc, it: any) => acc + (Number(it.mrp || it.unitPrice || 0) * Number(it.quantity || 1)),
    0
  );
  const totalSavings = Math.max(0, totalMrp - Number(selectedOrder?.subtotal || selectedOrder?.total || 0));

  const printPortalNode =
    typeof document !== 'undefined' ? document.getElementById('pos-direct-print-root') : null;

  return (
    <>
      {/* DIRECT PRINT PORTAL: Attached directly to <body>#pos-direct-print-root */}
      {selectedOrder &&
        printPortalNode &&
        createPortal(
          <ThermalReceiptTicket
            order={selectedOrder}
            outletProfile={outletProfile}
            printerConfig={printerConfig}
            receiptLang={receiptLang}
            isDuplicate={true}
            customer={selectedCustomer}
            loyaltyConfig={loyaltyConfig}
          />,
          printPortalNode
        )}

      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 select-none no-print">
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

        <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-4xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden industrial-shadow animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#00478c]/10 text-[#00478c] flex items-center justify-center">
              <span className="material-symbols-outlined text-xl">receipt_long</span>
            </div>
            <div>
              <h2 className="text-base font-bold text-[#09090B] flex items-center gap-2">
                <span>Search Past Customer Invoices &amp; Print Duplicate Receipt</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-100 text-[#00478c] border border-blue-200">
                  Thermal Printer
                </span>
              </h2>
              <p className="text-xs text-gray-500">
                Search previous bills by Bill#, customer phone, or date and print duplicate thermal receipts as usual.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">close</span>
          </button>
        </div>

        {/* Search Toolbar */}
        <div className="p-3 border-b border-gray-200 bg-white flex items-center justify-between gap-3">
          <div className="relative flex-1">
            <span className="material-symbols-outlined absolute left-3 top-2 text-gray-400 text-base">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Bill # (e.g. BILL-1001, 9), Customer Name, Mobile Number, or Item..."
              className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-8 py-1.5 text-xs text-gray-900 focus:bg-white focus:border-[#00478c] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-gray-400 hover:text-gray-600 cursor-pointer"
                title="Clear Search"
              >
                <span className="material-symbols-outlined text-[15px]">close</span>
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={fetchOrders}
            disabled={isLoading}
            className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
            title="Refresh Invoices List"
          >
            <span className={`material-symbols-outlined text-[15px] ${isLoading ? 'animate-spin' : ''}`}>
              refresh
            </span>
            <span>Reload</span>
          </button>
          <div className="text-xs font-bold text-gray-500 shrink-0">
            {filteredOrders.length} Invoices Found
          </div>
        </div>

        {/* Content Body: Split View */}
        <div className="flex-1 flex overflow-hidden min-h-[350px]">
          {/* Left Column: Order List */}
          <div className="w-5/12 border-r border-gray-200 overflow-y-auto divide-y divide-gray-100 bg-white">
            {isLoading ? (
              <div className="p-8 text-center text-gray-400 text-xs">Loading past invoices...</div>
            ) : filteredOrders.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-xs">No matching invoices found</div>
            ) : (
              filteredOrders.map((ord) => {
                const isSelected = selectedOrder?.id === ord.id;
                return (
                  <div
                    key={ord.id}
                    onClick={() => {
                      playKeypadClick();
                      setSelectedOrder(ord);
                      setPrintStatus('idle');
                    }}
                    className={`p-3 cursor-pointer transition-colors ${
                      isSelected ? 'bg-blue-50/80 border-l-4 border-[#00478c]' : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#09090B]">Bill #{ord.orderNumber}</span>
                      <span className="font-mono font-bold text-xs text-[#00478c]">
                        {currency} {(ord.total || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="text-[11px] text-gray-600 mt-0.5 flex items-center justify-between">
                      <span>{ord.customerName || 'Walk-in Retail Customer'}</span>
                      <span className="text-gray-400">
                        {new Date(ord.createdAt).toLocaleDateString('en-IN')} {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-2">
                      <span>{ord.items?.length || 0} items</span>
                      <span>•</span>
                      <span>Terminal: {ord.terminalId}</span>
                      <span>•</span>
                      <span className="text-emerald-700 font-semibold">{ord.status}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Right Column: Thermal Paper Preview and Controls */}
          <div className="w-7/12 overflow-y-auto p-4 flex flex-col justify-between bg-gray-50">
            {selectedOrder ? (
              <div className="flex flex-col h-full space-y-3">
                {/* Language Selection & Print Confirmation Bar */}
                <div className="p-2 bg-blue-50/90 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs text-blue-900 shrink-0">
                  <div className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[#00478c] text-[16px]">translate</span>
                    <span className="text-[11px] font-bold text-gray-800">Print Language:</span>
                    <div className="flex items-center bg-white border border-blue-300 rounded p-0.5 shadow-2xs">
                      <button
                        type="button"
                        onClick={() => setReceiptLang('en')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                          receiptLang === 'en' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        English
                      </button>
                      <button
                        type="button"
                        onClick={() => setReceiptLang('ta')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                          receiptLang === 'ta' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        தமிழ்
                      </button>
                      <button
                        type="button"
                        onClick={() => setReceiptLang('hi')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                          receiptLang === 'hi' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        हिन्दी
                      </button>
                    </div>
                  </div>
                  {printStatus === 'printed' ? (
                    <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-[10px] font-bold rounded-full flex items-center gap-1">
                      <span className="material-symbols-outlined text-[13px]">done</span> Duplicate Printed
                    </span>
                  ) : (
                    <span className="text-[10px] text-blue-700 font-medium">Ready to print thermal</span>
                  )}
                </div>

                {/* Scrollable Receipt Preview (Matches live bill preview) */}
                <div className="flex-1 overflow-y-auto p-3 bg-[#fffdfa] border border-[#e5e5e5] rounded shadow-inner select-text max-w-sm mx-auto w-full">
                  <ThermalReceiptTicket
                    order={selectedOrder}
                    outletProfile={outletProfile}
                    printerConfig={printerConfig}
                    receiptLang={receiptLang}
                    isDuplicate={true}
                    customer={selectedCustomer}
                    loyaltyConfig={loyaltyConfig}
                  />
                </div>

                {/* Print Action Buttons */}
                <div className="pt-2 border-t border-gray-200 flex items-center justify-end gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handlePrintThermal}
                    className="flex-1 py-2.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded-lg font-extrabold text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
                  >
                    <span className="material-symbols-outlined text-[18px]">print</span>
                    <span>{printStatus === 'printed' ? 'Print Duplicate Again' : 'Print Duplicate Receipt (Thermal)'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-bold text-xs cursor-pointer transition-colors"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-400 text-xs my-auto">Select a bill from the left</div>
            )}
          </div>
        </div>
      </div>
    </div>
  </>
);
};
