import React, { useState, useEffect, useMemo } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../locales/en';
import { RECEIPT_LOCALIZED_LABELS, TENDER_NAME_LOCALIZED } from '../../locales/receiptTranslations';
import { getProductLocalizedName } from '../../locales/productTranslations';
import { apiClient } from '../../services/apiClient';
import { posDb } from '../../services/db';
import { Order } from '../../types/pos';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';

interface DuplicateReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDuplicateOrder?: (order: Order) => void;
}

export const DuplicateReceiptModal: React.FC<DuplicateReceiptModalProps> = ({
  isOpen,
  onClose,
  onSelectDuplicateOrder,
}) => {
  const { outletProfile, customers, lastCompletedOrder, loyaltyConfig } = usePOS();
  const { printerConfig } = usePeripherals();
  const { language: headerLanguage } = useLanguage();

  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [receiptLang, setReceiptLang] = useState<LanguageCode>(headerLanguage);
  const [printStatus, setPrintStatus] = useState<'idle' | 'printed'>('idle');

  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      const orderMap = new Map<string, any>();

      // 1. Fetch from server API
      try {
        const apiOrders = await apiClient.getOrders();
        if (Array.isArray(apiOrders)) {
          apiOrders.forEach((o) => {
            const key = o.id || o.orderNumber || o.order_number;
            if (key) orderMap.set(key, o);
          });
        }
      } catch (e) {
        console.warn('API getOrders failed, checking local storages:', e);
      }

      // 2. Fetch from IndexedDB
      try {
        const dbOrders = await posDb.orders.toArray();
        if (Array.isArray(dbOrders)) {
          dbOrders.forEach((o) => {
            const key = o.id || o.orderNumber || (o as any).order_number;
            if (key && !orderMap.has(key)) {
              orderMap.set(key, o);
            }
          });
        }
      } catch (e) {
        console.warn('IndexedDB orders.toArray failed:', e);
      }

      // 3. Check lastCompletedOrder from Context
      if (lastCompletedOrder) {
        const key = lastCompletedOrder.id || lastCompletedOrder.orderNumber;
        if (key && !orderMap.has(key)) {
          orderMap.set(key, lastCompletedOrder);
        }
      }

      // 4. Check localStorage last order
      try {
        const savedLast = localStorage.getItem('alfa_pos_last_order');
        if (savedLast) {
          const parsed = JSON.parse(savedLast);
          const key = parsed?.id || parsed?.orderNumber || parsed?.order_number;
          if (key && !orderMap.has(key)) {
            orderMap.set(key, parsed);
          }
        }
      } catch {}

      // 5. Check localStorage recent orders cache
      try {
        const savedRecent = localStorage.getItem('alfa_pos_recent_orders');
        if (savedRecent) {
          const parsedRecent = JSON.parse(savedRecent);
          if (Array.isArray(parsedRecent)) {
            parsedRecent.forEach((o) => {
              const key = o?.id || o?.orderNumber || o?.order_number;
              if (key && !orderMap.has(key)) {
                orderMap.set(key, o);
              }
            });
          }
        }
      } catch {}

      const allRaw = Array.from(orderMap.values());

      // Normalize all orders into standard Order format
      const mapped: Order[] = allRaw.map((ord) => ({
        id: ord.id || ord.order_number || ord.orderNumber || `ord_${Date.now()}`,
        orderNumber: ord.orderNumber || ord.order_number || ord.id || 'BILL-0001',
        terminalId: ord.terminalId || ord.terminal_id || 'TERM-01',
        cashierId: ord.cashierId || ord.cashier_id || 'OP-01',
        cashierName: ord.cashierName || ord.cashier_name || 'Admin',
        customerId: ord.customerId || ord.customer_id,
        customerName: ord.customerName || ord.customer_name || 'Walk-in Retail Customer',
        customerPhone: ord.customerPhone || ord.customer_phone,
        subtotal: Number(ord.subtotal || ord.total_amount || ord.total || 0),
        discountTotal: Number(ord.discountTotal || ord.discount_total || 0),
        taxAmount: Number(ord.taxAmount || ord.taxTotal || ord.tax_total || 0),
        taxRate: Number(ord.taxRate || 0.05),
        total: Number(ord.total || ord.totalAmount || ord.total_amount || 0),
        amountPaid: Number(ord.amountPaid || ord.total || ord.total_amount || 0),
        changeDue: Number(ord.changeDue || 0),
        status: ord.status || 'completed',
        createdAt: ord.createdAt || ord.created_at || new Date().toISOString(),
        synced: Boolean(ord.synced ?? true),
        payments: typeof ord.payments === 'string'
          ? JSON.parse(ord.payments)
          : ord.payments || (typeof ord.tenders === 'string' ? JSON.parse(ord.tenders) : ord.tenders || []),
        items: typeof ord.items === 'string' ? JSON.parse(ord.items) : ord.items || [],
      }));

      // Sort latest first
      mapped.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setOrders(mapped);
      if (mapped.length > 0) {
        setSelectedOrder((prev) => {
          if (!prev) return mapped[0];
          const exists = mapped.find((m) => m.id === prev.id);
          return exists || mapped[0];
        });
      }
    } catch (err) {
      console.error('Error fetching past orders:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchOrders();
      setReceiptLang(headerLanguage);
      setPrintStatus('idle');
    }
  }, [isOpen, headerLanguage]);

  const filteredOrders = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return orders;
    return orders.filter((o) => {
      const billNo = (o.orderNumber || '').toLowerCase();
      const orderId = (o.id || '').toLowerCase();
      const cName = (o.customerName || '').toLowerCase();
      const cPhone = (o.customerPhone || '').toLowerCase();
      const dateStr = new Date(o.createdAt).toLocaleDateString('en-IN').toLowerCase();
      const amountStr = (o.total || 0).toString();
      const itemNames = (o.items || []).map((it: any) => (it.productName || it.name || '').toLowerCase()).join(' ');

      return (
        billNo.includes(q) ||
        orderId.includes(q) ||
        cName.includes(q) ||
        cPhone.includes(q) ||
        dateStr.includes(q) ||
        amountStr.includes(q) ||
        itemNames.includes(q)
      );
    });
  }, [orders, searchQuery]);

  if (!isOpen) return null;

  const currency = outletProfile?.currencySymbol || 'Rs.';
  const t = RECEIPT_LOCALIZED_LABELS[receiptLang] || RECEIPT_LOCALIZED_LABELS.en;

  const handlePrintThermal = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    playSuccessChime();
    setPrintStatus('printed');
    try {
      if (typeof window !== 'undefined' && window.print) {
        window.print();
      }
    } catch (err) {
      console.warn('System print blocked or unavailable in iframe:', err);
    }
  };

  const selectedCustomer = selectedOrder?.customerId
    ? customers.find((c) => c.id === selectedOrder.customerId)
    : null;
  const totalMrp = (selectedOrder?.items || []).reduce(
    (acc, it: any) => acc + (Number(it.mrp || it.unitPrice || 0) * Number(it.quantity || 1)),
    0
  );
  const totalSavings = Math.max(0, totalMrp - Number(selectedOrder?.subtotal || selectedOrder?.total || 0));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 select-none">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-4xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden industrial-shadow animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#00478c]/10 text-[#00478c] flex items-center justify-center">
              <span className="material-symbols-outlined text-xl">receipt_long</span>
            </div>
            <div>
              <h2 className="text-base font-bold text-[#09090B] flex items-center gap-2">
                <span>Search Past Customer Invoices &amp; Print Duplicate Receipt</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-100 text-[#00478c] border border-blue-200">
                  Thermal Printer
                </span>
              </h2>
              <p className="text-xs text-gray-500">
                Search previous bills by Bill#, customer phone, or date and print duplicate thermal receipts as usual.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">close</span>
          </button>
        </div>

        {/* Search Toolbar */}
        <div className="p-3 border-b border-gray-200 bg-white flex items-center justify-between gap-3">
          <div className="relative flex-1">
            <span className="material-symbols-outlined absolute left-3 top-2 text-gray-400 text-base">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Bill # (e.g. BILL-1001, 9), Customer Name, Mobile Number, or Item..."
              className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-8 py-1.5 text-xs text-gray-900 focus:bg-white focus:border-[#00478c] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-gray-400 hover:text-gray-600 cursor-pointer"
                title="Clear Search"
              >
                <span className="material-symbols-outlined text-[15px]">close</span>
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={fetchOrders}
            disabled={isLoading}
            className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
            title="Refresh Invoices List"
          >
            <span className={`material-symbols-outlined text-[15px] ${isLoading ? 'animate-spin' : ''}`}>
              refresh
            </span>
            <span>Reload</span>
          </button>
          <div className="text-xs font-bold text-gray-500 shrink-0">
            {filteredOrders.length} Invoices Found
          </div>
        </div>

        {/* Content Body: Split View */}
        <div className="flex-1 flex overflow-hidden min-h-[350px]">
          {/* Left Column: Order List */}
          <div className="w-5/12 border-r border-gray-200 overflow-y-auto divide-y divide-gray-100 bg-white">
            {isLoading ? (
              <div className="p-8 text-center text-gray-400 text-xs">Loading past invoices...</div>
            ) : filteredOrders.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-xs">No matching invoices found</div>
            ) : (
              filteredOrders.map((ord) => {
                const isSelected = selectedOrder?.id === ord.id;
                return (
                  <div
                    key={ord.id}
                    onClick={() => {
                      playKeypadClick();
                      setSelectedOrder(ord);
                      setPrintStatus('idle');
                    }}
                    className={`p-3 cursor-pointer transition-colors ${
                      isSelected ? 'bg-blue-50/80 border-l-4 border-[#00478c]' : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#09090B]">Bill #{ord.orderNumber}</span>
                      <span className="font-mono font-bold text-xs text-[#00478c]">
                        {currency} {(ord.total || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="text-[11px] text-gray-600 mt-0.5 flex items-center justify-between">
                      <span>{ord.customerName || 'Walk-in Retail Customer'}</span>
                      <span className="text-gray-400">
                        {new Date(ord.createdAt).toLocaleDateString('en-IN')} {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-2">
                      <span>{ord.items?.length || 0} items</span>
                      <span>•</span>
                      <span>Terminal: {ord.terminalId}</span>
                      <span>•</span>
                      <span className="text-emerald-700 font-semibold">{ord.status}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Right Column: Thermal Paper Preview and Controls */}
          <div className="w-7/12 overflow-y-auto p-4 flex flex-col justify-between bg-gray-50">
            {selectedOrder ? (
              <div className="flex flex-col h-full space-y-3">
                {/* Language Selection & Print Confirmation Bar */}
                <div className="p-2 bg-blue-50/90 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs text-blue-900 shrink-0">
                  <div className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[#00478c] text-[16px]">translate</span>
                    <span className="text-[11px] font-bold text-gray-800">Print Language:</span>
                    <div className="flex items-center bg-white border border-blue-300 rounded p-0.5 shadow-2xs">
                      <button
                        type="button"
                        onClick={() => setReceiptLang('en')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                          receiptLang === 'en' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        English
                      </button>
                      <button
                        type="button"
                        onClick={() => setReceiptLang('ta')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                          receiptLang === 'ta' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        தமிழ்
                      </button>
                      <button
                        type="button"
                        onClick={() => setReceiptLang('hi')}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                          receiptLang === 'hi' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        हिन्दी
                      </button>
                    </div>
                  </div>
                  {printStatus === 'printed' ? (
                    <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-[10px] font-bold rounded-full flex items-center gap-1">
                      <span className="material-symbols-outlined text-[13px]">done</span> Duplicate Printed
                    </span>
                  ) : (
                    <span className="text-[10px] text-blue-700 font-medium">Ready to print thermal</span>
                  )}
                </div>

                {/* Printable Thermal Receipt Roll (matches standard receipt layout) */}
                <div className="printable-thermal-receipt flex-1 overflow-y-auto p-4 bg-[#fffdfa] border border-[#e5e5e5] rounded shadow-inner font-mono text-xs text-black leading-tight select-text max-w-sm mx-auto w-full">
                  {/* Duplicate Header Banner */}
                  <div className="text-center pb-2 mb-2 border-b-2 border-dashed border-gray-600">
                    <div className="font-extrabold text-xs tracking-wider text-black uppercase bg-gray-200/80 py-0.5 rounded">
                      *** DUPLICATE RECEIPT ***
                    </div>
                  </div>

                  {/* Outlet Header */}
                  <div className="text-center pb-2.5 border-b border-dashed border-gray-400 space-y-0.5">
                    <div className="font-extrabold text-sm tracking-tight text-black font-sans uppercase">
                      {outletProfile?.outletName || printerConfig.headerText || 'AMMA & APPA KADAI'}
                    </div>
                    {outletProfile?.branchName && (
                      <div className="text-[10px] font-bold text-gray-800">
                        {outletProfile.branchName}
                      </div>
                    )}
                    <div className="text-[10px] text-gray-700">
                      {[outletProfile?.addressLine1, outletProfile?.addressLine2, outletProfile?.city, outletProfile?.state, outletProfile?.pincode].filter(Boolean).join(', ') || 'Shop #12, Market Complex, Main Road, Chennai'}
                    </div>
                    <div className="text-[10px] text-gray-700 flex flex-wrap justify-center gap-x-2">
                      {outletProfile?.gstin && <span>GSTIN: <span className="font-bold">{outletProfile.gstin}</span></span>}
                      {outletProfile?.panNumber && <span>PAN: <span className="font-bold">{outletProfile.panNumber}</span></span>}
                    </div>
                    {outletProfile?.fssaiLicense && (
                      <div className="text-[10px] text-gray-700">
                        FSSAI Lic No: <span className="font-bold">{outletProfile.fssaiLicense}</span>
                      </div>
                    )}
                    <div className="text-[10px] text-gray-700">
                      Phone: {outletProfile?.phone || '+91 98200 12345'} {outletProfile?.email ? `• ${outletProfile.email}` : ''}
                    </div>
                  </div>

                  {/* Invoice Meta */}
                  <div className="py-2 border-b border-dashed border-gray-400 text-[11px] space-y-0.5">
                    <div className="flex justify-between">
                      <span>{t.billNo}: <span className="font-bold">{selectedOrder.orderNumber}</span></span>
                      <span>{t.cashier}: {selectedOrder.cashierName?.split(' ')[0] || 'Staff'}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>{t.date}: {new Date(selectedOrder.createdAt).toLocaleDateString('en-GB')}</span>
                      <span>{t.time}: {new Date(selectedOrder.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    {selectedOrder.customerName && (
                      <div className="flex justify-between text-gray-800 pt-0.5 font-sans font-bold text-[10px]">
                        <span>{t.customer}: {selectedOrder.customerName}</span>
                        {selectedOrder.customerPhone && <span>{selectedOrder.customerPhone}</span>}
                      </div>
                    )}
                  </div>

                  {/* Line Items Table */}
                  <div className="py-2 border-b border-dashed border-gray-400 space-y-1.5">
                    <div className="flex justify-between font-bold text-[10px] uppercase border-b border-gray-300 pb-1 text-gray-700">
                      <span className="w-1/2">{t.itemDescription}</span>
                      <span className="w-1/6 text-center">{t.qty}</span>
                      <span className="w-1/6 text-right">{t.rate}</span>
                      <span className="w-1/6 text-right">{t.amount}</span>
                    </div>

                    {(selectedOrder.items || []).map((item: any, idx: number) => {
                      const localizedName = getProductLocalizedName(item.productName || item.name || 'Item', receiptLang);
                      const unitPrice = Number(item.unitPrice || 0);
                      const qty = Number(item.quantity || 1);
                      return (
                        <div key={idx} className="flex justify-between items-baseline text-[11px]">
                          <div className="w-1/2 truncate pr-1">
                            <div className="font-sans font-medium text-black truncate">{localizedName}</div>
                            {item.packSize && (
                              <div className="text-[9px] text-gray-600">{t.pack}: {item.packSize}</div>
                            )}
                          </div>
                          <div className="w-1/6 text-center">{qty}</div>
                          <div className="w-1/6 text-right font-tabular-numeric">{currency} {unitPrice.toFixed(0)}</div>
                          <div className="w-1/6 text-right font-bold font-tabular-numeric">
                            {currency} {(unitPrice * qty).toFixed(2)}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Totals & Tax Summary */}
                  <div className="py-2 border-b border-dashed border-gray-400 space-y-1 text-[11px]">
                    <div className="flex justify-between">
                      <span>{t.itemsTotal} ({(selectedOrder.items || []).reduce((a: number, b: any) => a + Number(b.quantity || 1), 0)} {t.units}):</span>
                      <span className="font-bold">{currency} {Number(selectedOrder.subtotal || 0).toFixed(2)}</span>
                    </div>
                    {printerConfig.printGstSummary && (
                      <div className="flex justify-between text-gray-700">
                        <span>{t.gstSummary} ({((selectedOrder.taxRate || 0.05) * 100).toFixed(0)}%):</span>
                        <span>{currency} {Number(selectedOrder.taxAmount || 0).toFixed(2)}</span>
                      </div>
                    )}
                    {totalSavings > 0 && (
                      <div className="flex justify-between text-emerald-800 font-bold bg-emerald-50 px-1 py-0.5 rounded text-[10px]">
                        <span>{t.youSaved}:</span>
                        <span>{currency} {totalSavings.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm font-black pt-1.5 border-t border-gray-400 font-sans">
                      <span>{t.grandTotal}:</span>
                      <span>{currency} {Number(selectedOrder.total || 0).toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Payment Tender Details */}
                  <div className="py-2 border-b border-dashed border-gray-400 text-[10px] space-y-0.5">
                    <div className="font-bold uppercase tracking-wider text-gray-700">{t.paymentBreakdown}:</div>
                    {(selectedOrder.payments || (selectedOrder as any).tenders || []).map((p: any, pIdx: number) => {
                      const tenderLabel = TENDER_NAME_LOCALIZED[p.tenderType || p.type]?.[receiptLang] || (p.tenderType || p.type || 'CASH').toUpperCase();
                      return (
                        <div key={pIdx} className="flex justify-between">
                          <span>• {tenderLabel} ({p.reference || 'Paid'}):</span>
                          <span className="font-bold">{currency} {Number(p.amount || 0).toFixed(2)}</span>
                        </div>
                      );
                    })}
                    {Number(selectedOrder.changeDue || 0) > 0 && (
                      <div className="flex justify-between text-emerald-800 font-bold">
                        <span>{t.changeReturned}:</span>
                        <span>{currency} {Number(selectedOrder.changeDue).toFixed(2)}</span>
                      </div>
                    )}
                  </div>

                  {/* Customer Loyalty Program Summary (if available) */}
                  {selectedCustomer && (selectedCustomer.isLoyaltyMember ?? true) && loyaltyConfig?.enabled && (
                    <div className="py-2 border-b border-dashed border-gray-400 text-[10px] bg-amber-50/70 p-1.5 rounded space-y-0.5">
                      <div className="font-bold text-amber-900 flex items-center justify-between">
                        <span>{t.loyaltyHeader}</span>
                        <span className="text-[9px] bg-amber-200 px-1 rounded font-extrabold">{selectedCustomer.memberTier || 'Member'}</span>
                      </div>
                      <div className="flex justify-between text-gray-800">
                        <span>{t.pointsEarned}:</span>
                        <span className="font-bold text-emerald-700">+{selectedOrder.loyaltyPointsEarned || Math.floor(Number(selectedOrder.total || 0) / (loyaltyConfig?.spendAmountPerPoint || 100))} pts</span>
                      </div>
                      <div className="flex justify-between text-gray-900 font-bold pt-0.5 border-t border-amber-200">
                        <span>{t.availableBalance}:</span>
                        <span>{selectedCustomer.loyaltyPoints} pts</span>
                      </div>
                    </div>
                  )}

                  {/* Footer Note & Return Terms */}
                  <div className="pt-2 text-center text-[10px] text-gray-600 font-sans space-y-1">
                    <div className="font-bold text-black">
                      {outletProfile?.receiptFooterNote || printerConfig.footerText || t.footerDefault}
                    </div>
                    {outletProfile?.returnTerms && (
                      <div className="text-[8.5px] text-gray-500 leading-tight bg-gray-50 p-1 rounded border border-gray-200">
                        <span className="font-bold">{t.termsHeader}: </span>{outletProfile.returnTerms}
                      </div>
                    )}
                    <div className="text-[9px] font-bold text-gray-700 pt-1">*** DUPLICATE RECEIPT COPY ***</div>
                    <div className="text-[8px] text-gray-400">{t.softwareTag}</div>
                  </div>
                </div>

                {/* Print Action Buttons */}
                <div className="pt-2 border-t border-gray-200 flex items-center justify-end gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handlePrintThermal}
                    className="flex-1 py-2.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded-lg font-extrabold text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
                  >
                    <span className="material-symbols-outlined text-[18px]">print</span>
                    <span>{printStatus === 'printed' ? 'Print Duplicate Again' : 'Print Duplicate Receipt (Thermal)'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-bold text-xs cursor-pointer transition-colors"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-400 text-xs my-auto">Select a bill from the left</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
