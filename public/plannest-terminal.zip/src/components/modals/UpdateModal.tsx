import React from 'react';
import { useAppUpdate } from '../../context/UpdateContext';

export const UpdateModal: React.FC = () => {
  const {
    currentVersion,
    isUpdateModalOpen,
    setIsUpdateModalOpen,
    remoteInfo,
    isUpdating,
    updateStatus,
    updateError,
    updateSuccess,
    installUpdate,
  } = useAppUpdate();

  if (!isUpdateModalOpen || !remoteInfo) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-gray-100 overflow-hidden transform transition-all">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#00478c] to-[#003166] text-white p-5 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[24px] text-white">system_update</span>
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Software Update Available</h3>
              <p className="text-white/80 text-xs mt-0.5">Plannest POS Terminal Engine</p>
            </div>
          </div>
          {!isUpdating && (
            <button
              type="button"
              onClick={() => setIsUpdateModalOpen(false)}
              className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          {/* Version Comparison Card */}
          <div className="bg-[#f8f9fa] border border-gray-200 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider block">Current Version</span>
              <span className="text-sm font-mono font-bold text-gray-700">v{currentVersion}</span>
            </div>
            <div className="flex items-center text-blue-600 font-bold px-2">
              <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
            </div>
            <div className="text-right">
              <span className="text-[11px] font-semibold text-emerald-600 uppercase tracking-wider block">New Version</span>
              <span className="text-sm font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                v{remoteInfo.version}
              </span>
            </div>
          </div>

          {/* Release Notes */}
          {remoteInfo.releaseNotes && (
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-gray-700 uppercase tracking-wider block">What's New in this Update:</span>
              <div className="text-xs text-gray-600 bg-gray-50 rounded-lg p-3 border border-gray-200 leading-relaxed max-h-32 overflow-y-auto">
                {remoteInfo.releaseNotes}
              </div>
            </div>
          )}

          {/* Safety & Protection Guarantee */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-900">
            <span className="material-symbols-outlined text-[18px] text-amber-700 shrink-0 mt-0.5">verified_user</span>
            <div>
              <span className="font-bold block">100% Data Safe &amp; Protected</span>
              <span className="text-amber-800 text-[11px] leading-tight block mt-0.5">
                Your offline SQLite sales bills, store products, local receipts, and hardware settings will remain completely intact.
              </span>
            </div>
          </div>

          {/* Progress / Status display */}
          {isUpdating && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl space-y-2.5 animate-in fade-in">
              <div className="flex items-center gap-2 text-xs font-bold text-[#00478c]">
                <span className="material-symbols-outlined text-[18px] animate-spin">refresh</span>
                <span>{updateStatus || 'Applying update...'}</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-2 overflow-hidden">
                <div className={`h-full bg-[#00478c] transition-all duration-300 ${updateSuccess ? 'w-full' : 'w-3/4 animate-pulse'}`} />
              </div>
            </div>
          )}

          {/* Error Message */}
          {updateError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-start gap-2">
              <span className="material-symbols-outlined text-[18px] text-red-600 shrink-0">error</span>
              <div className="flex-1">
                <span className="font-bold block">Update Failed</span>
                <span className="text-[11px]">{updateError}</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-end gap-2.5">
          {!isUpdating && (
            <button
              type="button"
              onClick={() => setIsUpdateModalOpen(false)}
              className="px-4 py-2 text-xs font-bold text-gray-600 hover:text-gray-900 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            >
              Remind Me Later
            </button>
          )}

          <button
            type="button"
            disabled={isUpdating}
            onClick={installUpdate}
            className={`px-5 py-2.5 text-xs font-bold text-white rounded-lg transition-all flex items-center gap-2 shadow-sm ${
              isUpdating
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-700 active:scale-95 cursor-pointer'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">
              {isUpdating ? 'refresh' : 'system_update_alt'}
            </span>
            <span>{isUpdating ? 'Updating Terminal...' : 'Update & Restart Now'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
