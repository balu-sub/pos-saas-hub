import React, { useState, useEffect, useCallback, useRef } from 'react';
import { usePOS } from '../../context/POSContext';
import { playKeypadClick, playWarningTone, playSuccessChime } from '../../utils/audio';

interface PinLockModalProps {
  isOpen: boolean;
  onClose: () => void;
  isMandatory?: boolean;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({ isOpen, onClose, isMandatory = false }) => {
  const { currentOperator, switchOperatorByPin } = usePOS();
  const [pinInput, setPinInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const pinInputRef = useRef(pinInput);
  useEffect(() => {
    pinInputRef.current = pinInput;
  }, [pinInput]);

  useEffect(() => {
    if (!isOpen) {
      setPinInput('');
      setErrorMsg('');
    }
  }, [isOpen]);

  const handleDigit = useCallback((digit: string) => {
    playKeypadClick();
    const current = pinInputRef.current;
    if (current.length >= 4) return;
    const nextPin = current + digit;
    setPinInput(nextPin);
    setErrorMsg('');

    if (nextPin.length === 4) {
      const success = switchOperatorByPin(nextPin);
      if (success) {
        try {
          localStorage.removeItem('alfa_pos_is_locked');
        } catch {
          // ignore
        }
        playSuccessChime();
        setPinInput('');
        onClose();
      } else {
        playWarningTone();
        setErrorMsg('Invalid PIN. Please enter your valid 4-digit code.');
        setPinInput('');
      }
    }
  }, [switchOperatorByPin, onClose]);

  const handleClear = useCallback(() => {
    playKeypadClick();
    setPinInput('');
    setErrorMsg('');
  }, []);

  const handleBackspace = useCallback(() => {
    playKeypadClick();
    setPinInput((prev) => prev.slice(0, -1));
    setErrorMsg('');
  }, []);

  // Physical keyboard listener
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (!isMandatory) {
          e.preventDefault();
          e.stopPropagation();
          onClose();
        }
        return;
      }

      if (e.key === 'Backspace') {
        e.preventDefault();
        e.stopPropagation();
        handleBackspace();
        return;
      }

      if (e.key === 'Delete' || e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        e.stopPropagation();
        handleClear();
        return;
      }

      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        e.stopPropagation();
        handleDigit(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [isOpen, onClose, handleDigit, handleBackspace, handleClear]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center select-none">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={isMandatory ? undefined : onClose} />

      <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-[380px] max-w-[95vw] shadow-2xl p-6 text-center industrial-shadow animate-in fade-in zoom-in-95">
        <div className="w-12 h-12 rounded-full bg-[#00478c]/15 text-[#00478c] flex items-center justify-center mx-auto mb-3">
          <span className="material-symbols-outlined text-2xl">lock</span>
        </div>

        <h3 className="text-lg font-bold text-[#09090B]">{isMandatory ? 'Terminal Locked' : 'Operator Security Lock'}</h3>
        <p className="text-xs text-[#5c403c] mt-1">
          {isMandatory
            ? 'Enter your 4-digit PIN to unlock the register'
            : `Enter 4-digit Cashier PIN (Current: ${currentOperator.name})`}
        </p>

        {/* PIN Circles Display */}
        <div className="flex justify-center gap-3 my-5">
          {[0, 1, 2, 3].map((idx) => (
            <div
              key={idx}
              className={`w-4 h-4 rounded-full border-2 transition-all ${
                pinInput.length > idx ? 'bg-[#00478c] border-[#00478c]' : 'border-[#D4D4D8] bg-[#F4F4F5]'
              }`}
            />
          ))}
        </div>

        {errorMsg && (
          <div className="text-xs text-[#ba1a1a] font-semibold mb-3 bg-[#ffdad6]/50 p-2 rounded">
            {errorMsg}
          </div>
        )}

        {/* Keypad Grid */}
        <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
            <button
              key={k}
              onClick={() => {
                if (k === 'C') handleClear();
                else if (k === '⌫') handleBackspace();
                else handleDigit(k);
              }}
              className="h-12 border border-[#D4D4D8] rounded font-tabular-numeric text-base font-bold bg-white hover:bg-[#F4F4F5] active:bg-[#E4E4E7] transition-colors cursor-pointer"
            >
              {k}
            </button>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-[#D4D4D8] text-[11px] text-[#5c403c]">
          Authorized staff and cashier access only
        </div>
      </div>
    </div>
  );
};
