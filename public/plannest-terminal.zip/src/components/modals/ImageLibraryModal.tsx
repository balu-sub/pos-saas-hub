import React, { useState, useMemo } from 'react';
import { CLOUDINARY_PRODUCTS } from '../../../scripts/cloudinary-catalog';
import { apiClient } from '../../services/apiClient';
import { playBarcodeBeep, playSuccessChime } from '../../utils/audio';

interface ImageLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentImageUrl?: string;
  onSelectImage: (localUrl: string, cloudUrl: string, itemName: string) => void;
}

export const ImageLibraryModal: React.FC<ImageLibraryModalProps> = ({
  isOpen,
  onClose,
  currentImageUrl,
  onSelectImage,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadingName, setDownloadingName] = useState('');
  const [customUrl, setCustomUrl] = useState('');
  const [errorNotice, setErrorNotice] = useState<string | null>(null);

  const categories = useMemo(() => {
    const set = new Set(CLOUDINARY_PRODUCTS.map((p) => p.category).filter(Boolean));
    return ['All', ...Array.from(set)];
  }, []);

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return CLOUDINARY_PRODUCTS.filter((item) => {
      const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
      const matchQuery =
        !q ||
        item.name.toLowerCase().includes(q) ||
        (item.category && item.category.toLowerCase().includes(q));
      return matchCat && matchQuery;
    });
  }, [search, selectedCategory]);

  const handleChooseImage = async (cloudUrl: string, name: string) => {
    setIsDownloading(true);
    setDownloadingName(name);
    setErrorNotice(null);
    playBarcodeBeep();

    try {
      // Download image directly to local machine disk and obtain local path
      const result = await apiClient.downloadLibraryImage(cloudUrl, name);
      playSuccessChime();
      onSelectImage(result.localUrl, cloudUrl, name);
      onClose();
    } catch (err: any) {
      console.warn('Local download fallback:', err);
      // If offline, use CDN URL directly
      onSelectImage(cloudUrl, cloudUrl, name);
      onClose();
    } finally {
      setIsDownloading(false);
      setDownloadingName('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[88vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in-95 font-sans">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between bg-gray-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#00478c] flex items-center justify-center">
              <span className="material-symbols-outlined text-[24px]">photo_library</span>
            </div>
            <div>
              <h3 className="font-bold text-base text-[#09090B]">Cloud Product Image Library</h3>
              <p className="text-xs text-[#5c403c]">
                Select an image — it will be downloaded to your local machine for 100% offline access
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isDownloading}
            className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Downloading Overlay */}
        {isDownloading && (
          <div className="bg-blue-50 border-b border-blue-200 p-3 px-6 flex items-center gap-3 text-xs font-bold text-[#00478c] animate-pulse">
            <span className="material-symbols-outlined animate-spin text-[18px]">sync</span>
            <span>Downloading "{downloadingName}" to local disk storage &amp; updating catalog...</span>
          </div>
        )}

        {errorNotice && (
          <div className="bg-red-50 border-b border-red-200 p-3 px-6 text-xs text-red-700 font-bold">
            {errorNotice}
          </div>
        )}

        {/* Search & Category Filter Bar */}
        <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row gap-3 bg-white">
          <div className="relative flex-1">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-[18px]">
              search
            </span>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search 170+ items (e.g. Apple, Onion, Milk, Dates, Grape)..."
              className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs focus:outline-none focus:border-[#00478c] focus:bg-white font-medium"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#00478c] text-white shadow-xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Image Grid */}
        <div className="flex-1 overflow-y-auto p-5 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5 bg-gray-50/40">
          {filteredItems.length === 0 ? (
            <div className="col-span-full py-12 text-center text-gray-400 text-xs font-medium">
              No matching items found for "{search}". You can paste a custom URL below.
            </div>
          ) : (
            filteredItems.map((item) => {
              const isSelected =
                currentImageUrl &&
                (currentImageUrl.includes(item.imageUrl) ||
                  currentImageUrl.toLowerCase().includes(item.name.toLowerCase().replace(/\s+/g, '_')));
              return (
                <div
                  key={item.id + item.name}
                  onClick={() => !isDownloading && handleChooseImage(item.imageUrl, item.name)}
                  className={`group relative rounded-xl border p-2 bg-white flex flex-col justify-between gap-2 cursor-pointer transition-all hover:shadow-md hover:border-[#00478c] hover:-translate-y-0.5 ${
                    isSelected ? 'ring-2 ring-[#00478c] border-[#00478c] bg-blue-50/20' : 'border-gray-200'
                  }`}
                >
                  <div className="w-full aspect-square rounded-lg bg-gray-100 overflow-hidden relative">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      onError={(e: any) => {
                        e.target.style.display = 'none';
                      }}
                    />
                    {isSelected && (
                      <div className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-[#00478c] text-white flex items-center justify-center shadow-xs">
                        <span className="material-symbols-outlined text-[14px]">check</span>
                      </div>
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="font-bold text-xs text-[#09090B] truncate" title={item.name}>
                      {item.name}
                    </div>
                    <div className="text-[10px] text-[#5c403c] font-medium truncate">
                      {item.category} • ₹{item.price}/{item.unit}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer: Custom URL option */}
        <div className="p-4 border-t border-gray-200 bg-white flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex-1 flex items-center gap-2 w-full">
            <input
              type="url"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              placeholder="Or paste external image URL (https://...)"
              className="flex-1 px-3 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs focus:outline-none focus:border-[#00478c] font-mono"
            />
            <button
              type="button"
              disabled={!customUrl.trim() || isDownloading}
              onClick={() => {
                if (customUrl.trim()) {
                  handleChooseImage(customUrl.trim(), 'custom_item');
                }
              }}
              className="px-4 py-2 bg-gray-900 hover:bg-black disabled:opacity-40 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Download &amp; Use URL
            </button>
          </div>

          <button
            type="button"
            disabled={isDownloading}
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:text-black font-bold text-xs cursor-pointer"
          >
            Cancel
          </button>
        </div>

      </div>
    </div>
  );
};
