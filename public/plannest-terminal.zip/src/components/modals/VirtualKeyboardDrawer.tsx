import React, { useState, useRef, useEffect } from 'react';
import { useVirtualKeyboard } from '../../context/VirtualKeyboardContext';

export const VirtualKeyboardDrawer: React.FC = () => {
  const {
    isTouchKeyboardEnabled,
    isKeyboardVisible,
    keyboardLayout,
    inputTitle,
    inputUnit,
    isDiscreteOnly,
    closeKeyboard,
    sendKey,
  } = useVirtualKeyboard();

  const [shiftActive, setShiftActive] = useState(false);
  const [capsLock, setCapsLock] = useState(false);
  const [activeTab, setActiveTab] = useState<'numpad' | 'qwerty'>(keyboardLayout);
  const [isMinimized, setIsMinimized] = useState(false);

  // Floating Position & Dragging State
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 0,
    posY: 0,
  });
  const containerRef = useRef<HTMLDivElement>(null);

  // Sync tab with layout when opening
  useEffect(() => {
    setActiveTab(keyboardLayout);
    setIsMinimized(false);
  }, [keyboardLayout, isKeyboardVisible]);

  // Default positioning: Bottom Right or Bottom Center without full-screen blocking
  useEffect(() => {
    if (isKeyboardVisible && position === null && typeof window !== 'undefined') {
      const isMobile = window.innerWidth < 640;
      const defaultWidth = isMobile ? window.innerWidth - 16 : 380;
      const posX = isMobile ? 8 : Math.max(16, window.innerWidth - defaultWidth - 24);
      const posY = Math.max(20, window.innerHeight - 330);
      setPosition({ x: posX, y: posY });
    }
  }, [isKeyboardVisible, position]);

  // Drag handlers
  const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const currentX = position?.x ?? 20;
    const currentY = position?.y ?? 20;

    dragStartRef.current = {
      startX: clientX,
      startY: clientY,
      posX: currentX,
      posY: currentY,
    };
    setIsDragging(true);
  };

  useEffect(() => {
    const handleDragMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;

      const deltaX = clientX - dragStartRef.current.startX;
      const deltaY = clientY - dragStartRef.current.startY;

      const newX = Math.max(10, Math.min(window.innerWidth - 200, dragStartRef.current.posX + deltaX));
      const newY = Math.max(10, Math.min(window.innerHeight - 80, dragStartRef.current.posY + deltaY));

      setPosition({ x: newX, y: newY });
    };

    const handleDragEnd = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleDragMove);
      window.addEventListener('mouseup', handleDragEnd);
      window.addEventListener('touchmove', handleDragMove);
      window.addEventListener('touchend', handleDragEnd);
    }
    return () => {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchmove', handleDragMove);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, [isDragging]);

  if (!isTouchKeyboardEnabled || !isKeyboardVisible) {
    return null;
  }

  const isNumpad = activeTab === 'numpad';

  const qwertyRows = [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    ['z', 'x', 'c', 'v', 'b', 'n', 'm'],
  ];

  const symbolsRow = ['@', '.', '-', '_', '/', ',', '₹'];

  const handleCharKey = (char: string) => {
    const isUpper = shiftActive || capsLock;
    sendKey(isUpper ? char.toUpperCase() : char.toLowerCase());
    if (shiftActive) setShiftActive(false);
  };

  // Minimized Compact Pill Mode
  if (isMinimized) {
    return (
      <div
        data-virtual-keyboard="true"
        style={{
          position: 'fixed',
          left: position?.x ?? 20,
          top: position?.y ?? window.innerHeight - 80,
          zIndex: 9999,
        }}
        className="flex items-center gap-2 bg-[#0f172a] text-white px-3.5 py-2 rounded-full shadow-2xl border-2 border-[#00478c] cursor-pointer hover:bg-slate-800 transition-all select-none animate-in fade-in"
        onClick={() => setIsMinimized(false)}
        onMouseDown={(e) => e.preventDefault()}
      >
        <span className="material-symbols-outlined text-amber-400 text-[20px]">
          {isNumpad ? 'dialpad' : 'keyboard'}
        </span>
        <span className="text-xs font-bold text-slate-100">
          {inputTitle || 'Tap to expand keyboard'}
        </span>
        <span className="material-symbols-outlined text-gray-400 text-[18px]">
          open_in_full
        </span>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      data-virtual-keyboard="true"
      style={{
        position: 'fixed',
        left: position ? `${position.x}px` : undefined,
        top: position ? `${position.y}px` : undefined,
        bottom: position ? undefined : '16px',
        right: position ? undefined : '16px',
        zIndex: 9999,
      }}
      className={`bg-[#0f172a] text-white rounded-2xl border-2 border-slate-700 shadow-[0_15px_40px_rgba(0,0,0,0.6)] select-none overflow-hidden transition-shadow ${
        isNumpad ? 'w-[325px]' : 'w-[480px] max-w-[96vw]'
      } ${isDragging ? 'opacity-90 shadow-2xl scale-[1.01]' : 'opacity-100'}`}
      onMouseDown={(e) => {
        // Prevent stealing focus from the active input
        e.preventDefault();
      }}
    >
      {/* Draggable Compact Header Bar */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-[#1e293b] border-b border-slate-700 cursor-move"
        onMouseDown={handleDragStart}
        onTouchStart={handleDragStart}
        title="Click and drag to move keyboard anywhere on screen"
      >
        <div className="flex items-center gap-1.5 min-w-0 flex-1">
          <span className="material-symbols-outlined text-gray-400 text-[16px] shrink-0">
            drag_indicator
          </span>
          <span className="material-symbols-outlined text-amber-400 text-[18px] shrink-0">
            {isNumpad ? 'dialpad' : 'keyboard'}
          </span>
          <span className="text-xs font-bold text-slate-200 truncate" title={inputTitle}>
            {inputTitle || (isNumpad ? 'Touch Numpad' : 'Touch Keyboard')}
          </span>
          {inputUnit && (
            <span className="px-1.5 py-0.2 bg-[#00478c] text-white text-[9px] font-extrabold rounded uppercase tracking-wider shrink-0">
              {inputUnit}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0 ml-1">
          {/* Switch layout button */}
          <button
            type="button"
            onClick={() => setActiveTab(isNumpad ? 'qwerty' : 'numpad')}
            className="px-2 py-0.8 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-bold flex items-center gap-1 cursor-pointer border border-slate-600 transition-colors"
            title="Switch between Numpad and QWERTY keyboard"
          >
            <span className="material-symbols-outlined text-[14px]">
              {isNumpad ? 'keyboard' : 'dialpad'}
            </span>
            <span>{isNumpad ? 'QWERTY' : '123'}</span>
          </button>

          {/* Reset position to bottom right */}
          <button
            type="button"
            onClick={() => {
              if (typeof window !== 'undefined') {
                const isMobile = window.innerWidth < 640;
                const width = isMobile ? window.innerWidth - 16 : 360;
                setPosition({
                  x: Math.max(16, window.innerWidth - width - 24),
                  y: Math.max(20, window.innerHeight - 330),
                });
              }
            }}
            className="w-6 h-6 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center justify-center cursor-pointer border border-slate-600"
            title="Dock to bottom right"
          >
            <span className="material-symbols-outlined text-[14px]">dock_to_right</span>
          </button>

          {/* Minimize button */}
          <button
            type="button"
            onClick={() => setIsMinimized(true)}
            className="w-6 h-6 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center justify-center cursor-pointer border border-slate-600"
            title="Minimize keyboard"
          >
            <span className="material-symbols-outlined text-[15px]">remove</span>
          </button>

          {/* Close button */}
          <button
            type="button"
            onClick={closeKeyboard}
            className="w-6 h-6 bg-red-600/80 hover:bg-red-600 text-white rounded text-xs flex items-center justify-center cursor-pointer"
            title="Close touch keyboard"
          >
            <span className="material-symbols-outlined text-[15px]">close</span>
          </button>
        </div>
      </div>

      {/* Keyboard Content: Clean & Compact with ZERO dark side margins */}
      <div className="p-2 w-full bg-[#0f172a]">
        {isNumpad ? (
          /* ================= COMPACT FLOATING NUMPAD ================= */
          <div className="flex gap-1.5 justify-center items-stretch">
            {/* Quick Increments Column */}
            <div className="flex flex-col gap-1 w-14">
              <button
                type="button"
                onClick={() => sendKey('+1')}
                className="flex-1 py-1 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] text-amber-300 border border-slate-700 rounded-lg font-bold text-xs flex items-center justify-center cursor-pointer shadow-2xs"
              >
                +1
              </button>
              <button
                type="button"
                onClick={() => sendKey('+5')}
                className="flex-1 py-1 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] text-amber-300 border border-slate-700 rounded-lg font-bold text-xs flex items-center justify-center cursor-pointer shadow-2xs"
              >
                +5
              </button>
              <button
                type="button"
                onClick={() => sendKey('+10')}
                className="flex-1 py-1 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] text-amber-300 border border-slate-700 rounded-lg font-bold text-xs flex items-center justify-center cursor-pointer shadow-2xs"
              >
                +10
              </button>
              <button
                type="button"
                onClick={() => sendKey('+100')}
                className="flex-1 py-1 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] text-amber-300 border border-slate-700 rounded-lg font-bold text-xs flex items-center justify-center cursor-pointer shadow-2xs"
              >
                +100
              </button>
            </div>

            {/* 3x4 Digits Grid */}
            <div className="grid grid-cols-3 gap-1 flex-1">
              {['7', '8', '9', '4', '5', '6', '1', '2', '3'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => sendKey(digit)}
                  className="h-10.5 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-lg font-black text-lg flex items-center justify-center cursor-pointer transition-transform active:scale-95 shadow-2xs"
                >
                  {digit}
                </button>
              ))}

              {/* Bottom Row: Decimal, 0, 00 */}
              <button
                type="button"
                disabled={isDiscreteOnly}
                onClick={() => sendKey('.')}
                className={`h-10.5 border rounded-lg font-black text-lg flex items-center justify-center cursor-pointer transition-transform active:scale-95 shadow-2xs ${
                  isDiscreteOnly
                    ? 'bg-slate-900 border-slate-800 text-slate-600 opacity-40 cursor-not-allowed'
                    : 'bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border-slate-700 text-amber-400'
                }`}
                title={isDiscreteOnly ? 'Decimal disabled for discrete items' : 'Decimal point'}
              >
                .
              </button>

              <button
                type="button"
                onClick={() => sendKey('0')}
                className="h-10.5 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-lg font-black text-lg flex items-center justify-center cursor-pointer transition-transform active:scale-95 shadow-2xs"
              >
                0
              </button>

              <button
                type="button"
                onClick={() => sendKey('00')}
                className="h-10.5 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-lg font-black text-sm flex items-center justify-center cursor-pointer transition-transform active:scale-95 shadow-2xs"
              >
                00
              </button>
            </div>

            {/* Action Column: Del, Clear, Enter */}
            <div className="flex flex-col gap-1 w-18">
              <button
                type="button"
                onClick={() => sendKey('BACKSPACE')}
                className="h-10.5 bg-amber-700 hover:bg-amber-600 active:bg-amber-800 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95 shadow-2xs"
                title="Backspace / Delete"
              >
                <span className="material-symbols-outlined text-[16px]">backspace</span>
                <span>Del</span>
              </button>

              <button
                type="button"
                onClick={() => sendKey('CLEAR')}
                className="h-10.5 bg-slate-700 hover:bg-slate-600 active:bg-slate-800 text-rose-300 rounded-lg font-bold text-xs uppercase flex items-center justify-center cursor-pointer transition-transform active:scale-95 shadow-2xs"
              >
                Clear
              </button>

              <button
                type="button"
                onClick={() => sendKey('ENTER')}
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-lg font-black text-xs uppercase tracking-wide flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-transform active:scale-95 shadow-2xs"
              >
                <span className="material-symbols-outlined text-[18px]">check_circle</span>
                <span>Enter</span>
              </button>
            </div>
          </div>
        ) : (
          /* ================= COMPACT FLOATING QWERTY KEYBOARD ================= */
          <div className="flex flex-col gap-1 w-full">
            {/* Number Row */}
            <div className="flex justify-center gap-1 w-full">
              {qwertyRows[0].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => sendKey(k)}
                  className="flex-1 h-8 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-md font-bold text-xs flex items-center justify-center cursor-pointer active:scale-95 shadow-2xs"
                >
                  {k}
                </button>
              ))}
              <button
                type="button"
                onClick={() => sendKey('BACKSPACE')}
                className="w-12 h-8 bg-amber-700 hover:bg-amber-600 text-white rounded-md font-bold text-xs flex items-center justify-center gap-0.5 cursor-pointer active:scale-95 shadow-2xs"
              >
                <span className="material-symbols-outlined text-[14px]">backspace</span>
                <span>Del</span>
              </button>
            </div>

            {/* Row 1 (QWERTY) */}
            <div className="flex justify-center gap-1 w-full">
              {qwertyRows[1].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => handleCharKey(k)}
                  className="flex-1 h-8 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-md font-bold text-xs uppercase shadow-2xs flex items-center justify-center cursor-pointer active:scale-95"
                >
                  {shiftActive || capsLock ? k.toUpperCase() : k.toLowerCase()}
                </button>
              ))}
            </div>

            {/* Row 2 (ASDF) */}
            <div className="flex justify-center gap-1 w-full">
              <button
                type="button"
                onClick={() => setCapsLock(!capsLock)}
                className={`w-11 h-8 rounded-md font-bold text-[11px] flex items-center justify-center cursor-pointer transition-colors shadow-2xs ${
                  capsLock ? 'bg-amber-500 text-black' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                Caps
              </button>
              {qwertyRows[2].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => handleCharKey(k)}
                  className="flex-1 h-8 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-md font-bold text-xs uppercase shadow-2xs flex items-center justify-center cursor-pointer active:scale-95"
                >
                  {shiftActive || capsLock ? k.toUpperCase() : k.toLowerCase()}
                </button>
              ))}
              <button
                type="button"
                onClick={() => sendKey('CLEAR')}
                className="w-11 h-8 bg-slate-700 hover:bg-slate-600 text-rose-300 rounded-md font-bold text-[10px] flex items-center justify-center cursor-pointer shadow-2xs uppercase"
              >
                Clear
              </button>
            </div>

            {/* Row 3 (ZXCV) */}
            <div className="flex justify-center gap-1 w-full">
              <button
                type="button"
                onClick={() => setShiftActive(!shiftActive)}
                className={`w-12 h-8 rounded-md font-bold text-[11px] flex items-center justify-center gap-0.5 cursor-pointer transition-colors shadow-2xs ${
                  shiftActive ? 'bg-[#00478c] text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                <span className="material-symbols-outlined text-[13px]">arrow_upward</span>
                <span>Shift</span>
              </button>
              {qwertyRows[3].map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => handleCharKey(k)}
                  className="flex-1 h-8 bg-slate-800 hover:bg-slate-700 active:bg-[#00478c] border border-slate-700 text-white rounded-md font-bold text-xs uppercase shadow-2xs flex items-center justify-center cursor-pointer active:scale-95"
                >
                  {shiftActive || capsLock ? k.toUpperCase() : k.toLowerCase()}
                </button>
              ))}
              <button
                type="button"
                onClick={() => sendKey('ENTER')}
                className="w-14 h-8 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md font-bold text-xs flex items-center justify-center gap-0.5 cursor-pointer active:scale-95 shadow-2xs"
              >
                <span>Enter</span>
                <span className="material-symbols-outlined text-[14px]">keyboard_return</span>
              </button>
            </div>

            {/* Bottom Row: Symbols + Space */}
            <div className="flex justify-center gap-1 w-full">
              {symbolsRow.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => sendKey(s)}
                  className="px-2 h-7.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md font-bold text-xs flex items-center justify-center cursor-pointer border border-slate-700/60 shadow-2xs"
                >
                  {s}
                </button>
              ))}
              <button
                type="button"
                onClick={() => sendKey(' ')}
                className="flex-1 h-7.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md font-bold text-xs flex items-center justify-center cursor-pointer tracking-widest uppercase border border-slate-700 shadow-2xs"
              >
                Space
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
