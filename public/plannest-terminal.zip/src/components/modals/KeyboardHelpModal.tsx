import React from 'react';

interface KeyboardHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KeyboardHelpModal: React.FC<KeyboardHelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'F12', label: 'Instant Charge / Split-Tender Checkout' },
    { key: 'F2', label: 'AI Camera Produce Visual Recognition (Gemini Vision)' },
    { key: 'F3', label: 'AI Multilingual Voice Input (Speech-to-Cart)' },
    { key: 'F4', label: 'Barcode & QR Hardware Scanner Configuration' },
    { key: 'F6', label: 'Tare Weighing Scale to Zero' },
    { key: 'F8', label: 'Kick Open Cash Drawer (ESC/POS 24V Solenoid)' },
    { key: 'ESC', label: 'Cancel / Dismiss Active Modal or Overlay' },
    { key: 'Enter', label: 'Confirm Scan / Add Line Item / Execute' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center select-none">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-[500px] max-w-[95vw] shadow-2xl p-6 industrial-shadow animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-[#D4D4D8]">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00478c]">keyboard</span>
            <h3 className="font-bold text-lg text-[#09090B]">Hardware Keyboard Map</h3>
          </div>
          <button onClick={onClose} className="text-[#5c403c] hover:text-[#ba1a1a]">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="my-4 divide-y divide-[#D4D4D8]">
          {shortcuts.map((s) => (
            <div key={s.key} className="py-2.5 flex justify-between items-center text-xs">
              <span className="text-[#09090B] font-medium">{s.label}</span>
              <kbd className="px-2.5 py-1 bg-[#F4F4F5] border border-[#D4D4D8] rounded font-mono font-bold text-[#00478c] shadow-xs">
                {s.key}
              </kbd>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded font-bold text-xs"
        >
          Got It
        </button>
      </div>
    </div>
  );
};
