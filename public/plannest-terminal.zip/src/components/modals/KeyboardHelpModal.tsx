import React, { useState } from 'react';

interface KeyboardHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KeyboardHelpModal: React.FC<KeyboardHelpModalProps> = ({ isOpen, onClose }) => {
  const [activeView, setActiveView] = useState<'guide' | 'shortcuts'>('guide');

  if (!isOpen) return null;

  const shortcuts = [
    { key: 'F12', label: 'Instant Charge / Split-Tender Checkout' },
    { key: 'F2', label: 'AI Camera Produce Visual Recognition (Gemini Vision)' },
    { key: 'F3', label: 'AI Multilingual Voice Input (Speech-to-Cart)' },
    { key: 'F4', label: 'Barcode & QR Hardware Scanner Configuration' },
    { key: 'F6', label: 'Tare Weighing Scale to Zero' },
    { key: 'F8', label: 'Kick Open Cash Drawer (ESC/POS 24V Solenoid)' },
    { key: 'ESC', label: 'Cancel / Dismiss Active Modal or Overlay' },
    { key: 'Enter', label: 'Confirm Scan / Add Line Item / Execute' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center select-none">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-[96vw] max-w-[1440px] h-[92vh] shadow-2xl flex flex-col overflow-hidden industrial-shadow animate-in fade-in zoom-in-95">
        {/* Top Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 bg-[#0f172a] text-white border-b border-slate-800 shrink-0">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2.5">
              <span className="material-symbols-outlined text-blue-400 text-[22px]">menu_book</span>
              <div>
                <h3 className="font-extrabold text-sm text-white leading-tight">
                  Plannest Retail POS — Complete Operator Help &amp; User Manual
                </h3>
                <p className="text-[11px] text-slate-400">
                  Step-by-step visual guide for every screen, menu, submenu &amp; cloud sync
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-800/90 p-1 rounded-lg border border-slate-700">
              <button
                type="button"
                onClick={() => setActiveView('guide')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeView === 'guide'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">help</span>
                <span>Visual User Manual (All Screens)</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveView('shortcuts')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeView === 'shortcuts'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">keyboard</span>
                <span>Hardware Keyboard Map</span>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <a
              href="/help/index.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <span className="material-symbols-outlined text-[15px]">open_in_new</span>
              <span>Open Full Help Page in Browser Tab</span>
            </a>
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
              <span>Close</span>
            </button>
          </div>
        </div>

        {/* Body */}
        {activeView === 'guide' ? (
          <div className="flex-1 w-full bg-slate-100 overflow-hidden">
            <iframe
              src="/help/index.html"
              title="Plannest Retail POS Operator Help & User Manual"
              className="w-full h-full border-0"
            />
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-8 bg-slate-50 flex items-start justify-center">
            <div className="bg-white rounded-xl border border-[#D4D4D8] w-full max-w-xl p-6 shadow-md space-y-5">
              {/* Prominent Direct Link Banner to Complete Help & User Manual */}
              <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <span className="material-symbols-outlined text-[#00478c] text-[24px] mt-0.5">
                    menu_book
                  </span>
                  <div>
                    <h4 className="font-bold text-sm text-[#09090B]">
                      Need the Full Step-by-Step Visual User Guide?
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Includes screenshots and simple instructions for every menu &amp; submenu.
                    </p>
                  </div>
                </div>
                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setActiveView('guide')}
                    className="px-3 py-1.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded-lg font-bold text-xs cursor-pointer text-center"
                  >
                    View Inside App
                  </button>
                  <a
                    href="/help/index.html"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-white hover:bg-slate-100 text-[#00478c] border border-blue-300 rounded-lg font-bold text-xs flex items-center justify-center gap-1"
                  >
                    <span>Open Full Page</span>
                    <span className="material-symbols-outlined text-[13px]">open_in_new</span>
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-2 pb-3 border-b border-[#D4D4D8]">
                <span className="material-symbols-outlined text-[#00478c]">keyboard</span>
                <h4 className="font-bold text-base text-[#09090B]">
                  Hardware Keyboard Map &amp; Shortcuts
                </h4>
              </div>

              <div className="divide-y divide-[#D4D4D8]">
                {shortcuts.map((s) => (
                  <div key={s.key} className="py-2.5 flex justify-between items-center text-xs">
                    <span className="text-[#09090B] font-medium">{s.label}</span>
                    <kbd className="px-2.5 py-1 bg-[#F4F4F5] border border-[#D4D4D8] rounded font-mono font-bold text-[#00478c] shadow-xs">
                      {s.key}
                    </kbd>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 bg-[#00478c] hover:bg-[#005eb7] text-white rounded font-bold text-xs cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
