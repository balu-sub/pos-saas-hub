import React, { useState, useRef, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { playBarcodeBeep, playSuccessChime, playWarningTone } from '../../utils/audio';

export const BarcodeScannerModal: React.FC = () => {
  const { isBarcodeScannerModalOpen, setIsBarcodeScannerModalOpen, barcodeConfig, setBarcodeConfig } = usePeripherals();
  const { scanBarcode, products } = usePOS();

  const [testInput, setTestInput] = useState('');
  const [scanHistory, setScanHistory] = useState<Array<{ code: string; name: string; success: boolean; time: string }>>([]);
  const [isCameraScannerActive, setIsCameraScannerActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const testInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isBarcodeScannerModalOpen) {
      setTimeout(() => {
        testInputRef.current?.focus();
      }, 100);
    } else {
      stopCamera();
    }
  }, [isBarcodeScannerModalOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setIsCameraScannerActive(true);
    } catch (err: any) {
      setCameraError('Camera access unavailable. Use USB Keyboard Wedge mode or manual input.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraScannerActive(false);
  };

  const handleTestScan = (code: string) => {
    const trimmed = code.trim();
    if (!trimmed) return;

    const matchedProd = products.find(
      (p) => p.baseBarcode === trimmed || p.baseSku === trimmed || p.variants.some((v) => v.barcode === trimmed || v.sku === trimmed)
    );

    const success = Boolean(matchedProd);
    if (success) {
      playBarcodeBeep();
      if (barcodeConfig.autoAddToCart) {
        scanBarcode(trimmed);
      }
    } else {
      playWarningTone();
    }

    setScanHistory((prev) => [
      {
        code: trimmed,
        name: matchedProd ? matchedProd.name : 'Unknown / Unmapped SKU',
        success,
        time: new Date().toLocaleTimeString(),
      },
      ...prev.slice(0, 7),
    ]);

    setBarcodeConfig((prev) => ({
      ...prev,
      lastScannedCode: trimmed,
      lastScannedTime: Date.now(),
    }));

    setTestInput('');
  };

  if (!isBarcodeScannerModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 md:p-6 select-none animate-in fade-in">
      <div className="bg-white w-full max-w-3xl rounded-xl shadow-2xl flex flex-col overflow-hidden border border-[#D4D4D8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#00478c] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[24px]">barcode_scanner</span>
            <div>
              <h2 className="font-bold text-base md:text-lg">Barcode &amp; QR Scanner Configuration</h2>
              <p className="text-xs text-blue-100">
                Configure USB HID Keyboard Wedge, WebSerial Scanners &amp; Optical Camera Barcode Readers
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopCamera();
              setIsBarcodeScannerModalOpen(false);
            }}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 md:p-6 space-y-5 overflow-y-auto max-h-[80vh]">
          {/* Hardware Configuration Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">SCANNER INTERFACE</label>
              <select
                value={barcodeConfig.mode}
                onChange={(e: any) => setBarcodeConfig((prev) => ({ ...prev, mode: e.target.value }))}
                className="w-full h-9 border border-gray-300 rounded px-2.5 text-xs bg-white font-medium text-gray-800 focus:outline-none"
              >
                <option value="KEYBOARD_WEDGE">USB Keyboard Wedge (HID)</option>
                <option value="SERIAL_HID">WebSerial / Bluetooth RS232</option>
                <option value="CAMERA_BARCODE">Built-in Device Camera</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">TERMINATOR SUFFIX</label>
              <select
                value={barcodeConfig.suffix}
                onChange={(e: any) => setBarcodeConfig((prev) => ({ ...prev, suffix: e.target.value }))}
                className="w-full h-9 border border-gray-300 rounded px-2.5 text-xs bg-white font-medium text-gray-800 focus:outline-none"
              >
                <option value="Enter">Enter / Carriage Return [CR+LF]</option>
                <option value="Tab">Tab Character [TAB]</option>
                <option value="None">None (Stream Mode)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">MIN BARCODE LENGTH</label>
              <input
                type="number"
                min="3"
                max="20"
                value={barcodeConfig.minBarcodeLength}
                onChange={(e) => setBarcodeConfig((prev) => ({ ...prev, minBarcodeLength: parseInt(e.target.value) || 4 }))}
                className="w-full h-9 border border-gray-300 rounded px-2.5 text-xs bg-white font-medium text-gray-800 focus:outline-none"
              />
            </div>
          </div>

          {/* Toggles */}
          <div className="flex items-center gap-6 flex-wrap bg-gray-50 p-3 rounded-lg border border-gray-200 text-xs">
            <label className="flex items-center gap-2 cursor-pointer font-bold text-gray-700">
              <input
                type="checkbox"
                checked={barcodeConfig.beepOnScan}
                onChange={(e) => setBarcodeConfig((prev) => ({ ...prev, beepOnScan: e.target.checked }))}
                className="rounded text-[#00478c] focus:ring-0"
              />
              <span>2.4kHz WebAudio Beep Chime</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-bold text-gray-700">
              <input
                type="checkbox"
                checked={barcodeConfig.autoAddToCart}
                onChange={(e) => setBarcodeConfig((prev) => ({ ...prev, autoAddToCart: e.target.checked }))}
                className="rounded text-[#00478c] focus:ring-0"
              />
              <span>Auto Add to POS Bill on Scan</span>
            </label>
          </div>

          {/* Test Scanner Input Zone */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-gray-700 flex items-center justify-between">
              <span>SCANNER TEST INPUT ZONE</span>
              <span className="text-[11px] text-gray-400">Aim handheld scanner here &amp; pull trigger</span>
            </label>
            <div className="flex gap-2">
              <input
                ref={testInputRef}
                type="text"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleTestScan(testInput);
                  }
                }}
                placeholder="Scan or type barcode (e.g. 8901201001014) and hit Enter..."
                className="flex-1 h-10 px-3 border-2 border-emerald-500 rounded font-mono text-sm bg-white text-gray-900 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleTestScan(testInput)}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-bold text-xs cursor-pointer"
              >
                Test Scan
              </button>
            </div>
          </div>

          {/* Sample Barcode Quick Emulators */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-[#5c403c] uppercase">Quick Emulation Triggers:</span>
            <div className="flex flex-wrap gap-2">
              {[
                { label: 'Tomato (8901201001014)', code: '8901201001014' },
                { label: 'Toor Dal (8901030882107)', code: '8901030882107' },
                { label: 'Atta 5kg (8901030383789)', code: '8901030383789' },
                { label: 'Milk 1L (8901262020221)', code: '8901262020221' },
                { label: 'Sunflower Oil (8901030671234)', code: '8901030671234' },
              ].map((b, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleTestScan(b.code)}
                  className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded font-mono text-[11px] border border-gray-300 cursor-pointer"
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>

          {/* Scan History Table */}
          {scanHistory.length > 0 && (
            <div className="space-y-2 border-t border-gray-200 pt-3">
              <span className="text-xs font-bold text-gray-700">Recent Scanner Events:</span>
              <div className="border border-gray-200 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 text-gray-600 font-bold border-b border-gray-200">
                    <tr>
                      <th className="p-2">Time</th>
                      <th className="p-2">Barcode</th>
                      <th className="p-2">Resolved Product</th>
                      <th className="p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {scanHistory.map((h, i) => (
                      <tr key={i} className="hover:bg-gray-50">
                        <td className="p-2 text-gray-500 font-mono text-[11px]">{h.time}</td>
                        <td className="p-2 font-mono font-bold text-gray-900">{h.code}</td>
                        <td className="p-2 text-gray-800">{h.name}</td>
                        <td className="p-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              h.success ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {h.success ? 'Matched' : 'Unmapped'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
