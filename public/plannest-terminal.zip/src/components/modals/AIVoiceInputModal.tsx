import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { apiClient } from '../../services/apiClient';
import { PureAudioRecorder } from '../../utils/audioRecorder';
import { playBarcodeBeep, playSuccessChime, playKeypadClick } from '../../utils/audio';
import { Product } from '../../types/pos';

interface MatchedOption {
  product: Product;
  variantId?: string;
  matchedName: string;
  price: number;
  unit: string;
  quantity: number;
  confidence: number;
  matchReason?: string;
}

export const AIVoiceInputModal: React.FC = () => {
  const { isAIVoiceModalOpen, setIsAIVoiceModalOpen, voiceConfig } = usePeripherals();
  const { products, addToCart } = usePOS();

  // The primary text input state - whatever is spoken or typed goes straight into this box
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [audioVolume, setAudioVolume] = useState(0);
  const [statusMessage, setStatusMessage] = useState<string>('Click "Start Voice" to speak item name');
  const [selectedQuantities, setSelectedQuantities] = useState<Record<string, number>>({});
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const speechRecognitionRef = useRef<any>(null);
  const audioRecorderRef = useRef<PureAudioRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const timerIntervalRef = useRef<any>(null);
  const isMountedRef = useRef(true);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Stop recording & release mic hardware
  const stopAudio = useCallback(() => {
    setIsRecording(false);
    setAudioVolume(0);

    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch (e) {}
      speechRecognitionRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
  }, []);

  // Multi-language keyword & quantity parser (English, Hindi, Tamil, Telugu, Marathi, Hinglish)
  const parseQuery = (text: string): { keyword: string; parsedQty: number; unit: string } => {
    const lower = text.toLowerCase().trim();
    if (!lower) return { keyword: '', parsedQty: 1, unit: 'kg' };

    // Quantity extraction
    let parsedQty = 1;
    let unit = 'kg';

    if (/\b(2|two|do|rendu|don)\s*(kg|kilo|kilos)?\b/i.test(lower)) parsedQty = 2;
    else if (/\b(3|three|teen|moonu)\s*(kg|kilo|kilos)?\b/i.test(lower)) parsedQty = 3;
    else if (/\b(4|four|chaar|naalu)\s*(kg|kilo|kilos)?\b/i.test(lower)) parsedQty = 4;
    else if (/\b(5|five|paanch|aindhu)\s*(kg|kilo|kilos)?\b/i.test(lower)) parsedQty = 5;
    else if (/\b(500\s*g|500g|half\s*kg|aadha\s*kilo|arai\s*kilo)\b/i.test(lower)) parsedQty = 0.5;
    else if (/\b(250\s*g|250g|pav\s*kilo|kaal\s*kilo)\b/i.test(lower)) parsedQty = 0.25;
    else if (/\b(100\s*g|100g)\b/i.test(lower)) parsedQty = 0.1;
    else if (/\b(1|one|ek|oru|okati)\s*(kg|kilo|kilos)?\b/i.test(lower)) parsedQty = 1;

    // Unit detection
    if (lower.includes('liter') || lower.includes('litre') || lower.includes(' l ') || lower.endsWith('l')) {
      unit = 'L';
    } else if (lower.includes('pack') || lower.includes('packet')) {
      unit = 'pack';
    } else if (lower.includes('piece') || lower.includes('pc') || lower.includes('bunch') || lower.includes('nos')) {
      unit = 'pc';
    }

    // Regional keyword translations to English
    const terms: Record<string, string> = {
      thakkali: 'tomato',
      tamatar: 'tomato',
      tomato: 'tomato',
      vengayam: 'onion',
      pyaaz: 'onion',
      kanda: 'onion',
      onion: 'onion',
      urulaikizhangu: 'potato',
      aloo: 'potato',
      batata: 'potato',
      potato: 'potato',
      pachai: 'green chilli',
      mirch: 'green chilli',
      milagai: 'green chilli',
      chilli: 'green chilli',
      inji: 'ginger',
      adrak: 'ginger',
      ginger: 'ginger',
      poondu: 'garlic',
      lahsun: 'garlic',
      garlic: 'garlic',
      kathirikai: 'brinjal',
      baingan: 'brinjal',
      brinjal: 'brinjal',
      eggplant: 'brinjal',
      paal: 'milk',
      doodh: 'milk',
      milk: 'milk',
      arisi: 'rice',
      chawal: 'rice',
      rice: 'rice',
      atta: 'atta',
      wheat: 'atta',
      dal: 'dal',
      paruppu: 'dal',
      toor: 'toor dal',
      sarkarai: 'sugar',
      cheeni: 'sugar',
      sugar: 'sugar',
      paneer: 'paneer',
      curd: 'curd',
      dahi: 'curd',
      thayir: 'curd',
      oil: 'oil',
      ennai: 'oil',
      tel: 'oil',
      apple: 'apple',
      banana: 'banana',
      vazhaipazham: 'banana',
      kela: 'banana',
      carrot: 'carrot',
      gajar: 'carrot',
      cabbage: 'cabbage',
      patta: 'cabbage',
      muttakose: 'cabbage',
      capsicum: 'capsicum',
      shimla: 'capsicum',
      kuda: 'capsicum',
      coriander: 'coriander',
      dhaniya: 'coriander',
      kothamalli: 'coriander',
      mint: 'mint',
      pudina: 'mint',
      salt: 'salt',
      uppu: 'salt',
      namak: 'salt',
    };

    let matchedTerm = '';
    for (const [key, val] of Object.entries(terms)) {
      if (lower.includes(key)) {
        matchedTerm = val;
        break;
      }
    }

    // If no specific dictionary match, clean standard stop words
    if (!matchedTerm) {
      matchedTerm = lower
        .replace(/\b(kg|kilo|kilos|gram|grams|g|liter|litre|l|pack|packet|pc|piece|pieces|nos|bunch)\b/gi, '')
        .replace(/\b(1|2|3|4|5|6|7|8|9|10|one|two|three|four|five|six|seven|eight|nine|ten)\b/gi, '')
        .replace(/\b(ek|do|teen|chaar|paanch|oru|rendu|moonu|naalu|aindhu|half|quarter|aadha|pav|arai|kaal)\b/gi, '')
        .replace(/\b(please|add|give|kilo|lo|do|ta|tha|chahiye|venum|kudu)\b/gi, '')
        .trim();
    }

    return { keyword: matchedTerm || lower, parsedQty, unit };
  };

  // Instant fuzzy match suggestions from catalog based on input text
  const matchedSuggestions = useMemo((): MatchedOption[] => {
    const raw = inputText.trim();
    if (!raw) {
      // Default initial top popular items
      return products.slice(0, 6).map((p) => {
        const v = p.variants?.[0];
        return {
          product: p,
          variantId: v?.id,
          matchedName: p.name,
          price: v?.price || p.price,
          unit: p.unit || 'kg',
          quantity: 1,
          confidence: 0.8,
          matchReason: 'Popular item',
        };
      });
    }

    const { keyword, parsedQty } = parseQuery(raw);
    const results: MatchedOption[] = [];

    products.forEach((p) => {
      const pName = p.name.toLowerCase();
      const pCat = (p.category || '').toLowerCase();
      const pBarcode = (p.barcode || '').toLowerCase();
      const pAlias = (p.searchKeywords || []).join(' ').toLowerCase();

      let score = 0;
      let reason = '';

      if (keyword && pName === keyword) {
        score = 100;
        reason = 'Exact name match';
      } else if (keyword && pName.includes(keyword)) {
        score = 85;
        reason = 'Name match';
      } else if (pName.includes(raw.toLowerCase())) {
        score = 80;
        reason = 'Direct match';
      } else if (keyword && pAlias.includes(keyword)) {
        score = 75;
        reason = 'Alias match';
      } else if (keyword && pCat.includes(keyword)) {
        score = 60;
        reason = 'Category match';
      } else if (raw.length >= 3 && pBarcode.includes(raw.toLowerCase())) {
        score = 90;
        reason = 'Barcode partial match';
      } else {
        // Multi-word fuzzy match
        const words = keyword.split(/\s+/).filter(Boolean);
        const matchedWords = words.filter((w) => pName.includes(w) || pAlias.includes(w));
        if (matchedWords.length > 0) {
          score = 50 + matchedWords.length * 15;
          reason = 'Fuzzy word match';
        }
      }

      if (score > 0) {
        const variant = p.variants?.[0];
        results.push({
          product: p,
          variantId: variant?.id,
          matchedName: p.name,
          price: variant?.price || p.price,
          unit: p.unit || 'kg',
          quantity: parsedQty,
          confidence: Math.min(score / 100, 1.0),
          matchReason: reason,
        });
      }
    });

    results.sort((a, b) => b.confidence - a.confidence);

    if (results.length === 0) {
      return products.slice(0, 4).map((p) => ({
        product: p,
        matchedName: p.name,
        price: p.price,
        unit: p.unit || 'kg',
        quantity: parsedQty || 1,
        confidence: 0.4,
        matchReason: 'Closest store product',
      }));
    }

    return results.slice(0, 6);
  }, [inputText, products]);

  // Quick Gemini audio transcription convert
  const convertVoiceToText = useCallback(async () => {
    if (!audioRecorderRef.current) {
      stopAudio();
      return;
    }

    setIsTranscribing(true);
    setStatusMessage('Transcribing voice audio with AI...');

    try {
      const wavBlob = await audioRecorderRef.current.stop();
      stopAudio();

      if (!wavBlob || wavBlob.size < 500) {
        setStatusMessage('No clear speech detected. Please speak closer to the mic or type.');
        setIsTranscribing(false);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = (reader.result as string)?.split(',')[1];
        if (!base64Data) {
          setIsTranscribing(false);
          return;
        }

        try {
          const res = await fetch('/api/ai/transcribe-voice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64Data,
              mimeType: 'audio/wav',
            }),
          });
          const data = res.ok ? await res.json() : null;

          if (data?.success && data?.text) {
            const englishText = data.text.trim();
            setInputText(englishText);
            setStatusMessage(`Voice text: "${englishText}"`);
            playBarcodeBeep();
          } else if (isMountedRef.current) {
            setStatusMessage('Voice converted. Select from nearest products below.');
          }
        } catch (err: any) {
          console.warn('Transcription API error:', err);
          if (isMountedRef.current) {
            setStatusMessage('Could not convert audio. You can type directly in the box.');
          }
        } finally {
          if (isMountedRef.current) {
            setIsTranscribing(false);
          }
        }
      };
      reader.readAsDataURL(wavBlob);
    } catch (err) {
      setIsTranscribing(false);
    }
  }, [stopAudio]);

  // Start instant voice recording & speech recognition
  const handleToggleVoice = useCallback(async () => {
    // If already recording, stop and immediately convert voice to English text
    if (isRecording) {
      convertVoiceToText();
      return;
    }

    // Clean up any stale handles
    stopAudio();
    setIsRecording(true);
    setRecordingSeconds(0);
    setStatusMessage('🎤 Listening... Speak item name (e.g. Tomato 2kg, Tamatar, Onion 1kg)');

    // Start timer counter
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    timerIntervalRef.current = setInterval(() => {
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);

    // 1. Browser Web Speech Recognition (Real-time live text typing)
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRec) {
      try {
        const rec = new SpeechRec();
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = voiceConfig.language === 'auto' ? 'en-IN' : voiceConfig.language;

        rec.onresult = (evt: any) => {
          if (!isMountedRef.current) return;
          let currentText = '';
          for (let i = 0; i < evt.results.length; i++) {
            currentText += evt.results[i][0]?.transcript || '';
          }
          if (currentText.trim()) {
            const trimmed = currentText.trim();
            setInputText(trimmed);
            setStatusMessage(`Live Voice: "${trimmed}"`);
          }
        };

        rec.onerror = (e: any) => {
          console.warn('SpeechRecognition info:', e?.error);
        };

        speechRecognitionRef.current = rec;
        rec.start();
      } catch (e) {
        console.warn('SpeechRec start failed:', e);
      }
    }

    // 2. Pure PCM Microphone Capture (Direct Audio Streaming & Volume Meter)
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setStatusMessage('Microphone not supported in browser. Please type directly below.');
        setIsRecording(false);
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });

      mediaStreamRef.current = stream;

      const recorder = new PureAudioRecorder();
      audioRecorderRef.current = recorder;
      await recorder.start(stream, (vol) => {
        if (isMountedRef.current) {
          setAudioVolume(vol);
        }
      });
    } catch (err: any) {
      console.warn('Microphone permission denied:', err);
      setIsRecording(false);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      setStatusMessage('Microphone access blocked. Click the lock icon in your URL bar to allow, or type directly.');
    }
  }, [isRecording, convertVoiceToText, stopAudio, voiceConfig.language]);

  // Adjust quantity for a specific product option
  const handleQtyChange = (productId: string, delta: number, defaultQty: number) => {
    playKeypadClick();
    setSelectedQuantities((prev) => {
      const current = prev[productId] !== undefined ? prev[productId] : defaultQty;
      const updated = Math.max(0.25, Number((current + delta).toFixed(2)));
      return { ...prev, [productId]: updated };
    });
  };

  // Select an option and add to bill
  const handleSelectOption = (opt: MatchedOption) => {
    const qty = selectedQuantities[opt.product.id] !== undefined ? selectedQuantities[opt.product.id] : opt.quantity;
    const variantId = opt.variantId || opt.product.variants?.[0]?.id;

    addToCart(opt.product, variantId, qty);
    playBarcodeBeep();
    playSuccessChime();

    stopAudio();
    setIsAIVoiceModalOpen(false);
  };

  // Enter key selects the top match
  const handleKeyDown = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (matchedSuggestions.length > 0) {
        handleSelectOption(matchedSuggestions[0]);
      }
    }
  };

  // On open, reset and auto-start listening
  useEffect(() => {
    isMountedRef.current = true;
    if (isAIVoiceModalOpen) {
      setInputText('');
      setSelectedQuantities({});
      handleToggleVoice();
      setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
    } else {
      stopAudio();
    }

    return () => {
      isMountedRef.current = false;
      stopAudio();
    };
  }, [isAIVoiceModalOpen]);

  if (!isAIVoiceModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 md:p-6 select-none animate-in fade-in">
      <div className="bg-white w-full max-w-2xl max-h-[92vh] rounded-xl shadow-2xl flex flex-col overflow-hidden border border-[#D4D4D8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-purple-800 to-indigo-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center border border-white/20">
              <span className="material-symbols-outlined text-[22px] text-purple-200">mic</span>
            </div>
            <div>
              <h2 className="font-bold text-base md:text-lg flex items-center gap-2">
                <span>AI Voice Assisted Item Addition</span>
                <span className="text-[10px] bg-purple-300 text-purple-950 font-black px-2 py-0.5 rounded tracking-wider uppercase">
                  Multilingual
                </span>
              </h2>
              <p className="text-xs text-purple-200">
                Speak item name in English, Hindi, Tamil, Telugu or Marathi (e.g. "Tamatar 2kg", "Onion 1kg")
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopAudio();
              setIsAIVoiceModalOpen(false);
            }}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto space-y-4">
          {/* Audio Visualizer & Mic Controls Banner */}
          <div
            className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row items-center justify-between gap-4 ${
              isRecording
                ? 'bg-purple-50 border-purple-300 shadow-inner'
                : isTranscribing
                ? 'bg-amber-50 border-amber-300'
                : 'bg-gray-50 border-gray-200'
            }`}
          >
            <div className="flex items-center gap-3 w-full sm:w-auto">
              {/* Mic Icon Pulse Indicator */}
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 transition-transform ${
                  isRecording
                    ? 'bg-purple-700 text-white animate-pulse scale-105 shadow-md shadow-purple-300'
                    : 'bg-gray-200 text-gray-700'
                }`}
              >
                <span className="material-symbols-outlined text-[26px]">
                  {isRecording ? 'mic' : isTranscribing ? 'sync' : 'mic_none'}
                </span>
              </div>

              {/* Status Text & Audio Volume Bars */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-gray-900">
                    {isRecording ? 'Listening Live...' : isTranscribing ? 'Processing Speech...' : 'Voice Ready'}
                  </span>
                  {isRecording && (
                    <span className="text-[11px] font-mono bg-purple-200 text-purple-900 px-1.5 py-0.2 rounded font-bold">
                      {recordingSeconds}s
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-600 truncate">{statusMessage}</p>

                {/* Live Mic Volume Level Bars */}
                {isRecording && (
                  <div className="flex items-center gap-1 mt-1.5">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((bar) => {
                      const active = audioVolume * 8 >= bar;
                      return (
                        <div
                          key={bar}
                          className={`h-2.5 w-3 rounded-xs transition-all duration-75 ${
                            active ? 'bg-purple-600 scale-y-110' : 'bg-gray-200'
                          }`}
                        />
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Mic Toggle Button */}
            <button
              type="button"
              onClick={handleToggleVoice}
              className={`w-full sm:w-auto px-5 py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs ${
                isRecording
                  ? 'bg-rose-600 hover:bg-rose-700 text-white'
                  : 'bg-purple-800 hover:bg-purple-900 text-white'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">
                {isRecording ? 'stop' : 'mic'}
              </span>
              <span>{isRecording ? 'Done Speaking' : 'Start Voice'}</span>
            </button>
          </div>

          {/* Spoken Text / Manual Edit Box */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider">
              Spoken Query or Item Description:
            </label>
            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Spoken words will type here (or type e.g. Tomato 2kg, Tamatar, Onion 1kg)..."
                className="w-full pl-3 pr-10 py-3 bg-white border-2 border-purple-300 focus:border-purple-600 rounded-lg text-sm font-semibold text-gray-900 outline-none shadow-xs"
              />
              {inputText && (
                <button
                  type="button"
                  onClick={() => {
                    setInputText('');
                    inputRef.current?.focus();
                  }}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">clear</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Clickable Suggestions */}
          <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
            <span className="text-[11px] text-gray-400 font-bold uppercase tracking-wider">Quick:</span>
            {[
              'Tomato 2kg',
              'Onion 1kg',
              'Potato 3kg',
              'Milk 1L',
              'Tamatar 2kg',
              'Green Chilli 250g',
              'Thakkali 1kg',
              'Paneer 500g',
            ].map((chip, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputText(chip);
                  setStatusMessage(`Set to: "${chip}"`);
                  playKeypadClick();
                }}
                className="px-2.5 py-1 bg-gray-100 hover:bg-purple-100 text-gray-800 hover:text-purple-900 rounded-full text-xs font-semibold border border-gray-200 hover:border-purple-300 transition-colors cursor-pointer active:scale-95 shadow-2xs"
              >
                🗣️ "{chip}"
              </button>
            ))}
          </div>

          {/* Nearest Matching Products List */}
          <div className="space-y-2 pt-2 border-t border-gray-200">
            <div className="flex items-center justify-between text-xs font-bold text-gray-700 uppercase tracking-wide">
              <span>Nearest Matching Store Products:</span>
              <span className="text-[11px] text-purple-700 font-bold lowercase">
                {matchedSuggestions.length} items found
              </span>
            </div>

            <div className="space-y-2 max-h-[36vh] overflow-y-auto pr-1">
              {matchedSuggestions.map((opt, idx) => {
                const qty = selectedQuantities[opt.product.id] !== undefined ? selectedQuantities[opt.product.id] : opt.quantity;
                const itemPrice = opt.price;
                const totalOptionPrice = (itemPrice * qty).toFixed(2);
                const isTopMatch = idx === 0;

                return (
                  <div
                    key={opt.product.id}
                    className={`p-3 rounded-xl transition-all flex items-center justify-between gap-3 group border-2 ${
                      isTopMatch
                        ? 'bg-purple-50/70 border-purple-500 shadow-xs'
                        : 'bg-white hover:border-purple-400 border-gray-200 shadow-2xs'
                    }`}
                  >
                    {/* Item Details */}
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center shrink-0">
                        <span className="material-symbols-outlined text-[22px]">eco</span>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-gray-900 truncate">
                            {opt.matchedName}
                          </span>
                          {isTopMatch && (
                            <span className="px-1.5 py-0.2 bg-purple-700 text-white text-[9px] font-extrabold rounded uppercase tracking-wider">
                              Top Match
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-gray-600 flex items-center gap-2">
                          <span>
                            Rs. {itemPrice} / {opt.unit}
                          </span>
                          {opt.matchReason && (
                            <span className="text-[10px] text-purple-700 bg-purple-100/80 px-1.5 py-0.2 rounded font-medium">
                              {opt.matchReason}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Quantity Selector & Add Button */}
                    <div className="flex items-center gap-3 shrink-0">
                      {/* Quantity Stepper */}
                      <div className="flex items-center bg-white border border-gray-300 rounded-lg overflow-hidden shadow-2xs">
                        <button
                          type="button"
                          onClick={() => handleQtyChange(opt.product.id, -0.5, opt.quantity)}
                          className="w-8 h-8 flex items-center justify-center text-gray-700 hover:bg-gray-100 font-bold active:bg-gray-200"
                        >
                          -
                        </button>
                        <span className="w-14 text-center font-bold text-xs font-mono text-gray-900">
                          {qty} {opt.unit}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleQtyChange(opt.product.id, 0.5, opt.quantity)}
                          className="w-8 h-8 flex items-center justify-center text-gray-700 hover:bg-gray-100 font-bold active:bg-gray-200"
                        >
                          +
                        </button>
                      </div>

                      {/* Add Button */}
                      <button
                        type="button"
                        onClick={() => handleSelectOption(opt)}
                        className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer active:scale-95"
                      >
                        <span className="material-symbols-outlined text-[16px]">add_shopping_cart</span>
                        <span>Add Rs. {totalOptionPrice}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <span className="material-symbols-outlined text-[16px] text-gray-400">keyboard</span>
            <span>Press Enter to add the Top Match directly to bill</span>
          </div>
          <button
            type="button"
            onClick={() => {
              stopAudio();
              setIsAIVoiceModalOpen(false);
            }}
            className="px-4 py-1.5 bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 rounded-md font-semibold cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
