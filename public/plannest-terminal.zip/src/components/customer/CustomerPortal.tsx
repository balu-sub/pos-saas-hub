import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Download,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Laptop,
  Terminal,
  Cloud,
  ArrowRight,
  Copy,
  Check,
  ExternalLink,
  CreditCard,
  Building,
  Monitor,
  AlertCircle,
  HelpCircle,
  MessageSquare,
  Sparkles,
  RefreshCw,
  LogOut,
  ChevronRight,
  HardDrive,
  ShoppingCart,
} from 'lucide-react';

export const CustomerPortal: React.FC = () => {
  const { currentUser, activeLicense, setCurrentView, logout, refreshLicense } = useAuth();

  const [selectedPlan, setSelectedPlan] = useState<'plan_a' | 'plan_b' | 'plan_c'>('plan_a');
  const [copiedToken, setCopiedToken] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [upgradeSuccess, setUpgradeSuccess] = useState<string | null>(null);

  // Bundle Info for Plan A
  const [bundleInfo, setBundleInfo] = useState<any>(null);

  // Feedback form state
  const [feedbackRating, setFeedbackRating] = useState(5);
  const [feedbackCategory, setFeedbackCategory] = useState('Installation');
  const [feedbackMsg, setFeedbackMsg] = useState('');
  const [feedbackSent, setFeedbackSent] = useState(false);

  useEffect(() => {
    fetch('/api/saas/plan-a/bundle-info')
      .then((res) => res.json())
      .then((data) => setBundleInfo(data))
      .catch(() => {});
  }, []);

  // Calculate Trial Countdown
  const calculateRemaining = () => {
    if (!currentUser?.trialEndsAt) return { hours: 72, expired: false };
    const diff = new Date(currentUser.trialEndsAt).getTime() - Date.now();
    if (diff <= 0) return { hours: 0, expired: true };
    const hours = Math.floor(diff / (1000 * 60 * 60));
    return { hours, expired: false };
  };

  const trialInfo = calculateRemaining();

  const handleCopy = (text: string, type: 'token' | 'key') => {
    navigator.clipboard.writeText(text);
    if (type === 'token') {
      setCopiedToken(true);
      setTimeout(() => setCopiedToken(false), 2000);
    } else {
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    }
  };

  const handleSimulatePayment = async () => {
    if (!currentUser) return;
    setIsUpgrading(true);
    setUpgradeSuccess(null);
    try {
      const res = await fetch('/api/saas/license/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          licenseKey: activeLicense?.licenseKey,
          planTier: selectedPlan === 'plan_c' ? 'enterprise' : 'pro',
        }),
      });
      const data = await res.json();
      if (data.success) {
        setUpgradeSuccess(data.message);
        await refreshLicense();
      }
    } catch (err: any) {
      alert('Upgrade error: ' + err.message);
    } finally {
      setIsUpgrading(false);
    }
  };

  const handleSendFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackMsg.trim()) return;
    try {
      await fetch('/api/saas/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          purchaserEmail: currentUser?.email,
          businessName: currentUser?.businessName,
          rating: feedbackRating,
          category: feedbackCategory,
          message: feedbackMsg,
          priority: 'normal',
        }),
      });
      setFeedbackSent(true);
      setFeedbackMsg('');
      setTimeout(() => setFeedbackSent(false), 4000);
    } catch {
      // ignore
    }
  };

  const tokenParam = activeLicense?.token || '';
  const keyParam = activeLicense?.licenseKey || '';
  const storeParam = encodeURIComponent(currentUser?.businessName || 'Retail Store');

  const downloadUrlBat = `/api/saas/plan-a/installer-script?os=bat&token=${tokenParam}&key=${keyParam}&store=${storeParam}`;
  const downloadUrlPs1 = `/api/saas/plan-a/installer-script?os=ps1&token=${tokenParam}&key=${keyParam}&store=${storeParam}`;
  const downloadUrlSh = `/api/saas/plan-a/installer-script?os=sh&token=${tokenParam}&key=${keyParam}&store=${storeParam}`;
  const downloadUrlShortcut = `/api/saas/plan-a/installer-script?os=url&token=${tokenParam}&key=${keyParam}&store=${storeParam}`;

  return (
    <div className="min-h-screen bg-[#FBF8FC] text-gray-900 flex flex-col selection:bg-[#00478c] selection:text-white">
      {/* Top Navbar */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-slate-200/70 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center cursor-pointer" onClick={() => setCurrentView('home')}>
            <img
              src="/Logo.png"
              alt="Plannest POS"
              className="h-14 md:h-16 w-auto max-w-[240px] object-contain"
              loading="eager"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentView('pos_terminal')}
              className="px-3.5 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm transition-all flex items-center gap-1.5"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>Open Billing Terminal</span>
            </button>

            <button
              onClick={() => setCurrentView('home')}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-[#00478c] hover:bg-slate-100 rounded-lg transition-colors"
            >
              Home
            </button>

            <button
              onClick={logout}
              className="p-2 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Trial Status / Welcome Hero Banner - Cadence Light Style */}
        <div className="bg-white text-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-200/80 shadow-xs relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2.5">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-semibold tracking-wide uppercase border border-slate-200">
                  Store Deployment Cockpit
                </span>
                <span className="text-emerald-700 text-xs font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Account Active
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
                Welcome, {currentUser?.businessName || 'Retail Store Owner'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 max-w-xl">
                Your high-throughput retail POS terminal is ready for immediate deployment. Pick your preferred
                architecture below, download the 1-click installer, and start billing!
              </p>
            </div>

            {/* Trial Countdown Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-center sm:min-w-[240px] shrink-0">
              {currentUser?.isPaid ? (
                <div>
                  <span className="text-xs text-emerald-700 font-bold uppercase tracking-wider block">
                    License Status
                  </span>
                  <div className="text-xl font-extrabold text-slate-900 mt-1">Full 1-Year License</div>
                  <p className="text-[11px] text-slate-500 mt-1">All features unlocked with priority support</p>
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-center gap-1.5 text-amber-700 text-xs font-bold uppercase">
                    <Clock className="w-3.5 h-3.5 text-amber-600" />
                    <span>3-Day Free Trial</span>
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                    {trialInfo.hours > 0 ? `${trialInfo.hours} Hours` : 'Expired'}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    {trialInfo.expired ? 'Trial ended. Upgrade below.' : 'Full features unlocked with no card required.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Upgrade Success Notification */}
        {upgradeSuccess && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{upgradeSuccess}</span>
          </div>
        )}

        {/* STEP 1: CHOOSE DEPLOYMENT PLAN */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
          <div>
            <span className="text-xs font-bold text-[#00478c] tracking-widest uppercase">Step 1: Deployment Choice</span>
            <h2 className="text-xl font-bold text-gray-900 mt-1">Select Your Store Deployment Architecture</h2>
            <p className="text-xs text-gray-500 mt-1">
              Choose the model matching your physical store layout and counter requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Plan A Option */}
            <div
              onClick={() => setSelectedPlan('plan_a')}
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                selectedPlan === 'plan_a'
                  ? 'border-[#00478c] bg-blue-50/40 shadow-sm'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 bg-blue-100/70 text-[#00478c] rounded-lg">
                    <Laptop className="w-5 h-5" />
                  </div>
                  {selectedPlan === 'plan_a' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-[#00478c] text-white rounded-full">
                      SELECTED
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-gray-900">Plan A: Local On-Premises</h3>
                <p className="text-xs text-gray-500 mt-1">
                  1-Click Windows/Linux installer. Offline-first embedded SQLite with pre-bundled catalog images.
                </p>
                <div className="mt-4 pt-3 border-t border-gray-100 text-[11px] space-y-1 text-gray-600">
                  <p>• Zero internet dependence</p>
                  <p>• Instant .bat / .ps1 desktop shortcut</p>
                  <p>• Hardware-bound license file</p>
                </div>
              </div>
              <div className="mt-4 text-xs font-bold text-[#00478c]">₹999 / mo / counter</div>
            </div>

            {/* Plan B Option */}
            <div
              onClick={() => setSelectedPlan('plan_b')}
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                selectedPlan === 'plan_b'
                  ? 'border-[#00478c] bg-blue-50/40 shadow-sm'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 bg-emerald-100/70 text-emerald-700 rounded-lg">
                    <Terminal className="w-5 h-5" />
                  </div>
                  {selectedPlan === 'plan_b' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-600 text-white rounded-full">
                      SELECTED
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-gray-900">Plan B: Self-Hosted VPS</h3>
                <p className="text-xs text-gray-500 mt-1">
                  Deploy to your own DigitalOcean, Hetzner, or AWS Linux server via automated cloud-init.sh & Docker.
                </p>
                <div className="mt-4 pt-3 border-t border-gray-100 text-[11px] space-y-1 text-gray-600">
                  <p>• Automated Docker & Caddy SSL</p>
                  <p>• Custom domain routing</p>
                  <p>• Nightly automated DB backups</p>
                </div>
              </div>
              <div className="mt-4 text-xs font-bold text-gray-900">Self-Hosted / BYO Server</div>
            </div>

            {/* Plan C Option */}
            <div
              onClick={() => setSelectedPlan('plan_c')}
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                selectedPlan === 'plan_c'
                  ? 'border-[#00478c] bg-blue-50/40 shadow-sm'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 bg-purple-100/70 text-purple-700 rounded-lg">
                    <Cloud className="w-5 h-5" />
                  </div>
                  {selectedPlan === 'plan_c' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-purple-600 text-white rounded-full">
                      SELECTED
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-gray-900">Plan C: Managed Cloud</h3>
                <p className="text-xs text-gray-500 mt-1">
                  Multi-counter supermarket cloud cluster with isolated Cloud SQL database and pre-configured staff
                  PINs.
                </p>
                <div className="mt-4 pt-3 border-t border-gray-100 text-[11px] space-y-1 text-gray-600">
                  <p>• Dedicated static IP & subdomain</p>
                  <p>• Cross-counter live stock locking</p>
                  <p>• Pre-configured PINs (1234, 1111, 2222, 9999)</p>
                </div>
              </div>
              <div className="mt-4 text-xs font-bold text-purple-700">₹2,499 / mo / store</div>
            </div>
          </div>
        </div>

        {/* STEP 2: 1-CLICK DOWNLOAD & INSTALLATION (FOR PLAN A) */}
        {selectedPlan === 'plan_a' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-[#00478c] tracking-widest uppercase">
                  Step 2: Install Terminal
                </span>
                <h2 className="text-xl font-bold text-gray-900 mt-1">1-Click Native Desktop Installers</h2>
                <p className="text-xs text-gray-500 mt-1">
                  Click to download. No administrative permissions needed. The installer automatically generates desktop
                  shortcuts and starts in kiosk mode.
                </p>
              </div>

              {bundleInfo && (
                <div className="text-right text-xs text-gray-500 hidden md:block">
                  <p>
                    Bundle: <strong>{bundleInfo.bundleVersion}</strong>
                  </p>
                  <p>
                    {bundleInfo.productsCount} SKUs • {bundleInfo.imageCount} Pre-cached Images
                  </p>
                </div>
              )}
            </div>

            {/* Installer Action Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Windows 1-Click .bat */}
              <a
                href={downloadUrlBat}
                download="install-plannestpos-local.bat"
                className="p-5 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-100/60 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="p-2 rounded-lg bg-blue-600 text-white">
                      <Download className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-200/80 text-blue-900 rounded">
                      RECOMMENDED
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 group-hover:text-blue-700">Windows 1-Click .bat</h4>
                  <p className="text-[11px] text-gray-600 mt-1">
                    Zero-permission batch installer for Windows 10 & 11. Generates Desktop & Start Menu kiosk shortcut.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-blue-100 flex items-center justify-between text-xs font-bold text-blue-700">
                  <span>Download .bat</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </a>

              {/* Windows PowerShell .ps1 */}
              <a
                href={downloadUrlPs1}
                download="install-plannestpos-local.ps1"
                className="p-5 rounded-xl border border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="p-2 rounded-lg bg-gray-800 text-white">
                      <Terminal className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 bg-gray-100 text-gray-700 rounded">
                      HW-LOCKED
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-gray-900">PowerShell .ps1</h4>
                  <p className="text-[11px] text-gray-600 mt-1">
                    Auto-binds to motherboard UUID (`Win32_ComputerSystemProduct`). Secure hardware locked.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-gray-700">
                  <span>Download .ps1</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </a>

              {/* Linux / Ubuntu .sh */}
              <a
                href={downloadUrlSh}
                download="install-plannestpos-linux.sh"
                className="p-5 rounded-xl border border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="p-2 rounded-lg bg-purple-700 text-white">
                      <HardDrive className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 bg-purple-100 text-purple-800 rounded">
                      LINUX / UBUNTU
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-gray-900">Linux Bash .sh</h4>
                  <p className="text-[11px] text-gray-600 mt-1">
                    Installs desktop launcher entry to `~/Desktop/plannest-pos.desktop` with RS232 permissions.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-purple-700">
                  <span>Download .sh</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </a>

              {/* Direct Desktop .url */}
              <a
                href={downloadUrlShortcut}
                download="Plannest POS.url"
                className="p-5 rounded-xl border border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="p-2 rounded-lg bg-emerald-600 text-white">
                      <Monitor className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                      INSTANT
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-gray-900">Direct Desktop .url</h4>
                  <p className="text-[11px] text-gray-600 mt-1">
                    Windows internet shortcut with embedded license token. Drag-and-drop to desktop.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-emerald-700">
                  <span>Download .url</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </a>
            </div>

            {/* 3-Step Simple Setup Instructions */}
            <div className="p-5 rounded-xl bg-gray-50 border border-gray-200">
              <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-3">
                3-Step Terminal Launch Guide
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-gray-600">
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Download the .bat</p>
                    <p className="text-[11px] mt-0.5">Click the Windows 1-Click .bat installer button above.</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Double-Click to Run</p>
                    <p className="text-[11px] mt-0.5">Run the batch file. It creates your Desktop & Start Menu icons.</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Start Billing Instantly</p>
                    <p className="text-[11px] mt-0.5">Edge/Chrome opens fullscreen. Barcode scanner & scale auto-sync.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2 ALTERNATIVE: PLAN B CLOUD-INIT */}
        {selectedPlan === 'plan_b' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
            <div>
              <span className="text-xs font-bold text-emerald-700 tracking-widest uppercase">
                Step 2: VPS cloud-init
              </span>
              <h2 className="text-xl font-bold text-gray-900 mt-1">Autonomous 45-Second VPS Bootstrapper</h2>
              <p className="text-xs text-gray-500 mt-1">
                Paste this script into the "User Data / Cloud-Init" section of any Ubuntu 22.04 or 24.04 VPS.
              </p>
            </div>

            <div className="p-4 bg-gray-900 text-gray-200 rounded-xl font-mono text-xs overflow-x-auto relative">
              <pre>{`#!/bin/bash
# Plannest POS - VPS Cloud-Init Script for ${currentUser?.businessName || 'My Store'}
curl -sSL https://raw.githubusercontent.com/plannest/pos/main/deploy/vps-init.sh | \\
  STORE_NAME="${currentUser?.businessName || 'Retail Store'}" \\
  LICENSE_KEY="${activeLicense?.licenseKey || 'PLANNEST-TRIAL'}" \\
  bash`}</pre>
            </div>

            <p className="text-xs text-gray-600">
              Includes automated Docker Engine setup, Caddy reverse proxy with Let's Encrypt SSL, and SQLite database
              persistence.
            </p>
          </div>
        )}

        {/* STEP 2 ALTERNATIVE: PLAN C MANAGED CLOUD */}
        {selectedPlan === 'plan_c' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
            <div>
              <span className="text-xs font-bold text-purple-700 tracking-widest uppercase">
                Step 2: Managed Cloud Cluster
              </span>
              <h2 className="text-xl font-bold text-gray-900 mt-1">Dedicated Multi-Counter Supermarket Cluster</h2>
              <p className="text-xs text-gray-500 mt-1">
                Your dedicated GCP Cloud Run and isolated Cloud SQL database pool is ready for configuration.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-purple-50 border border-purple-200">
                <h4 className="text-xs font-bold text-purple-900">Pre-configured Staff PINs</h4>
                <div className="mt-3 space-y-2 text-xs text-purple-950">
                  <div className="flex justify-between">
                    <span>Store Manager (Admin):</span>
                    <strong className="font-mono">1234</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Counter 1 Cashier:</span>
                    <strong className="font-mono">1111</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Counter 2 Cashier:</span>
                    <strong className="font-mono">2222</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Shift Auditor / Supervisor:</span>
                    <strong className="font-mono">9999</strong>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-gray-900">Dedicated Tenant Subdomain</h4>
                  <p className="text-xs text-gray-600 mt-1">
                    https://pos-
                    {(currentUser?.businessName || 'store').toLowerCase().replace(/[^a-z0-9]/g, '')}
                    .plannestpos.cloud
                  </p>
                </div>
                <div className="mt-4 w-full py-2 px-3 bg-purple-50 border border-purple-200 text-purple-900 text-xs font-semibold rounded-lg flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    Cloud Gateway Active
                  </span>
                  <span className="text-[10px] text-purple-600 font-mono">TLS 1.3 Sync</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: LICENSE KEY & CRYPTOGRAPHIC TOKEN DETAILS */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-[#00478c] tracking-widest uppercase">
                Step 3: Cryptographic License Token
              </span>
              <h2 className="text-xl font-bold text-gray-900 mt-1">Machine License & Authentication Token</h2>
              <p className="text-xs text-gray-500 mt-1">
                This signed HMAC-SHA256 token authorizes your physical register hardware to operate 100% offline.
              </p>
            </div>

            {!currentUser?.isPaid && (
              <button
                onClick={handleSimulatePayment}
                disabled={isUpgrading}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition-all flex items-center gap-2 self-start sm:self-auto disabled:opacity-50"
              >
                <CreditCard className="w-4 h-4" />
                <span>{isUpgrading ? 'Activating License...' : 'Pay & Upgrade to 1-Year License'}</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* License Key Box */}
            <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                License Key
              </span>
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-gray-900">
                  {activeLicense?.licenseKey || 'PLANNEST-TRIAL-KEY'}
                </span>
                <button
                  onClick={() => handleCopy(activeLicense?.licenseKey || '', 'key')}
                  className="p-1.5 text-gray-500 hover:text-gray-900 rounded hover:bg-gray-200 transition-colors"
                  title="Copy Key"
                >
                  {copiedKey ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* License Expiry Box */}
            <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                License Expiration
              </span>
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-gray-900">
                  {activeLicense?.expiresAt ? new Date(activeLicense.expiresAt).toLocaleDateString() : 'Active Trial'}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                  {currentUser?.isPaid ? 'PAID PRO' : 'TRIAL ACTIVE'}
                </span>
              </div>
            </div>
          </div>

          {/* Token String Preview */}
          <div className="p-4 rounded-xl bg-gray-900 text-gray-300 font-mono text-[11px] relative">
            <div className="flex items-center justify-between pb-2 border-b border-gray-800 mb-2">
              <span className="text-gray-400 text-[10px]">HMAC-SHA256 ASYMMETRIC TOKEN PAYLOAD</span>
              <button
                onClick={() => handleCopy(activeLicense?.token || '', 'token')}
                className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                {copiedToken ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedToken ? 'Copied!' : 'Copy Token'}</span>
              </button>
            </div>
            <div className="truncate text-gray-400">
              {activeLicense?.token || 'eyJsaWNlbnNlX2tleSI6IlBMQU5ORVNULVRSSUFMIiwiZXhwaXJlc19hdCI6IjIwMjYtMDktMDRU...'}
            </div>
          </div>
        </div>

        {/* STEP 4: PURCHASER FEEDBACK & HARDWARE INTEGRATION SUPPORT */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
          <div>
            <span className="text-xs font-bold text-[#00478c] tracking-widest uppercase">
              Support & Hardware Inquiries
            </span>
            <h2 className="text-xl font-bold text-gray-900 mt-1">Purchaser Support & Hardware Compatibility Ticket</h2>
            <p className="text-xs text-gray-500 mt-1">
              Need help configuring your Essae scale, Honeywell scanner, or 80mm thermal printer? Send a note directly
              to Plannest engineering.
            </p>
          </div>

          {feedbackSent && (
            <div className="p-3 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg">
              Thank you! Your ticket has been dispatched to the Plannest technical team.
            </div>
          )}

          <form onSubmit={handleSendFeedback} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Inquiry Category</label>
                <select
                  value={feedbackCategory}
                  onChange={(e) => setFeedbackCategory(e.target.value)}
                  className="w-full text-xs p-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00478c]"
                >
                  <option value="Weighing Scale">Weighing Scale (RS232 / WebSerial)</option>
                  <option value="Thermal Printer">Thermal Printer (ESC/POS 80mm)</option>
                  <option value="Barcode Scanner">Barcode Scanner (USB HID)</option>
                  <option value="Installation">Installation & Batch Script</option>
                  <option value="Feature Request">Feature Request / Customization</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Overall Satisfaction Rating</label>
                <div className="flex items-center gap-2 pt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setFeedbackRating(star)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                        feedbackRating >= star ? 'bg-amber-400 text-amber-950 shadow-sm' : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      ★ {star}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Message / Hardware Model Details</label>
              <textarea
                required
                rows={3}
                value={feedbackMsg}
                onChange={(e) => setFeedbackMsg(e.target.value)}
                placeholder="e.g. Connecting Essae DS-852 scale via RS232-to-USB converter. Baud rate is 9600."
                className="w-full text-xs p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-gray-900 hover:bg-black text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Submit Ticket to Support</span>
            </button>
          </form>
        </div>
      </main>

      {/* Minimalist Footer */}
      <footer className="bg-white border-t border-slate-200 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center text-xs text-slate-500">
          <span>© 2026 Plannest Systems. All rights reserved.</span>
        </div>
      </footer>
    </div>
  );
};
