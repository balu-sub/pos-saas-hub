import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { useLanguage } from '../../context/LanguageContext';
import { playBarcodeBeep, playKeypadClick, playSuccessChime } from '../../utils/audio';

export const KioskPaymentModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    totalDue,
    cart,
    products,
    itemCount,
    addPaymentSplit,
    completeTransaction,
    outletProfile,
  } = usePOS();

  const { getItemName } = useLanguage();

  const [paymentMode, setPaymentMode] = useState<'upi' | 'card' | 'counter'>('upi');
  const [simulationStep, setSimulationStep] = useState<'idle' | 'authorizing' | 'success'>('idle');
  const [countdownSeconds, setCountdownSeconds] = useState(300); // 5 minutes QR timer
  const [simulatedTxnId, setSimulatedTxnId] = useState('');

  const currency = outletProfile?.currencySymbol || 'Rs.';

  const formatPrice = (val: number | string | undefined | null): string => {
    if (val === undefined || val === null) return '0.00';
    const num = typeof val === 'number' ? val : Number(val);
    if (isNaN(num)) return '0.00';
    return num.toFixed(2);
  };

  // Countdown for UPI QR expiration
  useEffect(() => {
    if (!isCheckoutOpen) {
      setSimulationStep('idle');
      return;
    }

    setCountdownSeconds(300);
    const interval = setInterval(() => {
      setCountdownSeconds((prev) => (prev > 1 ? prev - 1 : 300));
    }, 1000);

    return () => clearInterval(interval);
  }, [isCheckoutOpen]);

  if (!isCheckoutOpen) return null;

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSimulatePayment = (mode: 'upi' | 'card' | 'counter') => {
    playKeypadClick();
    const txnRef = `KIOSK-${mode.toUpperCase()}-${Date.now().toString().slice(-6)}`;
    setSimulatedTxnId(txnRef);
    setSimulationStep('authorizing');

    // Simulate gateway handshakes
    setTimeout(() => {
      setSimulationStep('success');
      playSuccessChime();

      // Finalize transaction
      setTimeout(async () => {
        addPaymentSplit(
          mode === 'counter' ? 'cash' : mode === 'card' ? 'card' : 'upi',
          totalDue,
          mode === 'counter' ? 'PAY_AT_COUNTER' : txnRef
        );
        await completeTransaction();
        setSimulationStep('idle');
      }, 900);
    }, 1300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 select-none animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm"
        onClick={() => {
          if (simulationStep === 'idle') setIsCheckoutOpen(false);
        }}
      />

      {/* Main Kiosk Payment Modal Window */}
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden flex flex-col max-h-[92vh] z-10">
        {/* Kiosk Header */}
        <div className="bg-gradient-to-r from-[#00366c] via-[#00478c] to-[#005eb7] text-white px-6 py-4 flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <span className="material-symbols-outlined text-[24px] text-amber-300">
                contactless
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-tight">Self-Service Express Checkout</h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-zinc-950 uppercase tracking-wider">
                  Kiosk Mode
                </span>
              </div>
              <p className="text-xs text-blue-100 font-medium">
                Choose your preferred payment method below to complete your order
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={simulationStep !== 'idle'}
            onClick={() => setIsCheckoutOpen(false)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white transition-all cursor-pointer disabled:opacity-50"
            title="Cancel and return to basket"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6 bg-gray-50/60">
          {/* LEFT: Order Tray Summary & Total Payable (5 cols) */}
          <div className="md:col-span-5 flex flex-col gap-4">
            {/* Big Payable Banner */}
            <div className="bg-white rounded-xl p-5 border border-gray-200 shadow-xs flex flex-col items-center justify-center text-center">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Total Amount Due</span>
              <div className="text-3xl sm:text-4xl font-black text-[#00478c] tracking-tight mt-1">
                {currency} {formatPrice(totalDue)}
              </div>
              <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-[#00478c] text-xs font-bold border border-blue-100">
                <span className="material-symbols-outlined text-[14px]">receipt_long</span>
                <span>{itemCount} {itemCount === 1 ? 'Item' : 'Items'} in Order</span>
              </div>
            </div>

            {/* Itemized Order Tray Preview */}
            <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-xs flex-1 flex flex-col min-h-[220px] max-h-[340px]">
              <div className="flex items-center justify-between pb-2 border-b border-gray-200 text-xs font-bold text-gray-700">
                <span>Selected Items</span>
                <span className="text-gray-400 text-[11px] font-medium">Qty / Price</span>
              </div>

              <div className="flex-1 overflow-y-auto divide-y divide-gray-100 py-1 pr-1">
                {(cart || []).map((item) => {
                  const prodObj = (products || []).find((p) => p.id === item.productId);
                  const displayName = prodObj ? getItemName(prodObj) : item.productName;
                  const lineTotal = item.unitPrice * item.quantity - (item.discountAmount || 0);

                  return (
                    <div key={item.id} className="py-2 flex items-center justify-between text-xs">
                      <div className="pr-2 min-w-0">
                        <p className="font-bold text-[#09090B] truncate">{displayName}</p>
                        <p className="text-[11px] text-gray-500">
                          {item.quantity} {item.unit || 'kg'} × {currency} {formatPrice(item.unitPrice)}
                        </p>
                      </div>
                      <span className="font-bold text-[#09090B] shrink-0">
                        {currency} {formatPrice(lineTotal)}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="pt-3 border-t border-gray-200 text-xs text-gray-500 flex items-center justify-between font-medium">
                <span>GST / Taxes:</span>
                <span className="text-gray-700 font-bold">Included in Price</span>
              </div>
            </div>
          </div>

          {/* RIGHT: Payment Method Selector & Interactive Simulation Screen (7 cols) */}
          <div className="md:col-span-7 flex flex-col gap-4">
            {/* Mode Tabs */}
            <div className="grid grid-cols-3 gap-2 p-1.5 bg-gray-200/80 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setPaymentMode('upi');
                }}
                className={`py-2.5 px-2 rounded-lg font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  paymentMode === 'upi'
                    ? 'bg-white text-[#00478c] shadow-sm scale-100'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-white/40'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">qr_code_scanner</span>
                <span>UPI QR Code</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setPaymentMode('card');
                }}
                className={`py-2.5 px-2 rounded-lg font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  paymentMode === 'card'
                    ? 'bg-white text-[#00478c] shadow-sm scale-100'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-white/40'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">credit_card</span>
                <span>Card (Tap/Insert)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setPaymentMode('counter');
                }}
                className={`py-2.5 px-2 rounded-lg font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                  paymentMode === 'counter'
                    ? 'bg-white text-[#00478c] shadow-sm scale-100'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-white/40'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">counter_0</span>
                <span>Pay at Counter</span>
              </button>
            </div>

            {/* Active Payment View Container */}
            <div className="bg-white rounded-xl p-5 border border-gray-200 shadow-xs flex-1 flex flex-col justify-between relative overflow-hidden">
              {/* Simulation Overlay State */}
              {simulationStep !== 'idle' && (
                <div className="absolute inset-0 bg-white/95 backdrop-blur-xs flex flex-col items-center justify-center p-6 z-20 text-center animate-in fade-in">
                  {simulationStep === 'authorizing' && (
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-full border-4 border-[#00478c]/30 border-t-[#00478c] animate-spin" />
                      <div>
                        <h3 className="text-lg font-black text-[#00478c]">Connecting with Payment Gateway</h3>
                        <p className="text-xs text-gray-500 mt-1 font-medium">
                          Simulating secure bank authorisation • Ref: {simulatedTxnId}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                        <span>Awaiting Gateway Callback...</span>
                      </div>
                    </div>
                  )}

                  {simulationStep === 'success' && (
                    <div className="flex flex-col items-center gap-3 animate-in zoom-in-95 duration-200">
                      <div className="w-16 h-16 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg">
                        <span className="material-symbols-outlined text-[36px]">check</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-emerald-700">Payment Approved!</h3>
                        <p className="text-xs text-gray-600 font-medium mt-1">
                          Amount Received: {currency} {formatPrice(totalDue)} • Txn: {simulatedTxnId}
                        </p>
                      </div>
                      <p className="text-xs font-bold text-blue-800 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200 mt-2">
                        Printing Receipt & Order Token...
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* 1. UPI QR Code Mode */}
              {paymentMode === 'upi' && (
                <div className="flex flex-col items-center text-center">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-700">
                    <span className="material-symbols-outlined text-[#00478c] text-[18px]">qr_code_2</span>
                    <span>Scan with Any UPI App</span>
                  </div>

                  {/* Simulated Dynamic QR Code */}
                  <div className="relative my-3 p-3 bg-white border-2 border-[#00478c] rounded-2xl shadow-md flex flex-col items-center">
                    <svg
                      className="w-44 h-44 sm:w-48 sm:h-48 text-zinc-900"
                      viewBox="0 0 100 100"
                      fill="currentColor"
                    >
                      {/* Realistic high-density QR pattern */}
                      <path d="M5 5h30v30H5zM10 10v20h20V10zm5 5h10v10H15zM65 5h30v30H65zM70 10v20h20V10zm5 5h10v10H75zM5 65h30v30H5zM10 70v20h20V70zm5 5h10v10H15zM45 5h10v10H45zM45 25h10v10H45zM25 45h10v10H25zM45 45h10v10H45zM65 45h10v10H65zM85 45h10v10H85zM45 65h10v10H45zM65 65h10v10H65zM85 65h10v10H85zM45 85h10v10H45zM65 85h10v10H65zM85 85h10v10H85zM5 45h10v10H5zM15 55h10v10H15zM75 55h10v10H75zM55 75h10v10H55zM75 75h10v10H75z" />
                    </svg>

                    {/* Center UPI Badge */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="bg-white px-2 py-0.5 rounded border border-gray-300 shadow-sm flex items-center gap-1">
                        <span className="text-[10px] font-black tracking-tighter text-[#00478c]">UPI</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      </div>
                    </div>

                    <div className="text-[10px] font-mono text-gray-500 mt-1 flex items-center gap-1">
                      <span>Expires in:</span>
                      <span className="font-bold text-rose-600">{formatTimer(countdownSeconds)}</span>
                    </div>
                  </div>

                  {/* Accepted Apps Badges */}
                  <div className="flex items-center justify-center gap-2 flex-wrap mb-4 text-[11px] font-bold text-gray-500">
                    <span className="px-2 py-0.5 rounded bg-gray-100 border border-gray-200">GPay</span>
                    <span className="px-2 py-0.5 rounded bg-gray-100 border border-gray-200">PhonePe</span>
                    <span className="px-2 py-0.5 rounded bg-gray-100 border border-gray-200">Paytm</span>
                    <span className="px-2 py-0.5 rounded bg-gray-100 border border-gray-200">BHIM</span>
                    <span className="px-2 py-0.5 rounded bg-gray-100 border border-gray-200">Any Bank App</span>
                  </div>

                  {/* Simulation Trigger Button */}
                  <button
                    type="button"
                    onClick={() => handleSimulatePayment('upi')}
                    className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">smart_button</span>
                    <span>Simulate UPI Payment Success ({currency} {formatPrice(totalDue)})</span>
                  </button>
                </div>
              )}

              {/* 2. Card Payment Mode */}
              {paymentMode === 'card' && (
                <div className="flex flex-col items-center text-center py-2">
                  <div className="w-16 h-16 rounded-full bg-blue-50 border-2 border-[#00478c] text-[#00478c] flex items-center justify-center mb-3">
                    <span className="material-symbols-outlined text-[32px] animate-pulse">contactless</span>
                  </div>

                  <h3 className="text-base font-black text-[#09090B]">Insert or Tap Card on Terminal</h3>
                  <p className="text-xs text-gray-500 max-w-xs mt-1">
                    Please tap your contactless Visa, Mastercard, or RuPay card on the external card reader or insert your chip card.
                  </p>

                  <div className="my-5 p-4 rounded-xl bg-gray-50 border border-gray-200 w-full max-w-sm flex items-center justify-between">
                    <div className="text-left">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Terminal ID</span>
                      <span className="text-xs font-mono font-bold text-gray-800">EDC-KIOSK-01</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Status</span>
                      <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                        Ready for Tap
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSimulatePayment('card')}
                    className="w-full py-3.5 px-4 bg-[#00478c] hover:bg-[#005eb7] active:bg-[#00366c] text-white rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">credit_score</span>
                    <span>Simulate Card Tap & PIN Approval ({currency} {formatPrice(totalDue)})</span>
                  </button>
                </div>
              )}

              {/* 3. Pay at Counter Mode */}
              {paymentMode === 'counter' && (
                <div className="flex flex-col items-center text-center py-2">
                  <div className="w-16 h-16 rounded-full bg-amber-50 border-2 border-amber-500 text-amber-700 flex items-center justify-center mb-3">
                    <span className="material-symbols-outlined text-[32px]">point_of_sale</span>
                  </div>

                  <h3 className="text-base font-black text-[#09090B]">Pay Cash at the Billing Counter</h3>
                  <p className="text-xs text-gray-500 max-w-xs mt-1">
                    An order token receipt will be printed for you. Take it to <strong>Counter #1</strong> to pay cash and collect your items.
                  </p>

                  <div className="my-5 p-4 rounded-xl bg-amber-50/70 border border-amber-200 w-full max-w-sm text-left">
                    <div className="flex items-center gap-2 text-amber-900 font-bold text-xs mb-1">
                      <span className="material-symbols-outlined text-[18px]">info</span>
                      <span>Express Token Pickup Process</span>
                    </div>
                    <ol className="text-[11px] text-amber-800 list-decimal list-inside space-y-1">
                      <li>Confirm order to print token receipt</li>
                      <li>Walk to Counter #1 with your receipt</li>
                      <li>Pay cash & show token at the gate to exit</li>
                    </ol>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSimulatePayment('counter')}
                    className="w-full py-3.5 px-4 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">receipt</span>
                    <span>Generate Token & Pay at Counter ({currency} {formatPrice(totalDue)})</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3 bg-white border-t border-gray-200 flex items-center justify-between shrink-0">
          <button
            type="button"
            disabled={simulationStep !== 'idle'}
            onClick={() => setIsCheckoutOpen(false)}
            className="text-xs font-bold text-gray-600 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100 flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
          >
            <span className="material-symbols-outlined text-[16px]">arrow_back</span>
            <span>Back to Tray / Add More Items</span>
          </button>

          <span className="text-[11px] text-gray-400 font-medium">
            © 2026 Plannest • Self-Service Payment Terminal
          </span>
        </div>
      </div>
    </div>
  );
};
