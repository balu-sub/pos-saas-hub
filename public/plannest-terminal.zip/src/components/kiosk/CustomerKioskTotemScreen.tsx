import React, { useState, useMemo, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { useLanguage } from '../../context/LanguageContext';
import { Product } from '../../types/pos';
import { playBarcodeBeep, playKeypadClick, playSuccessChime } from '../../utils/audio';
import { filterAndSortProducts } from '../../utils/productSearch';
import { getProductImageUrl, handleProductImageError } from '../../utils/productImages';
import logoImg from '../../assets/First.png';

interface CustomerKioskTotemScreenProps {
  onOpenStaffExit: () => void;
}

// Visual category metadata helper with icons and color schemes for light mode
const getCategoryMetadata = (catName: string) => {
  const lower = (catName || '').toLowerCase();
  if (lower.includes('fruit')) {
    return {
      num: '1',
      title: 'Fresh Fruits',
      subtitle: 'Farm fresh & sweet',
      icon: 'nutrition',
      bgClass: 'from-amber-100 to-orange-50 text-amber-700 border-amber-200',
      activeRing: 'border-amber-500 ring-amber-400',
    };
  }
  if (lower.includes('veg')) {
    return {
      num: '2',
      title: 'Vegetables',
      subtitle: 'Green & organic',
      icon: 'eco',
      bgClass: 'from-emerald-100 to-green-50 text-emerald-700 border-emerald-200',
      activeRing: 'border-emerald-500 ring-emerald-400',
    };
  }
  if (lower.includes('dairy')) {
    return {
      num: '3',
      title: 'Dairy & Milk',
      subtitle: 'Milk, butter & paneer',
      icon: 'local_drink',
      bgClass: 'from-sky-100 to-blue-50 text-sky-700 border-sky-200',
      activeRing: 'border-sky-500 ring-sky-400',
    };
  }
  if (lower.includes('grocer')) {
    return {
      num: '4',
      title: 'Groceries',
      subtitle: 'Staples, pulses & flour',
      icon: 'shopping_basket',
      bgClass: 'from-rose-100 to-red-50 text-rose-700 border-rose-200',
      activeRing: 'border-rose-500 ring-rose-400',
    };
  }
  if (lower.includes('snack')) {
    return {
      num: '5',
      title: 'Snacks & Nuts',
      subtitle: 'Dry fruits & quick bites',
      icon: 'cookie',
      bgClass: 'from-purple-100 to-violet-50 text-purple-700 border-purple-200',
      activeRing: 'border-purple-500 ring-purple-400',
    };
  }
  if (lower.includes('beverag')) {
    return {
      num: '6',
      title: 'Beverages',
      subtitle: 'Juices, water & tea',
      icon: 'local_cafe',
      bgClass: 'from-teal-100 to-cyan-50 text-teal-700 border-teal-200',
      activeRing: 'border-teal-500 ring-teal-400',
    };
  }
  return {
    num: '*',
    title: catName,
    subtitle: 'Store selection',
    icon: 'category',
    bgClass: 'from-slate-100 to-gray-50 text-slate-700 border-slate-200',
    activeRing: 'border-[#00478c] ring-blue-400',
  };
};

// Safe number formatter helper to completely prevent TypeError during render
const formatPrice = (val: number | string | undefined | null): string => {
  if (val === undefined || val === null) return '0.00';
  const num = typeof val === 'number' ? val : Number(val);
  if (isNaN(num)) return '0.00';
  return num.toFixed(2);
};

export const CustomerKioskTotemScreen: React.FC<CustomerKioskTotemScreenProps> = ({
  onOpenStaffExit,
}) => {
  const {
    products,
    categories,
    cart,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    totalDue,
    itemCount,
    outletProfile,
    setIsCheckoutOpen,
    lastCompletedOrder,
    setIsReceiptOpen,
  } = usePOS();

  const { getItemName, getCategoryName, language, setLanguage } = useLanguage();

  // Kiosk UI states
  const [orderType, setOrderType] = useState<'DINE_IN' | 'TAKEAWAY'>('DINE_IN');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [onlyOffers, setOnlyOffers] = useState<boolean>(false);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState<boolean>(false);

  // Orientation tracking & manual rotation toggle state
  const [orientationMode, setOrientationMode] = useState<'auto' | 'portrait' | 'landscape'>('auto');
  const [isDevicePortrait, setIsDevicePortrait] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerHeight > window.innerWidth;
    }
    return false;
  });

  // Dynamic orientation listeners (resize, orientationchange, and screen.orientation API)
  useEffect(() => {
    const handleOrientationChange = () => {
      const portrait = window.innerHeight > window.innerWidth;
      setIsDevicePortrait(portrait);
    };

    handleOrientationChange();
    window.addEventListener('resize', handleOrientationChange);
    window.addEventListener('orientationchange', handleOrientationChange);

    if (window.screen?.orientation) {
      try {
        window.screen.orientation.addEventListener('change', handleOrientationChange);
      } catch {
        // ignore
      }
    }

    return () => {
      window.removeEventListener('resize', handleOrientationChange);
      window.removeEventListener('orientationchange', handleOrientationChange);
      if (window.screen?.orientation) {
        try {
          window.screen.orientation.removeEventListener('change', handleOrientationChange);
        } catch {
          // ignore
        }
      }
    };
  }, []);

  // Effective orientation (either forced by user or dynamically detected from device/window)
  const isPortrait =
    orientationMode === 'portrait'
      ? true
      : orientationMode === 'landscape'
      ? false
      : isDevicePortrait;

  // Toggle orientation function
  const handleToggleOrientation = async () => {
    playKeypadClick();
    let nextMode: 'auto' | 'portrait' | 'landscape' = 'auto';
    if (orientationMode === 'auto') {
      nextMode = isDevicePortrait ? 'landscape' : 'portrait';
    } else if (orientationMode === 'portrait') {
      nextMode = 'landscape';
    } else {
      nextMode = 'auto';
    }
    setOrientationMode(nextMode);

    // Attempt hardware orientation lock if supported by browser/PWA
    try {
      if (window.screen?.orientation && 'lock' in window.screen.orientation) {
        if (nextMode === 'portrait') {
          await (window.screen.orientation as any).lock('portrait').catch(() => {});
        } else if (nextMode === 'landscape') {
          await (window.screen.orientation as any).lock('landscape').catch(() => {});
        } else {
          (window.screen.orientation as any).unlock?.();
        }
      }
    } catch {
      // Hardware orientation lock requires fullscreen or browser permission, silently proceed
    }
  };

  const currency = outletProfile?.currencySymbol || 'Rs.';

  // Build clean categories list for totem rail
  const totemCategories = useMemo(() => {
    const list = (categories || []).filter(
      (c) => c !== 'All Items' && c !== 'All' && c !== '__OFFERS__'
    );
    return ['All', ...list];
  }, [categories]);

  // Robust product filtering using multi-lingual search utility
  const displayedProducts = useMemo(() => {
    return filterAndSortProducts(
      products || [],
      searchQuery,
      selectedCategory,
      onlyOffers,
      (p: Product) => !!p.isOfferActive
    );
  }, [products, searchQuery, selectedCategory, onlyOffers]);

  // Quantity in cart helper
  const getProductCartCount = (productId: string) => {
    const line = (cart || []).find((item) => item.productId === productId);
    return line ? line.quantity : 0;
  };

  const getProductCartLineId = (productId: string) => {
    const line = (cart || []).find((item) => item.productId === productId);
    return line ? line.id : null;
  };

  const handleAddToCart = (product: Product) => {
    playBarcodeBeep();
    addToCart(product, product.variants?.[0], 1);
  };

  const handleIncrement = (lineId: string) => {
    playKeypadClick();
    updateQuantity(lineId, 1);
  };

  const handleDecrement = (lineId: string, currentQty: number) => {
    playKeypadClick();
    if (currentQty <= 1) {
      removeFromCart(lineId);
    } else {
      updateQuantity(lineId, -1);
    }
  };

  return (
    <div
      id="customer-kiosk-totem-screen"
      className="w-full h-full flex flex-col bg-[#F4F6F8] text-slate-900 font-sans select-none overflow-hidden"
    >
      {/* 1. TOP KIOSK HEADER (Light Mode - Always Visible & Responsive) */}
      <header className="bg-white border-b border-slate-200 px-3 sm:px-4 py-2 sm:py-2.5 shrink-0 flex items-center justify-between z-30 shadow-xs min-h-[64px] sm:min-h-[76px] sticky top-0 gap-2">
        {/* Left: Brand Identity & Order Type */}
        <div className="flex items-center gap-2.5 sm:gap-4 min-w-0">
          <div className="flex items-center gap-2.5 sm:gap-3.5 min-w-0">
            <img
              src={logoImg}
              alt="Plannest"
              className={`w-auto object-contain shrink-0 drop-shadow-xs transition-all ${
                isPortrait ? 'h-11 sm:h-13 max-h-13' : 'h-14 sm:h-16 max-h-16'
              }`}
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-sm sm:text-base md:text-lg font-black tracking-tight text-slate-900 uppercase truncate">
                  {outletProfile?.outletName || 'PLANNEST FRESH'}
                </span>
                <span className="text-[9px] sm:text-[10px] font-black px-1.5 sm:px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 shrink-0">
                  KIOSK
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-500 font-medium truncate">
                {isPortrait ? 'Self-Service Totem' : 'Self-Service Touch Ordering'}
              </p>
            </div>
          </div>

          {/* Dine In vs Take Away Pill (Desktop & Landscape) */}
          <div className="hidden lg:flex items-center bg-slate-100 border border-slate-200 rounded-xl p-1 ml-1 shrink-0">
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setOrderType('DINE_IN');
              }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                orderType === 'DINE_IN'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🏬 Shop in Store
            </button>
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setOrderType('TAKEAWAY');
              }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                orderType === 'TAKEAWAY'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🛍️ Take Away
            </button>
          </div>
        </div>

        {/* Right: Rotate Screen Button, Language Switcher & Staff PIN Exit */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Rotate / Orientation Toggle Button */}
          <button
            type="button"
            onClick={handleToggleOrientation}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer select-none active:scale-95 ${
              orientationMode !== 'auto'
                ? 'bg-[#00478c] text-white border-[#00478c] shadow-xs ring-2 ring-[#00478c]/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
            title={`Orientation: ${orientationMode === 'auto' ? (isPortrait ? 'Vertical Totem (Auto)' : 'Horizontal Countertop (Auto)') : (orientationMode === 'portrait' ? 'Vertical (Locked)' : 'Horizontal (Locked)')}. Click to rotate.`}
          >
            <span
              className={`material-symbols-outlined text-[18px] transition-transform duration-300 ${
                isPortrait ? 'rotate-90 text-amber-400' : 'text-[#00478c]'
              }`}
            >
              screen_rotation
            </span>
            <span className="hidden sm:inline font-bold">
              {orientationMode === 'auto'
                ? isPortrait ? 'Vertical' : 'Horizontal'
                : orientationMode === 'portrait' ? 'Vertical (Fixed)' : 'Horizontal (Fixed)'}
            </span>
            <span className="text-[10px] font-mono px-1 py-0.5 rounded bg-black/10 leading-none">
              {isPortrait ? '↕' : '↔'}
            </span>
          </button>

          {/* Language Selector */}
          <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl p-1">
            {(['en', 'ta', 'hi'] as const).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setLanguage(lang);
                }}
                className={`px-2 sm:px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  language === lang
                    ? 'bg-[#00478c] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lang === 'en' ? 'EN' : lang === 'ta' ? 'தமிழ்' : 'हिंदी'}
              </button>
            ))}
          </div>

          {/* Discreet Staff PIN Exit */}
          <button
            type="button"
            onClick={() => {
              playKeypadClick();
              onOpenStaffExit();
            }}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border border-slate-200 transition-colors cursor-pointer"
            title="Staff Login / Exit Kiosk"
          >
            <span className="material-symbols-outlined text-[18px]">lock</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN KIOSK BODY: LEFT NUMBERED CATEGORY RAIL + RIGHT PRODUCT CATALOG */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* LEFT COLUMN: Large Numbered Circular Category Rail (Light Mode - Scrollable & Orientation Adaptive) */}
        <aside
          id="kiosk-category-rail"
          className={`bg-white border-r border-slate-200 flex flex-col shrink-0 z-10 shadow-xs h-full min-h-0 select-none transition-all duration-200 ${
            isPortrait
              ? 'w-22 sm:w-26 md:w-32'
              : 'w-36 sm:w-44 md:w-48 lg:w-52'
          }`}
        >
          <div className="py-2 px-1 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center shrink-0 border-b border-slate-100 bg-white">
            CATEGORIES
          </div>

          {/* Scrollable Category List with Touch Pan and Visible Scroll */}
          <div className="flex-1 overflow-y-auto touch-pan-y overscroll-contain py-2 px-1.5 sm:px-2 space-y-2 sm:space-y-2.5 scroll-smooth scrollbar-thin scrollbar-thumb-slate-200 hover:scrollbar-thumb-slate-300">
            {/* [0] All Items Option */}
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setSelectedCategory('All');
              }}
              className={`w-full group flex flex-col items-center p-2 rounded-2xl border transition-all text-center cursor-pointer ${
                selectedCategory === 'All' || selectedCategory === 'All Items'
                  ? 'bg-blue-50/90 border-[#00478c] ring-2 ring-[#00478c]/30 shadow-xs'
                  : 'bg-slate-50/70 border-slate-200 hover:border-slate-300 hover:bg-slate-100/80'
              }`}
            >
              <div className="relative mb-1">
                <div
                  className={`rounded-full border-2 p-0.5 flex items-center justify-center transition-transform group-hover:scale-105 ${
                    isPortrait ? 'w-11 h-11 sm:w-13 sm:h-13' : 'w-14 h-14 sm:w-16 sm:h-16'
                  } ${
                    selectedCategory === 'All' || selectedCategory === 'All Items'
                      ? 'border-[#00478c] bg-[#00478c]/10'
                      : 'border-slate-300 bg-white'
                  }`}
                >
                  <span
                    className={`material-symbols-outlined text-[#00478c] ${
                      isPortrait ? 'text-[22px]' : 'text-[28px]'
                    }`}
                  >
                    apps
                  </span>
                </div>
                <span className="absolute -top-1 -left-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-slate-900 border border-white text-[11px] sm:text-[12px] font-black text-white flex items-center justify-center shadow-xs">
                  0
                </span>
              </div>
              <span className="text-[11px] sm:text-xs font-black tracking-tight text-slate-900 line-clamp-1">
                All Items
              </span>
              <span className="text-[9px] sm:text-[10px] text-slate-500 font-medium">
                {(products || []).length} items
              </span>
            </button>

            {/* Numbered Category Items (1, 2, 3...) */}
            {totemCategories.slice(1).map((catName, index) => {
              const meta = getCategoryMetadata(catName);
              const isSelected =
                selectedCategory.toLowerCase() === catName.toLowerCase();
              const optionNumber = index + 1;
              const categoryProductCount = (products || []).filter(
                (p) => (p.category || '').toLowerCase() === catName.toLowerCase()
              ).length;

              return (
                <button
                  key={catName}
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setSelectedCategory(catName);
                  }}
                  className={`w-full group flex flex-col items-center p-2 rounded-2xl border transition-all text-center cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50/90 border-[#00478c] ring-2 ring-[#00478c]/30 shadow-xs'
                      : 'bg-slate-50/70 border-slate-200 hover:border-slate-300 hover:bg-slate-100/80'
                  }`}
                >
                  <div className="relative mb-1">
                    <div
                      className={`rounded-full border-2 p-0.5 flex items-center justify-center transition-transform group-hover:scale-105 bg-gradient-to-br ${
                        isPortrait ? 'w-11 h-11 sm:w-13 sm:h-13' : 'w-14 h-14 sm:w-16 sm:h-16'
                      } ${meta.bgClass} ${
                        isSelected
                          ? 'border-[#00478c] ring-2 ring-[#00478c]/20'
                          : 'border-slate-200'
                      }`}
                    >
                      <span
                        className={`material-symbols-outlined ${
                          isPortrait ? 'text-[22px]' : 'text-[28px]'
                        }`}
                      >
                        {meta.icon}
                      </span>
                    </div>
                    {/* Number Badge (1, 2, 3... matching physical totem) */}
                    <span
                      className={`absolute -top-1 -left-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full font-black text-[11px] sm:text-[12px] flex items-center justify-center shadow-xs ${
                        isSelected
                          ? 'bg-[#00478c] text-white'
                          : 'bg-slate-800 text-white'
                      }`}
                    >
                      {optionNumber}
                    </span>
                  </div>
                  <span className="text-[11px] sm:text-xs font-black tracking-tight text-slate-900 line-clamp-1">
                    {getCategoryName(catName)}
                  </span>
                  <span className="text-[9px] sm:text-[10px] text-slate-500 font-medium line-clamp-1">
                    {categoryProductCount} items
                  </span>
                </button>
              );
            })}
          </div>
        </aside>

        {/* RIGHT AREA: TOUCH PRODUCT CATALOG GRID (Light Mode) */}
        <main className="flex-1 flex flex-col min-h-0 overflow-hidden bg-[#F4F6F8]">
          {/* Search & Quick Filter Header */}
          <div className="p-3 bg-white border-b border-slate-200 shrink-0 flex flex-col sm:flex-row items-center gap-2.5">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <span className="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-[18px]">
                search
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search produce name, category or SKU..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-9 py-2 text-xs sm:text-sm font-medium text-slate-900 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-[#00478c] focus:ring-1 focus:ring-[#00478c]"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-700 p-0.5"
                >
                  <span className="material-symbols-outlined text-[18px]">close</span>
                </button>
              )}
            </div>

            {/* Quick Filter: Deals & Offers Only */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  setOnlyOffers(!onlyOffers);
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                  onlyOffers
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs font-black'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span className="material-symbols-outlined text-[16px] text-rose-500">
                  local_fire_department
                </span>
                <span>Deals & Offers</span>
              </button>

              <span className="text-xs text-slate-600 font-bold px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl">
                {displayedProducts.length} items
              </span>
            </div>
          </div>

          {/* Active Category Sub-header */}
          <div className="px-3 sm:px-4 py-2 bg-slate-100/80 border-b border-slate-200 flex items-center justify-between shrink-0 gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 shrink-0">
                Category:
              </span>
              <span className="text-xs font-black text-[#00478c] truncate">
                {selectedCategory === 'All' ? 'All Items' : getCategoryName(selectedCategory)}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* In Store / Take Away Selector for portrait / compact screens */}
              <div className="flex lg:hidden items-center bg-white border border-slate-200 rounded-lg p-0.5">
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setOrderType('DINE_IN');
                  }}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                    orderType === 'DINE_IN'
                      ? 'bg-[#00478c] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  In Store
                </button>
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setOrderType('TAKEAWAY');
                  }}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                    orderType === 'TAKEAWAY'
                      ? 'bg-[#00478c] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Take Away
                </button>
              </div>

              {selectedCategory !== 'All' && (
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setSelectedCategory('All');
                  }}
                  className="text-xs text-[#00478c] hover:underline font-bold flex items-center gap-1 shrink-0"
                >
                  <span className="hidden sm:inline">Show All</span>
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              )}
            </div>
          </div>

          {/* Product Items Grid (Orientation Adaptive: 2-4 cols vertical, 3-6 cols horizontal) */}
          <div className="flex-1 overflow-y-auto p-2.5 sm:p-4">
            {displayedProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500 space-y-3">
                <span className="material-symbols-outlined text-[54px] text-slate-400">
                  search_off
                </span>
                <p className="text-base font-bold text-slate-800">No matching items found</p>
                <p className="text-xs text-slate-500 max-w-sm">
                  Try clearing your search query or choosing another category from the left menu.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    setSearchQuery('');
                    setOnlyOffers(false);
                    setSelectedCategory('All');
                  }}
                  className="px-5 py-2.5 bg-[#00478c] hover:bg-[#00366c] text-white rounded-xl text-xs font-black shadow-xs cursor-pointer"
                >
                  Reset Search & Filters
                </button>
              </div>
            ) : (
              <div
                className={`grid gap-2.5 sm:gap-3.5 pb-24 ${
                  isPortrait
                    ? 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4'
                    : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6'
                }`}
              >
                {displayedProducts.map((product) => {
                  const inCartQty = getProductCartCount(product.id);
                  const lineId = getProductCartLineId(product.id);
                  const primaryVariant = product.variants?.[0];
                  const baseSellingPrice =
                    primaryVariant?.price || product.basePrice || 0;
                  const mrp =
                    primaryVariant?.mrp || product.baseMrp || baseSellingPrice;

                  const imageUrl = getProductImageUrl(product, primaryVariant);

                  return (
                    <div
                      key={product.id}
                      className="bg-white border border-slate-200 hover:border-[#00478c]/60 rounded-2xl overflow-hidden flex flex-col transition-all duration-200 shadow-xs hover:shadow-md group relative"
                    >
                      {/* Product Image Area with Safe Multi-Tier Fallback */}
                      <div className="relative aspect-square w-full bg-[#f8fafc] overflow-hidden flex items-center justify-center">
                        {imageUrl ? (
                          <img
                            src={imageUrl}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            loading="lazy"
                            referrerPolicy="no-referrer"
                            onError={(e) => handleProductImageError(e, product)}
                          />
                        ) : null}

                        {/* Styled Icon Fallback (shown automatically if image is missing or fails) */}
                        <div
                          className={`img-fallback ${
                            imageUrl ? 'hidden' : 'flex'
                          } flex-col items-center justify-center w-full h-full bg-gradient-to-br from-blue-50 via-slate-50 to-emerald-50 text-[#00478c] p-2 select-none`}
                        >
                          <span className="material-symbols-outlined text-[36px] opacity-70">
                            {product.category?.toLowerCase().includes('fruit')
                              ? 'nutrition'
                              : product.category?.toLowerCase().includes('veg')
                              ? 'spa'
                              : product.category?.toLowerCase().includes('bev')
                              ? 'local_cafe'
                              : product.category?.toLowerCase().includes('dairy')
                              ? 'local_drink'
                              : product.category?.toLowerCase().includes('snack')
                              ? 'cookie'
                              : 'shopping_basket'}
                          </span>
                          <span className="text-[10px] font-bold text-slate-500 mt-1 line-clamp-1">
                            {product.category}
                          </span>
                        </div>

                        {/* Veg Green Dot Badge */}
                        <div className="absolute top-2.5 left-2.5 w-5 h-5 bg-white rounded-md border border-emerald-600 flex items-center justify-center shadow-xs">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                        </div>

                        {/* Special Deal / Discount Badge */}
                        {product.isOfferActive && (
                          <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black shadow-xs">
                            {product.offerType === 'percentage'
                              ? `${product.offerValue}% OFF`
                              : `${currency}${product.offerValue} OFF`}
                          </div>
                        )}

                        {/* In-cart overlay badge */}
                        {inCartQty > 0 && (
                          <div className="absolute bottom-2.5 left-2.5 bg-[#00478c] text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                            <span>{inCartQty} in cart</span>
                          </div>
                        )}
                      </div>

                      {/* Product Info & Touch Controls */}
                      <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                        <div>
                          <h3 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-2 leading-tight">
                            {getItemName(product)}
                          </h3>
                          <p className="text-[10px] text-slate-500 font-medium mt-0.5">
                            Unit: {product.unit || 'kg'} • {product.category}
                          </p>
                        </div>

                        {/* Price & Add to Cart Controls */}
                        <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
                          <div className="flex items-baseline justify-between">
                            <div>
                              <span className="text-sm sm:text-base font-black text-[#00478c]">
                                {currency} {formatPrice(baseSellingPrice)}
                              </span>
                              {mrp > baseSellingPrice && (
                                <span className="text-[11px] text-slate-400 line-through ml-1.5">
                                  {currency} {formatPrice(mrp)}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 font-bold">
                              /{product.unit || 'kg'}
                            </span>
                          </div>

                          {/* Stepper or Add Button */}
                          {inCartQty > 0 && lineId ? (
                            <div className="flex items-center justify-between bg-[#00478c] text-white rounded-xl overflow-hidden shadow-xs">
                              <button
                                type="button"
                                onClick={() => handleDecrement(lineId, inCartQty)}
                                className="w-10 h-9 flex items-center justify-center hover:bg-[#00366c] active:scale-95 transition-transform cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-[18px]">
                                  remove
                                </span>
                              </button>
                              <span className="flex-1 text-center font-black text-xs sm:text-sm">
                                {inCartQty}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleIncrement(lineId)}
                                className="w-10 h-9 flex items-center justify-center hover:bg-[#00366c] active:scale-95 transition-transform cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-[18px]">
                                  add
                                </span>
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleAddToCart(product)}
                              className="w-full py-2 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
                            >
                              <span className="material-symbols-outlined text-[16px]">add</span>
                              <span>ADD TO BASKET</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* 3. STICKY BOTTOM ORDER & CHECKOUT BAR (Light Mode - Always Visible) */}
      <footer className="bg-white border-t border-slate-200 px-4 py-3 shrink-0 flex items-center justify-between z-30 shadow-lg sticky bottom-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setIsCartDrawerOpen(true);
              }}
              className="w-12 h-12 rounded-2xl bg-[#00478c] hover:bg-[#003870] text-white flex items-center justify-center shadow-md active:scale-95 transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined text-[24px]">shopping_basket</span>
            </button>
            {itemCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-600 text-white font-black text-[11px] flex items-center justify-center shadow-xs">
                {itemCount}
              </span>
            )}
          </div>

          <div>
            <div className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">
              TOTAL DUE ({itemCount} {itemCount === 1 ? 'item' : 'items'})
            </div>
            <div className="text-lg sm:text-xl font-black text-slate-900">
              {currency} {formatPrice(totalDue)}
            </div>
            <div className="text-[10px] font-bold text-slate-400 mt-0.5 flex items-center gap-1 sm:hidden">
              <span>©</span>
              <span>2026 Plannest</span>
            </div>
          </div>
        </div>

        {/* Center Copyright Banner (Always Visible on Desktop / Kiosk Tablet) */}
        <div className="hidden sm:flex flex-col items-center justify-center text-center px-4">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 tracking-wide">
            <span className="text-sm font-normal text-slate-400">©</span>
            <span>2026 Plannest</span>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">
            Self-Service Touch Terminal
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Quick Clear Basket */}
          {(cart || []).length > 0 && (
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                clearCart();
              }}
              className="px-3.5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-rose-600 font-bold text-xs transition-colors cursor-pointer"
              title="Clear Cart"
            >
              <span className="material-symbols-outlined text-[18px]">delete_sweep</span>
            </button>
          )}

          {/* Review Order / Express Checkout Button */}
          {(cart || []).length === 0 && lastCompletedOrder ? (
            <button
              type="button"
              onClick={() => {
                playKeypadClick();
                setIsReceiptOpen(true);
              }}
              className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-md transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">receipt_long</span>
              <span>VIEW LAST RECEIPT</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={(cart || []).length === 0}
              onClick={() => {
                playKeypadClick();
                setIsCheckoutOpen(true);
              }}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 active:scale-95 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <span>CHECKOUT & PAY</span>
              <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
            </button>
          )}
        </div>
      </footer>

      {/* 4. SLIDE-UP TOUCH CART REVIEW DRAWER (Light Mode) */}
      {isCartDrawerOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div
            className="flex-1 cursor-pointer"
            onClick={() => setIsCartDrawerOpen(false)}
          />

          <div className="w-full max-w-2xl mx-auto bg-white border-t border-slate-200 rounded-t-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            {/* Drawer Header */}
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[#00478c] text-[24px]">
                  shopping_cart
                </span>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                    My Self-Service Basket
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {itemCount} {itemCount === 1 ? 'item' : 'items'} ready for checkout
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsCartDrawerOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            {/* Cart Line Items */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-slate-100">
              {(cart || []).length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <span className="material-symbols-outlined text-[48px] text-slate-300">
                    remove_shopping_cart
                  </span>
                  <p className="text-sm font-bold text-slate-700">
                    Your basket is currently empty
                  </p>
                  <p className="text-xs text-slate-500">
                    Touch any item on the menu to add it to your basket.
                  </p>
                </div>
              ) : (
                (cart || []).map((item) => {
                  const prodObj = (products || []).find((p) => p.id === item.productId);
                  const itemImg = item.image || (prodObj ? getProductImageUrl(prodObj) : '');
                  const displayName = prodObj ? getItemName(prodObj) : item.productName;
                  const lineTotal = item.unitPrice * item.quantity - (item.discountAmount || 0);

                  return (
                    <div
                      key={item.id}
                      className="pt-3 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-12 h-12 rounded-xl bg-slate-100 overflow-hidden shrink-0 border border-slate-200 flex items-center justify-center">
                          {itemImg ? (
                            <img
                              src={itemImg}
                              alt={displayName}
                              className="w-full h-full object-cover"
                              loading="lazy"
                              referrerPolicy="no-referrer"
                              onError={(e) => handleProductImageError(e, prodObj)}
                            />
                          ) : (
                            <span className="material-symbols-outlined text-[20px] text-slate-400">
                              inventory_2
                            </span>
                          )}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {displayName}
                          </h4>
                          <div className="text-[11px] text-slate-500">
                            {currency} {formatPrice(item.unitPrice)} × {item.quantity}
                          </div>
                        </div>
                      </div>

                      {/* Stepper */}
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                          <button
                            type="button"
                            onClick={() => handleDecrement(item.id, item.quantity)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-slate-200 active:scale-95 text-slate-700 cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[16px]">
                              remove
                            </span>
                          </button>
                          <span className="w-7 text-center font-black text-xs text-slate-900">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleIncrement(item.id)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-slate-200 active:scale-95 text-slate-700 cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[16px]">add</span>
                          </button>
                        </div>

                        <div className="text-right min-w-[70px]">
                          <span className="text-xs sm:text-sm font-black text-[#00478c]">
                            {currency} {formatPrice(lineTotal)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Drawer Total & Checkout Action */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
                <span>Subtotal</span>
                <span>
                  {currency} {formatPrice(totalDue)}
                </span>
              </div>
              <div className="flex items-center justify-between text-base font-black text-slate-900">
                <span>Total Amount Due</span>
                <span className="text-[#00478c]">
                  {currency} {formatPrice(totalDue)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCartDrawerOpen(false)}
                  className="py-3 px-4 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-black text-xs transition-colors cursor-pointer"
                >
                  + ADD MORE ITEMS
                </button>

                <button
                  type="button"
                  disabled={(cart || []).length === 0}
                  onClick={() => {
                    setIsCartDrawerOpen(false);
                    setIsCheckoutOpen(true);
                  }}
                  className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md transition-all disabled:opacity-50 cursor-pointer"
                >
                  PROCEED TO PAY
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
