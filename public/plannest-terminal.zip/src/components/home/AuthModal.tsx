import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { X, Lock, Mail, Building, Phone, ArrowRight } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'signin' | 'signup';
  noticeMessage?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'signin',
  noticeMessage,
}) => {
  const { login, signup, isLoadingAuth } = useAuth();

  const [mode, setMode] = useState<'signin' | 'signup'>(defaultMode);

  // Sync mode when defaultMode changes or modal opens
  useEffect(() => {
    setMode(defaultMode);
    setErrorMessage(null);
  }, [defaultMode, isOpen]);

  // Form states
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [phone, setPhone] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (mode === 'signin') {
      const res = await login(identifier, password);
      if (!res.success) {
        setErrorMessage(res.error || 'Invalid credentials. Please check your username/email and password.');
      } else {
        onClose();
      }
    } else {
      // Sign up is exclusively for customers
      const res = await signup({
        businessName: businessName.trim() || `${identifier.split('@')[0]}'s Store`,
        email: identifier.trim(),
        phone: phone.trim() || undefined,
        password,
        role: 'customer',
        planTier: 'trial',
      });
      if (!res.success) {
        setErrorMessage(res.error || 'Failed to register customer account');
      } else {
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header matching Cadence clean home style */}
        <div className="p-6 pb-4 border-b border-slate-100 bg-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-3">
            <img src="/Logo.png" alt="Plannest" className="h-10 w-auto object-contain" />
          </div>

          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            {mode === 'signin' ? 'Sign in to Plannest' : 'Create your Customer Account'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {mode === 'signin'
              ? 'Enter your credentials to access your store deployment'
              : 'Sign up to deploy your retail POS and manage licenses'}
          </p>
        </div>

        {/* Super Admin Notice if triggered by POS simulation access */}
        {noticeMessage && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 py-3 text-xs text-amber-950 flex items-start gap-2.5">
            <Lock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold block text-amber-900">Access Restricted</span>
              <p className="text-[11px] text-amber-800 mt-0.5 leading-normal">{noticeMessage}</p>
            </div>
          </div>
        )}

        {/* Tab Selector */}
        <div className="flex border-b border-gray-100 bg-gray-50/50">
          <button
            type="button"
            onClick={() => {
              setMode('signin');
              setErrorMessage(null);
            }}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 ${
              mode === 'signin'
                ? 'border-[#00478c] text-[#00478c] bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-900'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setErrorMessage(null);
            }}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 ${
              mode === 'signup'
                ? 'border-[#00478c] text-[#00478c] bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-900'
            }`}
          >
            Sign Up
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Store / Business Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    placeholder="e.g. Apex Supermarket"
                    className="w-full pl-9 pr-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] text-gray-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number (Optional)</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98400 12345"
                    className="w-full pl-9 pr-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] text-gray-900"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              {mode === 'signin' ? 'User ID or Email' : 'Email Address'} <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder={mode === 'signin' ? 'e.g. balu or user@example.com' : 'store@example.com'}
                className="w-full pl-9 pr-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] text-gray-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Password <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00478c] text-gray-900"
              />
            </div>
          </div>

          {mode === 'signup' && (
            <p className="text-[11px] text-gray-500">
              Only customers can sign up. Staff IDs are allotted by the Super Admin.
            </p>
          )}

          {mode === 'signin' && (
            <div className="pt-2 border-t border-slate-100">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between">
                <span>Quick Test Logins</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIdentifier('balu');
                    setPassword('1234');
                  }}
                  className="p-2 text-left rounded-lg bg-slate-50 hover:bg-blue-50/70 border border-slate-200/80 hover:border-blue-300 transition-all"
                >
                  <div className="text-[11px] font-bold text-slate-800">Super Admin (Balu)</div>
                  <div className="text-[10px] text-slate-500 font-mono">balu / 1234</div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIdentifier('varun@gmail.com');
                    setPassword('1111');
                  }}
                  className="p-2 text-left rounded-lg bg-slate-50 hover:bg-emerald-50/70 border border-slate-200/80 hover:border-emerald-300 transition-all"
                >
                  <div className="text-[11px] font-bold text-emerald-800">Customer (Varun)</div>
                  <div className="text-[10px] text-slate-500 font-mono">varun@gmail.com / 1111</div>
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoadingAuth}
            className="w-full mt-2 py-2.5 px-4 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-lg shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isLoadingAuth ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'signin' ? 'Sign In' : 'Sign Up'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Footer switcher */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 text-center">
          {mode === 'signin' ? (
            <p className="text-xs text-gray-500">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setErrorMessage(null);
                }}
                className="font-bold text-[#00478c] hover:underline"
              >
                Sign Up
              </button>
            </p>
          ) : (
            <p className="text-xs text-gray-500">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  setErrorMessage(null);
                }}
                className="font-bold text-[#00478c] hover:underline"
              >
                Sign In
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
