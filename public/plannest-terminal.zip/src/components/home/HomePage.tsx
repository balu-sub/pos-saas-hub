import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { AuthModal } from './AuthModal';
import {
  ShieldCheck,
  Scale,
  Printer,
  Barcode,
  Database,
  Cloud,
  Server,
  Zap,
  CheckCircle2,
  ArrowRight,
  Download,
  Terminal,
  Layers,
  Sparkles,
  Check,
  ChevronRight,
  Laptop,
  Cpu,
  RefreshCw,
  Sliders,
  HardDrive,
  Workflow,
  Radio,
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const {
    currentUser,
    isStaff,
    isCustomer,
    setCurrentView,
    logout,
  } = useAuth();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [authNotice, setAuthNotice] = useState<string | undefined>(undefined);

  // Cadence-style interactive capability walkthrough state
  const [activeWorkflowTab, setActiveWorkflowTab] = useState<'scan' | 'tare' | 'settle' | 'sync'>('scan');

  const openSignIn = (notice?: string) => {
    setAuthNotice(notice);
    setAuthMode('signin');
    setIsAuthModalOpen(true);
  };

  const openSignUp = () => {
    setAuthNotice(undefined);
    setAuthMode('signup');
    setIsAuthModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FDFDFE] text-[#0F172A] flex flex-col selection:bg-[#00478c] selection:text-white antialiased font-sans">
      {/* 1. Cadence-Style Sticky Floating Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-slate-200/70 transition-all">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center cursor-pointer" onClick={() => setCurrentView('home')}>
            <img
              src="/Logo.png"
              alt="Plannest POS"
              className="h-16 md:h-18 w-auto max-w-[280px] object-contain"
              loading="eager"
            />
          </div>

          <nav className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-600">
            <a href="#features" className="hover:text-[#00478c] transition-colors">
              Platform
            </a>
            <a href="#workflow" className="hover:text-[#00478c] transition-colors">
              Workflow
            </a>
            <a href="#hardware" className="hover:text-[#00478c] transition-colors">
              Peripherals
            </a>
            <a href="#pricing" className="hover:text-[#00478c] transition-colors">
              Pricing
            </a>
          </nav>

          <div className="flex items-center gap-3">
            {currentUser ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-600 hidden sm:inline">
                  Hello, <strong className="text-slate-900">{currentUser.businessName || currentUser.email}</strong>
                </span>

                {isStaff && (
                  <button
                    onClick={() => setCurrentView('saas_hub')}
                    className="px-3 py-1.5 text-xs font-semibold bg-[#00478c] hover:bg-[#003366] text-white rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                  >
                    <Server className="w-3.5 h-3.5" />
                    <span>SaaS Hub</span>
                  </button>
                )}

                {isCustomer && (
                  <button
                    onClick={() => setCurrentView('customer_portal')}
                    className="px-3 py-1.5 text-xs font-semibold bg-[#00478c] hover:bg-[#003366] text-white rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Portal</span>
                  </button>
                )}

                <button
                  onClick={logout}
                  className="px-2.5 py-1.5 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <>
                <button
                  onClick={() => openSignIn()}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
                >
                  Sign In
                </button>
                <button
                  onClick={openSignUp}
                  className="px-3.5 py-1.5 text-xs font-semibold bg-[#00478c] hover:bg-[#003366] text-white rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-1"
                >
                  <span>Sign Up</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* 2. Cadence Hero Section: High Impact Typography, Centered Hierarchy, Micro-Badges */}
      <section className="relative pt-16 pb-14 md:pt-24 md:pb-20 overflow-hidden bg-gradient-to-b from-white via-[#F8FAFC] to-[#F1F5F9]/50 border-b border-slate-200/60">
        {/* Subtle geometric background grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Eyebrow Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100/90 border border-slate-200 text-slate-700 text-xs font-medium mb-6 shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>High-Speed Retail Billing & Offline SQLite Engine</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </div>

          {/* Display Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12] max-w-4xl mx-auto">
            The ultra-fast, offline-first POS for modern supermarkets.
          </h1>

          {/* Subtitle */}
          <p className="mt-5 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto font-normal leading-relaxed">
            Eliminate checkout queues with 0.3s barcode scans, instant RS232 auto-tare digital scales, and 100% local database autonomy that never stops when internet drops.
          </p>

          {/* Cadence CTA Group */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3.5">
            <button
              onClick={openSignUp}
              className="px-6 py-3 bg-[#00478c] hover:bg-[#003366] text-white text-sm font-bold rounded-xl shadow-lg shadow-blue-900/15 hover:shadow-xl transition-all flex items-center gap-2"
            >
              <span>Get Started with Free Trial</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Trust Highlights */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500 font-medium">
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> 1-Click Windows & Linux installer
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> 0.3s Barcode scan response
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> Zero cloud downtime risk
            </span>
          </div>

          {/* Product Hero Visual Frame */}
          <div className="mt-12 sm:mt-14 max-w-5xl mx-auto">
            <div className="relative rounded-2xl bg-white p-2 shadow-2xl shadow-slate-300/60 border border-slate-200/90 ring-1 ring-black/[0.03]">
              <img
                src="/images/screenshot-pos.png"
                alt="Plannest POS Register Production Interface"
                className="w-full h-auto rounded-xl object-cover object-top border border-slate-200"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 3. Cadence Bento Grid: Core Capabilities */}
      <section id="features" className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-14">
            <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">
              Engineered for Volume
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Everything high-throughput retail requires.
            </h2>
            <p className="text-sm text-slate-600 mt-3 leading-relaxed">
              Every millisecond saved at the cashier counter compounds into thousands in saved turnover. Plannest eliminates every point of friction.
            </p>
          </div>

          {/* Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Card 1: 0.3s Scan Rate (Span 2 cols on md) */}
            <div className="md:col-span-2 rounded-2xl bg-[#F8FAFC] border border-slate-200 p-8 flex flex-col justify-between hover:border-slate-300 transition-all">
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-100/70 text-[#00478c] flex items-center justify-center mb-5">
                  <Zap className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">0.3s Real-Time Scanning & Keyboard Navigation</h3>
                <p className="text-xs text-slate-600 mt-2.5 leading-relaxed max-w-xl">
                  Cashiers never touch the mouse during rush hours. Full functional keyboard shortcut suite (F1 Search, F2 Quantity, F6 Auto-Tare, F8 Drawer, F12 Pay) keeps barcode lines moving at lightning pace.
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-slate-200/80 grid grid-cols-3 gap-4 font-mono text-center">
                <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                  <span className="text-lg font-bold text-slate-900 block">0.3s</span>
                  <span className="text-[10px] text-slate-500 uppercase">Barcode Latency</span>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                  <span className="text-lg font-bold text-slate-900 block">50K+</span>
                  <span className="text-[10px] text-slate-500 uppercase">Cached Local SKUs</span>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                  <span className="text-lg font-bold text-emerald-600 block">100%</span>
                  <span className="text-[10px] text-slate-500 uppercase">Keyboard Accessible</span>
                </div>
              </div>
            </div>

            {/* Card 2: Offline SQLite Engine */}
            <div className="rounded-2xl bg-[#F8FAFC] border border-slate-200 p-8 flex flex-col justify-between hover:border-slate-300 transition-all">
              <div>
                <div className="w-10 h-10 rounded-xl bg-emerald-100/70 text-emerald-700 flex items-center justify-center mb-5">
                  <Database className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">100% Offline SQLite</h3>
                <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                  No broadband? No problem. The local database never blocks a checkout. All transactions are logged locally and push to the cloud automatically upon reconnection.
                </p>
              </div>

              <div className="mt-8 p-3 rounded-xl bg-white border border-slate-200/80 text-[11px] text-slate-600 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-800">Local Cache:</span>
                  <span className="text-emerald-700 font-mono font-bold">Active</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-800">Internet Resilience:</span>
                  <span className="text-slate-900 font-mono">Uninterrupted</span>
                </div>
              </div>
            </div>

            {/* Card 3: RS232 Weighing Scale */}
            <div className="rounded-2xl bg-[#F8FAFC] border border-slate-200 p-8 flex flex-col justify-between hover:border-slate-300 transition-all">
              <div>
                <div className="w-10 h-10 rounded-xl bg-amber-100/70 text-amber-700 flex items-center justify-center mb-5">
                  <Scale className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">RS232 Auto-Tare Scale</h3>
                <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                  Direct WebSerial integration with Essae, Avery, Phoenix, and Mettler Toledo scales. Automatic continuous stream weighing prevents cashier fraud and manual entry errors.
                </p>
              </div>

              <div className="mt-8 p-3 rounded-xl bg-black text-emerald-400 font-mono text-xs flex items-center justify-between shadow-inner">
                <div>
                  <span className="text-[9px] text-slate-400 block uppercase">WebSerial RS232</span>
                  <span className="text-sm font-bold">1.450 kg</span>
                </div>
                <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 rounded border border-emerald-800 text-[10px]">
                  TARE OK
                </span>
              </div>
            </div>

            {/* Card 4: Multi-Store SaaS Cockpit (Span 2 cols on md) */}
            <div className="md:col-span-2 rounded-2xl bg-[#F8FAFC] border border-slate-200 p-8 flex flex-col justify-between hover:border-slate-300 transition-all">
              <div>
                <div className="w-10 h-10 rounded-xl bg-purple-100/70 text-purple-700 flex items-center justify-center mb-5">
                  <Server className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">Multi-Store SaaS Fleet Management</h3>
                <p className="text-xs text-slate-600 mt-2.5 leading-relaxed max-w-xl">
                  Centrally inspect counter health, license tokens, OTA software versions, and aggregated sales across your entire store chain from a single browser cockpit.
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="font-semibold text-slate-800">OTA Fleet Updates</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <span className="font-semibold text-slate-800">Hardware Token Licensing</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                  <span className="font-semibold text-slate-800">Multi-Outlet Aggregation</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Cadence Scroll-Driven Workflow Tour */}
      <section id="workflow" className="py-20 bg-[#F8FAFC] border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">
              Operational Workflow
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Designed for retail rush hours.
            </h2>
            <p className="text-sm text-slate-600 mt-3">
              Explore how cashiers, store owners, and super admins interact with Plannest in real time.
            </p>
          </div>

          {/* Workflow Tabs */}
          <div className="flex justify-center mb-10 overflow-x-auto pb-2">
            <div className="inline-flex p-1.5 bg-slate-200/70 rounded-xl gap-1">
              <button
                onClick={() => setActiveWorkflowTab('scan')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeWorkflowTab === 'scan'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1. Rapid Barcode Scan
              </button>
              <button
                onClick={() => setActiveWorkflowTab('tare')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeWorkflowTab === 'tare'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2. Weight & Tare Scale
              </button>
              <button
                onClick={() => setActiveWorkflowTab('settle')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeWorkflowTab === 'settle'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                3. Instant Cash/UPI Settlement
              </button>
              <button
                onClick={() => setActiveWorkflowTab('sync')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeWorkflowTab === 'sync'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                4. Offline SQLite & Cloud Sync
              </button>
            </div>
          </div>

          {/* Active Workflow Card */}
          <div className="max-w-4xl mx-auto bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
            {activeWorkflowTab === 'scan' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#00478c] flex items-center justify-center font-bold text-sm mb-4">
                    F1
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">Barcode Trigger with In-Memory Index</h3>
                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                    Honeywell, TVS, and Zebra USB scanners emulate continuous keystrokes. In-memory indexing resolves even ambiguous barcodes in 300 microseconds with zero disk delays.
                  </p>
                  <ul className="mt-4 space-y-2 text-xs text-slate-700">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Support for variable-weight butcher & produce prefixes</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>F2 quantity multiplier without touching mouse</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 font-mono text-xs">
                  <div className="text-slate-400 text-[10px] mb-2 uppercase">Scanner Emulation Stream</div>
                  <div className="bg-white p-3 rounded-lg border border-slate-200 text-slate-800">
                    <span className="text-blue-600 font-bold">SCAN_IN:</span> 8901030383371 [ENTER]
                    <div className="text-emerald-700 text-[11px] mt-1">➔ Shimla Red Apples • Match in 0.003s</div>
                  </div>
                </div>
              </div>
            )}

            {activeWorkflowTab === 'tare' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center font-bold text-sm mb-4">
                    F6
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">Digital Scale Streaming with Auto-Tare</h3>
                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                    Connecting your weighing scale over WebSerial streams current gram readings live into the UI. Pressing F6 instantly zeros out packaging tare weight.
                  </p>
                  <ul className="mt-4 space-y-2 text-xs text-slate-700">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Compatible with Essae, Avery Berkel, Phoenix scales</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Stable-weight lock before item is added to bill</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400">
                  <div className="text-slate-400 text-[10px] mb-2 uppercase">RS232 Serial Port (9600-8-N-1)</div>
                  <div className="space-y-1 text-slate-300">
                    <p>STREAM: ST,GS,+001.450kg</p>
                    <p className="text-amber-400">COMMAND: TARE_SENT (F6)</p>
                    <p className="text-emerald-400 font-bold">LOCKED: 1.450 kg Net</p>
                  </div>
                </div>
              </div>
            )}

            {activeWorkflowTab === 'settle' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm mb-4">
                    F12
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">Split Cash, Card, and UPI QR Checkout</h3>
                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                    Settling a transaction prints an ESC/POS 80mm thermal receipt, kicks the cash drawer solenoid (F8), and logs change calculation in under a second.
                  </p>
                  <ul className="mt-4 space-y-2 text-xs text-slate-700">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Dynamic UPI QR code on customer-facing display</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Exact change calculator prevents cashier discrepancies</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 font-mono text-xs">
                  <div className="text-slate-400 text-[10px] mb-2 uppercase">Thermal Receipt Output</div>
                  <div className="bg-white p-3 rounded-lg border border-slate-200 text-slate-800 space-y-1">
                    <div className="flex justify-between font-bold"><span>TOTAL DUE</span><span>₹357.00</span></div>
                    <div className="flex justify-between text-slate-500"><span>CASH PAID</span><span>₹500.00</span></div>
                    <div className="flex justify-between text-emerald-600 font-bold"><span>CHANGE</span><span>₹143.00</span></div>
                  </div>
                </div>
              </div>
            )}

            {activeWorkflowTab === 'sync' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center font-bold text-sm mb-4">
                    Sync
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">Continuous Multi-Lane SQLite Ledger</h3>
                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                    The embedded SQLite database acts as the single source of truth locally. When network is available, deltas stream to the central cloud hub without locking the checkout screen.
                  </p>
                  <ul className="mt-4 space-y-2 text-xs text-slate-700">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Cryptographically signed offline sales transactions</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Multi-counter inventory locks across store network</span>
                    </li>
                  </ul>
                </div>
                <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 font-mono text-xs">
                  <div className="text-slate-400 text-[10px] mb-2 uppercase">Sync Status Monitor</div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between bg-white p-2 rounded border border-slate-200">
                      <span>Local SQLite Queue:</span>
                      <span className="text-emerald-600 font-bold">Synced (0 pending)</span>
                    </div>
                    <div className="flex items-center justify-between bg-white p-2 rounded border border-slate-200">
                      <span>Central Cloud Hub:</span>
                      <span className="text-blue-600 font-bold">Connected</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 5. Peripheral Suite Section */}
      <section id="hardware" className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">
              Native Hardware
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Plugs into your counter hardware.
            </h2>
            <p className="text-sm text-slate-600 mt-3">
              Zero driver headache. Plannest interfaces directly via WebSerial, WebUSB, and ESC/POS standards.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-7 rounded-2xl bg-[#F8FAFC] border border-slate-200 hover:border-slate-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-blue-100/70 text-[#00478c] flex items-center justify-center mb-5">
                <Scale className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">WebSerial RS232 Scales</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Connect Essae, Avery Berkel, Phoenix, or Mettler Toledo scales. Continuous weight stream with F6 zero-tare hotkey.
              </p>
            </div>

            <div className="p-7 rounded-2xl bg-[#F8FAFC] border border-slate-200 hover:border-slate-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-emerald-100/70 text-emerald-700 flex items-center justify-center mb-5">
                <Printer className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">80mm ESC/POS Thermal Printers</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                High-density bilingual thermal receipts, tax breakdowns, UPI QR payment codes, and automatic cash drawer kick (F8).
              </p>
            </div>

            <div className="p-7 rounded-2xl bg-[#F8FAFC] border border-slate-200 hover:border-slate-300 transition-all">
              <div className="w-12 h-12 rounded-xl bg-amber-100/70 text-amber-700 flex items-center justify-center mb-5">
                <Barcode className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">USB HID 1D/2D Barcode Scanners</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Plug-and-play support for Honeywell, TVS, and Zebra handheld and omnidirectional scanners with rapid prefix parsing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Cadence Clean Pricing Section */}
      <section id="pricing" className="py-20 bg-[#F8FAFC] border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">
              Transparent Pricing
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Deployment plans for every retail footprint.
            </h2>
            <p className="text-sm text-slate-600 mt-3">
              From single-store offline registers to enterprise multi-store cloud fleets. Every plan begins with an instant 3-Day Free Trial.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Plan A */}
            <div className="bg-white rounded-2xl p-8 border-2 border-[#00478c] shadow-lg relative flex flex-col justify-between">
              <div className="absolute -top-3 left-6 px-3 py-0.5 bg-[#00478c] text-white text-[10px] font-bold rounded-full uppercase tracking-wider">
                Recommended for Standalone Stores
              </div>

              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 bg-blue-50 text-[#00478c] rounded-xl">
                    <Laptop className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Plan A: Local On-Premises</h3>
                    <p className="text-xs text-slate-500">100% Offline-First / Single Store</p>
                  </div>
                </div>

                <div className="my-5 pb-5 border-b border-slate-100">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-slate-900">₹999</span>
                    <span className="text-xs text-slate-500">/ month / counter</span>
                  </div>
                  <span className="text-[11px] text-emerald-700 font-semibold mt-1 inline-block">
                    ✓ Includes 3-Day Free Trial (₹0)
                  </span>
                </div>

                <ul className="space-y-3 text-xs text-slate-700 mb-8">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>1-Click Native Installer</strong> (.bat, .ps1, .sh)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Embedded SQLite DB</strong> with local product images</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Machine-Locked License</strong> (.plannestlic token)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Works 100% offline with zero cloud latency</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>RS232 scale & 80mm thermal receipt support</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={openSignUp}
                className="w-full py-3 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2"
              >
                <span>Start Free Trial / Select Plan A</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Plan B */}
            <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                    <Terminal className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Plan B: Self-Hosted VPS</h3>
                    <p className="text-xs text-slate-500">BYO Cloud (Hetzner, DO, AWS)</p>
                  </div>
                </div>

                <div className="my-5 pb-5 border-b border-slate-100">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-slate-900">₹1,499</span>
                    <span className="text-xs text-slate-500">/ month / store</span>
                  </div>
                  <span className="text-[11px] text-emerald-700 font-semibold mt-1 inline-block">
                    ✓ Includes 3-Day Free Trial (₹0)
                  </span>
                </div>

                <ul className="space-y-3 text-xs text-slate-700 mb-8">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Automated cloud-init.sh</strong> setup in 45 seconds</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Docker Compose & Caddy</strong> with auto SSL</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Bring your own custom domain name</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Multi-counter LAN/WAN checkout sync</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={openSignUp}
                className="w-full py-3 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2"
              >
                <span>Start Free Trial / Select Plan B</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Plan C */}
            <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 bg-purple-50 text-purple-600 rounded-xl">
                    <Cloud className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Plan C: Managed Cloud</h3>
                    <p className="text-xs text-slate-500">Multi-Store Enterprise (GCP)</p>
                  </div>
                </div>

                <div className="my-5 pb-5 border-b border-slate-100">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-slate-900">₹2,499</span>
                    <span className="text-xs text-slate-500">/ month / store</span>
                  </div>
                  <span className="text-[11px] text-emerald-700 font-semibold mt-1 inline-block">
                    ✓ Includes 3-Day Free Trial (₹0)
                  </span>
                </div>

                <ul className="space-y-3 text-xs text-slate-700 mb-8">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Dedicated GCP Cloud Run & Cloud SQL</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Custom Subdomain</strong> provisioned instantly</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Real-time multi-cashier shift reconciliation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>24/7 Priority SLA & Centralized Fleet Control</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={openSignUp}
                className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2"
              >
                <span>Start Free Trial / Select Plan C</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Bottom Cadence Call to Action Banner */}
      <section className="py-16 bg-[#001D3D] text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Ready to upgrade your store's billing speed?
          </h2>
          <p className="text-sm text-blue-100/80 mt-3 max-w-xl mx-auto">
            Get started in under 60 seconds with our 1-click installer. No credit card required.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={openSignUp}
              className="px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-white text-xs sm:text-sm font-bold rounded-xl shadow-lg transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Start 3-Day Free Trial</span>
            </button>
            <button
              onClick={() => openSignIn()}
              className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-semibold rounded-xl border border-white/20 transition-colors"
            >
              Sign In to Account
            </button>
          </div>
        </div>
      </section>

      {/* 8. Minimalist Footer */}
      <footer className="bg-white border-t border-slate-200 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center text-xs text-slate-500">
          <span>© 2026 Plannest Systems. All rights reserved.</span>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => {
          setIsAuthModalOpen(false);
          setAuthNotice(undefined);
        }}
        defaultMode={authMode}
        noticeMessage={authNotice}
      />
    </div>
  );
};

