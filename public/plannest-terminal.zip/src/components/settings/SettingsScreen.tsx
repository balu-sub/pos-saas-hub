import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals, PeripheralType } from '../../context/PeripheralContext';
import { playBarcodeBeep, playSuccessChime } from '../../utils/audio';
import { LoyaltyProgramTab } from './LoyaltyProgramTab';

export const SettingsScreen: React.FC = () => {
  const { isOnline, dbDriver, isDbConnected } = usePOS();
  const {
    barcodeConfig,
    setBarcodeConfig,
    cameraConfig,
    setCameraConfig,
    voiceConfig,
    setVoiceConfig,
    scaleConfig,
    setScaleConfig,
    printerConfig,
    setPrinterConfig,
    drawerConfig,
    setDrawerConfig,
    installPeripheral,
    uninstallPeripheral,
    togglePeripheral,
    headerVisibility,
    toggleHeaderVisibility,
    activeInstallation,
    kickOpenDrawer,
    setIsAICameraModalOpen,
    setIsAIVoiceModalOpen,
    setIsBarcodeScannerModalOpen,
    tareScale,
    zeroScale,
    connectScaleWebSerial,
    disconnectScaleWebSerial,
    refreshInstalledPrinters,
    refreshHardwareDevices,
  } = usePeripherals();

  const [activeTab, setActiveTab] = useState<PeripheralType | 'mic' | 'database' | 'loyalty'>('scale');
  const [testNotice, setTestNotice] = useState<string | null>(null);
  const [isKickingDrawer, setIsKickingDrawer] = useState(false);

  const handleInstall = async (type: PeripheralType) => {
    const success = await installPeripheral(type);
    if (success) {
      setTestNotice(`✓ Hardware peripheral verified and installed successfully! Now active in top navigation.`);
      setTimeout(() => setTestNotice(null), 4000);
    }
  };

  const handleUninstall = (type: PeripheralType) => {
    if (!confirm(`Are you sure you want to uninstall and disable this ${type.toUpperCase()} peripheral configuration?`)) {
      return;
    }
    uninstallPeripheral(type);
    setTestNotice(`✓ Peripheral switched off and removed from top navigation.`);
    setTimeout(() => setTestNotice(null), 3000);
  };

  const handleToggle = (type: PeripheralType) => {
    togglePeripheral(type);
    const targetState = 
      type === 'camera' ? !cameraConfig.enabled :
      type === 'voice' ? !voiceConfig.enabled :
      type === 'scanner' ? !barcodeConfig.enabled :
      type === 'scale' ? !scaleConfig.enabled :
      type === 'printer' ? !printerConfig.enabled :
      !drawerConfig.enabled;
    
    setTestNotice(targetState 
      ? `✓ Peripheral switched ON (Icon now visible in header)`
      : `✓ Peripheral switched OFF (Icon removed from header)`
    );
    setTimeout(() => setTestNotice(null), 3000);
  };

  const handleTestDrawerKick = () => {
    setIsKickingDrawer(true);
    kickOpenDrawer();
    setTestNotice(`✓ Cash drawer solenoid pulse fired (${drawerConfig.drawerPulseCode}) via ${drawerConfig.connectedVia}!`);
    setTimeout(() => {
      setIsKickingDrawer(false);
    }, 800);
    setTimeout(() => {
      setTestNotice(null);
    }, 4000);
  };

  const handleTestPrinter = () => {
    playSuccessChime();
    window.print();
    setTestNotice(`✓ Test receipt sent to ${printerConfig.printerType === 'ESC_POS_80MM' ? '80mm Thermal Printer' : printerConfig.printerType === 'ESC_POS_58MM' ? '58mm Thermal Printer' : 'System Print Dialog'}`);
    setTimeout(() => setTestNotice(null), 3500);
  };

  const installedCount = [
    cameraConfig.enabled,
    voiceConfig.enabled,
    barcodeConfig.enabled,
    scaleConfig.enabled,
    printerConfig.enabled,
    drawerConfig.enabled,
  ].filter(Boolean).length;

  return (
    <div className="flex-1 w-full h-full min-h-0 bg-[#F4F4F5] p-4 lg:p-8 pb-24 overflow-y-auto flex flex-col gap-6 font-sans">
      {/* Test Notice Toast */}
      {testNotice && (
        <div className="fixed top-16 right-6 z-50 bg-[#09090B] text-white px-4 py-2.5 rounded-lg shadow-xl text-xs font-bold flex items-center gap-2 border border-gray-700 animate-in fade-in slide-in-from-top-3">
          <span className="material-symbols-outlined text-[18px] text-emerald-400">check_circle</span>
          <span>{testNotice}</span>
        </div>
      )}

      {/* Installation Modal / In-flight Progress Overlay */}
      {activeInstallation && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-gray-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                activeInstallation.status === 'failed'
                  ? 'bg-red-100 text-red-700'
                  : activeInstallation.status === 'success'
                  ? 'bg-emerald-100 text-emerald-700'
                  : 'bg-blue-100 text-[#00478c]'
              }`}>
                {activeInstallation.status === 'installing' || activeInstallation.status === 'verifying' ? (
                  <span className="material-symbols-outlined text-[28px] animate-spin">sync</span>
                ) : activeInstallation.status === 'success' ? (
                  <span className="material-symbols-outlined text-[28px]">check_circle</span>
                ) : (
                  <span className="material-symbols-outlined text-[28px]">error</span>
                )}
              </div>
              <div>
                <h3 className="font-black text-base text-[#09090B] capitalize">
                  {activeInstallation.status === 'installing' && `Connecting ${activeInstallation.type}...`}
                  {activeInstallation.status === 'verifying' && `Verifying Hardware Handshake...`}
                  {activeInstallation.status === 'success' && `Peripheral Installed & Verified!`}
                  {activeInstallation.status === 'failed' && `Installation Failed`}
                </h3>
                <p className="text-xs text-gray-500">
                  Hardware Diagnostic &amp; Device Pairing Flow
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden mb-3">
              <div
                className={`h-full transition-all duration-300 ${
                  activeInstallation.status === 'failed'
                    ? 'bg-red-600'
                    : activeInstallation.status === 'success'
                    ? 'bg-emerald-600'
                    : 'bg-[#00478c]'
                }`}
                style={{ width: `${activeInstallation.progressPercent}%` }}
              ></div>
            </div>

            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 text-xs font-mono text-gray-700 flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-gray-400">terminal</span>
              <span className="truncate">{activeInstallation.step}</span>
            </div>

            <div className="mt-4 text-[11px] text-gray-500 text-center">
              The peripheral icon will be automatically applied to the header bar upon verified handshake.
            </div>
          </div>
        </div>
      )}

      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-[#D4D4D8] shadow-xs">
        <div>
          <h1 className="text-2xl font-black text-[#09090B] flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[#00478c] text-[28px]">devices</span>
            <span>POS Hardware &amp; Peripherals Configuration</span>
          </h1>
          <p className="text-xs text-[#5c403c] mt-1">
            Install and configure peripheral devices in your browser. Use the header switches to customize which active icons appear in the top bar.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 bg-blue-50 border border-blue-200 text-[#00478c] rounded text-xs font-bold flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px]">check_circle</span>
            <span>{installedCount} of 6 Peripherals Installed</span>
          </span>
          <button
            type="button"
            onClick={async () => {
              await refreshHardwareDevices();
              playSuccessChime();
              setTestNotice('✓ Refreshed connected USB & Media Peripherals');
              setTimeout(() => setTestNotice(null), 3000);
            }}
            className="px-3.5 py-2 bg-white hover:bg-gray-100 border border-gray-300 text-gray-700 rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <span className="material-symbols-outlined text-[16px]">refresh</span>
            <span>Rescan Devices</span>
          </button>
        </div>
      </div>

      {/* Quick Installation & Fleet Control Grid */}
      <div className="bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-xs">
        <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[16px] text-[#00478c]">check_box</span>
            <span>Hardware Devices &amp; Header Visibility Controls</span>
          </div>
          <span className="text-[11px] text-gray-400 lowercase font-normal">Check box to show/hide icon in top header</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
          {/* Camera (Paused / Later) */}
          <div className="p-3.5 rounded-xl border border-gray-200 bg-gray-50 opacity-40 grayscale flex flex-col justify-between gap-3 select-none cursor-not-allowed">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="material-symbols-outlined text-[20px] text-gray-400">photo_camera</span>
                <span className="font-bold text-xs text-gray-500 whitespace-nowrap">1. AI Camera</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 font-bold uppercase">Paused</span>
            </div>
            <div className="text-[11px] font-medium text-gray-400">
              Feature paused for later release
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-semibold text-gray-400">Unavailable</span>
            </div>
          </div>

          {/* Voice (Paused / Later) */}
          <div className="p-3.5 rounded-xl border border-gray-200 bg-gray-50 opacity-40 grayscale flex flex-col justify-between gap-3 select-none cursor-not-allowed">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="material-symbols-outlined text-[20px] text-gray-400">mic</span>
                <span className="font-bold text-xs text-gray-500 whitespace-nowrap">2. AI Voice</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 font-bold uppercase">Paused</span>
            </div>
            <div className="text-[11px] font-medium text-gray-400">
              Feature paused for later release
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-semibold text-gray-400">Unavailable</span>
            </div>
          </div>

          {/* Barcode Scanner */}
          <div 
            onClick={() => setActiveTab('scanner')}
            className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all cursor-pointer ${
              activeTab === 'scanner'
                ? 'border-blue-500 bg-sky-50/90 shadow-md ring-2 ring-sky-400/50'
                : 'border-gray-200 bg-gray-50 hover:bg-gray-100'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`material-symbols-outlined text-[20px] shrink-0 ${barcodeConfig.enabled ? 'text-blue-700' : 'text-gray-400'}`}>qr_code_scanner</span>
                <span className="font-bold text-xs text-[#09090B] whitespace-nowrap" title="3. Scanner">3. Scanner</span>
              </div>
              <label 
                className="flex items-center cursor-pointer select-none shrink-0 p-1 bg-white hover:bg-blue-50 rounded-md border border-gray-200 shadow-2xs hover:border-blue-500 transition-colors"
                title="Toggle Barcode Scanner in top header"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={headerVisibility.scanner}
                  onChange={() => toggleHeaderVisibility('scanner')}
                  className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer accent-blue-600"
                />
              </label>
            </div>
            <div className="text-[11px] font-medium space-y-0.5">
              <div className="flex items-center gap-1">
                <span className="text-blue-700 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                  Installed
                </span>
              </div>
              <div className="text-[10px] text-gray-500">
                {headerVisibility.scanner ? '🟢 Icon Visible' : '⚪ Icon Hidden'}
              </div>
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-bold text-blue-700">Click to Configure &rarr;</span>
            </div>
          </div>

          {/* Weighing Scale */}
          <div 
            onClick={() => setActiveTab('scale')}
            className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all cursor-pointer ${
              activeTab === 'scale'
                ? 'border-teal-600 bg-teal-50 shadow-md ring-2 ring-teal-400/50'
                : 'border-teal-300 bg-teal-50/50 hover:bg-teal-50'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`material-symbols-outlined text-[20px] shrink-0 ${scaleConfig.enabled ? 'text-teal-700' : 'text-gray-400'}`}>scale</span>
                <span className="font-bold text-xs text-[#09090B] whitespace-nowrap" title="4. Scale">4. Scale</span>
              </div>
              <label 
                className="flex items-center cursor-pointer select-none shrink-0 p-1 bg-white hover:bg-teal-50 rounded-md border border-gray-200 shadow-2xs hover:border-teal-500 transition-colors"
                title="Toggle Scale readout in top header"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={headerVisibility.scale}
                  onChange={() => toggleHeaderVisibility('scale')}
                  className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500 cursor-pointer accent-teal-600"
                />
              </label>
            </div>
            <div className="text-[11px] font-medium space-y-0.5">
              <div className="flex items-center gap-1">
                <span className="text-teal-700 font-bold flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-full ${scaleConfig.isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-teal-500'}`}></span>
                  {scaleConfig.isConnected ? 'Live Streaming' : 'Installed'}
                </span>
              </div>
              <div className="text-[10px] text-gray-500">
                {headerVisibility.scale ? '🟢 Icon Visible' : '⚪ Icon Hidden'}
              </div>
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-bold text-teal-700">Click for Baud &amp; Setup &rarr;</span>
            </div>
          </div>

          {/* Printer */}
          <div 
            onClick={() => setActiveTab('printer')}
            className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all cursor-pointer ${
              activeTab === 'printer'
                ? 'border-[#00478c] bg-blue-50 shadow-md ring-2 ring-blue-400/50'
                : 'border-blue-300 bg-blue-50/50 hover:bg-blue-50'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`material-symbols-outlined text-[20px] shrink-0 ${printerConfig.enabled ? 'text-[#00478c]' : 'text-gray-400'}`}>print</span>
                <span className="font-bold text-xs text-[#09090B] whitespace-nowrap" title="5. Printer">5. Printer</span>
              </div>
              <label 
                className="flex items-center cursor-pointer select-none shrink-0 p-1 bg-white hover:bg-blue-50 rounded-md border border-gray-200 shadow-2xs hover:border-[#00478c] transition-colors"
                title="Toggle Printer in top header"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={headerVisibility.printer}
                  onChange={() => toggleHeaderVisibility('printer')}
                  className="w-4 h-4 rounded border-gray-300 text-[#00478c] focus:ring-blue-500 cursor-pointer accent-[#00478c]"
                />
              </label>
            </div>
            <div className="text-[11px] font-medium space-y-0.5">
              <div className="flex items-center gap-1">
                <span className="text-[#00478c] font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#00478c] animate-pulse"></span>
                  Installed
                </span>
              </div>
              <div className="text-[10px] text-gray-500">
                {headerVisibility.printer ? '🟢 Icon Visible' : '⚪ Icon Hidden'}
              </div>
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-bold text-[#00478c]">Click for Printer Drivers &rarr;</span>
            </div>
          </div>

          {/* Cash Drawer (Paused / Later) */}
          <div className="p-3.5 rounded-xl border border-gray-200 bg-gray-50 opacity-40 grayscale flex flex-col justify-between gap-3 select-none cursor-not-allowed">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="material-symbols-outlined text-[20px] text-gray-400">point_of_sale</span>
                <span className="font-bold text-xs text-gray-500 whitespace-nowrap">6. Drawer</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 font-bold uppercase">Paused</span>
            </div>
            <div className="text-[11px] font-medium text-gray-400">
              Hardware pulse trigger paused
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-semibold text-gray-400">Unavailable</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-gray-300 gap-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('scale')}
          className={`px-4 py-2.5 font-bold text-xs flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'scale'
              ? 'border-[#00478c] text-[#00478c] bg-white rounded-t-lg shadow-xs'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">scale</span>
          <span>4. Weighing Scale (Baud Setup &amp; Live Stream)</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${scaleConfig.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'}`}>
            {scaleConfig.enabled ? 'Installed' : 'Not Installed'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('printer')}
          className={`px-4 py-2.5 font-bold text-xs flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'printer'
              ? 'border-[#00478c] text-[#00478c] bg-white rounded-t-lg shadow-xs'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">print</span>
          <span>5. Receipt Printer (Installed Windows Printers)</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${printerConfig.enabled ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-500'}`}>
            {printerConfig.enabled ? 'Installed' : 'Not Installed'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('scanner')}
          className={`px-4 py-2.5 font-bold text-xs flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'scanner'
              ? 'border-[#00478c] text-[#00478c] bg-white rounded-t-lg shadow-xs'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">qr_code_scanner</span>
          <span>3. Barcode Scanner</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${barcodeConfig.enabled ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-500'}`}>
            {barcodeConfig.enabled ? 'Installed' : 'Not Installed'}
          </span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="bg-white border border-[#D4D4D8] rounded-xl p-6 shadow-xs space-y-6">

        {/* TAB 1: AI CAMERA VISION */}
        {activeTab === 'camera' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              cameraConfig.enabled ? 'bg-emerald-50/70 border-emerald-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  cameraConfig.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">photo_camera</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {cameraConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.camera ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {cameraConfig.enabled ? 'AI Vision produce scanner device is verified and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.camera}
                    onChange={() => toggleHeaderVisibility('camera')}
                    className="w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (cameraConfig.enabled ? handleUninstall('camera') : handleInstall('camera'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    cameraConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {cameraConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{cameraConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-emerald-700">photo_camera</span>
                  <span>AI Visual Produce &amp; Object Recognition Camera</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Powered by Gemini 3.7 Flash Multimodal for unbarcoded vegetables, fruits, grains &amp; packaged items
                </p>
              </div>

              {cameraConfig.enabled && (
                <button
                  type="button"
                  onClick={() => setIsAICameraModalOpen(true)}
                  className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <span className="material-symbols-outlined text-[16px]">videocam</span>
                  <span>Open Camera Viewfinder [F2]</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  CAMERA VIDEO SOURCE
                </label>
                <select
                  value={cameraConfig.deviceId}
                  onChange={(e) => setCameraConfig((prev) => ({ ...prev, deviceId: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  {cameraConfig.availableDevices.length === 0 ? (
                    <option value="">Default Web Camera / Built-in</option>
                  ) : (
                    cameraConfig.availableDevices.map((d) => (
                      <option key={d.deviceId} value={d.deviceId}>
                        {d.label}
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  STREAM RESOLUTION PRESET
                </label>
                <select
                  value={cameraConfig.resolution}
                  onChange={(e: any) => setCameraConfig((prev) => ({ ...prev, resolution: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  <option value="720p">720p HD (Fastest AI Recognition)</option>
                  <option value="1080p">1080p Full HD (High Clarity)</option>
                  <option value="480p">480p Standard (Low Bandwidth)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  MINIMUM AI CONFIDENCE THRESHOLD ({cameraConfig.confidenceThreshold}%)
                </label>
                <input
                  type="range"
                  min="50"
                  max="95"
                  step="5"
                  value={cameraConfig.confidenceThreshold}
                  onChange={(e) =>
                    setCameraConfig((prev) => ({ ...prev, confidenceThreshold: parseInt(e.target.value) || 75 }))
                  }
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-700"
                />
                <div className="flex justify-between text-[11px] text-gray-500 mt-1">
                  <span>50% (Loose Matching)</span>
                  <span className="font-bold text-emerald-700">{cameraConfig.confidenceThreshold}%</span>
                  <span>95% (Exact Only)</span>
                </div>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={cameraConfig.autoAddWithScaleWeight}
                    onChange={(e) =>
                      setCameraConfig((prev) => ({ ...prev, autoAddWithScaleWeight: e.target.checked }))
                    }
                    className="w-4 h-4 text-emerald-700 rounded border-gray-300 focus:ring-emerald-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auto-Apply Live Scale Weight</div>
                    <div className="text-[11px] text-gray-500">
                      Instantly calculate subtotal using active RS-232 digital scale weight on recognition
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AI VOICE & MIC */}
        {(activeTab === 'voice' || activeTab === 'mic') && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              voiceConfig.enabled ? 'bg-purple-50/70 border-purple-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  voiceConfig.enabled ? 'bg-purple-100 text-purple-800' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">mic</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {voiceConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.voice ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {voiceConfig.enabled ? 'AI Voice & Speech input device is configured and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.voice}
                    onChange={() => toggleHeaderVisibility('voice')}
                    className="w-4 h-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500 cursor-pointer accent-purple-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (voiceConfig.enabled ? handleUninstall('voice') : handleInstall('voice'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    voiceConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-purple-700 hover:bg-purple-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {voiceConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{voiceConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-purple-700">mic</span>
                  <span>Multilingual Voice &amp; Microphone Input</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Natural speech-to-cart parsing in English, Hindi, Tamil, Telugu, Marathi &amp; Hinglish
                </p>
              </div>

              {voiceConfig.enabled && (
                <button
                  type="button"
                  onClick={() => setIsAIVoiceModalOpen(true)}
                  className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <span className="material-symbols-outlined text-[16px]">record_voice_over</span>
                  <span>Open Voice Modal [F3]</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  MICROPHONE AUDIO INPUT DEVICE
                </label>
                <select
                  value={voiceConfig.deviceId}
                  onChange={(e) => setVoiceConfig((prev) => ({ ...prev, deviceId: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  {voiceConfig.availableDevices.length === 0 ? (
                    <option value="">Default System Microphone</option>
                  ) : (
                    voiceConfig.availableDevices.map((d) => (
                      <option key={d.deviceId} value={d.deviceId}>
                        {d.label}
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  PRIMARY LANGUAGE / ACCENT MODEL
                </label>
                <select
                  value={voiceConfig.language}
                  onChange={(e) => setVoiceConfig((prev) => ({ ...prev, language: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  <option value="auto">Auto Detect (English / Hindi / Regional)</option>
                  <option value="en-IN">Indian English (en-IN)</option>
                  <option value="hi-IN">Hindi (हिन्दी - hi-IN)</option>
                  <option value="ta-IN">Tamil (தமிழ் - ta-IN)</option>
                  <option value="te-IN">Telugu (తెలుగు - te-IN)</option>
                  <option value="mr-IN">Marathi (मराठी - mr-IN)</option>
                </select>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={voiceConfig.autoExecuteHighConfidence}
                    onChange={(e) =>
                      setVoiceConfig((prev) => ({ ...prev, autoExecuteHighConfidence: e.target.checked }))
                    }
                    className="w-4 h-4 text-purple-700 rounded border-gray-300 focus:ring-purple-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auto Add High-Confidence Items</div>
                    <div className="text-[11px] text-gray-500">
                      Directly add matched SKU to cart if speech transcription confidence exceeds 85%
                    </div>
                  </div>
                </label>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={voiceConfig.beepOnVoiceCommand}
                    onChange={(e) =>
                      setVoiceConfig((prev) => ({ ...prev, beepOnVoiceCommand: e.target.checked }))
                    }
                    className="w-4 h-4 text-purple-700 rounded border-gray-300 focus:ring-purple-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auditory Confirmation Chime</div>
                    <div className="text-[11px] text-gray-500">
                      Play pleasant audio chime when voice command successfully adds items to cart
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: BARCODE & QR SCANNER */}
        {activeTab === 'scanner' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              barcodeConfig.enabled ? 'bg-blue-50/70 border-blue-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  barcodeConfig.enabled ? 'bg-blue-100 text-blue-800' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">qr_code_scanner</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {barcodeConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.scanner ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {barcodeConfig.enabled ? 'Barcode & QR Scanner hardware device is verified and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.scanner}
                    onChange={() => toggleHeaderVisibility('scanner')}
                    className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer accent-blue-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (barcodeConfig.enabled ? handleUninstall('scanner') : handleInstall('scanner'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    barcodeConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-blue-700 hover:bg-blue-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {barcodeConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{barcodeConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-blue-700">qr_code_scanner</span>
                  <span>1D/2D Barcode &amp; QR Code Hardware Scanner</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  USB Keyboard Wedge (HID), Bluetooth RS-232, and Camera QR Decoder configuration
                </p>
              </div>

              {barcodeConfig.enabled && (
                <button
                  type="button"
                  onClick={() => setIsBarcodeScannerModalOpen(true)}
                  className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <span className="material-symbols-outlined text-[16px]">barcode_scanner</span>
                  <span>Open Scanner Diagnostics [F4]</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  SCANNER INTERFACE PROTOCOL
                </label>
                <select
                  value={barcodeConfig.mode}
                  onChange={(e: any) => setBarcodeConfig((prev) => ({ ...prev, mode: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  <option value="KEYBOARD_WEDGE">USB Keyboard Wedge / HID Emulation (Universal)</option>
                  <option value="SERIAL_HID">WebSerial / Bluetooth RS-232 Scanner</option>
                  <option value="CAMERA_BARCODE">Built-in Device Web Camera Scanner</option>
                  <option value="MANUAL">Manual Keyboard SKU Input Only</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  TERMINATOR SUFFIX KEY
                </label>
                <select
                  value={barcodeConfig.suffix}
                  onChange={(e: any) => setBarcodeConfig((prev) => ({ ...prev, suffix: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  <option value="Enter">Enter / Carriage Return (Standard CR+LF)</option>
                  <option value="Tab">Tab Key</option>
                  <option value="None">None (Fixed character length scan)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  MINIMUM BARCODE DIGIT LENGTH
                </label>
                <input
                  type="number"
                  min="3"
                  max="18"
                  value={barcodeConfig.minBarcodeLength}
                  onChange={(e) =>
                    setBarcodeConfig((prev) => ({ ...prev, minBarcodeLength: parseInt(e.target.value) || 4 }))
                  }
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                />
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={barcodeConfig.beepOnScan}
                    onChange={(e) => setBarcodeConfig((prev) => ({ ...prev, beepOnScan: e.target.checked }))}
                    className="w-4 h-4 text-blue-700 rounded border-gray-300 focus:ring-blue-500"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">WebAudio 2.4kHz Scan Beep</div>
                    <div className="text-[11px] text-gray-500">
                      Play instant crisp high-pitch barcode beep on successful scan
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: WEIGHING SCALE */}
        {activeTab === 'scale' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              scaleConfig.enabled ? 'bg-teal-50/70 border-teal-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  scaleConfig.enabled ? 'bg-teal-100 text-teal-800' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">scale</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {scaleConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.scale ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {scaleConfig.enabled ? 'Live digital scale weight badge is configured and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.scale}
                    onChange={() => toggleHeaderVisibility('scale')}
                    className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500 cursor-pointer accent-teal-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (scaleConfig.enabled ? handleUninstall('scale') : handleInstall('scale'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    scaleConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-teal-700 hover:bg-teal-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {scaleConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{scaleConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-3 gap-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-teal-700">scale</span>
                  <span>RS-232 Digital Scale Integration &amp; Baud Setup</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Connect commercial retail scales (Essae, CAS, Phoenix, Fairbanks, Toledo) via RS-232 / USB Serial
                </p>
              </div>

              {scaleConfig.enabled && (
                <div className="flex items-center gap-2">
                  {scaleConfig.isConnected ? (
                    <button
                      type="button"
                      onClick={disconnectScaleWebSerial}
                      className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
                    >
                      <span className="material-symbols-outlined text-[16px]">link_off</span>
                      <span>Disconnect Scale</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={connectScaleWebSerial}
                      className="px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
                    >
                      <span className="material-symbols-outlined text-[16px]">usb</span>
                      <span>Connect Scale (WebSerial)</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Scale Connection Status Banner */}
            <div className={`p-3 rounded-xl border text-xs flex items-center justify-between transition-colors ${
              scaleConfig.isConnected
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-2xs'
                : 'bg-gray-50 border-gray-200 text-gray-700'
            }`}>
              <div className="flex items-center gap-2.5">
                <span className={`w-3 h-3 rounded-full shrink-0 ${scaleConfig.isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-gray-400'}`} />
                <div>
                  <span className="font-bold block text-xs">
                    {scaleConfig.isConnected ? 'Scale Hardware Connected & Streaming Live Weight' : 'Scale Not Connected to Browser Serial'}
                  </span>
                  <span className="text-[11px] text-gray-500 block">
                    {scaleConfig.isConnected
                      ? `Reading serial ASCII stream on ${scaleConfig.port || 'USB Serial'} at ${scaleConfig.baudRate} baud`
                      : 'Click "Connect Scale (WebSerial)" above to choose your COM port'}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-gray-500 uppercase font-semibold block">Active Weight</span>
                <span className="font-mono font-black text-base text-emerald-700">
                  {scaleConfig.currentWeight.toFixed(3)} {scaleConfig.unit}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  SERIAL PORT / DEVICE NAME
                </label>
                <input
                  type="text"
                  value={scaleConfig.serialPortName || scaleConfig.port}
                  onChange={(e) => setScaleConfig((prev) => ({ ...prev, port: e.target.value }))}
                  placeholder="e.g. COM1 or USB-Serial CH340"
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-teal-600 font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  BAUD RATE (BPS)
                </label>
                <select
                  value={scaleConfig.baudRate}
                  onChange={(e) => setScaleConfig((prev) => ({ ...prev, baudRate: parseInt(e.target.value) || 9600 }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 font-bold focus:outline-none focus:border-teal-600"
                >
                  <option value="1200">1200 bps</option>
                  <option value="2400">2400 bps</option>
                  <option value="4800">4800 bps</option>
                  <option value="9600">9600 bps (Standard Retail Scale Default)</option>
                  <option value="19200">19200 bps</option>
                  <option value="38400">38400 bps</option>
                  <option value="57600">57600 bps</option>
                  <option value="115200">115200 bps (High Speed USB-Serial)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  TEST / OVERRIDE WEIGHT (KG)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    value={scaleConfig.currentWeight}
                    onChange={(e) =>
                      setScaleConfig((prev) => ({ ...prev, currentWeight: parseFloat(e.target.value) || 0 }))
                    }
                    className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 font-bold focus:outline-none focus:border-teal-600"
                  />
                  <span className="text-xs font-bold text-gray-600">kg</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: RECEIPT PRINTER (INDEPENDENT) */}
        {activeTab === 'printer' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              printerConfig.enabled ? 'bg-blue-50/70 border-blue-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  printerConfig.enabled ? 'bg-blue-100 text-[#00478c]' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">print</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {printerConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.printer ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {printerConfig.enabled ? 'Thermal printer test trigger is configured and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.printer}
                    onChange={() => toggleHeaderVisibility('printer')}
                    className="w-4 h-4 rounded border-gray-300 text-[#00478c] focus:ring-blue-500 cursor-pointer accent-[#00478c]"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (printerConfig.enabled ? handleUninstall('printer') : handleInstall('printer'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    printerConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-[#00478c] hover:bg-[#005eb7] text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {printerConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{printerConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-3 gap-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00478c]">print</span>
                  <span>ESC/POS Thermal Receipt Printer Configuration</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  High-speed 250mm/s direct thermal receipt generation, paper cut codes, header/footer branding &amp; GST tax summaries
                </p>
              </div>

              {printerConfig.enabled && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTestPrinter}
                    className="px-3.5 py-2 bg-[#00478c] hover:bg-[#005eb7] text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
                  >
                    <span className="material-symbols-outlined text-[16px]">receipt_long</span>
                    <span>Test Print Receipt</span>
                  </button>
                </div>
              )}
            </div>

            {/* Installed Windows Printers Selector */}
            <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-label-caps text-[#00478c] font-bold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[17px]">print</span>
                  <span>SELECT INSTALLED PRINTER (WINDOWS)</span>
                </label>
                <button
                  type="button"
                  onClick={refreshInstalledPrinters}
                  className="text-xs text-[#00478c] hover:underline flex items-center gap-1 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[14px]">refresh</span>
                  <span>Refresh Printers List</span>
                </button>
              </div>

              <select
                value={printerConfig.selectedPrinterName || ''}
                onChange={(e) => setPrinterConfig((prev) => ({ ...prev, selectedPrinterName: e.target.value }))}
                className="w-full h-10 border border-blue-300 rounded px-3 text-xs bg-white text-gray-900 font-bold focus:outline-none focus:ring-1 focus:ring-[#00478c]"
              >
                {printerConfig.installedPrinters && printerConfig.installedPrinters.length > 0 ? (
                  printerConfig.installedPrinters.map((p) => (
                    <option key={p.name} value={p.name}>
                      {p.name} {p.isDefault ? '(System Default)' : ''} {p.port ? `• [Port: ${p.port}]` : ''}
                    </option>
                  ))
                ) : (
                  <option value="System Default Printer">System Default Printer</option>
                )}
              </select>
              <p className="text-[11px] text-gray-500">
                Receipts will be printed through this installed printer driver when finalizing billing.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  THERMAL PAPER ROLL SPECIFICATION
                </label>
                <select
                  value={printerConfig.printerType}
                  onChange={(e: any) => setPrinterConfig((prev) => ({ ...prev, printerType: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  <option value="ESC_POS_80MM">80mm High-Density Thermal Roll (Standard Retail - 48 Cols)</option>
                  <option value="ESC_POS_58MM">58mm Compact Mobile Thermal Roll (32 Cols)</option>
                  <option value="BROWSER_PRINT">Browser Native Print Dialog</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  CONNECTION INTERFACE
                </label>
                <select
                  value={printerConfig.connectionInterface}
                  onChange={(e: any) => setPrinterConfig((prev) => ({ ...prev, connectionInterface: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#00478c]"
                >
                  <option value="USB_RAW">USB Direct Raw (ESC/POS WinUSB / Linux lp0)</option>
                  <option value="NETWORK_IP">Ethernet LAN / Wi-Fi Raw Socket (Port 9100)</option>
                  <option value="BLUETOOTH">Bluetooth Thermal SPP / BLE</option>
                  <option value="SYSTEM_PRINT">Standard OS Print Spooler</option>
                </select>
              </div>

              {printerConfig.connectionInterface === 'NETWORK_IP' && (
                <>
                  <div>
                    <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                      PRINTER IP ADDRESS
                    </label>
                    <input
                      type="text"
                      value={printerConfig.ipAddress}
                      onChange={(e) => setPrinterConfig((prev) => ({ ...prev, ipAddress: e.target.value }))}
                      className="w-full h-10 border border-gray-300 rounded px-3 text-xs font-mono bg-white text-gray-900 focus:outline-none"
                      placeholder="192.168.1.100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                      RAW TCP PORT
                    </label>
                    <input
                      type="number"
                      value={printerConfig.port}
                      onChange={(e) => setPrinterConfig((prev) => ({ ...prev, port: parseInt(e.target.value) || 9100 }))}
                      className="w-full h-10 border border-gray-300 rounded px-3 text-xs font-mono bg-white text-gray-900 focus:outline-none"
                      placeholder="9100"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  DEFAULT RECEIPT COPIES
                </label>
                <select
                  value={printerConfig.printReceiptCopyCount}
                  onChange={(e) => setPrinterConfig((prev) => ({ ...prev, printReceiptCopyCount: parseInt(e.target.value) || 1 }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                >
                  <option value="1">1 Copy (Customer Invoice)</option>
                  <option value="2">2 Copies (Customer + Store Copy)</option>
                  <option value="3">3 Copies (Customer + Store + Accounts)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  RECEIPT HEADER STORE TITLE
                </label>
                <input
                  type="text"
                  value={printerConfig.headerText}
                  onChange={(e) => setPrinterConfig((prev) => ({ ...prev, headerText: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                  placeholder="e.g. ENTER STORE NAME"
                />
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  RECEIPT FOOTER / GREETING MESSAGE
                </label>
                <input
                  type="text"
                  value={printerConfig.footerText}
                  onChange={(e) => setPrinterConfig((prev) => ({ ...prev, footerText: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                  placeholder="Thank you for shopping with us!"
                />
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={printerConfig.autoCut}
                    onChange={(e) => setPrinterConfig((prev) => ({ ...prev, autoCut: e.target.checked }))}
                    className="w-4 h-4 text-[#00478c] rounded border-gray-300 focus:ring-[#00478c]"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Automatic Paper Guillotine Cut</div>
                    <div className="text-[11px] text-gray-500">
                      Send ESC/POS cut sequence (GS V 66 0) at receipt end
                    </div>
                  </div>
                </label>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={printerConfig.printGstSummary}
                    onChange={(e) => setPrinterConfig((prev) => ({ ...prev, printGstSummary: e.target.checked }))}
                    className="w-4 h-4 text-[#00478c] rounded border-gray-300 focus:ring-[#00478c]"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Print GST &amp; HSN Tax Summary Table</div>
                    <div className="text-[11px] text-gray-500">
                      Include CGST, SGST &amp; IGST tax slab breakdowns on invoice
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CASH DRAWER (INDEPENDENT) */}
        {activeTab === 'drawer' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              drawerConfig.enabled ? 'bg-red-50/70 border-red-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  drawerConfig.enabled ? 'bg-red-100 text-[#950008]' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">point_of_sale</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {drawerConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.drawer ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {drawerConfig.enabled ? 'Cash drawer solenoid kick trigger is configured and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.drawer}
                    onChange={() => toggleHeaderVisibility('drawer')}
                    className="w-4 h-4 rounded border-gray-300 text-red-600 focus:ring-red-500 cursor-pointer accent-red-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (drawerConfig.enabled ? handleUninstall('drawer') : handleInstall('drawer'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    drawerConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-[#950008] hover:bg-red-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {drawerConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{drawerConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-3 gap-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#950008]">point_of_sale</span>
                  <span>Cash Drawer Solenoid &amp; Kick Configuration</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Configure 24V/12V cash drawer solenoid kick signals, RJ11 drive pins, auto-open triggers and manual keyboard shortcuts
                </p>
              </div>

              {drawerConfig.enabled && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTestDrawerKick}
                    disabled={isKickingDrawer}
                    className={`px-4 py-2 bg-[#950008] hover:bg-[#bd1616] text-white rounded font-bold text-xs flex items-center gap-2 cursor-pointer shadow-xs transition-all ${
                      isKickingDrawer ? 'ring-4 ring-red-300 scale-95' : ''
                    }`}
                  >
                    <span className="material-symbols-outlined text-[17px]">
                      {isKickingDrawer ? 'lock_open' : 'key'}
                    </span>
                    <span>{isKickingDrawer ? 'Kicking Solenoid...' : 'Kick Open Drawer [F8]'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Diagnostic Status Box */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-[#950008]">
                  <span className="material-symbols-outlined text-[22px]">inbox</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-900">Solenoid Circuit Status: {drawerConfig.enabled ? 'Ready / Armed' : 'Disabled'}</div>
                  <div className="text-[11px] text-gray-600">
                    Last pulse triggered:{' '}
                    {drawerConfig.lastKickedTime > 0
                      ? new Date(drawerConfig.lastKickedTime).toLocaleTimeString()
                      : 'Not yet fired in this session'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-bold ${
                  drawerConfig.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-600'
                }`}>
                  <span className={`w-2 h-2 rounded-full mr-1.5 ${drawerConfig.enabled ? 'bg-emerald-500 animate-pulse' : 'bg-gray-400'}`}></span>
                  {drawerConfig.enabled ? '24V Solenoid Armed' : 'Solenoid Disarmed'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  CONNECTION INTERFACE
                </label>
                <select
                  value={drawerConfig.connectedVia}
                  onChange={(e: any) => setDrawerConfig((prev) => ({ ...prev, connectedVia: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#950008]"
                >
                  <option value="PRINTER_RJ11">Printer DK Port (RJ-11 / 6-Pin Solenoid)</option>
                  <option value="USB_RELAY">Dedicated USB Cash Drawer Relay / Trigger Box</option>
                  <option value="SERIAL_COM">RS-232 Serial COM Port Kick Trigger</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  SOLENOID PULSE COMMAND (ESC/POS)
                </label>
                <input
                  type="text"
                  value={drawerConfig.drawerPulseCode}
                  onChange={(e) => setDrawerConfig((prev) => ({ ...prev, drawerPulseCode: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs font-mono bg-white text-gray-900 focus:outline-none focus:border-[#950008]"
                  placeholder="ESC p 0 25 250"
                />
                <span className="text-[10px] text-gray-500 mt-0.5 block">
                  Standard 24V pulse: ESC p 0 25 250 (ASCII: 27 112 0 25 250)
                </span>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  RJ-11 DRIVE PIN NUMBER
                </label>
                <select
                  value={drawerConfig.pinNumber}
                  onChange={(e: any) => setDrawerConfig((prev) => ({ ...prev, pinNumber: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                >
                  <option value="Pin 2 (Standard)">Pin 2 (Standard ESC/POS Drive 1)</option>
                  <option value="Pin 5">Pin 5 (Secondary ESC/POS Drive 2)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  SOLENOID PULSE DURATION (MS)
                </label>
                <input
                  type="number"
                  step="50"
                  min="50"
                  max="500"
                  value={drawerConfig.pulseDurationMs}
                  onChange={(e) =>
                    setDrawerConfig((prev) => ({ ...prev, pulseDurationMs: parseInt(e.target.value) || 250 }))
                  }
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                />
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={drawerConfig.autoOpenOnCashPayment}
                    onChange={(e) =>
                      setDrawerConfig((prev) => ({ ...prev, autoOpenOnCashPayment: e.target.checked }))
                    }
                    className="w-4 h-4 text-[#950008] rounded border-gray-300 focus:ring-[#950008]"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auto-Open on 100% Cash Settlement</div>
                    <div className="text-[11px] text-gray-500">
                      Automatically fire solenoid trigger whenever a cash sale is completed
                    </div>
                  </div>
                </label>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={drawerConfig.autoOpenOnSplitTender}
                    onChange={(e) =>
                      setDrawerConfig((prev) => ({ ...prev, autoOpenOnSplitTender: e.target.checked }))
                    }
                    className="w-4 h-4 text-[#950008] rounded border-gray-300 focus:ring-[#950008]"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auto-Open on Split-Tender with Cash</div>
                    <div className="text-[11px] text-gray-500">
                      Trigger drawer kick if any portion of split payment includes cash tender
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}
      </div>

      {testNotice && (
        <div className="p-3 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-lg font-bold text-xs animate-in fade-in flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px]">check_circle</span>
          <span>{testNotice}</span>
        </div>
      )}
    </div>
  );
};

export default SettingsScreen;
