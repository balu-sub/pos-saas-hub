import React, { useState, useRef } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals, PeripheralType } from '../../context/PeripheralContext';
import { playBarcodeBeep, playSuccessChime } from '../../utils/audio';
import { LoyaltyProgramTab } from './LoyaltyProgramTab';

export const SettingsScreen: React.FC = () => {
  const { isOnline, dbDriver, isDbConnected } = usePOS();
  const {
    barcodeConfig,
    setBarcodeConfig,
    cameraConfig,
    setCameraConfig,
    voiceConfig,
    setVoiceConfig,
    scaleConfig,
    setScaleConfig,
    printerConfig,
    setPrinterConfig,
    drawerConfig,
    setDrawerConfig,
    installPeripheral,
    uninstallPeripheral,
    togglePeripheral,
    headerVisibility,
    toggleHeaderVisibility,
    activeInstallation,
    kickOpenDrawer,
    setIsAICameraModalOpen,
    setIsAIVoiceModalOpen,
    setIsBarcodeScannerModalOpen,
    tareScale,
    zeroScale,
    connectScaleWebSerial,
    disconnectScaleWebSerial,
    refreshInstalledPrinters,
    refreshHardwareDevices,
  } = usePeripherals();

  const [activeTab, setActiveTab] = useState<PeripheralType | 'mic' | 'database' | 'loyalty'>('scale');
  const [testNotice, setTestNotice] = useState<string | null>(null);
  const [isKickingDrawer, setIsKickingDrawer] = useState(false);
  const configPanelRef = useRef<HTMLDivElement>(null);

  const handleSelectPeripheral = (type: PeripheralType) => {
    setActiveTab(type);
    setTimeout(() => {
      configPanelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  const handleInstall = async (type: PeripheralType) => {
    const success = await installPeripheral(type);
    if (success) {
      setTestNotice(`✓ Hardware peripheral verified and installed successfully! Now active in top navigation.`);
      setTimeout(() => setTestNotice(null), 4000);
    }
  };

  const handleUninstall = (type: PeripheralType) => {
    if (!confirm(`Are you sure you want to uninstall and disable this ${type.toUpperCase()} peripheral configuration?`)) {
      return;
    }
    uninstallPeripheral(type);
    setTestNotice(`✓ Peripheral switched off and removed from top navigation.`);
    setTimeout(() => setTestNotice(null), 3000);
  };

  const handleToggle = (type: PeripheralType) => {
    togglePeripheral(type);
    const targetState = 
      type === 'camera' ? !cameraConfig.enabled :
      type === 'voice' ? !voiceConfig.enabled :
      type === 'scanner' ? !barcodeConfig.enabled :
      type === 'scale' ? !scaleConfig.enabled :
      type === 'printer' ? !printerConfig.enabled :
      !drawerConfig.enabled;
    
    setTestNotice(targetState 
      ? `✓ Peripheral switched ON (Icon now visible in header)`
      : `✓ Peripheral switched OFF (Icon removed from header)`
    );
    setTimeout(() => setTestNotice(null), 3000);
  };

  const handleTestDrawerKick = () => {
    setIsKickingDrawer(true);
    kickOpenDrawer();
    setTestNotice(`✓ Cash drawer solenoid pulse fired (${drawerConfig.drawerPulseCode}) via ${drawerConfig.connectedVia}!`);
    setTimeout(() => {
      setIsKickingDrawer(false);
    }, 800);
    setTimeout(() => {
      setTestNotice(null);
    }, 4000);
  };

  const handleTestPrinter = () => {
    playSuccessChime();
    window.print();
    setTestNotice(`✓ Test receipt sent to ${printerConfig.printerType === 'ESC_POS_80MM' ? '80mm Thermal Printer' : printerConfig.printerType === 'ESC_POS_58MM' ? '58mm Thermal Printer' : 'System Print Dialog'}`);
    setTimeout(() => setTestNotice(null), 3500);
  };

  const installedCount = [
    cameraConfig.enabled,
    voiceConfig.enabled,
    barcodeConfig.enabled,
    scaleConfig.enabled,
    printerConfig.enabled,
    drawerConfig.enabled,
  ].filter(Boolean).length;

  return (
    <div className="flex-1 w-full h-full min-h-0 bg-[#F4F4F5] p-4 lg:p-8 pb-24 overflow-y-auto flex flex-col gap-6 font-sans">
      {/* Test Notice Toast */}
      {testNotice && (
        <div className="fixed top-16 right-6 z-50 bg-[#09090B] text-white px-4 py-2.5 rounded-lg shadow-xl text-xs font-bold flex items-center gap-2 border border-gray-700 animate-in fade-in slide-in-from-top-3">
          <span className="material-symbols-outlined text-[18px] text-emerald-400">check_circle</span>
          <span>{testNotice}</span>
        </div>
      )}

      {/* Installation Modal / In-flight Progress Overlay */}
      {activeInstallation && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-gray-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                activeInstallation.status === 'failed'
                  ? 'bg-red-100 text-red-700'
                  : activeInstallation.status === 'success'
                  ? 'bg-emerald-100 text-emerald-700'
                  : 'bg-blue-100 text-[#00478c]'
              }`}>
                {activeInstallation.status === 'installing' || activeInstallation.status === 'verifying' ? (
                  <span className="material-symbols-outlined text-[28px] animate-spin">sync</span>
                ) : activeInstallation.status === 'success' ? (
                  <span className="material-symbols-outlined text-[28px]">check_circle</span>
                ) : (
                  <span className="material-symbols-outlined text-[28px]">error</span>
                )}
              </div>
              <div>
                <h3 className="font-black text-base text-[#09090B] capitalize">
                  {activeInstallation.status === 'installing' && `Connecting ${activeInstallation.type}...`}
                  {activeInstallation.status === 'verifying' && `Verifying Hardware Handshake...`}
                  {activeInstallation.status === 'success' && `Peripheral Installed & Verified!`}
                  {activeInstallation.status === 'failed' && `Installation Failed`}
                </h3>
                <p className="text-xs text-gray-500">
                  Hardware Diagnostic &amp; Device Pairing Flow
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden mb-3">
              <div
                className={`h-full transition-all duration-300 ${
                  activeInstallation.status === 'failed'
                    ? 'bg-red-600'
                    : activeInstallation.status === 'success'
                    ? 'bg-emerald-600'
                    : 'bg-[#00478c]'
                }`}
                style={{ width: `${activeInstallation.progressPercent}%` }}
              ></div>
            </div>

            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 text-xs font-mono text-gray-700 flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-gray-400">terminal</span>
              <span className="truncate">{activeInstallation.step}</span>
            </div>

            <div className="mt-4 text-[11px] text-gray-500 text-center">
              The peripheral icon will be automatically applied to the header bar upon verified handshake.
            </div>
          </div>
        </div>
      )}

      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-[#D4D4D8] shadow-xs">
        <div>
          <h1 className="text-2xl font-black text-[#09090B] flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[#00478c] text-[28px]">devices</span>
            <span>POS Hardware &amp; Peripherals Configuration</span>
          </h1>
          <p className="text-xs text-[#5c403c] mt-1">
            Install and configure peripheral devices in your browser. Use the header switches to customize which active icons appear in the top bar.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 bg-blue-50 border border-blue-200 text-[#00478c] rounded text-xs font-bold flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px]">check_circle</span>
            <span>{installedCount} of 6 Peripherals Installed</span>
          </span>
          <button
            type="button"
            onClick={async () => {
              await refreshHardwareDevices();
              playSuccessChime();
              setTestNotice('✓ Refreshed connected USB & Media Peripherals');
              setTimeout(() => setTestNotice(null), 3000);
            }}
            className="px-3.5 py-2 bg-white hover:bg-gray-100 border border-gray-300 text-gray-700 rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <span className="material-symbols-outlined text-[16px]">refresh</span>
            <span>Rescan Devices</span>
          </button>
        </div>
      </div>

      {/* Quick Installation & Fleet Control Grid */}
      <div className="bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-xs">
        <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[16px] text-[#00478c]">devices</span>
            <span>Hardware Devices &amp; Peripherals Management</span>
          </div>
          <span className="text-[11px] text-teal-700 font-semibold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Scale Reading Active in Top Header
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
          {/* Camera (Paused / Later) */}
          <div className="p-3.5 rounded-xl border border-gray-200 bg-gray-50 opacity-40 grayscale flex flex-col justify-between gap-3 select-none cursor-not-allowed">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="material-symbols-outlined text-[20px] text-gray-400">photo_camera</span>
                <span className="font-bold text-xs text-gray-500 whitespace-nowrap">1. AI Camera</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 font-bold uppercase">Paused</span>
            </div>
            <div className="text-[11px] font-medium text-gray-400">
              Feature paused for later release
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-semibold text-gray-400">Unavailable</span>
            </div>
          </div>

          {/* Voice (Paused / Later) */}
          <div className="p-3.5 rounded-xl border border-gray-200 bg-gray-50 opacity-40 grayscale flex flex-col justify-between gap-3 select-none cursor-not-allowed">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="material-symbols-outlined text-[20px] text-gray-400">mic</span>
                <span className="font-bold text-xs text-gray-500 whitespace-nowrap">2. AI Voice</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 font-bold uppercase">Paused</span>
            </div>
            <div className="text-[11px] font-medium text-gray-400">
              Feature paused for later release
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-semibold text-gray-400">Unavailable</span>
            </div>
          </div>

          {/* Barcode Scanner */}
          <div 
            onClick={() => handleSelectPeripheral('scanner')}
            className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all cursor-pointer ${
              activeTab === 'scanner'
                ? 'border-blue-500 bg-sky-50/90 shadow-md ring-2 ring-sky-400/50'
                : 'border-gray-200 bg-gray-50 hover:bg-gray-100'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`material-symbols-outlined text-[20px] shrink-0 ${barcodeConfig.enabled ? 'text-blue-700' : 'text-gray-400'}`}>qr_code_scanner</span>
                <span className="font-bold text-xs text-[#09090B] whitespace-nowrap" title="3. Scanner">3. Scanner</span>
              </div>
              <label 
                className="flex items-center cursor-pointer select-none shrink-0 p-1 bg-white hover:bg-blue-50 rounded-md border border-gray-200 shadow-2xs hover:border-blue-500 transition-colors"
                title="Toggle Barcode Scanner in top header"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={headerVisibility.scanner}
                  onChange={() => toggleHeaderVisibility('scanner')}
                  className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer accent-blue-600"
                />
              </label>
            </div>
            <div className="text-[11px] font-medium space-y-0.5">
              <div className="flex items-center gap-1">
                <span className="text-blue-700 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                  Installed
                </span>
              </div>
              <div className="text-[10px] text-gray-500">
                {headerVisibility.scanner ? '🟢 Icon Visible' : '⚪ Icon Hidden'}
              </div>
            </div>
            <div className="pt-1 border-t border-gray-200/60">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectPeripheral('scanner');
                }}
                className="w-full py-1 px-2 bg-blue-700 hover:bg-blue-800 text-white rounded text-[11px] font-bold flex items-center justify-center gap-1 shadow-2xs cursor-pointer transition-colors"
              >
                <span className="material-symbols-outlined text-[14px]">tune</span>
                <span>Configure Protocol &rarr;</span>
              </button>
            </div>
          </div>

          {/* Weighing Scale */}
          <div 
            onClick={() => handleSelectPeripheral('scale')}
            className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all cursor-pointer ${
              activeTab === 'scale'
                ? 'border-teal-600 bg-teal-50 shadow-md ring-2 ring-teal-400/50'
                : 'border-teal-300 bg-teal-50/50 hover:bg-teal-50'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`material-symbols-outlined text-[20px] shrink-0 ${scaleConfig.enabled ? 'text-teal-700' : 'text-gray-400'}`}>scale</span>
                <span className="font-bold text-xs text-[#09090B] whitespace-nowrap" title="4. Scale">4. Scale</span>
              </div>
              <label 
                className="flex items-center cursor-pointer select-none shrink-0 p-1 bg-white hover:bg-teal-50 rounded-md border border-gray-200 shadow-2xs hover:border-teal-500 transition-colors"
                title="Toggle Scale readout in top header"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={headerVisibility.scale}
                  onChange={() => toggleHeaderVisibility('scale')}
                  className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500 cursor-pointer accent-teal-600"
                />
              </label>
            </div>
            <div className="text-[11px] font-medium space-y-0.5">
              <div className="flex items-center gap-1">
                <span className="text-teal-700 font-bold flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-full ${scaleConfig.isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-teal-500'}`}></span>
                  {scaleConfig.isConnected ? 'Live Streaming' : 'Installed'}
                </span>
              </div>
              <div className="text-[10px] text-gray-500">
                {headerVisibility.scale ? '🟢 Icon Visible' : '⚪ Icon Hidden'}
              </div>
            </div>
            <div className="pt-1 border-t border-gray-200/60">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectPeripheral('scale');
                }}
                className="w-full py-1 px-2 bg-teal-700 hover:bg-teal-800 text-white rounded text-[11px] font-bold flex items-center justify-center gap-1 shadow-2xs cursor-pointer transition-colors"
              >
                <span className="material-symbols-outlined text-[14px]">settings_ethernet</span>
                <span>Configure Baud &amp; Stream &rarr;</span>
              </button>
            </div>
          </div>

          {/* Printer */}
          <div 
            onClick={() => handleSelectPeripheral('printer')}
            className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all cursor-pointer ${
              activeTab === 'printer'
                ? 'border-[#00478c] bg-blue-50 shadow-md ring-2 ring-blue-400/50'
                : 'border-blue-300 bg-blue-50/50 hover:bg-blue-50'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className={`material-symbols-outlined text-[20px] shrink-0 ${printerConfig.enabled ? 'text-[#00478c]' : 'text-gray-400'}`}>print</span>
                <span className="font-bold text-xs text-[#09090B] whitespace-nowrap" title="5. Printer">5. Printer</span>
              </div>
              <label 
                className="flex items-center cursor-pointer select-none shrink-0 p-1 bg-white hover:bg-blue-50 rounded-md border border-gray-200 shadow-2xs hover:border-[#00478c] transition-colors"
                title="Toggle Printer in top header"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={headerVisibility.printer}
                  onChange={() => toggleHeaderVisibility('printer')}
                  className="w-4 h-4 rounded border-gray-300 text-[#00478c] focus:ring-blue-500 cursor-pointer accent-[#00478c]"
                />
              </label>
            </div>
            <div className="text-[11px] font-medium space-y-0.5">
              <div className="flex items-center gap-1">
                <span className="text-[#00478c] font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#00478c] animate-pulse"></span>
                  Installed
                </span>
              </div>
              <div className="text-[10px] text-gray-500">
                {headerVisibility.printer ? '🟢 Icon Visible' : '⚪ Icon Hidden'}
              </div>
            </div>
            <div className="pt-1 border-t border-gray-200/60">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectPeripheral('printer');
                }}
                className="w-full py-1 px-2 bg-[#00478c] hover:bg-[#005eb7] text-white rounded text-[11px] font-bold flex items-center justify-center gap-1 shadow-2xs cursor-pointer transition-colors"
              >
                <span className="material-symbols-outlined text-[14px]">tune</span>
                <span>Select Printer Driver &rarr;</span>
              </button>
            </div>
          </div>

          {/* Cash Drawer (Paused / Later) */}
          <div className="p-3.5 rounded-xl border border-gray-200 bg-gray-50 opacity-40 grayscale flex flex-col justify-between gap-3 select-none cursor-not-allowed">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <span className="material-symbols-outlined text-[20px] text-gray-400">point_of_sale</span>
                <span className="font-bold text-xs text-gray-500 whitespace-nowrap">6. Drawer</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-200 text-gray-600 font-bold uppercase">Paused</span>
            </div>
            <div className="text-[11px] font-medium text-gray-400">
              Hardware pulse trigger paused
            </div>
            <div className="pt-1 border-t border-gray-200/60 text-center">
              <span className="text-xs font-semibold text-gray-400">Unavailable</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-gray-300 gap-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => handleSelectPeripheral('scale')}
          className={`px-4 py-2.5 font-bold text-xs flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'scale'
              ? 'border-[#00478c] text-[#00478c] bg-white rounded-t-lg shadow-xs'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">scale</span>
          <span>4. Weighing Scale (Baud Setup &amp; Live Stream)</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${scaleConfig.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'}`}>
            {scaleConfig.enabled ? 'Installed' : 'Not Installed'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => handleSelectPeripheral('printer')}
          className={`px-4 py-2.5 font-bold text-xs flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'printer'
              ? 'border-[#00478c] text-[#00478c] bg-white rounded-t-lg shadow-xs'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">print</span>
          <span>5. Receipt Printer (Installed Windows Printers)</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${printerConfig.enabled ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-500'}`}>
            {printerConfig.enabled ? 'Installed' : 'Not Installed'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => handleSelectPeripheral('scanner')}
          className={`px-4 py-2.5 font-bold text-xs flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'scanner'
              ? 'border-[#00478c] text-[#00478c] bg-white rounded-t-lg shadow-xs'
              : 'border-transparent text-gray-600 hover:text-gray-900'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">qr_code_scanner</span>
          <span>3. Barcode Scanner</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${barcodeConfig.enabled ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-500'}`}>
            {barcodeConfig.enabled ? 'Installed' : 'Not Installed'}
          </span>
        </button>
      </div>

      {/* Tab Panels */}
      <div ref={configPanelRef} className="bg-white border border-[#D4D4D8] rounded-xl p-6 shadow-xs space-y-6">

        {/* TAB 1: AI CAMERA VISION */}
        {activeTab === 'camera' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              cameraConfig.enabled ? 'bg-emerald-50/70 border-emerald-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  cameraConfig.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">photo_camera</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {cameraConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.camera ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {cameraConfig.enabled ? 'AI Vision produce scanner device is verified and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.camera}
                    onChange={() => toggleHeaderVisibility('camera')}
                    className="w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (cameraConfig.enabled ? handleUninstall('camera') : handleInstall('camera'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    cameraConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {cameraConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{cameraConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-emerald-700">photo_camera</span>
                  <span>AI Visual Produce &amp; Object Recognition Camera</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Powered by Gemini 3.7 Flash Multimodal for unbarcoded vegetables, fruits, grains &amp; packaged items
                </p>
              </div>

              {cameraConfig.enabled && (
                <button
                  type="button"
                  onClick={() => setIsAICameraModalOpen(true)}
                  className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <span className="material-symbols-outlined text-[16px]">videocam</span>
                  <span>Open Camera Viewfinder [F2]</span>
                </button>
              )}
            </div>

                      </div>
        )}

        {/* TAB 6: CASH DRAWER (INDEPENDENT) */}
        {activeTab === 'drawer' && (
          <div className="space-y-6">
            {/* Installed Verification Banner */}
            <div className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-xl gap-3 border transition-all ${
              drawerConfig.enabled ? 'bg-red-50/70 border-red-200 shadow-xs' : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  drawerConfig.enabled ? 'bg-red-100 text-[#950008]' : 'bg-gray-200 text-gray-400'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">point_of_sale</span>
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#09090B] flex items-center gap-2">
                    <span>Hardware: {drawerConfig.enabled ? '🟢 Installed' : '⚪ Not Installed'}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-xs font-semibold text-gray-600">
                      Header: {headerVisibility.drawer ? '🟢 Visible' : '⚪ Hidden'}
                    </span>
                  </h4>
                  <p className="text-xs text-gray-600">
                    {drawerConfig.enabled ? 'Cash drawer solenoid kick trigger is configured and ready.' : 'Peripheral is not installed in the browser session.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <label className="flex items-center gap-1.5 cursor-pointer select-none bg-white px-3 py-2 rounded-lg border border-gray-300 shadow-2xs text-xs font-bold text-gray-700">
                  <input
                    type="checkbox"
                    checked={headerVisibility.drawer}
                    onChange={() => toggleHeaderVisibility('drawer')}
                    className="w-4 h-4 rounded border-gray-300 text-red-600 focus:ring-red-500 cursor-pointer accent-red-600"
                  />
                  <span>Show in Header</span>
                </label>
                <button
                  type="button"
                  onClick={() => (drawerConfig.enabled ? handleUninstall('drawer') : handleInstall('drawer'))}
                  className={`px-4 py-2 rounded-lg font-bold text-xs cursor-pointer shadow-xs transition-all flex items-center gap-1.5 ${
                    drawerConfig.enabled
                      ? 'bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200'
                      : 'bg-[#950008] hover:bg-red-800 text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {drawerConfig.enabled ? 'delete' : 'download'}
                  </span>
                  <span>{drawerConfig.enabled ? 'Uninstall Hardware' : 'Install Hardware'}</span>
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-3 gap-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#950008]">point_of_sale</span>
                  <span>Cash Drawer Solenoid &amp; Kick Configuration</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Configure 24V/12V cash drawer solenoid kick signals, RJ11 drive pins, auto-open triggers and manual keyboard shortcuts
                </p>
              </div>

              {drawerConfig.enabled && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTestDrawerKick}
                    disabled={isKickingDrawer}
                    className={`px-4 py-2 bg-[#950008] hover:bg-[#bd1616] text-white rounded font-bold text-xs flex items-center gap-2 cursor-pointer shadow-xs transition-all ${
                      isKickingDrawer ? 'ring-4 ring-red-300 scale-95' : ''
                    }`}
                  >
                    <span className="material-symbols-outlined text-[17px]">
                      {isKickingDrawer ? 'lock_open' : 'key'}
                    </span>
                    <span>{isKickingDrawer ? 'Kicking Solenoid...' : 'Kick Open Drawer [F8]'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Diagnostic Status Box */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-[#950008]">
                  <span className="material-symbols-outlined text-[22px]">inbox</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-900">Solenoid Circuit Status: {drawerConfig.enabled ? 'Ready / Armed' : 'Disabled'}</div>
                  <div className="text-[11px] text-gray-600">
                    Last pulse triggered:{' '}
                    {drawerConfig.lastKickedTime > 0
                      ? new Date(drawerConfig.lastKickedTime).toLocaleTimeString()
                      : 'Not yet fired in this session'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-bold ${
                  drawerConfig.enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-200 text-gray-600'
                }`}>
                  <span className={`w-2 h-2 rounded-full mr-1.5 ${drawerConfig.enabled ? 'bg-emerald-500 animate-pulse' : 'bg-gray-400'}`}></span>
                  {drawerConfig.enabled ? '24V Solenoid Armed' : 'Solenoid Disarmed'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  CONNECTION INTERFACE
                </label>
                <select
                  value={drawerConfig.connectedVia}
                  onChange={(e: any) => setDrawerConfig((prev) => ({ ...prev, connectedVia: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none focus:border-[#950008]"
                >
                  <option value="PRINTER_RJ11">Printer DK Port (RJ-11 / 6-Pin Solenoid)</option>
                  <option value="USB_RELAY">Dedicated USB Cash Drawer Relay / Trigger Box</option>
                  <option value="SERIAL_COM">RS-232 Serial COM Port Kick Trigger</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  SOLENOID PULSE COMMAND (ESC/POS)
                </label>
                <input
                  type="text"
                  value={drawerConfig.drawerPulseCode}
                  onChange={(e) => setDrawerConfig((prev) => ({ ...prev, drawerPulseCode: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs font-mono bg-white text-gray-900 focus:outline-none focus:border-[#950008]"
                  placeholder="ESC p 0 25 250"
                />
                <span className="text-[10px] text-gray-500 mt-0.5 block">
                  Standard 24V pulse: ESC p 0 25 250 (ASCII: 27 112 0 25 250)
                </span>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  RJ-11 DRIVE PIN NUMBER
                </label>
                <select
                  value={drawerConfig.pinNumber}
                  onChange={(e: any) => setDrawerConfig((prev) => ({ ...prev, pinNumber: e.target.value }))}
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                >
                  <option value="Pin 2 (Standard)">Pin 2 (Standard ESC/POS Drive 1)</option>
                  <option value="Pin 5">Pin 5 (Secondary ESC/POS Drive 2)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-label-caps text-[#5c403c] font-bold mb-1">
                  SOLENOID PULSE DURATION (MS)
                </label>
                <input
                  type="number"
                  step="50"
                  min="50"
                  max="500"
                  value={drawerConfig.pulseDurationMs}
                  onChange={(e) =>
                    setDrawerConfig((prev) => ({ ...prev, pulseDurationMs: parseInt(e.target.value) || 250 }))
                  }
                  className="w-full h-10 border border-gray-300 rounded px-3 text-xs bg-white text-gray-900 focus:outline-none"
                />
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={drawerConfig.autoOpenOnCashPayment}
                    onChange={(e) =>
                      setDrawerConfig((prev) => ({ ...prev, autoOpenOnCashPayment: e.target.checked }))
                    }
                    className="w-4 h-4 text-[#950008] rounded border-gray-300 focus:ring-[#950008]"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auto-Open on 100% Cash Settlement</div>
                    <div className="text-[11px] text-gray-500">
                      Automatically fire solenoid trigger whenever a cash sale is completed
                    </div>
                  </div>
                </label>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={drawerConfig.autoOpenOnSplitTender}
                    onChange={(e) =>
                      setDrawerConfig((prev) => ({ ...prev, autoOpenOnSplitTender: e.target.checked }))
                    }
                    className="w-4 h-4 text-[#950008] rounded border-gray-300 focus:ring-[#950008]"
                  />
                  <div>
                    <div className="text-xs font-bold text-gray-900">Auto-Open on Split-Tender with Cash</div>
                    <div className="text-[11px] text-gray-500">
                      Trigger drawer kick if any portion of split payment includes cash tender
                    </div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        )}
      </div>

      {testNotice && (
        <div className="p-3 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-lg font-bold text-xs animate-in fade-in flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px]">check_circle</span>
          <span>{testNotice}</span>
        </div>
      )}
    </div>
  );
};

export default SettingsScreen;
