import React, { useState, useEffect, useMemo } from 'react';
import { usePOS } from '../../context/POSContext';
import { OutletProfile } from '../../types/pos';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';
import { formatBillNumber, getFinancialYear } from '../../utils/billNumber';

export const OutletProfileTab: React.FC = () => {
  const { outletProfile, updateOutletProfile } = usePOS();

  const [formData, setFormData] = useState<OutletProfile>({
    ...outletProfile,
    outletName: outletProfile?.outletName?.trim() || 'Amma Appa Kadai',
    branchName: outletProfile?.branchName?.trim() || 'Main Market Branch',
    phone: outletProfile?.phone?.trim() || '+91 98200 12345',
    email: outletProfile?.email?.trim() || 'contact@freshkadai.in',
    addressLine1: outletProfile?.addressLine1?.trim() || 'Shop #12, Market Complex',
    addressLine2: outletProfile?.addressLine2?.trim() || 'Main Road',
    city: outletProfile?.city?.trim() || 'Chennai',
    state: outletProfile?.state?.trim() || 'Tamil Nadu',
    pincode: outletProfile?.pincode?.trim() || '600001',
    gstin: outletProfile?.gstin?.trim() || '33AABCA1234F1Z9',
    panNumber: outletProfile?.panNumber?.trim() || 'AABCA1234F',
    fssaiLicense: outletProfile?.fssaiLicense?.trim() || '11521018000450',
    billPrefix: outletProfile.billPrefix !== undefined ? outletProfile.billPrefix : 'INV/',
    billSuffix: outletProfile.billSuffix !== undefined ? outletProfile.billSuffix : '',
    billStartNumber: outletProfile.billStartNumber !== undefined ? Number(outletProfile.billStartNumber) : 1001,
    billIncrementStep: outletProfile.billIncrementStep !== undefined ? Math.max(1, Number(outletProfile.billIncrementStep)) : 1,
    billNextSequence: outletProfile.billNextSequence !== undefined ? Number(outletProfile.billNextSequence) : (outletProfile.billStartNumber !== undefined ? Number(outletProfile.billStartNumber) : 1001),
    billNumberPadding: outletProfile.billNumberPadding !== undefined ? Number(outletProfile.billNumberPadding) : 4,
    billResetFrequency: outletProfile.billResetFrequency || 'never',
    billLastResetDate: outletProfile.billLastResetDate || '',
  });

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [activeTokenTarget, setActiveTokenTarget] = useState<'billPrefix' | 'billSuffix'>('billPrefix');

  useEffect(() => {
    if (outletProfile) {
      const startNum = outletProfile.billStartNumber !== undefined && outletProfile.billStartNumber !== null
        ? Number(outletProfile.billStartNumber)
        : 1001;
      const step = outletProfile.billIncrementStep !== undefined && outletProfile.billIncrementStep !== null
        ? Math.max(1, Number(outletProfile.billIncrementStep))
        : 1;
      const nextSeq = outletProfile.billNextSequence !== undefined && outletProfile.billNextSequence !== null
        ? Number(outletProfile.billNextSequence)
        : startNum;

      setFormData({
        ...outletProfile,
        outletName: outletProfile.outletName?.trim() || 'Amma Appa Kadai',
        branchName: outletProfile.branchName?.trim() || 'Main Market Branch',
        phone: outletProfile.phone?.trim() || '+91 98200 12345',
        email: outletProfile.email?.trim() || 'contact@freshkadai.in',
        addressLine1: outletProfile.addressLine1?.trim() || 'Shop #12, Market Complex',
        addressLine2: outletProfile.addressLine2?.trim() || 'Main Road',
        city: outletProfile.city?.trim() || 'Chennai',
        state: outletProfile.state?.trim() || 'Tamil Nadu',
        pincode: outletProfile.pincode?.trim() || '600001',
        gstin: outletProfile.gstin?.trim() || '33AABCA1234F1Z9',
        panNumber: outletProfile.panNumber?.trim() || 'AABCA1234F',
        fssaiLicense: outletProfile.fssaiLicense?.trim() || '11521018000450',
        billPrefix: outletProfile.billPrefix !== undefined ? outletProfile.billPrefix : 'INV/',
        billSuffix: outletProfile.billSuffix !== undefined ? outletProfile.billSuffix : '',
        billStartNumber: startNum,
        billIncrementStep: step,
        billNextSequence: nextSeq,
        billNumberPadding: outletProfile.billNumberPadding !== undefined ? Number(outletProfile.billNumberPadding) : 4,
        billResetFrequency: outletProfile.billResetFrequency || 'never',
        billLastResetDate: outletProfile.billLastResetDate || '',
      });
    }
  }, [outletProfile]);

  const handleChange = (field: keyof OutletProfile, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // Handler when starting number changes -> also update next sequence counter to start from that number
  const handleStartNumberChange = (val: number) => {
    const safeNum = Math.max(1, isNaN(val) ? 1 : val);
    setFormData((prev) => ({
      ...prev,
      billStartNumber: safeNum,
      billNextSequence: safeNum,
    }));
  };

  // Handler for auto increment step changes
  const handleIncrementStepChange = (val: number) => {
    const safeStep = Math.max(1, isNaN(val) ? 1 : val);
    setFormData((prev) => ({
      ...prev,
      billIncrementStep: safeStep,
    }));
  };

  const handleInsertToken = (target: 'billPrefix' | 'billSuffix', token: string) => {
    playKeypadClick();
    const currentVal = (formData[target] as string) || '';
    handleChange(target, currentVal + token);
  };

  const handleApplyPreset = (preset: {
    name: string;
    prefix: string;
    suffix: string;
    start: number;
    step: number;
    padding: number;
    reset: 'never' | 'daily' | 'monthly' | 'yearly';
  }) => {
    playKeypadClick();
    setFormData((prev) => ({
      ...prev,
      billPrefix: preset.prefix,
      billSuffix: preset.suffix,
      billStartNumber: preset.start,
      billIncrementStep: preset.step,
      billNextSequence: preset.start,
      billNumberPadding: preset.padding,
      billResetFrequency: preset.reset,
    }));
  };

  const handleResetCounter = () => {
    playKeypadClick();
    const start = formData.billStartNumber !== undefined ? Number(formData.billStartNumber) : 2;
    setFormData((prev) => ({
      ...prev,
      billNextSequence: start,
    }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const payload: OutletProfile = {
        ...formData,
        billStartNumber: Number(formData.billStartNumber) || 1,
        billIncrementStep: Math.max(1, Number(formData.billIncrementStep) || 1),
        billNextSequence: Number(formData.billNextSequence) || Number(formData.billStartNumber) || 1,
        billNumberPadding: Number(formData.billNumberPadding) >= 0 ? Number(formData.billNumberPadding) : 0,
      };
      await updateOutletProfile(payload);
      playSuccessChime();
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3500);
    } catch (err) {
      console.error('Failed to save outlet profile:', err);
    } finally {
      setIsSaving(false);
    }
  };

  // Evaluate current sequence safely
  const currentSeq = useMemo(() => {
    if (formData.billNextSequence !== undefined && !isNaN(Number(formData.billNextSequence))) {
      return Number(formData.billNextSequence);
    }
    if (formData.billStartNumber !== undefined && !isNaN(Number(formData.billStartNumber))) {
      return Number(formData.billStartNumber);
    }
    return 2;
  }, [formData.billNextSequence, formData.billStartNumber]);

  const step = useMemo(() => {
    return Math.max(1, Number(formData.billIncrementStep) || 1);
  }, [formData.billIncrementStep]);

  // Generate live sample consecutive bill numbers for preview
  const sample1 = useMemo(() => formatBillNumber(formData, currentSeq), [formData, currentSeq]);
  const sample2 = useMemo(() => formatBillNumber(formData, currentSeq + step), [formData, currentSeq, step]);
  const sample3 = useMemo(() => formatBillNumber(formData, currentSeq + (step * 2)), [formData, currentSeq, step]);
  const sample4 = useMemo(() => formatBillNumber(formData, currentSeq + (step * 3)), [formData, currentSeq, step]);

  const financialYearStr = useMemo(() => getFinancialYear(new Date()), []);

  return (
    <div className="flex flex-col xl:flex-row gap-6 animate-in fade-in duration-200">
      {/* Form Card */}
      <div className="flex-1 bg-white border border-[#D4D4D8] rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 mb-5 border-b border-gray-200">
          <div>
            <h3 className="text-base font-extrabold text-[#09090B] flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00478c] text-[22px]">storefront</span>
              Outlet Profile &amp; Billing Identification
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Configure outlet identity, tax registrations, starting bill number, and auto-increment step rules.
            </p>
          </div>
          {savedSuccess && (
            <span className="px-3 py-1.5 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold rounded-lg flex items-center gap-1.5 animate-in fade-in">
              <span className="material-symbols-outlined text-[16px] text-emerald-600">check_circle</span>
              Saved &amp; Rules Updated!
            </span>
          )}
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          {/* Section: Basic Identity */}
          <div>
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">badge</span>
              Store Identity
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Outlet / Store Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.outletName}
                  onChange={(e) => handleChange('outletName', e.target.value)}
                  placeholder="e.g. Amma & Appa Kadai"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Branch / Location Name
                </label>
                <input
                  type="text"
                  value={formData.branchName || ''}
                  onChange={(e) => handleChange('branchName', e.target.value)}
                  placeholder="e.g. Main Market Branch"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Primary Contact Phone <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.phone || ''}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="e.g. +91 98200 12345"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Official Email Address
                </label>
                <input
                  type="email"
                  value={formData.email || ''}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="e.g. contact@freshkadai.in"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* SECTION: BILL NUMBERING & AUTO INCREMENT RULES */}
          {/* ========================================================================= */}
          <div className="pt-4 border-t border-gray-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
              <div>
                <h4 className="text-xs font-bold text-[#00478c] uppercase tracking-wider flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[18px] text-[#00478c]">pin</span>
                  Bill Numbering &amp; Auto-Increment Rules
                </h4>
                <p className="text-[11px] text-gray-500 mt-0.5">
                  Set starting number, auto-increment step, prefix, suffix, and formatting rules.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetCounter}
                  className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 rounded text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                  title="Reset counter back to starting number"
                >
                  <span className="material-symbols-outlined text-[14px]">restart_alt</span>
                  <span>Reset Counter to Start (#{formData.billStartNumber || 2})</span>
                </button>
              </div>
            </div>

            {/* Quick 1-Click Templates */}
            <div className="mb-4 p-3 bg-blue-50/50 border border-blue-200 rounded-xl space-y-2">
              <span className="block text-[10px] font-extrabold text-blue-900 uppercase tracking-wider">
                ⚡ Quick 1-Click Presets:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  {
                    name: 'Start at 2 (Step +2)',
                    desc: 'inv/2, inv/4, inv/6...',
                    prefix: 'inv/',
                    suffix: '',
                    start: 2,
                    step: 2,
                    padding: 0,
                    reset: 'never' as const,
                  },
                  {
                    name: 'Start at 1 (Step +1)',
                    desc: 'INV/1, INV/2, INV/3...',
                    prefix: 'INV/',
                    suffix: '',
                    start: 1,
                    step: 1,
                    padding: 0,
                    reset: 'never' as const,
                  },
                  {
                    name: '4-Digit Standard',
                    desc: 'INV/1001, 1002...',
                    prefix: 'INV/',
                    suffix: '',
                    start: 1001,
                    step: 1,
                    padding: 4,
                    reset: 'never' as const,
                  },
                  {
                    name: 'Financial Year',
                    desc: `FM/${financialYearStr}/0001`,
                    prefix: 'FM/{FY}/',
                    suffix: '',
                    start: 1,
                    step: 1,
                    padding: 4,
                    reset: 'yearly' as const,
                  },
                ].map((preset) => (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() => handleApplyPreset(preset)}
                    className="p-2 bg-white hover:bg-blue-100/60 border border-blue-200 hover:border-blue-400 rounded-lg text-left transition-all cursor-pointer shadow-2xs group"
                  >
                    <div className="text-xs font-bold text-[#00478c] group-hover:text-blue-800">
                      {preset.name}
                    </div>
                    <div className="text-[10px] font-mono text-gray-600 mt-0.5 truncate">
                      {preset.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Bill Numbering Controls Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Prefix */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-gray-700">
                    Bill Prefix
                  </label>
                  <span className="text-[10px] text-gray-400">e.g. inv/, INV/, FM-</span>
                </div>
                <input
                  type="text"
                  value={formData.billPrefix || ''}
                  onChange={(e) => handleChange('billPrefix', e.target.value)}
                  onFocus={() => setActiveTokenTarget('billPrefix')}
                  placeholder="e.g. inv/ or INV/"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-bold focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              {/* Starting Number */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-[#00478c]">
                    Starting Number <span className="text-red-500">*</span>
                  </label>
                  <span className="text-[10px] text-gray-500 font-semibold">1st bill starts at</span>
                </div>
                <input
                  type="number"
                  min={1}
                  required
                  value={formData.billStartNumber !== undefined ? formData.billStartNumber : 2}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    handleStartNumberChange(isNaN(val) ? 1 : val);
                  }}
                  placeholder="2"
                  className="w-full px-3 py-2 border-2 border-[#00478c] rounded-lg text-xs font-mono font-black text-[#09090B] focus:ring-2 focus:ring-[#00478c] focus:outline-hidden bg-blue-50/30"
                />
                {/* Quick Starting Number Badges */}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {[1, 2, 5, 10, 20, 100, 1001].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => {
                        playKeypadClick();
                        handleStartNumberChange(n);
                      }}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold cursor-pointer transition-colors ${
                        formData.billStartNumber === n
                          ? 'bg-[#00478c] text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200'
                      }`}
                    >
                      #{n}
                    </button>
                  ))}
                </div>
              </div>

              {/* Auto Increment Step */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-emerald-800">
                    Auto Increment Step <span className="text-red-500">*</span>
                  </label>
                  <span className="text-[10px] text-emerald-700 font-bold">+ per sale</span>
                </div>
                <input
                  type="number"
                  min={1}
                  required
                  value={formData.billIncrementStep !== undefined ? formData.billIncrementStep : 2}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    handleIncrementStepChange(isNaN(val) ? 1 : val);
                  }}
                  placeholder="2"
                  className="w-full px-3 py-2 border-2 border-emerald-500 bg-emerald-50/40 rounded-lg text-xs font-mono font-black text-emerald-950 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                />
                {/* Quick Auto-Increment Step Badges */}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {[1, 2, 3, 5, 10].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => {
                        playKeypadClick();
                        handleIncrementStepChange(s);
                      }}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold cursor-pointer transition-colors ${
                        formData.billIncrementStep === s
                          ? 'bg-emerald-700 text-white'
                          : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-300'
                      }`}
                    >
                      +{s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Zero-Padding */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Zero-Padding (Digits)
                </label>
                <select
                  value={formData.billNumberPadding ?? 0}
                  onChange={(e) => handleChange('billNumberPadding', Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden bg-white cursor-pointer"
                >
                  <option value={0}>No Padding (e.g. inv/2, inv/4, inv/6)</option>
                  <option value={2}>2 Digits (02, 04, 06)</option>
                  <option value={3}>3 Digits (002, 004, 006)</option>
                  <option value={4}>4 Digits (0002, 0004, 0006)</option>
                  <option value={5}>5 Digits (00002, 00004)</option>
                  <option value={6}>6 Digits (000002, 000004)</option>
                </select>
                <span className="text-[10px] text-gray-400 block mt-1">
                  Selected: {formData.billNumberPadding ? `${formData.billNumberPadding} digits` : 'Exact number (no extra zeros)'}
                </span>
              </div>

              {/* Suffix */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-gray-700">
                    Bill Suffix
                  </label>
                  <span className="text-[10px] text-gray-400">Optional text</span>
                </div>
                <input
                  type="text"
                  value={formData.billSuffix || ''}
                  onChange={(e) => handleChange('billSuffix', e.target.value)}
                  onFocus={() => setActiveTokenTarget('billSuffix')}
                  placeholder="e.g. /26-27 or empty"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-bold focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              {/* Reset Frequency */}
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Periodic Auto-Reset Rule
                </label>
                <select
                  value={formData.billResetFrequency || 'never'}
                  onChange={(e) => handleChange('billResetFrequency', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden bg-white cursor-pointer"
                >
                  <option value="never">Never (Continuous Auto-Incrementing Series)</option>
                  <option value="daily">Daily (Reset back to Starting Number every midnight)</option>
                  <option value="monthly">Monthly (Reset back to Starting Number on 1st of every month)</option>
                  <option value="yearly">Yearly (Reset back to Starting Number every Year / FY)</option>
                </select>
              </div>

              {/* Current Sequence Status */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Current Status
                </label>
                <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs font-mono font-bold text-gray-800 flex items-center justify-between">
                  <span>Current: #{currentSeq}</span>
                  <span className="text-[10px] text-emerald-700 font-bold">Step: +{step}</span>
                </div>
              </div>
            </div>

            {/* Dynamic Tokens Bar */}
            <div className="mt-3 p-3 bg-gray-50 border border-gray-200 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-gray-700 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px] text-gray-500">token</span>
                  Dynamic Tokens (Click to append into {activeTokenTarget === 'billPrefix' ? 'Prefix' : 'Suffix'}):
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveTokenTarget('billPrefix')}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                      activeTokenTarget === 'billPrefix'
                        ? 'bg-[#00478c] text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    Target: Prefix
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTokenTarget('billSuffix')}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                      activeTokenTarget === 'billSuffix'
                        ? 'bg-[#00478c] text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    Target: Suffix
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {[
                  { token: '{YYYY}', label: '4-Digit Year (2026)' },
                  { token: '{YY}', label: '2-Digit Year (26)' },
                  { token: '{MM}', label: '2-Digit Month (08)' },
                  { token: '{DD}', label: '2-Digit Day (24)' },
                  { token: '{FY}', label: `Financial Year (${financialYearStr})` },
                  { token: '{BRANCH}', label: 'Branch Code (MAIN)' },
                ].map((item) => (
                  <button
                    key={item.token}
                    type="button"
                    onClick={() => handleInsertToken(activeTokenTarget, item.token)}
                    className="px-2.5 py-1 bg-white hover:bg-blue-50 border border-gray-300 hover:border-blue-400 text-gray-800 rounded-md text-[11px] font-mono flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                    title={`Click to insert ${item.token} into ${activeTokenTarget}`}
                  >
                    <span className="text-[#00478c] font-bold">+</span>
                    <span className="font-bold text-[#09090B]">{item.token}</span>
                    <span className="text-[10px] text-gray-500">({item.label.split(' ')[0]})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Live Bill Sequence Preview Box */}
            <div className="mt-4 p-3.5 bg-linear-to-r from-slate-900 to-indigo-950 text-white rounded-xl shadow-md border border-slate-700">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-700/80">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-amber-400 text-[20px]">verified</span>
                  <div>
                    <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                      LIVE BILL NUMBER PREVIEW (NEXT SALE)
                    </div>
                    <div className="text-2xl font-black font-mono text-amber-300 tracking-wide">
                      {sample1}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block font-sans">Numbering Formula</span>
                  <span className="text-xs font-bold text-amber-300 font-mono">
                    Starts at {formData.billStartNumber || 2}, Auto-Increments +{step} per sale
                  </span>
                </div>
              </div>

              <div className="pt-2.5 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-slate-300 gap-2">
                <span className="text-[11px] text-slate-400 font-medium">
                  Next 4 Consecutive Bills:
                </span>
                <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
                  <span className="bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500 text-amber-300 font-bold">
                    ① {sample1}
                  </span>
                  <span className="text-slate-500">➔</span>
                  <span className="bg-slate-800/90 px-2 py-0.5 rounded border border-slate-700 text-slate-200">
                    ② {sample2}
                  </span>
                  <span className="text-slate-500">➔</span>
                  <span className="bg-slate-800/90 px-2 py-0.5 rounded border border-slate-700 text-slate-200">
                    ③ {sample3}
                  </span>
                  <span className="text-slate-500">➔</span>
                  <span className="bg-slate-800/90 px-2 py-0.5 rounded border border-slate-700 text-slate-200">
                    ④ {sample4}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Section: Tax & Legal Registrations */}
          <div className="pt-4 border-t border-gray-200">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">receipt</span>
              Tax &amp; Legal Registrations
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  GSTIN (GST Number)
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={formData.gstin || ''}
                  onChange={(e) => handleChange('gstin', e.target.value.toUpperCase())}
                  placeholder="e.g. 33AABCA1234F1Z9"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono uppercase font-semibold focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
                <span className="text-[10px] text-gray-400">15-digit GST identification number</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  PAN Number
                </label>
                <input
                  type="text"
                  maxLength={10}
                  value={formData.panNumber || ''}
                  onChange={(e) => handleChange('panNumber', e.target.value.toUpperCase())}
                  placeholder="e.g. AABCA1234F"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono uppercase font-semibold focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
                <span className="text-[10px] text-gray-400">10-digit Permanent Account Number</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  FSSAI License No.
                </label>
                <input
                  type="text"
                  maxLength={14}
                  value={formData.fssaiLicense || ''}
                  onChange={(e) => handleChange('fssaiLicense', e.target.value)}
                  placeholder="e.g. 11521018000450"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-semibold focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
                <span className="text-[10px] text-gray-400">14-digit food safety registration</span>
              </div>
            </div>
          </div>

          {/* Section: Physical Address */}
          <div className="pt-4 border-t border-gray-200">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">location_on</span>
              Physical Address (Printed on Bill)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Address Line 1 (Shop / Building / Market)
                </label>
                <input
                  type="text"
                  value={formData.addressLine1 || ''}
                  onChange={(e) => handleChange('addressLine1', e.target.value)}
                  placeholder="e.g. Shop #12, Mandi Market Complex"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Address Line 2 (Street / Area / Landmark)
                </label>
                <input
                  type="text"
                  value={formData.addressLine2 || ''}
                  onChange={(e) => handleChange('addressLine2', e.target.value)}
                  placeholder="e.g. Main Road, Gandhi Nagar"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  City
                </label>
                <input
                  type="text"
                  value={formData.city || ''}
                  onChange={(e) => handleChange('city', e.target.value)}
                  placeholder="e.g. Chennai"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    State
                  </label>
                  <input
                    type="text"
                    value={formData.state || ''}
                    onChange={(e) => handleChange('state', e.target.value)}
                    placeholder="e.g. Tamil Nadu"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    Pincode
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={formData.pincode || ''}
                    onChange={(e) => handleChange('pincode', e.target.value)}
                    placeholder="e.g. 600001"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section: Receipt Customization & Terms */}
          <div className="pt-4 border-t border-gray-200">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">notes</span>
              Receipt Header, Footer &amp; Return Terms
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Receipt Header Tagline
                </label>
                <input
                  type="text"
                  value={formData.receiptHeaderNote || ''}
                  onChange={(e) => handleChange('receiptHeaderNote', e.target.value)}
                  placeholder="e.g. AMMA & APPA KADAI - FRESH PRODUCE & PROVISIONS"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Receipt Footer Thank You Message
                </label>
                <input
                  type="text"
                  value={formData.receiptFooterNote || ''}
                  onChange={(e) => handleChange('receiptFooterNote', e.target.value)}
                  placeholder="e.g. Thank you for shopping with us! Visit again."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Exchange / Return Terms &amp; Conditions (Printed on Bill)
                </label>
                <textarea
                  rows={2}
                  value={formData.returnTerms || ''}
                  onChange={(e) => handleChange('returnTerms', e.target.value)}
                  placeholder="e.g. Goods once sold can be exchanged within 24 hours with original bill receipt."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-gray-200 flex justify-end gap-3">
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 bg-[#00478c] hover:bg-[#005eb7] disabled:opacity-50 text-white rounded-lg font-bold text-xs flex items-center gap-2 cursor-pointer shadow-sm transition-all"
            >
              <span className="material-symbols-outlined text-[18px]">
                {isSaving ? 'sync' : 'save'}
              </span>
              <span>{isSaving ? 'Saving Changes...' : 'Save Outlet Profile & Numbering Rules'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Real-time Bill Preview Card */}
      <div className="w-full xl:w-80 shrink-0">
        <div className="bg-[#fffdfa] border-2 border-dashed border-gray-400 rounded-xl p-5 shadow-inner sticky top-4 font-mono text-xs text-black select-none">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-dashed border-gray-400 font-sans">
            <span className="font-bold text-[11px] uppercase tracking-wider text-gray-600 flex items-center gap-1">
              <span className="material-symbols-outlined text-[14px]">visibility</span>
              Live Bill Preview
            </span>
            <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-bold rounded">
              80mm Sample
            </span>
          </div>

          <div className="text-center pb-3 border-b border-dashed border-gray-400 space-y-0.5">
            <div className="font-extrabold text-sm tracking-tight text-black font-sans uppercase">
              {formData.outletName || 'AMMA & APPA KADAI'}
            </div>
            {formData.branchName && (
              <div className="text-[10px] font-bold text-gray-800">
                {formData.branchName}
              </div>
            )}
            <div className="text-[9.5px] text-gray-700 leading-tight">
              {[formData.addressLine1, formData.addressLine2, formData.city, formData.state, formData.pincode].filter(Boolean).join(', ') || 'Shop #12, Market Complex, Chennai'}
            </div>
            <div className="text-[9.5px] text-gray-700 flex flex-wrap justify-center gap-x-1.5 pt-0.5">
              {formData.gstin && <span>GSTIN: <b>{formData.gstin}</b></span>}
              {formData.panNumber && <span>PAN: <b>{formData.panNumber}</b></span>}
            </div>
            {formData.fssaiLicense && (
              <div className="text-[9.5px] text-gray-700">
                FSSAI: <b>{formData.fssaiLicense}</b>
              </div>
            )}
            <div className="text-[9.5px] text-gray-700">
              Ph: {formData.phone || '+91 98200 12345'}
            </div>
            {formData.receiptHeaderNote && (
              <div className="text-[8.5px] italic text-gray-500 pt-0.5 border-t border-dotted border-gray-300">
                {formData.receiptHeaderNote}
              </div>
            )}
          </div>

          <div className="py-2 border-b border-dashed border-gray-400 text-[10px] space-y-0.5">
            <div className="flex justify-between items-center">
              <span>Bill No: <b className="text-[#00478c]">{sample1}</b></span>
              <span>Cashier: Alex</span>
            </div>
            <div className="flex justify-between text-gray-600">
              <span>Date: 24/08/2026</span>
              <span>Time: 10:45 AM</span>
            </div>
          </div>

          <div className="py-2 border-b border-dashed border-gray-400 text-[10px] space-y-1">
            <div className="flex justify-between font-bold text-[9px] uppercase border-b border-gray-300 pb-0.5 text-gray-600">
              <span>Item</span>
              <span>Qty</span>
              <span>Rate</span>
              <span>Amt</span>
            </div>
            <div className="flex justify-between">
              <span className="truncate w-24">Fresh Mango</span>
              <span>2.00</span>
              <span>Rs.120</span>
              <span className="font-bold">Rs.240.00</span>
            </div>
            <div className="flex justify-between">
              <span className="truncate w-24">Aashirvaad Atta</span>
              <span>1.00</span>
              <span>Rs.275</span>
              <span className="font-bold">Rs.275.00</span>
            </div>
          </div>

          <div className="py-2 border-b border-dashed border-gray-400 text-[10px] space-y-0.5">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-bold">Rs. 515.00</span>
            </div>
            <div className="flex justify-between text-gray-600">
              <span>CGST + SGST (5%):</span>
              <span>Rs. 25.75</span>
            </div>
            <div className="flex justify-between text-sm font-black pt-1 border-t border-gray-400 font-sans">
              <span>GRAND TOTAL:</span>
              <span>Rs. 540.75</span>
            </div>
          </div>

          <div className="pt-2 text-center text-[9.5px] text-gray-600 font-sans space-y-1">
            <div className="font-bold text-black">
              {formData.receiptFooterNote || 'Thank you for shopping with us! Visit again.'}
            </div>
            {formData.returnTerms && (
              <div className="text-[8px] text-gray-500 leading-tight bg-gray-100 p-1 rounded border border-gray-200">
                <b>Terms:</b> {formData.returnTerms}
              </div>
            )}
            <div className="text-[8.5px] text-gray-400">*** Software: Plannest POS Retail Enterprise ***</div>
          </div>
        </div>
      </div>
    </div>
  );
};
