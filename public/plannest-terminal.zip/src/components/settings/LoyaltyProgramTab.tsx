import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { LoyaltyProgramConfig } from '../../types/pos';
import { playSuccessChime } from '../../utils/audio';

export const LoyaltyProgramTab: React.FC = () => {
  const { loyaltyConfig, updateLoyaltyConfig, customers, outletProfile } = usePOS();

  const [formData, setFormData] = useState<LoyaltyProgramConfig>(loyaltyConfig);
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Simulation test calculator state
  const [simSpend, setSimSpend] = useState<number>(500);
  const [simRedeemPoints, setSimRedeemPoints] = useState<number>(20);

  useEffect(() => {
    if (loyaltyConfig) {
      setFormData(loyaltyConfig);
    }
  }, [loyaltyConfig]);

  const handleChange = <K extends keyof LoyaltyProgramConfig>(
    field: K,
    value: LoyaltyProgramConfig[K]
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateLoyaltyConfig(formData);
      playSuccessChime();
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3500);
    } catch (err) {
      console.error('Failed to save loyalty settings:', err);
    } finally {
      setIsSaving(false);
    }
  };

  // Metrics
  const enrolledCustomers = customers.filter((c) => c.isLoyaltyMember ?? true);
  const totalPointsInCirculation = customers.reduce((sum, c) => sum + (c.loyaltyPoints || 0), 0);
  const totalPointsLiability = totalPointsInCirculation * (formData.pointRedemptionValue || 1);
  const currency = outletProfile?.currencySymbol || 'Rs.';

  // Simulated calculations
  const simEarnedPoints = formData.enabled && formData.spendAmountPerPoint > 0
    ? Math.floor(simSpend / formData.spendAmountPerPoint) * (formData.pointsEarnedPerSpend || 1)
    : 0;
  const simEarnedValue = simEarnedPoints * (formData.pointRedemptionValue || 1);
  const simRedeemDiscount = formData.enabled && simRedeemPoints >= (formData.minPointsToRedeem || 0)
    ? simRedeemPoints * (formData.pointRedemptionValue || 1)
    : 0;

  return (
    <div className="flex flex-col xl:flex-row gap-6 animate-in fade-in duration-200">
      {/* Settings Form Card */}
      <div className="flex-1 bg-white border border-[#D4D4D8] rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 mb-5 border-b border-gray-200">
          <div>
            <h3 className="text-base font-extrabold text-[#09090B] flex items-center gap-2">
              <span className="material-symbols-outlined text-amber-500 text-[24px]">loyalty</span>
              Customer Loyalty &amp; Rewards Program
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Reward your repeat shoppers with points on every ₹100 or ₹200 spent. Points can be redeemed for instant discounts at checkout or expire after a specified duration.
            </p>
          </div>
          {savedSuccess && (
            <span className="px-3 py-1.5 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold rounded-lg flex items-center gap-1.5 animate-in fade-in">
              <span className="material-symbols-outlined text-[16px] text-emerald-600">check_circle</span>
              Loyalty Program Saved!
            </span>
          )}
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          {/* Master Enable Toggle */}
          <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold">
                <span className="material-symbols-outlined text-[24px]">stars</span>
              </div>
              <div>
                <div className="font-extrabold text-xs text-[#09090B]">
                  Enable Loyalty Rewards in POS &amp; Checkout
                </div>
                <div className="text-[11px] text-gray-600">
                  When enabled, points will be automatically calculated during checkout and printed on bill receipts.
                </div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enabled}
                onChange={(e) => handleChange('enabled', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
            </label>
          </div>

          {/* Section: Earning Rules */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">trending_up</span>
              1. Points Earning Rules
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 bg-gray-50 border border-gray-200 rounded-xl space-y-1.5">
                <label className="block text-xs font-bold text-gray-800">
                  Spend Amount to Earn 1 Point ({currency}) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs font-bold text-gray-500">{currency}</span>
                  <input
                    type="number"
                    min={1}
                    max={10000}
                    step={1}
                    required
                    value={formData.spendAmountPerPoint}
                    onChange={(e) => handleChange('spendAmountPerPoint', Math.max(1, Number(e.target.value)))}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg text-xs font-bold text-[#00478c] focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                  />
                </div>
                <p className="text-[10px] text-gray-500">
                  e.g., Enter <b>100</b> for 1 pt per ₹100 spent, or <b>200</b> for 1 pt per ₹200 spent.
                </p>
              </div>

              <div className="p-3.5 bg-gray-50 border border-gray-200 rounded-xl space-y-1.5">
                <label className="block text-xs font-bold text-gray-800">
                  Points Credited per Spend Tier <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  step={1}
                  required
                  value={formData.pointsEarnedPerSpend}
                  onChange={(e) => handleChange('pointsEarnedPerSpend', Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-bold text-[#00478c] focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
                <p className="text-[10px] text-gray-500">
                  Number of points added per spend milestone (Default: <b>1 point</b>).
                </p>
              </div>
            </div>
          </div>

          {/* Section: Redemption Rules */}
          <div className="pt-3 border-t border-gray-200 space-y-4">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">savings</span>
              2. Points Redemption &amp; Discount Value
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 bg-gray-50 border border-gray-200 rounded-xl space-y-1.5">
                <label className="block text-xs font-bold text-gray-800">
                  Value of 1 Point in Cash Discount ({currency}) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs font-bold text-gray-500">{currency}</span>
                  <input
                    type="number"
                    min={0.1}
                    max={100}
                    step={0.1}
                    required
                    value={formData.pointRedemptionValue}
                    onChange={(e) => handleChange('pointRedemptionValue', Math.max(0.01, Number(e.target.value)))}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg text-xs font-bold text-emerald-700 focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                  />
                </div>
                <p className="text-[10px] text-gray-500">
                  e.g., <b>1.0</b> means 1 pt = ₹1 discount; <b>2.0</b> means 1 pt = ₹2 discount.
                </p>
              </div>

              <div className="p-3.5 bg-gray-50 border border-gray-200 rounded-xl space-y-1.5">
                <label className="block text-xs font-bold text-gray-800">
                  Minimum Points Required to Redeem
                </label>
                <input
                  type="number"
                  min={0}
                  max={500}
                  step={1}
                  value={formData.minPointsToRedeem}
                  onChange={(e) => handleChange('minPointsToRedeem', Math.max(0, Number(e.target.value)))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-bold text-gray-700 focus:ring-2 focus:ring-[#00478c] focus:outline-hidden"
                />
                <p className="text-[10px] text-gray-500">
                  Customer must accumulate at least this many points before redeeming (e.g. <b>10 pts</b>).
                </p>
              </div>
            </div>
          </div>

          {/* Section: Expiry & Enrollment */}
          <div className="pt-3 border-t border-gray-200 space-y-4">
            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-gray-500">schedule</span>
              3. Validity Period &amp; Membership Enrollment
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3.5 bg-gray-50 border border-gray-200 rounded-xl space-y-1.5">
                <label className="block text-xs font-bold text-gray-800">
                  Points Expiry Duration (Days)
                </label>
                <select
                  value={formData.expiryPeriodDays}
                  onChange={(e) => handleChange('expiryPeriodDays', Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-[#00478c] focus:outline-hidden bg-white"
                >
                  <option value={30}>30 Days (1 Month)</option>
                  <option value={60}>60 Days (2 Months)</option>
                  <option value={90}>90 Days (3 Months - Recommended)</option>
                  <option value={180}>180 Days (6 Months)</option>
                  <option value={365}>365 Days (1 Year)</option>
                  <option value={0}>Never Expire (Lifetime Points)</option>
                </select>
                <p className="text-[10px] text-gray-500">
                  Points unredeemed within this time will expire from the customer balance.
                </p>
              </div>

              <div className="p-3.5 bg-gray-50 border border-gray-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-gray-800">
                    Auto-Enroll New Customers
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Automatically make new customers loyalty members on signup.
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.autoEnrollOnRegistration}
                    onChange={(e) => handleChange('autoEnrollOnRegistration', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-gray-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-gray-200 flex justify-end gap-3">
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 bg-[#00478c] hover:bg-[#005eb7] disabled:opacity-50 text-white rounded-lg font-bold text-xs flex items-center gap-2 cursor-pointer shadow-sm transition-all"
            >
              <span className="material-symbols-outlined text-[18px]">
                {isSaving ? 'sync' : 'save'}
              </span>
              <span>{isSaving ? 'Saving Program...' : 'Save Loyalty Settings'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Simulator & Loyalty Portfolio Summary */}
      <div className="w-full xl:w-88 flex flex-col gap-4 shrink-0">
        {/* Live Simulator Card */}
        <div className="bg-white border border-[#D4D4D8] rounded-xl p-5 shadow-xs">
          <div className="flex items-center gap-2 pb-3 mb-3 border-b border-gray-200">
            <span className="material-symbols-outlined text-amber-500 text-[20px]">calculate</span>
            <h4 className="font-extrabold text-xs text-[#09090B] uppercase tracking-wider">
              Live Loyalty Calculation Test
            </h4>
          </div>

          <div className="space-y-3.5 text-xs">
            <div>
              <label className="block text-[11px] font-bold text-gray-700 mb-1">
                Simulated Bill Amount:
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  step={50}
                  value={simSpend}
                  onChange={(e) => setSimSpend(Number(e.target.value))}
                  className="flex-1 px-3 py-1.5 border border-gray-300 rounded text-xs font-bold text-[#00478c]"
                />
                <span className="text-gray-500 font-bold">{currency}</span>
              </div>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg space-y-1">
              <div className="text-[11px] text-amber-900 font-medium">Points Earned on this Bill:</div>
              <div className="text-base font-black text-amber-950">
                +{simEarnedPoints} Points
              </div>
              <div className="text-[10px] text-amber-800">
                Worth <b>{currency} {simEarnedValue.toFixed(2)}</b> discount on future visits!
              </div>
            </div>

            <div className="pt-2 border-t border-gray-200">
              <label className="block text-[11px] font-bold text-gray-700 mb-1">
                Points Redeemed at Checkout:
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  step={5}
                  value={simRedeemPoints}
                  onChange={(e) => setSimRedeemPoints(Number(e.target.value))}
                  className="flex-1 px-3 py-1.5 border border-gray-300 rounded text-xs font-bold text-emerald-700"
                />
                <span className="text-gray-500 font-bold">pts</span>
              </div>
            </div>

            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg space-y-1">
              <div className="text-[11px] text-emerald-900 font-medium">Instant Cash Discount:</div>
              <div className="text-base font-black text-emerald-950">
                - {currency} {simRedeemDiscount.toFixed(2)}
              </div>
              {simRedeemPoints < (formData.minPointsToRedeem || 0) && (
                <div className="text-[10px] text-red-600 font-bold">
                  (Below minimum {formData.minPointsToRedeem} points threshold)
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Member Portfolio Card */}
        <div className="bg-white border border-[#D4D4D8] rounded-xl p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
            <span className="material-symbols-outlined text-[#00478c] text-[20px]">group</span>
            <h4 className="font-extrabold text-xs text-[#09090B] uppercase tracking-wider">
              Store Loyalty Portfolio
            </h4>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="p-2.5 bg-gray-50 border border-gray-200 rounded-lg">
              <div className="text-[10px] text-gray-500 font-bold uppercase">Enrolled Members</div>
              <div className="text-base font-black text-[#00478c]">{enrolledCustomers.length}</div>
            </div>
            <div className="p-2.5 bg-gray-50 border border-gray-200 rounded-lg">
              <div className="text-[10px] text-gray-500 font-bold uppercase">Points Issued</div>
              <div className="text-base font-black text-amber-600">{totalPointsInCirculation}</div>
            </div>
          </div>

          <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-lg text-center">
            <div className="text-[10px] text-blue-800 font-bold uppercase">Outstanding Rewards Liability</div>
            <div className="text-sm font-black text-[#00478c]">{currency} {totalPointsLiability.toFixed(2)}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
