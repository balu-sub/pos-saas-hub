import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useOptionalPOS } from '../../context/POSContext';
import { useAuth } from '../../context/AuthContext';
import { triggerHaptic } from '../../utils/tabletUtils';
import {
  Tablet,
  Download,
  Smartphone,
  Check,
  Copy,
  X,
  Zap,
  WifiOff,
  Scale,
  ShieldCheck,
  QrCode,
  ExternalLink,
} from 'lucide-react';

export const PWAInstallButton: React.FC<{
  variant?: 'header' | 'badge' | 'full' | 'saas';
}> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const pos = useOptionalPOS();
  const { currentUser } = useAuth();
  const [showGuide, setShowGuide] = useState(false);
  const [activeDeviceTab, setActiveDeviceTab] = useState<'android' | 'ios' | 'qr'>('android');
  const [copied, setCopied] = useState(false);

  // If in POS context, verify role; if in SaaS Hub, allow logged-in user
  const isAuthorized = pos
    ? pos.canManageUsers || pos.currentOperator?.userRole === 'Admin'
    : !!currentUser;

  if (!isAuthorized) {
    return null;
  }

  // If already running inside standalone app, hide from standard POS header/badge,
  // but keep accessible in SaaS Hub for pairing external counter tablets
  if (isInstalled && variant !== 'saas') {
    return null;
  }

  const handleInstallClick = async () => {
    triggerHaptic('medium');
    if (isInstallable) {
      const installed = await install();
      if (!installed) {
        setShowGuide(true);
      }
    } else {
      setShowGuide(true);
    }
  };

  const appUrl = typeof window !== 'undefined' ? window.location.origin : 'https://plannest.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&margin=4&data=${encodeURIComponent(appUrl)}`;

  const handleCopyLink = () => {
    try {
      navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const renderModal = () => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 shrink-0">
              <Tablet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <span>Install Tablet POS App</span>
                {isInstallable && (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-bold">
                    1-Click Ready
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-500">
                Run as a dedicated, standalone fullscreen counter terminal
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowGuide(false)}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 1-Click Install Banner if available */}
        {isInstallable && (
          <div className="mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-emerald-900">Supported Device Detected</div>
              <div className="text-[11px] text-emerald-700">
                Your browser supports direct installation without app store downloads.
              </div>
            </div>
            <button
              type="button"
              onClick={async () => {
                await install();
                setShowGuide(false);
              }}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install Now</span>
            </button>
          </div>
        )}

        {/* Device Selection Tabs */}
        <div className="flex items-center gap-1 mt-4 p-1 bg-slate-100 rounded-xl border border-slate-200/70">
          <button
            type="button"
            onClick={() => setActiveDeviceTab('android')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeDeviceTab === 'android'
                ? 'bg-white text-[#00478c] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android Tablet</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveDeviceTab('ios')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeDeviceTab === 'ios'
                ? 'bg-white text-[#00478c] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span>Apple iPad</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveDeviceTab('qr')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeDeviceTab === 'qr'
                ? 'bg-white text-[#00478c] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Scan QR Code</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="mt-4 overflow-y-auto pr-1 flex-1">
          {activeDeviceTab === 'android' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    1
                  </span>
                  <span>
                    Open <strong>Google Chrome</strong> on your Android tablet and navigate to this store URL.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    2
                  </span>
                  <span>
                    Tap the Chrome three-dot menu <strong>(⋮)</strong> in the upper-right corner.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    3
                  </span>
                  <span>
                    Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    4
                  </span>
                  <span>
                    The app launches as a standalone, fullscreen POS without browser address bars!
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeDeviceTab === 'ios' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    1
                  </span>
                  <span>
                    Open <strong>Safari</strong> on your Apple iPad and visit this POS store URL.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    2
                  </span>
                  <span>
                    Tap the <strong>Share</strong> button (square with arrow pointing up) at the top of Safari.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    3
                  </span>
                  <span>
                    Scroll down and select <strong>"Add to Home Screen"</strong>.
                  </span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-[#00478c] text-white flex items-center justify-center font-bold text-[11px] shrink-0">
                    4
                  </span>
                  <span>
                    Tap <strong>"Add"</strong> in the top right. Plannest POS will appear as a native home screen app.
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeDeviceTab === 'qr' && (
            <div className="flex flex-col items-center justify-center text-center p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <p className="text-xs text-slate-600 mb-3">
                Scan with your Android tablet or iPad camera to instantly open and install:
              </p>
              <div className="p-2 bg-white rounded-xl border border-slate-200 shadow-sm mb-3">
                <img
                  src={qrCodeUrl}
                  alt="Tablet App QR Code"
                  className="w-36 h-36 object-contain"
                  loading="lazy"
                />
              </div>
              <div className="flex items-center gap-2 w-full max-w-sm">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="flex-1 px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-700 truncate"
                />
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="px-2.5 py-1.5 bg-[#00478c] hover:bg-[#00366c] text-white rounded-lg text-xs font-bold flex items-center gap-1 shrink-0 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Tablet Benefits Matrix */}
          <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-200/70">
            <div className="flex items-center gap-2 p-2 bg-emerald-50/50 rounded-lg border border-emerald-100 text-[11px] text-emerald-900 font-medium">
              <Zap className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Fullscreen Kiosk Mode</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-emerald-50/50 rounded-lg border border-emerald-100 text-[11px] text-emerald-900 font-medium">
              <WifiOff className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>100% Offline Database</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-emerald-50/50 rounded-lg border border-emerald-100 text-[11px] text-emerald-900 font-medium">
              <Scale className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Weighing Scale & Scanners</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-emerald-50/50 rounded-lg border border-emerald-100 text-[11px] text-emerald-900 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>PIN Lock Staff Security</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end">
          <button
            type="button"
            onClick={() => setShowGuide(false)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );

  if (variant === 'saas') {
    return (
      <>
        <button
          type="button"
          onClick={handleInstallClick}
          className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-bold rounded-lg shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
          title="Install dedicated Tablet App on Android or iPad"
        >
          <Tablet className="w-3.5 h-3.5 text-emerald-600" />
          <span>Install Tablet App</span>
          {isInstallable && (
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          )}
        </button>

        {showGuide && renderModal()}
      </>
    );
  }

  if (variant === 'badge') {
    return (
      <>
        <button
          type="button"
          onClick={handleInstallClick}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
          title="Install Plannest POS directly onto this Android Tablet"
        >
          <Tablet className="w-4 h-4" />
          <span>Install Tablet App</span>
        </button>

        {showGuide && renderModal()}
      </>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={handleInstallClick}
        className="h-8 px-2.5 flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-2xs shrink-0 active:scale-95"
        title="Install dedicated Android / iPad Tablet App"
      >
        <Tablet className="w-4 h-4" />
        <span className="hidden lg:inline text-[11px]">Install Tablet App</span>
      </button>

      {showGuide && renderModal()}
    </>
  );
};
