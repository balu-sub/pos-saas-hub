// Canonical Reusable Thermal Receipt Component
// Shared across POS Register, Customer Kiosk, Duplicate Reprint, and Admin Hub Preview
export * from '../checkout/ThermalReceiptTicket';
export { ThermalReceiptTicket } from '../checkout/ThermalReceiptTicket';
