import React, { ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error in POS Component:', error, errorInfo);
  }

  private handleReset = () => {
    try {
      localStorage.removeItem('alfa_pos_current_operator');
    } catch {}
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full flex flex-col items-center justify-center bg-[#F8FAFC] text-slate-800 p-6 select-none font-sans">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-8 shadow-xl text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-[36px]">refresh</span>
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">
                {this.props.fallbackTitle || 'Terminal Screen Recovered'}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                The terminal encountered an unexpected layout interrupt. Touch below to reload smoothly.
              </p>
            </div>
            {this.state.error?.message && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 font-mono text-left max-h-24 overflow-y-auto">
                {this.state.error.message}
              </div>
            )}
            <button
              type="button"
              onClick={this.handleReset}
              className="w-full py-3.5 px-4 bg-[#00478c] hover:bg-[#00366c] text-white rounded-xl font-bold text-sm shadow-md transition-all active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">restart_alt</span>
              <span>Restart Terminal View</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
