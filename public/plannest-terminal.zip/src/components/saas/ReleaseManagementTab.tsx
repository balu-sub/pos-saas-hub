import React, { useState, useEffect } from 'react';
import { Layers, Download, CheckCircle2, Clock, Plus, Tag, ArrowUpRight, Sparkles, RefreshCw } from 'lucide-react';
import { PosRelease } from '../../types/saas';

export const ReleaseManagementTab: React.FC = () => {
  const [releases, setReleases] = useState<PosRelease[]>([]);
  const [loading, setLoading] = useState(false);

  // New release form state
  const [showNewModal, setShowNewModal] = useState(false);
  const [newVersion, setNewVersion] = useState('');
  const [newReleaseName, setNewReleaseName] = useState('');
  const [newChannel, setNewChannel] = useState<'stable' | 'beta' | 'nightly'>('stable');
  const [newChangelog, setNewChangelog] = useState('');
  const [minOsVersion, setMinOsVersion] = useState('Windows 10 / Ubuntu 20.04');

  const fetchReleases = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/saas/releases');
      const data = await res.json();
      if (Array.isArray(data)) {
        setReleases(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReleases();
  }, []);

  const handleCreateRelease = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVersion || !newReleaseName) return;
    try {
      const res = await fetch('/api/saas/releases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          version: newVersion,
          releaseName: newReleaseName,
          channel: newChannel,
          changelog: newChangelog,
          minOsVersion,
        }),
      });
      if (res.ok) {
        setShowNewModal(false);
        setNewVersion('');
        setNewReleaseName('');
        setNewChangelog('');
        fetchReleases();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#00478c]" />
            <span>Over-the-Air (OTA) Release Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Stage and deploy POS updates, database migration patches, and peripheral firmware hooks across stores.
          </p>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="px-4 py-2 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Draft New Release</span>
        </button>
      </div>

      {/* Releases List */}
      <div className="space-y-4">
        {releases.map((rel) => (
          <div
            key={rel.id}
            className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 hover:border-slate-300 transition-all"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-purple-50 text-purple-700 border border-purple-200 font-mono font-bold text-sm">
                  {rel.version}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">{rel.release_name}</h3>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${
                        rel.channel === 'stable'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}
                    >
                      {rel.channel}
                    </span>
                    {Boolean(rel.is_current_stable) && (
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-50 text-[#00478c] border border-blue-200 rounded-full">
                        CURRENT STABLE
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Released on {rel.release_date} • Min OS: {rel.min_os_version}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 text-xs font-mono text-slate-700">
                <div>
                  <span className="text-slate-400 text-[10px] block uppercase">Rollout</span>
                  <span className="font-bold text-emerald-600">{rel.rollout_percentage}%</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block uppercase">Downloads</span>
                  <span className="font-bold text-slate-900">{rel.total_downloads}</span>
                </div>
              </div>
            </div>

            <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
              <span className="font-semibold text-slate-900 block mb-1 text-[11px] uppercase tracking-wider">
                Changelog & Highlights:
              </span>
              {rel.changelog}
            </div>
          </div>
        ))}
      </div>

      {/* New Release Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-lg shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">Draft New POS Release</h3>
            <form onSubmit={handleCreateRelease} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Version Number</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. v2.5.1"
                    value={newVersion}
                    onChange={(e) => setNewVersion(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Channel</label>
                  <select
                    value={newChannel}
                    onChange={(e) => setNewChannel(e.target.value as any)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                  >
                    <option value="stable">Stable</option>
                    <option value="beta">Beta</option>
                    <option value="nightly">Nightly</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Release Codename</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Autumn Precision Barcode & AI Tare"
                  value={newReleaseName}
                  onChange={(e) => setNewReleaseName(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Changelog</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Summarize improvements, fixes, or peripheral additions..."
                  value={newChangelog}
                  onChange={(e) => setNewChangelog(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-lg shadow-xs transition-all"
                >
                  Publish Release
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
