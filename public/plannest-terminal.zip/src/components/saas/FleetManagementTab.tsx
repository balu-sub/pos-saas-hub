import React, { useState, useEffect } from 'react';
import {
  Monitor,
  Scale,
  Printer,
  RefreshCw,
  Zap,
  ShieldAlert,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  HardDrive,
  Cpu,
  Radio,
} from 'lucide-react';
import { TerminalTelemetry } from '../../types/saas';

export const FleetManagementTab: React.FC = () => {
  const [terminals, setTerminals] = useState<TerminalTelemetry[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [pingingId, setPingingId] = useState<string | null>(null);
  const [pingResult, setPingResult] = useState<{ id: string; ms: number } | null>(null);

  const fetchTerminals = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/saas/fleet/terminals');
      const data = await res.json();
      if (Array.isArray(data)) {
        setTerminals(data);
      }
    } catch (err) {
      console.error('Failed to load terminals:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTerminals();
    const interval = setInterval(fetchTerminals, 10000); // 10s auto-refresh
    return () => clearInterval(interval);
  }, []);

  const handlePing = async (id: string) => {
    setPingingId(id);
    setPingResult(null);
    try {
      const res = await fetch('/api/saas/fleet/ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ terminalId: id }),
      });
      const data = await res.json();
      setPingResult({ id, ms: data.latencyMs });
    } catch (err) {
      console.error(err);
    } finally {
      setPingingId(null);
    }
  };

  const handleDeauthorize = async (id: string) => {
    if (!window.confirm(`Are you sure you want to revoke and de-authorize Terminal ${id}?`)) {
      return;
    }
    try {
      await fetch('/api/saas/fleet/deauthorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ terminalId: id }),
      });
      await fetchTerminals();
    } catch (err) {
      console.error(err);
    }
  };

  const filteredTerminals = terminals.filter(
    (t) =>
      t.terminal_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.machine_uuid.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.local_ip.includes(searchQuery)
  );

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-600 animate-pulse" />
            <span>Retail Fleet Telemetry & Remote Control</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Streaming status of all counter registers, scales, and thermal printers across store locations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search counter, UUID, IP..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-1 focus:ring-[#00478c] w-48 sm:w-60"
            />
          </div>

          <button
            onClick={fetchTerminals}
            disabled={loading}
            className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg transition-colors"
            title="Refresh Fleet"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#00478c]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Ping Result Flash */}
      {pingResult && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between animate-fadeIn">
          <span>
            Ping response from <strong>{pingResult.id}</strong>: <strong>{pingResult.ms}ms</strong> roundtrip latency.
          </span>
          <span className="font-mono text-[10px] text-emerald-700 font-bold">ICMP SUCCESS</span>
        </div>
      )}

      {/* Terminals Table */}
      <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50/80 text-[11px] uppercase tracking-wider text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Counter Terminal</th>
                <th className="py-3.5 px-4">Hardware UUID & OS</th>
                <th className="py-3.5 px-4">Local IP & Installer</th>
                <th className="py-3.5 px-4">Peripherals</th>
                <th className="py-3.5 px-4">CPU & Memory</th>
                <th className="py-3.5 px-4">Status & License</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredTerminals.map((term) => (
                <tr key={term.id} className="hover:bg-slate-50/60 transition-colors">
                  {/* Terminal Name */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          term.license_status === 'active' ? 'bg-emerald-500' : 'bg-rose-500'
                        }`}
                      />
                      <div>
                        <div className="font-bold text-slate-900 text-xs">{term.terminal_name}</div>
                        <span className="text-[10px] text-slate-400 font-mono">{term.id}</span>
                      </div>
                    </div>
                  </td>

                  {/* UUID & OS */}
                  <td className="py-3.5 px-4 font-mono text-[11px]">
                    <div className="text-slate-700">{term.os_type}</div>
                    <div className="text-slate-400 text-[10px] truncate max-w-[140px]">{term.machine_uuid}</div>
                  </td>

                  {/* IP & Installer */}
                  <td className="py-3.5 px-4">
                    <span className="font-mono text-slate-700">{term.local_ip}</span>
                    <div>
                      <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-slate-100 text-[#00478c] border border-slate-200">
                        {term.installer_used.toUpperCase()}
                      </span>
                    </div>
                  </td>

                  {/* Peripherals */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span
                        className={`flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded border ${
                          term.scale_status === 'online'
                            ? 'bg-blue-50 text-[#00478c] border-blue-200'
                            : 'bg-slate-100 text-slate-400 border-slate-200'
                        }`}
                      >
                        <Scale className="w-3 h-3" />
                        {term.scale_status}
                      </span>
                      <span
                        className={`flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded border ${
                          term.printer_status === 'ready'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-slate-100 text-slate-400 border-slate-200'
                        }`}
                      >
                        <Printer className="w-3 h-3" />
                        {term.printer_status}
                      </span>
                    </div>
                  </td>

                  {/* CPU & Memory */}
                  <td className="py-3.5 px-4 font-mono text-[11px]">
                    <span className="text-emerald-700 font-bold">{term.cpu_usage}% CPU</span>
                    <div className="text-slate-400 text-[10px]">{term.memory_mb} MB RAM</div>
                  </td>

                  {/* Status & License */}
                  <td className="py-3.5 px-4">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${
                        term.license_status === 'active'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border-rose-200'
                      }`}
                    >
                      {term.license_status}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-1">
                      {new Date(term.last_ping).toLocaleTimeString()}
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handlePing(term.id)}
                        disabled={pingingId === term.id}
                        className="px-2.5 py-1 text-xs bg-slate-50 hover:bg-slate-100 text-slate-700 rounded border border-slate-200 transition-colors flex items-center gap-1"
                        title="Ping Terminal"
                      >
                        <Zap className="w-3 h-3 text-amber-600" />
                        <span>Ping</span>
                      </button>

                      {term.license_status === 'active' && (
                        <button
                          onClick={() => handleDeauthorize(term.id)}
                          className="px-2 py-1 text-xs bg-rose-50 hover:bg-rose-100 text-rose-700 rounded border border-rose-200 transition-colors"
                          title="Revoke & De-authorize"
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
