import React, { useState, useEffect } from 'react';
import {
  Key,
  ShieldCheck,
  Plus,
  Copy,
  Check,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Search,
  Sparkles,
  Lock,
} from 'lucide-react';

export const LicenseManagerTab: React.FC = () => {
  const [licenses, setLicenses] = useState<any[]>([]);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Mint Form State
  const [storeName, setStoreName] = useState('');
  const [planTier, setPlanTier] = useState('pro');
  const [daysValid, setDaysValid] = useState('365');
  const [hwUuid, setHwUuid] = useState('');
  const [isMinting, setIsMinting] = useState(false);
  const [mintedLicense, setMintedLicense] = useState<any>(null);

  // Verify Form State
  const [tokenToVerify, setTokenToVerify] = useState('');
  const [verifyResult, setVerifyResult] = useState<any>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const fetchLicenses = async () => {
    try {
      const res = await fetch('/api/saas/fleet/terminals'); // We can inspect or query me/mock
      // Query demo licenses
      setLicenses([
        {
          id: 'LIC-BALU-001',
          storeName: 'Plannest HQ Global',
          licenseKey: 'PLANNEST-BALU-ENTERPRISE-PRO',
          planTier: 'enterprise',
          status: 'active',
          expiresAt: '2027-09-04T00:00:00.000Z',
          hardwareUuid: 'HW-BALU-MASTER-DEV',
          isTrial: false,
        },
        {
          id: 'LIC-RAMESH-001',
          storeName: 'FreshMart Supermarket',
          licenseKey: 'PLANNEST-8A2F-C3B1-9920',
          planTier: 'trial',
          status: 'active',
          expiresAt: new Date(Date.now() + 68 * 3600 * 1000).toISOString(),
          hardwareUuid: 'HW-DELL-OPTIPLEX-7090',
          isTrial: true,
        },
        {
          id: 'LIC-ANITA-002',
          storeName: 'Anita Organic Grocers',
          licenseKey: 'PLANNEST-41F9-88DE-0012',
          planTier: 'pro',
          status: 'active',
          expiresAt: '2027-04-15T00:00:00.000Z',
          hardwareUuid: 'HW-HP-PRODESK-400',
          isTrial: false,
        },
      ]);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchLicenses();
  }, []);

  const handleMintLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName) return;
    setIsMinting(true);
    setMintedLicense(null);
    try {
      const res = await fetch('/api/saas/license/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName: storeName,
          planTier,
          daysValid: Number(daysValid),
          hardwareUuid: hwUuid || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMintedLicense(data);
        setLicenses((prev) => [
          {
            id: `LIC-${Date.now().toString(36)}`,
            storeName: data.businessName,
            licenseKey: data.licenseKey,
            planTier: data.planTier,
            status: 'active',
            expiresAt: data.expiresAt,
            hardwareUuid: hwUuid || 'Unbound',
            isTrial: data.planTier === 'trial',
          },
          ...prev,
        ]);
        setStoreName('');
        setHwUuid('');
      }
    } catch (err: any) {
      alert('Minting failed: ' + err.message);
    } finally {
      setIsMinting(false);
    }
  };

  const handleVerifyToken = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenToVerify.trim()) return;
    setIsVerifying(true);
    setVerifyResult(null);
    try {
      const res = await fetch('/api/saas/license/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tokenToVerify.trim() }),
      });
      const data = await res.json();
      setVerifyResult(data);
    } catch (err: any) {
      setVerifyResult({ valid: false, error: err.message });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Key className="w-5 h-5 text-[#00478c]" />
            <span>Cryptographic License Center & Hardware Binding</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Issue asymmetric HMAC-SHA256 hardware tokens to enforce offline license validity and trial periods.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Mint Form */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-1 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>Mint Signed Hardware License</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Generates a cryptographically signed HMAC token bound to store identity and hardware UUID.
            </p>

            <form onSubmit={handleMintLicense} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Store / Business Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Royal Mart Supermarket"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Plan Tier</label>
                  <select
                    value={planTier}
                    onChange={(e) => setPlanTier(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                  >
                    <option value="trial">3-Day Trial</option>
                    <option value="local_starter">Plan A (Local Starter)</option>
                    <option value="pro">Plan A (Local Pro)</option>
                    <option value="enterprise">Plan C (Enterprise Cloud)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Validity Period</label>
                  <select
                    value={daysValid}
                    onChange={(e) => setDaysValid(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                  >
                    <option value="3">3 Days (Free Trial)</option>
                    <option value="30">30 Days (Monthly)</option>
                    <option value="365">365 Days (1-Year)</option>
                    <option value="1095">3 Years (Enterprise)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Hardware Machine UUID (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. HW-DELL-OPTIPLEX-7090 or leave empty for unbound"
                  value={hwUuid}
                  onChange={(e) => setHwUuid(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-mono focus:ring-2 focus:ring-[#00478c]"
                />
              </div>

              <button
                type="submit"
                disabled={isMinting}
                className="w-full py-2.5 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 mt-2 shadow-xs"
              >
                <Key className="w-4 h-4" />
                <span>{isMinting ? 'Signing Token...' : 'Mint Cryptographic License'}</span>
              </button>
            </form>

            {mintedLicense && (
              <div className="mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-800">License Minted!</span>
                  <button
                    onClick={() => handleCopy(mintedLicense.token, 'minted')}
                    className="text-[11px] text-emerald-700 hover:text-emerald-900 flex items-center gap-1 font-semibold"
                  >
                    {copiedKey === 'minted' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'minted' ? 'Copied Token' : 'Copy Token'}</span>
                  </button>
                </div>
                <div className="font-mono text-xs text-slate-800 bg-white p-2 rounded border border-emerald-200 break-all">
                  {mintedLicense.licenseKey}
                </div>
              </div>
            )}
          </div>

          {/* Token Verifier Box */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-1 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#00478c]" />
              <span>Validate & Inspect License Token</span>
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Paste any offline .plannestlic token string to verify HMAC authenticity and expiration.
            </p>

            <form onSubmit={handleVerifyToken} className="space-y-3">
              <textarea
                rows={2}
                placeholder="Paste token payload here..."
                value={tokenToVerify}
                onChange={(e) => setTokenToVerify(e.target.value)}
                className="w-full text-[11px] font-mono p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
              <button
                type="submit"
                disabled={isVerifying}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
              >
                <span>Verify Signature</span>
              </button>
            </form>

            {verifyResult && (
              <div
                className={`mt-3 p-3 rounded-xl border text-xs font-mono ${
                  verifyResult.valid
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                <div className="font-bold">{verifyResult.valid ? 'VALID SIGNATURE' : 'SIGNATURE REJECTED'}</div>
                <p className="text-[11px] mt-1">{verifyResult.message || verifyResult.error}</p>
                {verifyResult.payload && (
                  <div className="mt-2 pt-2 border-t border-emerald-200 text-[10px] space-y-0.5">
                    <div>Store: {verifyResult.payload.business_name}</div>
                    <div>Plan: {verifyResult.payload.plan_tier}</div>
                    <div>Expires: {new Date(verifyResult.payload.expires_at).toLocaleDateString()}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Issued Licenses Table */}
        <div className="lg:col-span-7 bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Active Store Licenses</h3>
              <p className="text-xs text-slate-500">Manage trials, expirations, and machine UUID bindings.</p>
            </div>
            <span className="text-xs font-mono text-slate-500">{licenses.length} Total</span>
          </div>

          <div className="space-y-3">
            {licenses.map((lic) => (
              <div
                key={lic.id}
                className="p-4 rounded-xl bg-slate-50/70 border border-slate-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{lic.storeName}</span>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${
                        lic.isTrial
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}
                    >
                      {lic.planTier}
                    </span>
                  </div>

                  <div className="font-mono text-xs text-slate-700 flex items-center gap-2">
                    <span>{lic.licenseKey}</span>
                    <button
                      onClick={() => handleCopy(lic.licenseKey, lic.id)}
                      className="text-slate-400 hover:text-slate-700"
                      title="Copy Key"
                    >
                      {copiedKey === lic.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-500">Hardware: {lic.hardwareUuid}</p>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-xs text-slate-600 font-mono">
                    Expires: {new Date(lic.expiresAt).toLocaleDateString()}
                  </span>
                  <div className="text-[10px] text-emerald-700 font-semibold mt-0.5">Offline Authorized</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
