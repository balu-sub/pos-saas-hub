import React, { useState, useEffect } from 'react';
import { Users, UserPlus, Trash2, Key, Shield, ShieldCheck, Mail, Phone, Lock, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface StaffUser {
  id: string;
  uuid: string;
  name: string;
  email: string;
  phone?: string;
  role: string;
  privileges: string;
  createdAt: string;
}

export const StaffManagementTab: React.FC = () => {
  const { currentUser } = useAuth();
  const [staffList, setStaffList] = useState<StaffUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New staff form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [userId, setUserId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [privileges, setPrivileges] = useState('staff_operator');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchStaff = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/saas/staff');
      const data = await res.json();
      if (data.success) {
        setStaffList(data.staff || []);
      }
    } catch (err: any) {
      console.error('Failed to load staff list:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  const handleCreateStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !password) return;
    setIsSubmitting(true);
    setNotice(null);

    try {
      const res = await fetch('/api/saas/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userId.trim() || undefined,
          name: name.trim(),
          email: email.trim() || undefined,
          password: password.trim(),
          phone: phone.trim() || undefined,
          privileges,
        }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        setNotice({ type: 'error', text: data.error || 'Failed to create staff account' });
      } else {
        setNotice({ type: 'success', text: `✓ Staff account for ${name} created successfully! They can log in immediately.` });
        setUserId('');
        setName('');
        setEmail('');
        setPassword('');
        setPhone('');
        setShowAddForm(false);
        fetchStaff();
      }
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Network error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteStaff = async (id: string, staffName: string) => {
    if (!window.confirm(`Are you sure you want to remove staff account for "${staffName}" (${id})?`)) return;

    try {
      const res = await fetch(`/api/saas/staff/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setNotice({ type: 'error', text: data.error || 'Could not delete staff member' });
      } else {
        setNotice({ type: 'success', text: `Staff account ${id} removed.` });
        fetchStaff();
      }
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Error deleting staff' });
    }
  };

  const isSuperAdmin = currentUser?.privileges === 'super_admin' || currentUser?.email === 'balu.sub@gmail.com' || currentUser?.id === 'USR-BALU-001';

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Tab Header Banner */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <ShieldCheck className="w-5 h-5 text-[#00478c]" />
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Staff Team & Access Control</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-50 text-[#00478c] border border-blue-200 rounded-full">
              Super Admin Managed
            </span>
          </div>
          <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
            Super Admin (Balu) provisions staff credentials here. Staff log in through the same unified Sign In page using their User ID or Email, and the system automatically recognizes them as staff.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchStaff}
            className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-xl transition-colors border border-slate-200"
            title="Refresh staff list"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          {isSuperAdmin && (
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2.5 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>{showAddForm ? 'Cancel Form' : 'Create Staff User'}</span>
            </button>
          )}
        </div>
      </div>

      {notice && (
        <div
          className={`p-4 text-xs font-medium rounded-xl flex items-center justify-between gap-3 ${
            notice.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {notice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            )}
            <span>{notice.text}</span>
          </div>
          <button onClick={() => setNotice(null)} className="text-slate-400 hover:text-slate-700 text-xs">
            ✕
          </button>
        </div>
      )}

      {/* Creation Modal / Form */}
      {showAddForm && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs animate-fadeIn">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-[#00478c]" />
                <span>Create New Staff Account</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Staff member will automatically receive Staff Hub and POS Terminal access upon signing in.
              </p>
            </div>
            <button
              onClick={() => setShowAddForm(false)}
              className="text-xs text-slate-600 hover:text-slate-900 px-2.5 py-1 bg-slate-100 rounded-lg"
            >
              Close
            </button>
          </div>

          <form onSubmit={handleCreateStaff} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Anand Kumar"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                User ID / Login Username <span className="text-slate-400">(Optional)</span>
              </label>
              <input
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="e.g. anand or STAFF-02"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Password <span className="text-rose-500">*</span>
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Initial login password"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Work Email <span className="text-slate-400">(Optional)</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="anand@plannest.internal"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98400 00000"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Privilege Level</label>
              <select
                value={privileges}
                onChange={(e) => setPrivileges(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              >
                <option value="staff_operator">Staff Operator (Fleet & Diagnostics)</option>
                <option value="license_manager">License Specialist (Key Minting)</option>
                <option value="deployment_eng">Deployment Engineer (Wizards & OTA)</option>
                <option value="super_admin">Super Administrator (Full Fleet & Team Control)</option>
              </select>
            </div>

            <div className="sm:col-span-2 lg:col-span-3 flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-lg shadow-xs transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {isSubmitting ? (
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Key className="w-3.5 h-3.5" />
                    <span>Create Staff Login</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Staff Roster Table */}
      <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50/70 border-b border-slate-200/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-500" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Active Plannest Staff Directory ({staffList.length})
            </h3>
          </div>
          <span className="text-[11px] text-slate-500">
            Sign In uses unified credentials check for all users
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">User ID / Name</th>
                <th className="py-3 px-4 font-semibold">Email / Contact</th>
                <th className="py-3 px-4 font-semibold">Role & Access</th>
                <th className="py-3 px-4 font-semibold">Privileges</th>
                <th className="py-3 px-4 font-semibold">Provisioned</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {staffList.map((staff) => {
                const isBalu = staff.id === 'USR-BALU-001' || staff.email === 'balu.sub@gmail.com';
                return (
                  <tr key={staff.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                          isBalu ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-blue-50 text-[#00478c] border border-blue-200'
                        }`}>
                          {staff.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900 flex items-center gap-1.5">
                            <span>{staff.name}</span>
                            {isBalu && (
                              <span className="text-[9px] px-1.5 py-0.2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded font-semibold uppercase">
                                Super Admin
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] font-mono text-slate-500">{staff.id}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex flex-col">
                        <span className="text-slate-800 font-mono text-[11px]">{staff.email}</span>
                        {staff.phone && <span className="text-slate-500 text-[10px]">{staff.phone}</span>}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-blue-50 text-[#00478c] border border-blue-200 uppercase">
                        {staff.role}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="text-slate-600 font-mono text-[11px]">
                        {staff.privileges}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-slate-500 text-[11px]">
                      {staff.createdAt ? new Date(staff.createdAt).toLocaleDateString() : 'Active'}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      {isBalu ? (
                        <span className="text-[10px] text-slate-400 italic">Protected</span>
                      ) : (
                        isSuperAdmin && (
                          <button
                            onClick={() => handleDeleteStaff(staff.id, staff.name)}
                            className="p-1.5 text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors"
                            title="Remove staff account"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )
                      )}
                    </td>
                  </tr>
                );
              })}

              {staffList.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No staff accounts found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
