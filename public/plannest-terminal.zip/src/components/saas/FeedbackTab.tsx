import React, { useState, useEffect } from 'react';
import { MessageSquare, Star, CheckCircle2, Clock, AlertCircle, RefreshCw, Filter, Search } from 'lucide-react';
import { PurchaserFeedback } from '../../types/saas';

export const FeedbackTab: React.FC = () => {
  const [feedbacks, setFeedbacks] = useState<PurchaserFeedback[]>([]);
  const [loading, setLoading] = useState(false);
  const [filterCategory, setFilterCategory] = useState('all');

  const fetchFeedbacks = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/saas/feedback');
      const data = await res.json();
      if (Array.isArray(data)) {
        setFeedbacks(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const handleUpdateStatus = async (id: string, newStatus: 'pending' | 'in_review' | 'resolved') => {
    try {
      await fetch(`/api/saas/feedback/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      setFeedbacks((prev) => prev.map((f) => (f.id === id ? { ...f, status: newStatus } : f)));
    } catch (err) {
      console.error(err);
    }
  };

  const filteredFeedbacks = feedbacks.filter((f) => {
    if (filterCategory === 'all') return true;
    return f.category.toLowerCase().includes(filterCategory.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#00478c]" />
            <span>Purchaser Feedback & Hardware Compatibility Tickets</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Incoming support inquiries, weighing scale drivers, and printer feedback from retail store owners.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
          >
            <option value="all">All Categories</option>
            <option value="Weighing Scale">Weighing Scale</option>
            <option value="Hardware Integration">Hardware Integration</option>
            <option value="Thermal Receipts">Thermal Receipts</option>
            <option value="Installation">Installation</option>
          </select>

          <button
            onClick={fetchFeedbacks}
            disabled={loading}
            className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-lg transition-colors"
            title="Refresh Feedback"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#00478c]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Feedback Cards */}
      <div className="space-y-4">
        {filteredFeedbacks.map((fb) => (
          <div
            key={fb.id}
            className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3 hover:border-slate-300 transition-all"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="flex text-amber-500">
                  {Array.from({ length: fb.rating }).map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
                <span className="text-xs font-bold text-slate-900">{fb.business_name}</span>
                <span className="text-xs text-slate-500 font-mono">({fb.purchaser_email})</span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-blue-50 text-[#00478c] border border-blue-200">
                  {fb.category}
                </span>
                <select
                  value={fb.status}
                  onChange={(e) => handleUpdateStatus(fb.id, e.target.value as any)}
                  className={`text-[11px] font-bold px-2 py-1 rounded-lg border bg-slate-50 focus:outline-none ${
                    fb.status === 'resolved'
                      ? 'text-emerald-700 border-emerald-200 bg-emerald-50'
                      : fb.status === 'in_review'
                      ? 'text-amber-700 border-amber-200 bg-amber-50'
                      : 'text-slate-700 border-slate-200'
                  }`}
                >
                  <option value="pending">Pending</option>
                  <option value="in_review">In Review</option>
                  <option value="resolved">Resolved</option>
                </select>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed font-sans">{fb.message}</p>

            <div className="text-[10px] text-slate-400 font-mono pt-1">
              Ticket ID: {fb.id} • Created: {new Date(fb.created_at).toLocaleString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
