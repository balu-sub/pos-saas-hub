import React, { useState } from 'react';
import {
  Laptop,
  Terminal,
  Cloud,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Download,
  Copy,
  Check,
  Building,
  Mail,
  Phone,
  Server,
  Key,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { DeploymentModel, DeploymentWizardState } from '../../types/saas';

export const DeploymentWizard: React.FC = () => {
  const [step, setStep] = useState<number>(1);

  const [wizardData, setWizardData] = useState<DeploymentWizardState>({
    model: 'plan_a',
    businessName: 'Apex Hypermarket & Superstore',
    ownerEmail: 'manager@apexretail.in',
    phone: '+91 98400 55555',
    city: 'Chennai',
    subdomain: 'apexmarket',
    storeCount: 3,
    dbChoice: 'sqlite',
  });

  const [isSimulating, setIsSimulating] = useState(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [generatedArtifacts, setGeneratedArtifacts] = useState<any>(null);
  const [copiedKey, setCopiedKey] = useState(false);

  const startSimulationAndGenerate = async () => {
    setIsSimulating(true);
    setTerminalLogs([]);
    setStep(3);

    const logMessages = [
      `[1/5] Initializing deployment pipeline for model: ${wizardData.model.toUpperCase()}...`,
      `[2/5] Minting HMAC-SHA256 hardware cryptographic license token for "${wizardData.businessName}"...`,
      `[3/5] Configuring database schemas and offline LWW CRDT conflict resolver...`,
      `[4/5] Packaging zero-permission desktop kiosk wrappers and RS232 scale hooks...`,
      `[5/5] Deployment artifacts compiled successfully! Launchpad ready.`,
    ];

    for (let i = 0; i < logMessages.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 350));
      setTerminalLogs((prev) => [...prev, logMessages[i]]);
    }

    try {
      if (wizardData.model === 'plan_a') {
        // Generate license token
        const licRes = await fetch('/api/saas/license/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            businessName: wizardData.businessName,
            planTier: 'pro',
            daysValid: 365,
          }),
        });
        const licData = await licRes.json();
        setGeneratedArtifacts({
          licenseKey: licData.licenseKey,
          token: licData.token,
          model: 'plan_a',
          downloadBat: `/api/saas/plan-a/installer-script?os=bat&token=${licData.token}&key=${licData.licenseKey}&store=${encodeURIComponent(
            wizardData.businessName
          )}`,
          downloadPs1: `/api/saas/plan-a/installer-script?os=ps1&token=${licData.token}&key=${licData.licenseKey}&store=${encodeURIComponent(
            wizardData.businessName
          )}`,
          downloadSh: `/api/saas/plan-a/installer-script?os=sh&token=${licData.token}&key=${licData.licenseKey}&store=${encodeURIComponent(
            wizardData.businessName
          )}`,
        });
      } else if (wizardData.model === 'plan_b') {
        const vpsRes = await fetch('/api/saas/plan-b/generate-cloud-init', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            storeName: wizardData.businessName,
            subdomain: wizardData.subdomain,
            dbDriver: wizardData.dbChoice,
          }),
        });
        const vpsData = await vpsRes.json();
        setGeneratedArtifacts({
          model: 'plan_b',
          cloudInit: vpsData.cloudInitScript,
          dockerCompose: vpsData.dockerCompose,
          subdomain: wizardData.subdomain,
        });
      } else {
        // Plan C: Cloud Cluster
        const cRes = await fetch('/api/saas/plan-c/provision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            businessName: wizardData.businessName,
            ownerEmail: wizardData.ownerEmail,
            subdomain: wizardData.subdomain,
            storeCount: wizardData.storeCount,
          }),
        });
        const cData = await cRes.json();
        setGeneratedArtifacts({
          model: 'plan_c',
          ...cData,
        });
      }
      setIsSimulating(false);
      setStep(4);
    } catch (err: any) {
      alert('Error during provisioning: ' + err.message);
      setIsSimulating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Wizard Step Progress Bar */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          {[
            { num: 1, label: 'Architecture' },
            { num: 2, label: 'Store Config' },
            { num: 3, label: 'Compiling' },
            { num: 4, label: 'Launchpad' },
          ].map((s, idx) => (
            <React.Fragment key={s.num}>
              <div className="flex items-center gap-2">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    step === s.num
                      ? 'bg-[#00478c] text-white ring-4 ring-blue-100'
                      : step > s.num
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {step > s.num ? <Check className="w-3.5 h-3.5" /> : s.num}
                </div>
                <span
                  className={`text-xs font-medium hidden sm:inline ${
                    step === s.num ? 'text-slate-900 font-bold' : 'text-slate-500'
                  }`}
                >
                  {s.label}
                </span>
              </div>
              {idx < 3 && <div className={`flex-1 h-0.5 mx-2 ${step > idx + 1 ? 'bg-emerald-500' : 'bg-slate-200'}`} />}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* STEP 1: MODEL SELECTION */}
      {step === 1 && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
          <div>
            <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">Step 1 of 4</span>
            <h2 className="text-xl font-bold text-slate-900 mt-1">Select Target Deployment Architecture</h2>
            <p className="text-xs text-slate-500 mt-1">
              Choose how the POS system will be deployed to physical counters or cloud infrastructure.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Plan A */}
            <div
              onClick={() => setWizardData({ ...wizardData, model: 'plan_a' })}
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                wizardData.model === 'plan_a'
                  ? 'border-[#00478c] bg-blue-50/50 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 bg-blue-50 text-[#00478c] rounded-xl border border-blue-100">
                    <Laptop className="w-5 h-5" />
                  </div>
                  {wizardData.model === 'plan_a' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-[#00478c] text-white rounded-full">
                      SELECTED
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-slate-900">Plan A: Local On-Premises</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Single store offline-first. Instant 1-click Windows (.bat) or Linux installer with embedded SQLite and
                  hardware license token.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-mono text-[#00478c] font-semibold">
                100% Offline • Zero Latency
              </div>
            </div>

            {/* Plan B */}
            <div
              onClick={() => setWizardData({ ...wizardData, model: 'plan_b' })}
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                wizardData.model === 'plan_b'
                  ? 'border-emerald-600 bg-emerald-50/50 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100">
                    <Terminal className="w-5 h-5" />
                  </div>
                  {wizardData.model === 'plan_b' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-600 text-white rounded-full">
                      SELECTED
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-slate-900">Plan B: Self-Hosted VPS</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Deploy to customer's DigitalOcean, Hetzner, or AWS VPS. Automated cloud-init, Docker Compose, and
                  Caddy SSL reverse proxy.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-mono text-emerald-700 font-semibold">
                BYO VPS • Automated SSL
              </div>
            </div>

            {/* Plan C */}
            <div
              onClick={() => setWizardData({ ...wizardData, model: 'plan_c' })}
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                wizardData.model === 'plan_c'
                  ? 'border-purple-600 bg-purple-50/50 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 bg-purple-50 text-purple-700 rounded-xl border border-purple-100">
                    <Cloud className="w-5 h-5" />
                  </div>
                  {wizardData.model === 'plan_c' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-purple-600 text-white rounded-full">
                      SELECTED
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-slate-900">Plan C: Managed Multi-Store Cloud</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Vendor-managed Google Cloud Run & Cloud SQL tenant pool. Pre-configured multi-cashier staff PINs and
                  dedicated subdomain.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-mono text-purple-700 font-semibold">
                Multi-Store • Cloud SQL Pool
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100">
            <button
              onClick={() => setStep(2)}
              className="px-6 py-2.5 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-2"
            >
              <span>Next: Store Configuration</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: STORE CONFIGURATION */}
      {step === 2 && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
          <div>
            <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">Step 2 of 4</span>
            <h2 className="text-xl font-bold text-slate-900 mt-1">Configure Store Parameters</h2>
            <p className="text-xs text-slate-500 mt-1">
              Provide the retail store identity and configuration settings for this deployment instance.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Business / Supermarket Name</label>
              <div className="relative">
                <Building className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={wizardData.businessName}
                  onChange={(e) => setWizardData({ ...wizardData, businessName: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Owner Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  value={wizardData.ownerEmail}
                  onChange={(e) => setWizardData({ ...wizardData, ownerEmail: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Store City / Location</label>
              <input
                type="text"
                value={wizardData.city}
                onChange={(e) => setWizardData({ ...wizardData, city: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Subdomain Slug</label>
              <input
                type="text"
                value={wizardData.subdomain}
                onChange={(e) => setWizardData({ ...wizardData, subdomain: e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '') })}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              />
            </div>

            {wizardData.model === 'plan_c' && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Number of Counters / Lanes</label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={wizardData.storeCount}
                  onChange={(e) => setWizardData({ ...wizardData, storeCount: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Embedded Database Engine</label>
              <select
                value={wizardData.dbChoice}
                onChange={(e) => setWizardData({ ...wizardData, dbChoice: e.target.value as any })}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:ring-2 focus:ring-[#00478c]"
              >
                <option value="sqlite">SQLite Embedded (WAL Mode - Fastest Local)</option>
                <option value="mysql">MySQL / MariaDB Remote Driver</option>
                <option value="cloudsql">Cloud SQL PostgreSQL (Developer Free Tier)</option>
              </select>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-slate-100">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              onClick={startSimulationAndGenerate}
              className="px-6 py-2.5 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate & Build Artifacts</span>
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: LIVE COMPILATION SIMULATION */}
      {step === 3 && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-[#00478c] uppercase tracking-wider">Step 3 of 4</span>
              <h2 className="text-xl font-bold text-slate-900 mt-1">Autonomous Compilation Terminal</h2>
              <p className="text-xs text-slate-500 mt-1">
                Synthesizing cryptographic license, native batch wrappers, and cloud configurations...
              </p>
            </div>
            <RefreshCw className="w-5 h-5 text-[#00478c] animate-spin" />
          </div>

          <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 space-y-2 min-h-[180px]">
            {terminalLogs.map((log, idx) => (
              <div key={idx} className="flex items-center gap-2 animate-fadeIn">
                <span className="text-slate-500 font-mono">&gt;</span>
                <span>{log}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STEP 4: FINAL LAUNCHPAD */}
      {step === 4 && generatedArtifacts && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>DEPLOYMENT READY</span>
              </div>
              <h2 className="text-xl font-bold text-slate-900 mt-2">
                Launchpad: {wizardData.businessName} ({generatedArtifacts.model.toUpperCase()})
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Download the generated installation packages or distribute to retail terminals.
              </p>
            </div>

            <button
              onClick={() => setStep(1)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors self-start sm:self-auto"
            >
              Deploy Another Store
            </button>
          </div>

          {/* Plan A Artifacts */}
          {generatedArtifacts.model === 'plan_a' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Assigned License Key
                  </span>
                  <p className="text-sm font-mono font-bold text-slate-900 mt-0.5">{generatedArtifacts.licenseKey}</p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedArtifacts.licenseKey);
                    setCopiedKey(true);
                    setTimeout(() => setCopiedKey(false), 2000);
                  }}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-medium rounded-lg flex items-center gap-1.5 shadow-xs"
                >
                  {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey ? 'Copied' : 'Copy Key'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <a
                  href={generatedArtifacts.downloadBat}
                  download="install-plannestpos-local.bat"
                  className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 hover:bg-blue-100/70 transition-all flex items-center justify-between"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Windows 1-Click .bat</h4>
                    <p className="text-[11px] text-[#00478c] mt-0.5">Desktop kiosk installer</p>
                  </div>
                  <Download className="w-5 h-5 text-[#00478c]" />
                </a>

                <a
                  href={generatedArtifacts.downloadPs1}
                  download="install-plannestpos-local.ps1"
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-all flex items-center justify-between"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">PowerShell .ps1</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Hardware-bound script</p>
                  </div>
                  <Download className="w-5 h-5 text-slate-500" />
                </a>

                <a
                  href={generatedArtifacts.downloadSh}
                  download="install-plannestpos-linux.sh"
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-all flex items-center justify-between"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Linux Bash .sh</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Ubuntu & Debian setup</p>
                  </div>
                  <Download className="w-5 h-5 text-slate-500" />
                </a>
              </div>
            </div>
          )}

          {/* Plan B Artifacts */}
          {generatedArtifacts.model === 'plan_b' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Target Domain / URL
                </span>
                <p className="text-sm font-mono font-bold text-emerald-700 mt-0.5">
                  https://{generatedArtifacts.subdomain}.plannestpos.com
                </p>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 font-mono text-xs text-slate-200 max-h-60 overflow-y-auto">
                <pre>{generatedArtifacts.cloudInit}</pre>
              </div>
            </div>
          )}

          {/* Plan C Artifacts */}
          {generatedArtifacts.model === 'plan_c' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Tenant Cluster URL</span>
                  <p className="text-sm font-mono font-bold text-purple-700 mt-0.5">
                    {generatedArtifacts.tenantSubdomain}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Dedicated IP: {generatedArtifacts.dedicatedIp}</p>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Multi-Cashier Staff PINs</span>
                  <div className="mt-2 space-y-1 text-xs text-slate-700">
                    <p>Manager: <strong>1234</strong> • Cashier 1: <strong>1111</strong></p>
                    <p>Cashier 2: <strong>2222</strong> • Shift Auditor: <strong>9999</strong></p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
