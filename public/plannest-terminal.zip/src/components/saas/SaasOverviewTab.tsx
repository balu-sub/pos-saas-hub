import React, { useEffect, useState } from 'react';
import {
  Users,
  Store,
  Monitor,
  CheckCircle2,
  Clock,
  TrendingUp,
  Server,
  Zap,
  Scale,
  Printer,
  ChevronRight,
} from 'lucide-react';

interface SaasOverviewTabProps {
  onNavigateTab: (tabKey: string) => void;
  onOpenDiagnostics?: () => void;
}

export const SaasOverviewTab: React.FC<SaasOverviewTabProps> = ({ onNavigateTab }) => {
  const [stats, setStats] = useState({
    activeStores: 14,
    liveTerminals: 4,
    activeTrials: 6,
    totalLicenses: 18,
    avgLatency: '6ms',
    dbHealth: 'Healthy (WAL Mode)',
    stableRelease: 'v2.4.2',
  });

  const [recentTelemetry, setRecentTelemetry] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/saas/fleet/terminals')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setRecentTelemetry(data.slice(0, 4));
          setStats((prev) => ({ ...prev, liveTerminals: data.length }));
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Retail Stores</span>
            <div className="p-2 rounded-xl bg-blue-50 text-[#00478c] border border-blue-100">
              <Store className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-slate-900">{stats.activeStores}</div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-emerald-700 font-medium">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>+3 new stores this week</span>
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Online Fleet Terminals</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-100">
              <Monitor className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-slate-900">{stats.liveTerminals}</div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-emerald-700 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Streaming RS232 heartbeat</span>
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">3-Day Free Trials</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-700 border border-amber-100">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-slate-900">{stats.activeTrials}</div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-amber-700 font-medium">
              <span>85% conversion to Plan A</span>
            </div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">POS Query Latency</span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-700 border border-purple-100">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-extrabold text-slate-900">&lt; 3ms</div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-slate-500">
              <span>SQLite In-Memory Indexing</span>
            </div>
          </div>
        </div>
      </div>

      {/* Live Fleet Heartbeat Summary */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Live Retail Fleet Telemetry</h3>
            <p className="text-xs text-slate-500">Active counter registers streaming real-time hardware status.</p>
          </div>
          <button
            onClick={() => onNavigateTab('fleet')}
            className="text-xs text-[#00478c] hover:underline font-semibold flex items-center gap-1"
          >
            <span>View All Terminals</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {recentTelemetry.map((t) => (
            <div
              key={t.id}
              className="p-4 rounded-xl bg-slate-50/70 border border-slate-200/70 flex items-center justify-between"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-xs font-bold text-slate-900">{t.terminal_name}</span>
                </div>
                <p className="text-[11px] text-slate-500 font-mono">{t.os_type} • IP: {t.local_ip}</p>
                <div className="flex items-center gap-3 text-[10px] text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Scale className="w-3 h-3 text-[#00478c]" />
                    Scale: <strong className="text-slate-800">{t.scale_status}</strong>
                  </span>
                  <span className="flex items-center gap-1">
                    <Printer className="w-3 h-3 text-amber-600" />
                    Printer: <strong className="text-slate-800">{t.printer_status}</strong>
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-mono font-bold text-emerald-700">CPU {t.cpu_usage}%</span>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5">{t.memory_mb} MB RAM</p>
                <span className="text-[10px] px-2 py-0.5 bg-blue-50 text-[#00478c] rounded border border-blue-200 uppercase mt-1 inline-block font-semibold">
                  {t.installer_used}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
