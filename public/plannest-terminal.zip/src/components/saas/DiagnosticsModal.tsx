import React, { useState, useEffect } from 'react';
import { X, Activity, CheckCircle2, AlertTriangle, RefreshCw, Server, ShieldCheck, Database, HardDrive, Cpu } from 'lucide-react';
import { DiagnosticReport, DiagnosticTestItem } from '../../types/saas';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({ isOpen, onClose }) => {
  const [report, setReport] = useState<DiagnosticReport | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const runDiagnostics = async () => {
    setIsRunning(true);
    try {
      const res = await fetch('/api/saas/diagnostics/run');
      const data = await res.json();
      setReport(data);
    } catch (err) {
      console.error('Diagnostics error:', err);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      runDiagnostics();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-fadeIn">
      <div
        className="relative w-full max-w-2xl bg-white text-slate-900 rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-50 text-[#00478c] border border-blue-200">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                System Diagnostics & Infrastructure Self-Test
              </h3>
              <p className="text-xs text-slate-500">
                End-to-end verification of database, cryptography, telemetry, and script compilers.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runDiagnostics}
              disabled={isRunning}
              className="p-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 transition-colors disabled:opacity-50"
              title="Rerun Tests"
            >
              <RefreshCw className={`w-4 h-4 ${isRunning ? 'animate-spin text-[#00478c]' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* Status summary banner */}
          {report && (
            <div
              className={`p-4 rounded-xl border flex items-center justify-between ${
                report.overallStatus === 'HEALTHY'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-amber-50 border-amber-200 text-amber-900'
              }`}
            >
              <div className="flex items-center gap-3">
                {report.overallStatus === 'HEALTHY' ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
                )}
                <div>
                  <h4 className="text-sm font-bold tracking-wide">
                    ALL SYSTEMS OPERATIONAL ({report.overallStatus})
                  </h4>
                  <p className="text-xs opacity-90 mt-0.5">
                    Completed 5 rigorous checks in {report.totalDurationMs}ms with zero critical errors.
                  </p>
                </div>
              </div>

              <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-white text-slate-700 border border-slate-200 shadow-xs">
                {new Date(report.timestamp).toLocaleTimeString()}
              </span>
            </div>
          )}

          {/* Test items */}
          <div className="space-y-2.5">
            {report?.tests.map((test: DiagnosticTestItem, idx: number) => {
              const getIcon = () => {
                switch (test.type) {
                  case 'database':
                    return <Database className="w-4 h-4 text-emerald-600" />;
                  case 'security':
                    return <ShieldCheck className="w-4 h-4 text-[#00478c]" />;
                  case 'telemetry':
                    return <Cpu className="w-4 h-4 text-purple-600" />;
                  case 'packaging':
                    return <HardDrive className="w-4 h-4 text-amber-600" />;
                  default:
                    return <Server className="w-4 h-4 text-cyan-600" />;
                }
              };

              return (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-50/60 border border-slate-200 flex items-start justify-between gap-4 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-white border border-slate-200 shadow-xs mt-0.5">{getIcon()}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{test.name}</span>
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-white text-slate-500 border border-slate-200">
                          {test.type}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">{test.detail}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full ${
                        test.passed
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}
                    >
                      {test.passed ? 'PASSED' : 'FAILED'}
                    </span>
                    <p className="text-[10px] font-mono text-slate-400 mt-1">{test.latencyMs}ms</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Engine: Plannest Autonomous Telemetry v2.4.2</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg transition-colors font-medium border border-slate-200"
          >
            Close Self-Test
          </button>
        </div>
      </div>
    </div>
  );
};
