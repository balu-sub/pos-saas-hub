import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { SaasOverviewTab } from './SaasOverviewTab';
import { DeploymentWizard } from './DeploymentWizard';
import { FleetManagementTab } from './FleetManagementTab';
import { LicenseManagerTab } from './LicenseManagerTab';
import { ReleaseManagementTab } from './ReleaseManagementTab';
import { FeedbackTab } from './FeedbackTab';
import { StaffManagementTab } from './StaffManagementTab';
import { DiagnosticsModal } from './DiagnosticsModal';
import { PWAInstallButton } from '../common/PWAInstallButton';
import {
  LayoutDashboard,
  Wand2,
  Radio,
  Key,
  Layers,
  MessageSquare,
  Users,
  Activity,
  Monitor,
  LogOut,
  ShieldCheck,
  Server,
  Zap,
  Home,
  CheckCircle2,
} from 'lucide-react';

export const SaasHubScreen: React.FC = () => {
  const { currentUser, isAuthorizedForSimulation, setCurrentView, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState<boolean>(false);

  const navTabs = [
    { key: 'overview', label: 'Overview', icon: LayoutDashboard },
    { key: 'wizard', label: 'Deployment Wizard', icon: Wand2 },
    { key: 'fleet', label: 'Fleet Telemetry', icon: Radio },
    { key: 'licenses', label: 'License Manager', icon: Key },
    { key: 'staff', label: 'Staff Team & Access', icon: Users },
    { key: 'releases', label: 'OTA Releases', icon: Layers },
    { key: 'feedback', label: 'Purchaser Feedback', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-[#FDFDFE] text-slate-900 flex flex-col font-sans selection:bg-[#00478c] selection:text-white">
      {/* Top Cockpit Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-slate-200/70 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-20 flex items-center justify-between">
            {/* Left Brand */}
            <div className="flex items-center cursor-pointer" onClick={() => setActiveTab('overview')}>
              <img
                src="/Logo.png"
                alt="Plannest POS"
                className="h-14 md:h-16 w-auto max-w-[240px] object-contain"
                loading="eager"
              />
            </div>

            {/* Middle Real-time Status Chips */}
            <div className="hidden lg:flex items-center gap-2.5 text-[11px] font-mono">
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>FLEET ONLINE</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium">
                <Server className="w-3 h-3 text-[#00478c]" />
                <span>SQLITE (WAL MODE)</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium">
                <Zap className="w-3 h-3 text-amber-600" />
                <span>LATENCY &lt; 3MS</span>
              </div>
            </div>

            {/* Right Action Buttons */}
            <div className="flex items-center gap-2.5">
              {/* Install Tablet App */}
              <PWAInstallButton variant="saas" />

              {/* System Diagnostics Runner */}
              <button
                onClick={() => setIsDiagnosticsOpen(true)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Activity className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">Self-Test</span>
              </button>

              {/* POS Terminal Simulator (Super Admin Balu only) */}
              {isAuthorizedForSimulation && (
                <button
                  onClick={() => setCurrentView('pos_terminal')}
                  className="px-3.5 py-1.5 bg-[#00478c] hover:bg-[#003366] text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                  title="Launch POS Terminal View"
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Launch POS Terminal</span>
                </button>
              )}

              {/* User Pill */}
              <div className="hidden md:flex items-center gap-2 pl-2 border-l border-slate-200">
                <div className="w-7 h-7 rounded-full bg-blue-100 text-[#00478c] border border-blue-200 flex items-center justify-center font-bold text-xs">
                  {currentUser?.businessName?.[0] || 'B'}
                </div>
                <div className="text-left">
                  <span className="text-xs font-bold text-slate-900 block leading-tight">
                    {currentUser?.businessName || currentUser?.email || 'Balu (Admin)'}
                  </span>
                  <span className="text-[10px] text-emerald-700 font-mono font-semibold">Super Admin</span>
                </div>
              </div>

              {/* Home & Sign Out */}
              <button
                onClick={() => setCurrentView('home')}
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
                title="Marketing Home"
              >
                <Home className="w-4 h-4" />
              </button>
              <button
                onClick={logout}
                className="p-1.5 text-slate-500 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Navigation Bar Tabs */}
          <nav className="flex space-x-1 overflow-x-auto py-2 border-t border-slate-200 scrollbar-none">
            {navTabs.map((t) => {
              const Icon = t.icon;
              const isActive = activeTab === t.key;
              return (
                <button
                  key={t.key}
                  onClick={() => setActiveTab(t.key)}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 ${
                    isActive
                      ? 'bg-blue-50 text-[#00478c] border border-blue-200 font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#00478c]' : 'text-slate-400'}`} />
                  <span>{t.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Tab Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <SaasOverviewTab onNavigateTab={setActiveTab} onOpenDiagnostics={() => setIsDiagnosticsOpen(true)} />
        )}
        {activeTab === 'wizard' && <DeploymentWizard />}
        {activeTab === 'fleet' && <FleetManagementTab />}
        {activeTab === 'licenses' && <LicenseManagerTab />}
        {activeTab === 'staff' && <StaffManagementTab />}
        {activeTab === 'releases' && <ReleaseManagementTab />}
        {activeTab === 'feedback' && <FeedbackTab />}
      </main>

      {/* Minimalist Footer */}
      <footer className="bg-white border-t border-slate-200 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center text-xs text-slate-500">
          <span>© 2026 Plannest Systems. All rights reserved.</span>
        </div>
      </footer>

      {/* System Diagnostics Modal */}
      <DiagnosticsModal isOpen={isDiagnosticsOpen} onClose={() => setIsDiagnosticsOpen(false)} />
    </div>
  );
};
