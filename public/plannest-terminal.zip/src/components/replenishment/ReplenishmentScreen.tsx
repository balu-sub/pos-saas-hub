import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { PurchaseOrder, Supplier, PurchaseOrderItem, ThreeWayMatchRecord } from '../../types/pos';
import { apiClient } from '../../services/apiClient';
import { exportToCSV } from '../../utils/csvExport';
import { generatePurchaseOrderPDF, generateAllPOsReportPDF, generateSupplierDirectoryPDF } from '../../utils/pdfExport';
import { playKeypadClick, playSuccessChime, playWarningTone } from '../../utils/audio';

type TabType = 'replenishment' | 'suppliers' | 'orders' | 'matching';

export const ReplenishmentScreen: React.FC = () => {
  const { products, outletProfile } = usePOS();

  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<TabType>('replenishment');

  // Server Data
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [matches, setMatches] = useState<ThreeWayMatchRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Supplier Add / Edit Modal State
  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [supplierForm, setSupplierForm] = useState({
    name: '',
    contactPerson: '',
    contactEmail: '',
    phone: '',
    leadTimeDays: 2,
    rating: 4.5,
    paymentTerms: 'Net 15',
    marketType: 'Mandi Trader' as 'Mandi Trader' | 'FMCG Distributor' | 'Dairy Co-op' | 'Farmer Producer Group',
  });
  const [supplierToDelete, setSupplierToDelete] = useState<Supplier | null>(null);

  // Multi-Item PO Creation Modal State
  const [isCreatePoModalOpen, setIsCreatePoModalOpen] = useState(false);
  const [selectedPoSupplierId, setSelectedPoSupplierId] = useState<string>('');
  const [poExpectedDelivery, setPoExpectedDelivery] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().slice(0, 10)
  );
  const [poItems, setPoItems] = useState<
    Array<{
      id: string;
      productId?: string;
      sku: string;
      productName: string;
      variantId?: string;
      quantityOrdered: number;
      unit: string;
      unitCost: number;
      totalCost: number;
    }>
  >([]);
  const [selectedProductToAdd, setSelectedProductToAdd] = useState<string>('');
  const [catalogSearchTerm, setCatalogSearchTerm] = useState<string>('');
  const [showCustomItemInput, setShowCustomItemInput] = useState(false);
  const [customItemName, setCustomItemName] = useState('');
  const [customItemUnit, setCustomItemUnit] = useState('kg');
  const [customItemQty, setCustomItemQty] = useState(20);
  const [customItemCost, setCustomItemCost] = useState(30);

  // Recommendations Multi-Selection State (tracked by unique product ID)
  const [selectedRecIds, setSelectedRecIds] = useState<string[]>([]);
  const [recSortField, setRecSortField] = useState<
    'name' | 'stock' | 'velocity' | 'daysLeft' | 'status' | 'suggested'
  >('daysLeft');
  const [recSortAsc, setRecSortAsc] = useState<boolean>(true);

  // GRN Receiving Modal State
  const [isGrnModalOpen, setIsGrnModalOpen] = useState(false);
  const [grnTargetPo, setGrnTargetPo] = useState<PurchaseOrder | null>(null);
  const [grnInvoiceNumber, setGrnInvoiceNumber] = useState('');
  const [grnInvoiceAmount, setGrnInvoiceAmount] = useState<number>(0);
  const [grnNotes, setGrnNotes] = useState('');
  const [grnKeepPoOpenOption, setGrnKeepPoOpenOption] = useState<'keep_open' | 'force_close'>('keep_open');
  const [poFilter, setPoFilter] = useState<'ALL' | 'ACTIVE' | 'PARTIALLY_RECEIVED' | 'FULFILLED'>('ALL');
  const [poDateFilter, setPoDateFilter] = useState<'ALL' | 'TODAY' | 'YESTERDAY_TODAY' | 'LAST_7_DAYS' | 'THIS_MONTH' | 'CUSTOM'>('ALL');
  const [poCustomStartDate, setPoCustomStartDate] = useState<string>('');
  const [poCustomEndDate, setPoCustomEndDate] = useState<string>('');
  const [poSearchQuery, setPoSearchQuery] = useState<string>('');
  const [grnItems, setGrnItems] = useState<
    Array<{
      id: string;
      sku: string;
      productName: string;
      variantId?: string;
      quantityOrdered: number;
      quantityAlreadyReceived: number;
      quantityPending: number;
      quantityReceived: number; // This intake quantity
      unit: string;
      unitCost: number;
      disposition: 'ACCEPT' | 'HOLD' | 'REJECT';
      holdReason?: string;
      isNonPoItem?: boolean;
    }>
  >([]);
  const [nonPoProductToAdd, setNonPoProductToAdd] = useState('');

  // Load Data on Mount
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [sups, pos, twm] = await Promise.all([
        apiClient.getSuppliers().catch(() => []),
        apiClient.getPurchaseOrders().catch(() => []),
        apiClient.getThreeWayMatches().catch(() => []),
      ]);
      setSuppliers(sups);
      
      let loadedPos = pos;
      let loadedMatches = twm;

      // If database returned 0 POs (e.g. fresh DB restart), seed default standard POs automatically
      if (loadedPos.length === 0) {
        try {
          const seedRes = await apiClient.seedDefaultPurchaseOrders(false);
          if (seedRes && seedRes.count > 0) {
            loadedPos = await apiClient.getPurchaseOrders().catch(() => []);
            loadedMatches = await apiClient.getThreeWayMatches().catch(() => []);
          }
        } catch (seedErr) {
          console.warn('Auto-seed check note:', seedErr);
        }
      }

      setPurchaseOrders(loadedPos);
      setMatches(loadedMatches);
    } catch (err: any) {
      console.error('Failed to load replenishment data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 3500);
  };

  // -------------------------------------------------------------
  // SUPPLIER CRUD OPERATIONS
  // -------------------------------------------------------------
  const handleOpenAddSupplier = () => {
    setEditingSupplier(null);
    setSupplierForm({
      name: '',
      contactPerson: '',
      contactEmail: '',
      phone: '',
      leadTimeDays: 2,
      rating: 4.5,
      paymentTerms: 'Net 15',
      marketType: 'Mandi Trader',
    });
    setIsSupplierModalOpen(true);
  };

  const handleOpenEditSupplier = (sup: Supplier) => {
    setEditingSupplier(sup);
    setSupplierForm({
      name: sup.name,
      contactPerson: sup.contactPerson || '',
      contactEmail: sup.contactEmail || '',
      phone: sup.phone || '',
      leadTimeDays: sup.leadTimeDays || 2,
      rating: sup.rating || 4.5,
      paymentTerms: sup.paymentTerms || 'Net 15',
      marketType: sup.marketType || 'Mandi Trader',
    });
    setIsSupplierModalOpen(true);
  };

  const handleSaveSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierForm.name.trim()) {
      showToast('Supplier Name is required', 'error');
      return;
    }

    try {
      if (editingSupplier) {
        await apiClient.updateSupplier(editingSupplier.id, supplierForm);
        showToast(`Supplier "${supplierForm.name}" updated successfully!`);
      } else {
        await apiClient.createSupplier(supplierForm);
        showToast(`Supplier "${supplierForm.name}" created successfully!`);
      }
      playSuccessChime();
      setIsSupplierModalOpen(false);
      await loadData();
    } catch (err: any) {
      showToast(err.message || 'Failed to save supplier', 'error');
    }
  };

  const handleDeleteSupplier = async () => {
    if (!supplierToDelete) return;
    try {
      await apiClient.deleteSupplier(supplierToDelete.id);
      showToast(`Supplier "${supplierToDelete.name}" removed successfully.`);
      playSuccessChime();
      setSupplierToDelete(null);
      await loadData();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete supplier', 'error');
    }
  };

  // -------------------------------------------------------------
  // MULTI-ITEM PURCHASE ORDER CREATION
  // -------------------------------------------------------------
  const handleOpenCreatePO = (prefillSupplierId?: string, prefillItems?: any | any[]) => {
    const targetSup = prefillSupplierId || (suppliers[0]?.id ?? '');
    setSelectedPoSupplierId(targetSup);
    setPoExpectedDelivery(new Date(Date.now() + 86400000).toISOString().slice(0, 10));
    setCatalogSearchTerm('');
    setShowCustomItemInput(false);

    if (prefillItems) {
      const itemsArray = Array.isArray(prefillItems) ? prefillItems : [prefillItems];
      setPoItems(
        itemsArray.map((it, idx) => ({
          id: `item-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
          productId: it.id || it.productId,
          sku: it.sku || `SKU-${idx + 1}`,
          productName: (it.name || it.productName || 'Produce Item').replace(/\s*\(\s*\)/g, '').trim(),
          variantId: it.variantId,
          quantityOrdered: Number(it.suggestedQty || it.quantityOrdered) || 20,
          unit: it.unit || 'kg',
          unitCost: Number(it.costPrice || it.unitCost) || 25,
          totalCost: (Number(it.suggestedQty || it.quantityOrdered) || 20) * (Number(it.costPrice || it.unitCost) || 25),
        }))
      );
    } else {
      setPoItems([]);
    }
    setIsCreatePoModalOpen(true);
  };

  const handleAddItemToPo = (prodId: string) => {
    if (!prodId) return;
    const prod = products.find((p) => p.id === prodId);
    if (!prod) return;

    // Clean up product name if it has unwanted parentheses
    const cleanName = prod.name ? prod.name.replace(/\s*\(\s*\)/g, '').trim() : 'Produce Item';
    const variant = prod.variants?.[0];
    const unitCost = variant?.costPrice || (prod.sellingPrice ? Math.round(prod.sellingPrice * 0.75) : 30);
    const qty = 20;

    const newItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      productId: prod.id,
      sku: prod.sku || '',
      productName: cleanName,
      variantId: variant?.id,
      quantityOrdered: qty,
      unit: prod.unit || 'kg',
      unitCost: unitCost,
      totalCost: qty * unitCost,
    };

    setPoItems((prev) => [...prev, newItem]);
    showToast(`Added ${cleanName} (${qty} ${prod.unit || 'kg'}) to PO`);
    // Reset selection so the dropdown returns to placeholder and user can pick the next item
    setSelectedProductToAdd('');
  };

  const handleAddCustomItemToPo = () => {
    if (!customItemName.trim()) {
      showToast('Please enter produce or item name', 'error');
      return;
    }
    const qty = Number(customItemQty) || 10;
    const cost = Number(customItemCost) || 25;
    const newItem = {
      id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      sku: `SKU-CUST-${Date.now().toString().slice(-4)}`,
      productName: customItemName.trim(),
      variantId: undefined,
      quantityOrdered: qty,
      unit: customItemUnit || 'kg',
      unitCost: cost,
      totalCost: qty * cost,
    };
    setPoItems((prev) => [...prev, newItem]);
    setCustomItemName('');
    setCustomItemQty(20);
    setCustomItemCost(30);
    setShowCustomItemInput(false);
    showToast(`Added custom item "${newItem.productName}" to PO`);
  };

  const handleAddAllLowStockToPo = () => {
    const lowStock = replenishmentRecommendations.filter((r) => r.isCritical);
    if (lowStock.length === 0) {
      showToast('All items currently have healthy stock levels!');
      return;
    }
    const newItems = [...poItems];
    let addedCount = 0;
    lowStock.forEach((rec) => {
      const existingIdx = newItems.findIndex((it) => it.sku === rec.sku);
      const qty = rec.suggestedQty || 25;
      const cost = rec.costPrice || 25;
      if (existingIdx >= 0) {
        newItems[existingIdx].quantityOrdered = Math.max(newItems[existingIdx].quantityOrdered, qty);
        newItems[existingIdx].totalCost = newItems[existingIdx].quantityOrdered * newItems[existingIdx].unitCost;
      } else {
        newItems.push({
          id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          sku: rec.sku,
          productName: rec.name,
          variantId: rec.variantId,
          quantityOrdered: qty,
          unit: rec.unit || 'kg',
          unitCost: cost,
          totalCost: qty * cost,
        });
        addedCount++;
      }
    });
    setPoItems(newItems);
    showToast(`Populated PO with ${lowStock.length} low-stock recommendations!`);
  };

  const handleToggleRecId = (id: string) => {
    setSelectedRecIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllRecs = () => {
    const allIds = replenishmentRecommendations.map((r) => r.id);
    if (selectedRecIds.length === allIds.length) {
      setSelectedRecIds([]);
    } else {
      setSelectedRecIds(allIds);
    }
  };

  const handleOpenCreatePOWithSelectedRecs = () => {
    const selectedItems = replenishmentRecommendations
      .filter((r) => selectedRecIds.includes(r.id))
      .map((r) => ({
        id: r.id,
        sku: r.sku,
        name: r.name,
        variantId: r.variantId,
        suggestedQty: r.suggestedQty || 20,
        unit: r.unit,
        costPrice: r.costPrice,
      }));

    if (selectedItems.length === 0) {
      showToast('Please select at least one item from the table', 'error');
      return;
    }

    handleOpenCreatePO(suppliers[0]?.id, selectedItems);
    setSelectedRecIds([]);
  };

  const handleUpdatePoItemQty = (index: number, newQty: number) => {
    const validQty = Math.max(0.1, newQty);
    setPoItems(
      poItems.map((item, i) =>
        i === index
          ? {
              ...item,
              quantityOrdered: validQty,
              totalCost: validQty * item.unitCost,
            }
          : item
      )
    );
  };

  const handleUpdatePoItemCost = (index: number, newCost: number) => {
    const validCost = Math.max(0, newCost);
    setPoItems(
      poItems.map((item, i) =>
        i === index
          ? {
              ...item,
              unitCost: validCost,
              totalCost: item.quantityOrdered * validCost,
            }
          : item
      )
    );
  };

  const handleRemovePoItem = (index: number) => {
    const item = poItems[index];
    const itemName = item?.productName || 'this line item';
    if (!confirm(`Are you sure you want to remove "${itemName}" from this Purchase Order draft?`)) {
      return;
    }
    setPoItems(poItems.filter((_, i) => i !== index));
  };

  const handleIssueMultiItemPO = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPoSupplierId) {
      showToast('Please select a Supplier', 'error');
      return;
    }
    if (poItems.length === 0) {
      showToast('Please add at least one item to this Purchase Order', 'error');
      return;
    }

    const sup = suppliers.find((s) => s.id === selectedPoSupplierId);
    const supplierName = sup ? sup.name : 'Preferred Supplier';
    const grandTotal = poItems.reduce((sum, it) => sum + it.totalCost, 0);

    try {
      const poNum = `PO-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
      await apiClient.createPurchaseOrder({
        poNumber: poNum,
        supplierId: selectedPoSupplierId,
        supplierName: supplierName,
        totalAmount: grandTotal,
        status: 'ISSUED',
        expectedDelivery: poExpectedDelivery,
        items: poItems,
        aiSuggested: false,
      });

      playSuccessChime();
      showToast(`Purchase Order ${poNum} with ${poItems.length} items issued to ${supplierName}!`);
      setIsCreatePoModalOpen(false);
      await loadData();
      setActiveTab('orders');
    } catch (err: any) {
      showToast(err.message || 'Failed to issue Purchase Order', 'error');
    }
  };

  // -------------------------------------------------------------
  // GRN RECEIVING (HOLD / REJECT / ACCEPT, PARTIAL INTAKE & NON-PO ITEMS)
  // -------------------------------------------------------------
  const handleOpenGRNModal = (po: PurchaseOrder) => {
    setGrnTargetPo(po);
    setGrnInvoiceNumber(`INV-${Date.now().toString().slice(-4)}`);
    setGrnNotes('');
    setGrnKeepPoOpenOption('keep_open');

    let initialSuggestedInvoice = 0;

    const initialGrnItems = (po.items || []).map((item) => {
      const quantityOrdered = Number(item.quantityOrdered) || 0;
      const quantityAlreadyReceived = Number(item.quantityReceived) || 0;
      const quantityPending = Math.max(0, quantityOrdered - quantityAlreadyReceived);
      // Default this intake quantity to remaining pending quantity
      const defaultIntakeQty = quantityPending > 0 ? quantityPending : quantityOrdered;
      const unitCost = Number(item.unitCost) || 0;

      initialSuggestedInvoice += defaultIntakeQty * unitCost;

      return {
        id: item.id || `grn-${Math.random()}`,
        sku: item.sku,
        productName: item.productName,
        variantId: item.variantId,
        quantityOrdered,
        quantityAlreadyReceived,
        quantityPending,
        quantityReceived: defaultIntakeQty, // default to what is pending
        unit: item.unit || 'kg',
        unitCost,
        disposition: 'ACCEPT' as 'ACCEPT' | 'HOLD' | 'REJECT',
        holdReason: '',
        isNonPoItem: false,
      };
    });

    setGrnInvoiceAmount(Number(initialSuggestedInvoice.toFixed(2)));
    setGrnItems(initialGrnItems);
    setIsGrnModalOpen(true);
  };

  const handleAddNonPoItemToGrn = (prodId: string) => {
    const prod = products.find((p) => p.id === prodId);
    if (!prod) return;
    const variant = prod.variants?.[0];
    const unitCost = variant?.costPrice || (prod.sellingPrice ? Math.round(prod.sellingPrice * 0.75) : 30);

    setGrnItems([
      ...grnItems,
      {
        id: `nonpo-${Date.now()}`,
        sku: prod.sku,
        productName: `${prod.name} (Non-PO Item)`,
        variantId: variant?.id,
        quantityOrdered: 0,
        quantityAlreadyReceived: 0,
        quantityPending: 0,
        quantityReceived: 10,
        unit: prod.unit || 'kg',
        unitCost: unitCost,
        disposition: 'HOLD', // default non-PO items to HOLD for inspection
        holdReason: 'Item was not on original Purchase Order',
        isNonPoItem: true,
      },
    ]);
    setNonPoProductToAdd('');
  };

  const handleUpdateGrnItemDisposition = (
    index: number,
    disposition: 'ACCEPT' | 'HOLD' | 'REJECT'
  ) => {
    setGrnItems(
      grnItems.map((item, i) =>
        i === index
          ? {
              ...item,
              disposition,
              holdReason:
                disposition === 'HOLD' && !item.holdReason
                  ? 'Quarantined for supervisor quality verification'
                  : disposition === 'REJECT' && !item.holdReason
                  ? 'Damaged or not ordered'
                  : item.holdReason,
            }
          : item
      )
    );
  };

  const handleProcessGRN = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!grnTargetPo) return;

    try {
      const hasPendingQuantityLeft = grnItems.some(
        (i) =>
          !i.isNonPoItem &&
          i.quantityAlreadyReceived + (i.disposition === 'ACCEPT' ? i.quantityReceived : 0) <
            i.quantityOrdered
      );

      const closePo = grnKeepPoOpenOption === 'force_close' || !hasPendingQuantityLeft;

      const res = await apiClient.receiveGRN({
        poId: grnTargetPo.id,
        poNumber: grnTargetPo.poNumber,
        invoiceNumber: grnInvoiceNumber,
        invoiceAmount: Number(grnInvoiceAmount),
        poAmount: grnTargetPo.totalAmount,
        supplierName: grnTargetPo.supplierName,
        receivedItems: grnItems,
        notes: grnNotes,
        closePo,
        poStatusOverride: closePo ? 'FULFILLED' : 'PARTIALLY_RECEIVED',
      });

      playSuccessChime();

      if (res.poStatus === 'PARTIALLY_RECEIVED') {
        showToast(
          `GRN ${res.grnNumber} recorded! Partial intake of Rs. ${res.grnReceivedAmount.toFixed(
            2
          )} added to stock. PO remains active for pending delivery.`
        );
      } else {
        showToast(
          `GRN ${res.grnNumber} finalized! Rs. ${res.grnReceivedAmount.toFixed(
            2
          )} added to stock & PO fulfilled.`
        );
      }

      setIsGrnModalOpen(false);
      await loadData();
      setActiveTab('orders');
    } catch (err: any) {
      showToast(err.message || 'Failed to process GRN', 'error');
    }
  };

  const handleForceClosePo = async (po: PurchaseOrder) => {
    if (
      !window.confirm(
        `Are you sure you want to mark Purchase Order ${po.poNumber} as FULFILLED/CLOSED? Any remaining undelivered quantities will be cancelled.`
      )
    ) {
      return;
    }
    try {
      await apiClient.updatePurchaseOrder(po.id, { status: 'FULFILLED' });
      playSuccessChime();
      showToast(`Purchase Order ${po.poNumber} marked as FULFILLED / Closed.`);
      await loadData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update Purchase Order', 'error');
    }
  };

  // -------------------------------------------------------------
  // VELOCITY / REPLENISHMENT CALCULATION FOR STORE PRODUCTS
  // -------------------------------------------------------------
  const replenishmentRecommendations = products.map((product) => {
    const variant = product.variants?.[0];
    const onHand = variant ? Number(variant.onHand) : 0;
    const reorderLevel = 15;
    const dailyVelocity = (product.id.charCodeAt(0) % 7) + 3;
    const daysRemaining = dailyVelocity > 0 ? (onHand / dailyVelocity).toFixed(1) : '10.0';
    const isCritical = onHand < reorderLevel;
    const suggestedQty = isCritical ? Math.max(25, 40 - onHand) : 0;
    const costPrice = variant?.costPrice || (product.sellingPrice ? Math.round(product.sellingPrice * 0.75) : 30);

    return {
      id: product.id,
      sku: product.sku,
      name: product.name,
      category: product.category,
      unit: product.unit || 'kg',
      variantId: variant?.id,
      onHand,
      dailyVelocity,
      daysRemaining,
      reorderLevel,
      isCritical,
      suggestedQty,
      costPrice,
    };
  }).sort((a, b) => {
    let comp = 0;
    if (recSortField === 'name') {
      comp = a.name.localeCompare(b.name);
    } else if (recSortField === 'stock') {
      comp = a.onHand - b.onHand;
    } else if (recSortField === 'velocity') {
      comp = a.dailyVelocity - b.dailyVelocity;
    } else if (recSortField === 'daysLeft') {
      comp = parseFloat(a.daysRemaining) - parseFloat(b.daysRemaining);
    } else if (recSortField === 'status') {
      comp = (a.isCritical ? 0 : 1) - (b.isCritical ? 0 : 1);
    } else if (recSortField === 'suggested') {
      comp = a.suggestedQty - b.suggestedQty;
    }
    return recSortAsc ? comp : -comp;
  });

  return (
    <div className="flex-1 w-full h-full min-h-0 bg-[#F4F4F5] overflow-y-auto">
      <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-150 font-sans pb-28">
        {/* Toast Feedback - Elevated z-index so it shows over modals */}
      {feedbackMsg && (
        <div
          className={`fixed top-5 right-5 z-[9999] px-4 py-3 rounded-xl shadow-2xl text-white text-xs font-bold flex items-center gap-2 animate-in slide-in-from-top-2 border border-white/20 pointer-events-auto ${
            feedbackMsg.type === 'success' ? 'bg-emerald-600' : 'bg-red-600'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">
            {feedbackMsg.type === 'success' ? 'check_circle' : 'error'}
          </span>
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {/* Screen Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#D4D4D8] pb-4">
        <div>
          <h1 className="text-2xl font-bold text-[#09090B] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00478c] text-[28px]">
              inventory_2
            </span>
            Supplier &amp; Replenishment
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            Supplier master catalog, multi-item purchase orders, goods receipt notes (GRN), and 3-way invoice matching.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => handleOpenCreatePO()}
            className="px-3.5 py-2 bg-[#00478c] hover:bg-[#005eb7] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">add_shopping_cart</span>
            Create Multi-Item PO
          </button>
          <button
            onClick={handleOpenAddSupplier}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">person_add</span>
            Add Supplier
          </button>
          <button
            onClick={() => {
              playKeypadClick();
              loadData();
            }}
            disabled={isLoading}
            className="px-3 py-2 bg-white hover:bg-gray-100 border border-[#D4D4D8] text-gray-700 rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
          >
            <span className={`material-symbols-outlined text-[16px] ${isLoading ? 'animate-spin' : ''}`}>
              refresh
            </span>
            Reload DB
          </button>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-gray-200 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('replenishment')}
          className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'replenishment'
              ? 'bg-[#00478c] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">trending_up</span>
          Replenishment Recommendations ({replenishmentRecommendations.filter((r) => r.isCritical).length} Low Stock)
        </button>

        <button
          onClick={() => setActiveTab('suppliers')}
          className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'suppliers'
              ? 'bg-[#00478c] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">storefront</span>
          Suppliers Master ({suppliers.length})
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'orders'
              ? 'bg-[#00478c] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">receipt_long</span>
          Purchase Orders &amp; GRN ({purchaseOrders.length})
        </button>

        <button
          onClick={() => setActiveTab('matching')}
          className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeTab === 'matching'
              ? 'bg-[#00478c] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <span className="material-symbols-outlined text-[16px]">verified</span>
          3-Way Invoice Matching ({matches.length})
        </button>
      </div>

      {/* --------------------------------------------------------- */}
      {/* TAB 1: REPLENISHMENT RECOMMENDATIONS                     */}
      {/* --------------------------------------------------------- */}
      {activeTab === 'replenishment' && (
        <div className="space-y-4">
          <div className="bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-2xs flex items-center justify-between flex-wrap gap-3">
            <div>
              <h2 className="text-sm font-bold text-[#09090B] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-amber-600 text-[18px]">warning</span>
                Velocity-Based Stock Recommendations
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Calculated from live local database inventory levels, daily velocity, and safe minimum stock thresholds.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {selectedRecIds.length > 0 && (
                <button
                  onClick={handleOpenCreatePOWithSelectedRecs}
                  className="px-3 py-1.5 bg-emerald-700 text-white rounded-lg text-xs font-bold hover:bg-emerald-800 flex items-center gap-1 shadow-sm cursor-pointer animate-in fade-in"
                >
                  <span className="material-symbols-outlined text-[15px]">add_shopping_cart</span>
                  Create PO with {selectedRecIds.length} Selected
                </button>
              )}
              <button
                onClick={() => {
                  const critical = replenishmentRecommendations.filter((r) => r.isCritical);
                  if (critical.length === 0) {
                    showToast('All items currently have healthy stock levels!');
                    return;
                  }
                  handleOpenCreatePO(
                    suppliers[0]?.id,
                    critical.map((c) => ({
                      id: c.id,
                      sku: c.sku,
                      name: c.name,
                      variantId: c.variantId,
                      suggestedQty: c.suggestedQty,
                      unit: c.unit,
                      costPrice: c.costPrice,
                    }))
                  );
                }}
                className="px-3 py-1.5 bg-[#00478c] text-white rounded-lg text-xs font-bold hover:bg-[#005eb7] flex items-center gap-1 cursor-pointer shadow-sm"
              >
                <span className="material-symbols-outlined text-[15px]">playlist_add</span>
                Draft PO for All Critical Items ({replenishmentRecommendations.filter((r) => r.isCritical).length})
              </button>
            </div>
          </div>

          <div className="bg-white border border-[#D4D4D8] rounded-xl shadow-2xs overflow-hidden">
            <div className="overflow-x-auto overflow-y-auto max-h-[560px] scrollbar-thin">
              <table className="w-full text-left text-xs min-w-[860px]">
                <thead className="bg-gray-50 text-gray-700 font-bold border-b border-gray-200 sticky top-0 z-10 shadow-2xs">
                  <tr>
                    <th className="py-3 px-3 w-10 text-center bg-gray-50">
                      <input
                        type="checkbox"
                        checked={
                          replenishmentRecommendations.length > 0 &&
                          selectedRecIds.length === replenishmentRecommendations.length
                        }
                        onChange={handleSelectAllRecs}
                        title={
                          selectedRecIds.length === replenishmentRecommendations.length
                            ? 'Deselect All'
                            : 'Select All Items'
                        }
                        className="rounded text-[#00478c] focus:ring-0 cursor-pointer"
                      />
                    </th>
                    <th
                      onClick={() => {
                        if (recSortField === 'name') {
                          setRecSortAsc(!recSortAsc);
                        } else {
                          setRecSortField('name');
                          setRecSortAsc(true);
                        }
                      }}
                      className="py-3 px-4 min-w-[180px] bg-gray-50 cursor-pointer select-none hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Item &amp; Category</span>
                        <span className="material-symbols-outlined text-[14px] text-gray-500 font-bold">
                          {recSortField === 'name' ? (recSortAsc ? 'arrow_upward' : 'arrow_downward') : 'unfold_more'}
                        </span>
                      </div>
                    </th>
                    <th
                      onClick={() => {
                        if (recSortField === 'stock') {
                          setRecSortAsc(!recSortAsc);
                        } else {
                          setRecSortField('stock');
                          setRecSortAsc(true);
                        }
                      }}
                      className="py-3 px-4 min-w-[110px] bg-gray-50 cursor-pointer select-none hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Current Stock</span>
                        <span className="material-symbols-outlined text-[14px] text-gray-500 font-bold">
                          {recSortField === 'stock' ? (recSortAsc ? 'arrow_upward' : 'arrow_downward') : 'arrow_drop_down'}
                        </span>
                      </div>
                    </th>
                    <th
                      onClick={() => {
                        if (recSortField === 'velocity') {
                          setRecSortAsc(!recSortAsc);
                        } else {
                          setRecSortField('velocity');
                          setRecSortAsc(false);
                        }
                      }}
                      className="py-3 px-4 min-w-[110px] bg-gray-50 cursor-pointer select-none hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Daily Velocity</span>
                        <span className="material-symbols-outlined text-[14px] text-gray-500 font-bold">
                          {recSortField === 'velocity' ? (recSortAsc ? 'arrow_upward' : 'arrow_downward') : 'unfold_more'}
                        </span>
                      </div>
                    </th>
                    <th
                      onClick={() => {
                        if (recSortField === 'daysLeft') {
                          setRecSortAsc(!recSortAsc);
                        } else {
                          setRecSortField('daysLeft');
                          setRecSortAsc(true);
                        }
                      }}
                      className="py-3 px-4 min-w-[100px] bg-gray-50 cursor-pointer select-none hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Days Left</span>
                        <span className="material-symbols-outlined text-[14px] text-gray-500 font-bold">
                          {recSortField === 'daysLeft' ? (recSortAsc ? 'arrow_upward' : 'arrow_downward') : 'unfold_more'}
                        </span>
                      </div>
                    </th>
                    <th
                      onClick={() => {
                        if (recSortField === 'status') {
                          setRecSortAsc(!recSortAsc);
                        } else {
                          setRecSortField('status');
                          setRecSortAsc(true);
                        }
                      }}
                      className="py-3 px-4 min-w-[90px] bg-gray-50 cursor-pointer select-none hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Status</span>
                        <span className="material-symbols-outlined text-[14px] text-gray-500 font-bold">
                          {recSortField === 'status' ? (recSortAsc ? 'arrow_upward' : 'arrow_downward') : 'unfold_more'}
                        </span>
                      </div>
                    </th>
                    <th
                      onClick={() => {
                        if (recSortField === 'suggested') {
                          setRecSortAsc(!recSortAsc);
                        } else {
                          setRecSortField('suggested');
                          setRecSortAsc(false);
                        }
                      }}
                      className="py-3 px-4 min-w-[130px] bg-gray-50 cursor-pointer select-none hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <span>Suggested Reorder</span>
                        <span className="material-symbols-outlined text-[14px] text-gray-500 font-bold">
                          {recSortField === 'suggested' ? (recSortAsc ? 'arrow_upward' : 'arrow_downward') : 'unfold_more'}
                        </span>
                      </div>
                    </th>
                    <th className="py-3 px-4 min-w-[110px] text-right bg-gray-50">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {replenishmentRecommendations.map((rec) => {
                    const isSelected = selectedRecIds.includes(rec.id);
                    return (
                      <tr
                        key={rec.id}
                        className={`transition-colors ${
                          isSelected ? 'bg-blue-50/60' : 'hover:bg-gray-50/70'
                        }`}
                      >
                        <td className="py-3 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleRecId(rec.id)}
                            className="rounded text-[#00478c] focus:ring-0 cursor-pointer"
                          />
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-[#09090B]">{rec.name}</div>
                          <div className="text-[10px] text-gray-500 font-mono">
                            {rec.sku} • {rec.category}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`font-mono font-bold ${
                              rec.isCritical ? 'text-red-700' : 'text-emerald-700'
                            }`}
                          >
                            {rec.onHand.toFixed(1)} {rec.unit}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-gray-700">
                          ~{rec.dailyVelocity} {rec.unit}/day
                        </td>
                        <td className="py-3 px-4 font-mono">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              Number(rec.daysRemaining) <= 2
                                ? 'bg-red-100 text-red-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {rec.daysRemaining} days
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {rec.isCritical ? (
                            <span className="px-2 py-0.5 bg-red-50 text-red-700 border border-red-200 rounded text-[10px] font-bold">
                              Low Stock
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[10px] font-bold">
                              Optimal
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-blue-900">
                          {rec.suggestedQty > 0 ? `+${rec.suggestedQty} ${rec.unit}` : '—'}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              handleOpenCreatePO(suppliers[0]?.id, {
                                id: rec.id,
                                sku: rec.sku,
                                name: rec.name,
                                variantId: rec.variantId,
                                suggestedQty: rec.suggestedQty || 20,
                                unit: rec.unit,
                                costPrice: rec.costPrice,
                              });
                            }}
                            className="px-2.5 py-1 bg-white hover:bg-blue-50 border border-gray-300 hover:border-[#00478c] text-[#00478c] rounded-md text-xs font-bold transition-colors cursor-pointer shrink-0"
                          >
                            + Add to PO
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* TAB 2: SUPPLIERS MASTER (ADD / EDIT / DELETE)            */}
      {/* --------------------------------------------------------- */}
      {activeTab === 'suppliers' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-2xs">
            <div>
              <h2 className="text-sm font-bold text-[#09090B]">Suppliers Directory</h2>
              <p className="text-xs text-gray-500">
                Manage registered vendors, lead times, credit payment terms, and contact profiles.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  generateSupplierDirectoryPDF(suppliers, outletProfile);
                  playSuccessChime();
                  showToast(`✓ Exported ${suppliers.length} suppliers directory (PDF)`);
                }}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                title="Export Suppliers Directory (PDF)"
              >
                <span className="material-symbols-outlined text-[16px]">upload</span>
                Export Suppliers (PDF)
              </button>
              <button
                onClick={handleOpenAddSupplier}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">add</span>
                Add Supplier
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {suppliers.map((sup) => (
              <div
                key={sup.id}
                className="bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-2xs flex flex-col justify-between hover:border-[#00478c] transition-all"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-bold text-sm text-[#09090B] leading-snug">{sup.name}</h3>
                      <span className="inline-block mt-0.5 px-2 py-0.5 bg-blue-50 text-blue-800 border border-blue-200 rounded-full text-[10px] font-bold">
                        {sup.marketType || 'Mandi Trader'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 bg-amber-50 px-1.5 py-0.5 rounded text-[11px] font-bold text-amber-800 border border-amber-200">
                      <span className="material-symbols-outlined text-[13px] text-amber-600">star</span>
                      <span>{Number(sup.rating || 4.5).toFixed(1)}</span>
                    </div>
                  </div>

                  <div className="text-xs text-gray-600 space-y-1 pt-1 border-t border-gray-100">
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[15px] text-gray-400">person</span>
                      <span>{sup.contactPerson || 'Direct Representative'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[15px] text-gray-400">call</span>
                      <span className="font-mono">{sup.phone || '+91 98000 00000'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[15px] text-gray-400">schedule</span>
                      <span>Lead Time: <strong>{sup.leadTimeDays} days</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[15px] text-gray-400">credit_card</span>
                      <span>Terms: <strong>{sup.paymentTerms}</strong></span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 mt-4 pt-3 border-t border-gray-100">
                  <button
                    onClick={() => handleOpenCreatePO(sup.id)}
                    className="px-2.5 py-1 bg-blue-50 text-[#00478c] hover:bg-blue-100 rounded text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <span className="material-symbols-outlined text-[14px]">add_shopping_cart</span>
                    Create PO
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEditSupplier(sup)}
                      className="p-1 text-gray-600 hover:text-blue-700 hover:bg-gray-100 rounded transition-colors cursor-pointer"
                      title="Edit Supplier"
                    >
                      <span className="material-symbols-outlined text-[18px]">edit</span>
                    </button>
                    <button
                      onClick={() => setSupplierToDelete(sup)}
                      className="p-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded transition-colors cursor-pointer"
                      title="Delete Supplier"
                    >
                      <span className="material-symbols-outlined text-[18px]">delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* TAB 3: PURCHASE ORDERS & GRN RECEIVING                    */}
      {/* --------------------------------------------------------- */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {/* Header & Main Actions */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-2xs">
            <div>
              <h2 className="text-sm font-bold text-[#09090B] flex items-center gap-2">
                <span>Purchase Orders &amp; GRN Intake Directory</span>
                <span className="px-2 py-0.5 bg-blue-50 text-blue-800 border border-blue-200 rounded-full text-xs font-mono font-bold">
                  {purchaseOrders.length} Total in DB
                </span>
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Track full &amp; partial deliveries, pending stock balances, and record Goods Receipt Notes (GRN).
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  playKeypadClick();
                  generateAllPOsReportPDF(purchaseOrders, outletProfile);
                  playSuccessChime();
                  showToast(`✓ Exported master PO report for ${purchaseOrders.length} orders (PDF)`);
                }}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                title="Export Comprehensive All POs Report (PDF)"
              >
                <span className="material-symbols-outlined text-[16px]">upload</span>
                All POs Report (PDF)
              </button>
              <button
                onClick={() => handleOpenCreatePO()}
                className="px-3 py-1.5 bg-[#00478c] text-white rounded-lg text-xs font-bold hover:bg-[#005eb7] flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
              >
                <span className="material-symbols-outlined text-[16px]">add</span>
                New Multi-Item PO
              </button>
            </div>
          </div>

          {/* Search & Filters Controls Container */}
          <div className="bg-white border border-[#D4D4D8] rounded-xl p-3.5 shadow-2xs space-y-3">
            {/* Row 1: Search & Date Presets */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              {/* Search Bar */}
              <div className="relative flex-1 max-w-md">
                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[18px] text-gray-400">
                  search
                </span>
                <input
                  type="text"
                  value={poSearchQuery}
                  onChange={(e) => setPoSearchQuery(e.target.value)}
                  placeholder="Search by PO#, Supplier Name, or Product..."
                  className="w-full pl-9 pr-8 py-1.5 bg-gray-50 border border-gray-300 rounded-lg text-xs focus:ring-1 focus:ring-[#00478c] focus:bg-white transition-all outline-none"
                />
                {poSearchQuery && (
                  <button
                    onClick={() => setPoSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Date / Calendar Filter Presets */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-bold text-gray-500 mr-1 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">calendar_month</span>
                  Date Range:
                </span>
                <button
                  onClick={() => setPoDateFilter('ALL')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    poDateFilter === 'ALL'
                      ? 'bg-blue-900 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All Time (All Dates)
                </button>
                <button
                  onClick={() => setPoDateFilter('TODAY')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    poDateFilter === 'TODAY'
                      ? 'bg-blue-900 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Today
                </button>
                <button
                  onClick={() => setPoDateFilter('YESTERDAY_TODAY')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    poDateFilter === 'YESTERDAY_TODAY'
                      ? 'bg-blue-900 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Yesterday &amp; Today
                </button>
                <button
                  onClick={() => setPoDateFilter('LAST_7_DAYS')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    poDateFilter === 'LAST_7_DAYS'
                      ? 'bg-blue-900 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Last 7 Days
                </button>
                <button
                  onClick={() => setPoDateFilter('THIS_MONTH')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    poDateFilter === 'THIS_MONTH'
                      ? 'bg-blue-900 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  This Month
                </button>
                <button
                  onClick={() => setPoDateFilter('CUSTOM')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    poDateFilter === 'CUSTOM'
                      ? 'bg-blue-900 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <span className="material-symbols-outlined text-[13px]">date_range</span>
                  Custom Calendar
                </button>
              </div>
            </div>

            {/* Custom Date Pickers Row (if CUSTOM selected) */}
            {poDateFilter === 'CUSTOM' && (
              <div className="flex items-center gap-3 pt-2 border-t border-gray-100 flex-wrap bg-blue-50/50 p-2.5 rounded-lg">
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="font-bold text-gray-700">From Date:</span>
                  <input
                    type="date"
                    value={poCustomStartDate}
                    onChange={(e) => setPoCustomStartDate(e.target.value)}
                    className="px-2.5 py-1 bg-white border border-gray-300 rounded text-xs focus:ring-1 focus:ring-[#00478c] outline-none"
                  />
                </div>
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="font-bold text-gray-700">To Date:</span>
                  <input
                    type="date"
                    value={poCustomEndDate}
                    onChange={(e) => setPoCustomEndDate(e.target.value)}
                    className="px-2.5 py-1 bg-white border border-gray-300 rounded text-xs focus:ring-1 focus:ring-[#00478c] outline-none"
                  />
                </div>
                {(poCustomStartDate || poCustomEndDate) && (
                  <button
                    onClick={() => {
                      setPoCustomStartDate('');
                      setPoCustomEndDate('');
                    }}
                    className="px-2 py-0.5 text-xs text-red-600 hover:underline font-bold cursor-pointer"
                  >
                    Clear Range
                  </button>
                )}
              </div>
            )}

            {/* Row 2: Status Filter Chips & Summary Badge */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-gray-100">
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  onClick={() => setPoFilter('ALL')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    poFilter === 'ALL'
                      ? 'bg-gray-900 text-white shadow-2xs'
                      : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  All Statuses ({purchaseOrders.length})
                </button>
                <button
                  onClick={() => setPoFilter('ACTIVE')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    poFilter === 'ACTIVE'
                      ? 'bg-blue-700 text-white shadow-2xs'
                      : 'bg-white border border-gray-200 text-blue-800 hover:bg-blue-50'
                  }`}
                >
                  <span className="material-symbols-outlined text-[14px]">local_shipping</span>
                  Pending Delivery ({
                    purchaseOrders.filter((p) => {
                      const ord = (p.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
                      const rec = (p.items || []).reduce((s, i) => s + (Number(i.quantityReceived) || 0), 0);
                      return ord - rec > 0 && p.status !== 'CANCELLED';
                    }).length
                  })
                </button>
                <button
                  onClick={() => setPoFilter('PARTIALLY_RECEIVED')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    poFilter === 'PARTIALLY_RECEIVED'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-white border border-gray-200 text-amber-800 hover:bg-amber-50'
                  }`}
                >
                  <span className="material-symbols-outlined text-[14px]">hourglass_top</span>
                  Partially Received ({
                    purchaseOrders.filter((p) => {
                      const ord = (p.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
                      const rec = (p.items || []).reduce((s, i) => s + (Number(i.quantityReceived) || 0), 0);
                      return rec > 0 && ord - rec > 0;
                    }).length
                  })
                </button>
                <button
                  onClick={() => setPoFilter('FULFILLED')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    poFilter === 'FULFILLED'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'bg-white border border-gray-200 text-emerald-800 hover:bg-emerald-50'
                  }`}
                >
                  <span className="material-symbols-outlined text-[14px]">check_circle</span>
                  Fulfilled ({
                    purchaseOrders.filter((p) => {
                      const ord = (p.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
                      const rec = (p.items || []).reduce((s, i) => s + (Number(i.quantityReceived) || 0), 0);
                      return ord > 0 && rec >= ord;
                    }).length
                  })
                </button>
              </div>

              <div className="text-[11px] text-gray-500 flex items-center gap-1.5 font-medium">
                {poDateFilter === 'ALL' ? (
                  <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-[11px]">
                    🗓️ Showing All Dates
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded text-[11px] font-bold">
                    🗓️ Filtered by: {poDateFilter}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {purchaseOrders
              .filter((po) => {
                // 1. Status Filter
                const totalOrderedQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
                const totalReceivedQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityReceived) || 0), 0);
                const totalPendingQty = Math.max(0, totalOrderedQty - totalReceivedQty);

                if (poFilter === 'ACTIVE') {
                  if (!(totalPendingQty > 0 && po.status !== 'CANCELLED')) return false;
                } else if (poFilter === 'PARTIALLY_RECEIVED') {
                  if (!(totalReceivedQty > 0 && totalPendingQty > 0)) return false;
                } else if (poFilter === 'FULFILLED') {
                  if (!(totalOrderedQty > 0 && totalReceivedQty >= totalOrderedQty)) return false;
                }

                // 2. Search Query Filter
                if (poSearchQuery.trim()) {
                  const q = poSearchQuery.toLowerCase().trim();
                  const poNumMatch = (po.poNumber || '').toLowerCase().includes(q);
                  const supMatch = (po.supplierName || '').toLowerCase().includes(q);
                  const itemMatch = (po.items || []).some(
                    (it) =>
                      (it.productName || '').toLowerCase().includes(q) ||
                      (it.sku || '').toLowerCase().includes(q)
                  );
                  if (!poNumMatch && !supMatch && !itemMatch) return false;
                }

                // 3. Date / Calendar Range Filter
                if (poDateFilter !== 'ALL') {
                  const rawDate = po.createdAt || po.expectedDelivery;
                  if (rawDate) {
                    const d = new Date(rawDate);
                    const now = new Date();
                    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
                    const dTime = d.getTime();

                    if (poDateFilter === 'TODAY' && dTime < todayStart) return false;
                    if (poDateFilter === 'YESTERDAY_TODAY' && dTime < todayStart - 86400000) return false;
                    if (poDateFilter === 'LAST_7_DAYS' && dTime < todayStart - 7 * 86400000) return false;
                    if (poDateFilter === 'THIS_MONTH') {
                      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
                      if (dTime < monthStart) return false;
                    }
                    if (poDateFilter === 'CUSTOM') {
                      if (poCustomStartDate) {
                        const start = new Date(poCustomStartDate).getTime();
                        if (dTime < start) return false;
                      }
                      if (poCustomEndDate) {
                        const end = new Date(poCustomEndDate).getTime() + 86400000;
                        if (dTime > end) return false;
                      }
                    }
                  }
                }

                return true;
              })
              .map((po) => {
                const totalOrderedQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
                const totalReceivedQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityReceived) || 0), 0);
                const totalPendingQty = Math.max(0, totalOrderedQty - totalReceivedQty);
                const pctReceived = totalOrderedQty > 0 ? Math.min(100, Math.round((totalReceivedQty / totalOrderedQty) * 100)) : 0;
                const hasPendingItems = totalPendingQty > 0;
                const isPartial = totalReceivedQty > 0 && hasPendingItems;

                return (
                  <div
                    key={po.id}
                    className={`bg-white border rounded-xl p-4 shadow-2xs transition-all space-y-3 ${
                      isPartial
                        ? 'border-amber-300 bg-amber-50/15'
                        : 'border-[#D4D4D8] hover:border-gray-400'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-sm text-[#00478c]">{po.poNumber}</span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                            isPartial
                              ? 'bg-amber-100 text-amber-900 border border-amber-300 font-extrabold animate-pulse'
                              : hasPendingItems
                              ? 'bg-blue-100 text-blue-800 border border-blue-200'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          }`}
                        >
                          {isPartial && (
                            <span className="material-symbols-outlined text-[13px] text-amber-700">hourglass_top</span>
                          )}
                          {isPartial
                            ? 'PARTIALLY RECEIVED (Pending Delivery)'
                            : hasPendingItems
                            ? 'ISSUED (Pending Delivery)'
                            : 'FULFILLED (100% Complete)'}
                        </span>

                        {hasPendingItems && (
                          <span className="px-2 py-0.5 bg-amber-500 text-white rounded text-[10px] font-bold">
                            {totalPendingQty} Qty Pending
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-gray-500 flex items-center gap-3 flex-wrap">
                        <span>
                          Supplier: <strong className="text-gray-800">{po.supplierName}</strong>
                        </span>
                        <span>
                          Expected: <strong className="text-gray-800">{new Date(po.expectedDelivery || Date.now()).toLocaleDateString()}</strong>
                        </span>
                        <span className="font-mono text-xs font-bold text-emerald-800">
                          PO Value: Rs. {Number(po.totalAmount).toFixed(2)}
                        </span>
                      </div>
                    </div>

                    {/* Overall Progress if partially received */}
                    {isPartial && (
                      <div className="bg-amber-50/80 border border-amber-200 rounded-lg p-2.5 flex items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="material-symbols-outlined text-amber-700 text-[18px]">hourglass_top</span>
                          <div>
                            <span className="font-bold text-amber-900">Partial shipment received into inventory.</span>{' '}
                            <span className="text-amber-800">
                              Received {totalReceivedQty} of {totalOrderedQty} total units ({pctReceived}% completed). <strong className="text-amber-900">{totalPendingQty} units remaining</strong> to be delivered.
                            </span>
                          </div>
                        </div>
                        <div className="w-28 bg-amber-200 rounded-full h-2 overflow-hidden flex-shrink-0">
                          <div className="bg-amber-600 h-full rounded-full" style={{ width: `${pctReceived}%` }} />
                        </div>
                      </div>
                    )}

                    {/* Line Items in this PO */}
                    <div className="bg-gray-50 rounded-lg p-2.5 border border-gray-200">
                      <div className="text-[11px] font-bold text-gray-700 mb-1.5 flex items-center justify-between">
                        <span>Line Items &amp; Delivery Progress ({po.items?.length || 0})</span>
                        <span className="text-gray-500 font-mono text-[10px]">
                          Total Ordered: {totalOrderedQty} | Received: {totalReceivedQty} | Pending: {totalPendingQty}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {(po.items || []).map((it, idx) => {
                          const ord = Number(it.quantityOrdered) || 0;
                          const rec = Number(it.quantityReceived) || 0;
                          const pending = Math.max(0, ord - rec);
                          const itemPct = ord > 0 ? Math.min(100, Math.round((rec / ord) * 100)) : 0;

                          return (
                            <div
                              key={idx}
                              className={`p-2 rounded border text-xs flex flex-col justify-between ${
                                rec >= ord && ord > 0
                                  ? 'bg-emerald-50/40 border-emerald-200'
                                  : rec > 0
                                  ? 'bg-amber-50/50 border-amber-200'
                                  : 'bg-white border-gray-200'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-1">
                                <div>
                                  <div className="font-bold text-gray-900 leading-tight">{it.productName}</div>
                                  <div className="text-[10px] text-gray-500 font-mono">
                                    {it.sku} • @ Rs. {Number(it.unitCost).toFixed(2)}/{it.unit}
                                  </div>
                                </div>
                                <div className="text-right font-mono">
                                  <div className="font-bold text-gray-800">
                                    {ord} {it.unit}
                                  </div>
                                </div>
                              </div>

                              <div className="mt-2 pt-1.5 border-t border-gray-100/80 text-[11px] flex items-center justify-between font-mono">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-emerald-700 font-bold">
                                    Rec: {rec} {it.unit}
                                  </span>
                                  {pending > 0 ? (
                                    <span className="text-amber-800 font-bold bg-amber-100 px-1 rounded text-[10px]">
                                      Pending: {pending} {it.unit}
                                    </span>
                                  ) : (
                                    <span className="text-emerald-700 font-bold bg-emerald-100 px-1 rounded text-[10px]">
                                      ✓ Complete
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-gray-400 font-sans">{itemPct}%</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* GRN Trigger Action */}
                    <div className="flex items-center justify-between pt-1 flex-wrap gap-2">
                      <div className="text-[11px] text-gray-500">
                        Created on {new Date(po.createdAt || Date.now()).toLocaleString()}
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        {/* PO PDF Export (acts for duplicates too) */}
                        <button
                          type="button"
                          onClick={() => {
                            playKeypadClick();
                            generatePurchaseOrderPDF(po, outletProfile, false);
                          }}
                          className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#00478c] border border-blue-200 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                          title="Print / Export Official Purchase Order (PDF)"
                        >
                          <span className="material-symbols-outlined text-[15px]">upload</span>
                          <span>Print PO (PDF)</span>
                        </button>

                        {hasPendingItems ? (
                          <>
                            <button
                              onClick={() => handleOpenGRNModal(po)}
                              className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                              title="Receive full shipment and add stock to inventory"
                            >
                              <span className="material-symbols-outlined text-[16px]">fact_check</span>
                              <span>Receive Complete Order (GRN)</span>
                            </button>
                          </>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                              <span className="material-symbols-outlined text-[16px]">check_circle</span>
                              100% Complete &amp; Received
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* TAB 4: 3-WAY INVOICE MATCHING                             */}
      {/* --------------------------------------------------------- */}
      {activeTab === 'matching' && (
        <div className="space-y-4">
          <div className="bg-white border border-[#D4D4D8] rounded-xl p-4 shadow-2xs flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#09090B]">3-Way Match Verification Records</h2>
              <p className="text-xs text-gray-500">
                Cross-verification between Purchase Orders (PO), Goods Receipt Notes (GRN), and Vendor Invoices.
              </p>
            </div>
            <button
              onClick={() => {
                exportToCSV<ThreeWayMatchRecord>(
                  'Three_Way_Matches_Audit',
                  matches,
                  [
                    { header: 'PO Number', accessor: (m) => m.poNumber },
                    { header: 'GRN Number', accessor: (m) => m.grnNumber },
                    { header: 'Invoice Number', accessor: (m) => m.invoiceNumber },
                    { header: 'Supplier', accessor: (m) => m.supplierName },
                    { header: 'PO Amount', accessor: (m) => m.poAmount },
                    { header: 'GRN Received Amount', accessor: (m) => m.grnReceivedAmount },
                    { header: 'Invoice Amount', accessor: (m) => m.invoiceAmount },
                    { header: 'Discrepancy', accessor: (m) => m.discrepancyAmount },
                    { header: 'Status', accessor: (m) => m.status },
                    { header: 'Notes', accessor: (m) => m.discrepancyNote || '' },
                  ]
                );
              }}
              className="px-3 py-1.5 bg-white hover:bg-gray-100 border border-gray-300 text-gray-700 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">upload</span>
              Export CSV
            </button>
          </div>

          <div className="bg-white border border-[#D4D4D8] rounded-xl shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-gray-50 text-gray-600 font-bold border-b border-gray-200">
                  <tr>
                    <th className="py-3 px-4">PO / GRN / Invoice</th>
                    <th className="py-3 px-4">Supplier</th>
                    <th className="py-3 px-4">PO Amount</th>
                    <th className="py-3 px-4">GRN Verified</th>
                    <th className="py-3 px-4">Invoice Total</th>
                    <th className="py-3 px-4">Discrepancy</th>
                    <th className="py-3 px-4">Match Status</th>
                    <th className="py-3 px-4">Quarantine &amp; Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {matches.map((m) => (
                    <tr key={m.id} className="hover:bg-gray-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono">
                        <div className="font-bold text-[#00478c]">{m.poNumber}</div>
                        <div className="text-[10px] text-gray-500">GRN: {m.grnNumber}</div>
                        <div className="text-[10px] text-gray-500">INV: {m.invoiceNumber}</div>
                      </td>
                      <td className="py-3 px-4 font-semibold text-gray-900">{m.supplierName}</td>
                      <td className="py-3 px-4 font-mono">Rs. {Number(m.poAmount).toFixed(2)}</td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-800">
                        Rs. {Number(m.grnReceivedAmount).toFixed(2)}
                      </td>
                      <td className="py-3 px-4 font-mono">Rs. {Number(m.invoiceAmount).toFixed(2)}</td>
                      <td className="py-3 px-4 font-mono">
                        {Number(m.discrepancyAmount) > 0 ? (
                          <span className="font-bold text-red-700">
                            Rs. {Number(m.discrepancyAmount).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-gray-400">Rs. 0.00</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            m.status === 'MATCHED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {m.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-[11px]">
                        {m.discrepancyNote || 'Verified and approved with full quantity matching.'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* MODAL 1: ADD / EDIT SUPPLIER                              */}
      {/* --------------------------------------------------------- */}
      {isSupplierModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-200 space-y-4">
            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c]">
                  {editingSupplier ? 'edit_square' : 'person_add'}
                </span>
                {editingSupplier ? 'Edit Supplier Details' : 'Add New Supplier'}
              </h3>
              <button
                onClick={() => setIsSupplierModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveSupplier} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-gray-700 mb-1">
                  Supplier / Vendor Name *
                </label>
                <input
                  type="text"
                  required
                  value={supplierForm.name}
                  onChange={(e) => setSupplierForm({ ...supplierForm, name: e.target.value })}
                  placeholder="e.g. Vashi APMC Mandi - Radhe Krishna Traders"
                  className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Market / Vendor Type</label>
                  <select
                    value={supplierForm.marketType}
                    onChange={(e) =>
                      setSupplierForm({
                        ...supplierForm,
                        marketType: e.target.value as any,
                      })
                    }
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none bg-white"
                  >
                    <option value="Mandi Trader">Mandi Trader</option>
                    <option value="FMCG Distributor">FMCG Distributor</option>
                    <option value="Dairy Co-op">Dairy Co-op</option>
                    <option value="Farmer Producer Group">Farmer Producer Group</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Contact Person</label>
                  <input
                    type="text"
                    value={supplierForm.contactPerson}
                    onChange={(e) =>
                      setSupplierForm({ ...supplierForm, contactPerson: e.target.value })
                    }
                    placeholder="e.g. Ramesh Patel"
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={supplierForm.phone}
                    onChange={(e) => setSupplierForm({ ...supplierForm, phone: e.target.value })}
                    placeholder="+91 98000 00000"
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={supplierForm.contactEmail}
                    onChange={(e) =>
                      setSupplierForm({ ...supplierForm, contactEmail: e.target.value })
                    }
                    placeholder="vendor@apmc.com"
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Lead Time (Days)</label>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    value={supplierForm.leadTimeDays}
                    onChange={(e) =>
                      setSupplierForm({ ...supplierForm, leadTimeDays: Number(e.target.value) })
                    }
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Payment Terms</label>
                  <select
                    value={supplierForm.paymentTerms}
                    onChange={(e) =>
                      setSupplierForm({ ...supplierForm, paymentTerms: e.target.value })
                    }
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none bg-white"
                  >
                    <option value="Immediate Cash">Immediate Cash</option>
                    <option value="Net 7">Net 7 Days</option>
                    <option value="Net 15">Net 15 Days</option>
                    <option value="Net 30">Net 30 Days</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Rating (1-5)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    max="5"
                    value={supplierForm.rating}
                    onChange={(e) =>
                      setSupplierForm({ ...supplierForm, rating: Number(e.target.value) })
                    }
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setIsSupplierModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#00478c] hover:bg-[#005eb7] text-white rounded-lg font-bold cursor-pointer"
                >
                  {editingSupplier ? 'Update Supplier' : 'Save Supplier'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* MODAL 2: DELETE SUPPLIER CONFIRMATION                     */}
      {/* --------------------------------------------------------- */}
      {supplierToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-red-200 space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <span className="material-symbols-outlined text-[32px]">warning</span>
              <div>
                <h3 className="font-bold text-base text-gray-900">Delete Supplier</h3>
                <p className="text-xs text-gray-500">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-gray-700">
              Are you sure you want to delete <strong>{supplierToDelete.name}</strong> from the master supplier registry?
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSupplierToDelete(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteSupplier}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                Delete Supplier
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* MODAL 3: CREATE MULTI-ITEM PURCHASE ORDER                 */}
      {/* --------------------------------------------------------- */}
      {isCreatePoModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-gray-200 space-y-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <h3 className="font-bold text-base text-[#09090B] flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00478c]">add_shopping_cart</span>
                  Create Multi-Item Purchase Order
                </h3>
                <p className="text-xs text-gray-500">
                  Select a supplier and add multiple produce/grocery items to issue a single unified PO.
                </p>
              </div>
              <button
                onClick={() => setIsCreatePoModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleIssueMultiItemPO} className="space-y-4 text-xs overflow-y-auto flex-1 pr-1">
              {/* Supplier & Delivery Date */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Select Supplier *</label>
                  <select
                    required
                    value={selectedPoSupplierId}
                    onChange={(e) => setSelectedPoSupplierId(e.target.value)}
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none bg-white font-medium text-xs"
                  >
                    {suppliers.map((sup) => (
                      <option key={sup.id} value={sup.id}>
                        {sup.name} • {sup.marketType} • {sup.paymentTerms}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Expected Delivery Date</label>
                  <input
                    type="date"
                    value={poExpectedDelivery}
                    onChange={(e) => setPoExpectedDelivery(e.target.value)}
                    className="w-full h-9 px-3 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none bg-white text-xs"
                  />
                </div>
              </div>

              {/* Add Items Controls */}
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="font-bold text-gray-800 flex items-center gap-1.5 text-xs">
                    <span className="material-symbols-outlined text-[#00478c] text-[18px]">inventory</span>
                    Add Line Items to this Purchase Order:
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleAddAllLowStockToPo}
                      className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <span className="material-symbols-outlined text-[14px]">bolt</span>
                      + Add All Low Stock Items
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowCustomItemInput(!showCustomItemInput)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors border ${
                        showCustomItemInput
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white hover:bg-gray-100 text-gray-700 border-gray-300'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[14px]">
                        {showCustomItemInput ? 'close' : 'edit_note'}
                      </span>
                      {showCustomItemInput ? 'Hide Custom Produce' : '+ Custom / Unlisted Item'}
                    </button>
                  </div>
                </div>

                {/* Catalog Dropdown & Add Button */}
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    {(() => {
                      const availableProducts = products.filter((p) => {
                        return !poItems.some((item) => {
                          if (item.productId && p.id && item.productId === p.id) return true;
                          if (
                            item.sku &&
                            p.sku &&
                            item.sku.trim() !== '' &&
                            item.sku.trim().toLowerCase() === p.sku.trim().toLowerCase()
                          )
                            return true;
                          if (
                            item.variantId &&
                            p.variants?.[0]?.id &&
                            item.variantId === p.variants[0].id
                          )
                            return true;
                          if (
                            item.productName &&
                            p.name &&
                            item.productName.trim() !== '' &&
                            item.productName.trim().toLowerCase() === p.name.trim().toLowerCase()
                          )
                            return true;
                          return false;
                        });
                      });

                      return (
                        <select
                          value={selectedProductToAdd}
                          onChange={(e) => setSelectedProductToAdd(e.target.value)}
                          className="w-full h-9 pl-3 pr-8 border border-gray-300 rounded-lg focus:border-[#00478c] focus:outline-none bg-white font-medium text-xs cursor-pointer shadow-2xs text-gray-800"
                        >
                          {availableProducts.length === 0 ? (
                            <option value="">All catalog items have been added to this PO</option>
                          ) : (
                            <option value="">+ Choose an item from store catalog to add ({availableProducts.length} available)...</option>
                          )}
                          {availableProducts.map((p) => {
                            const onHandQty = p.variants?.[0]?.onHand ?? 0;
                            const cleanName = p.name ? p.name.replace(/\s*\(\s*\)/g, '').trim() : 'Produce Item';
                            return (
                              <option key={p.id} value={p.id}>
                                {cleanName} — {p.sku || 'SKU'} | Stock: {onHandQty} {p.unit || 'kg'}
                              </option>
                            );
                          })}
                        </select>
                      );
                    })()}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (selectedProductToAdd) {
                        handleAddItemToPo(selectedProductToAdd);
                      }
                    }}
                    disabled={!selectedProductToAdd}
                    className="h-9 px-4 bg-[#00478c] hover:bg-[#005eb7] disabled:opacity-40 disabled:bg-gray-300 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer text-xs shrink-0 shadow-2xs transition-all"
                  >
                    <span className="material-symbols-outlined text-[16px]">add</span>
                    + Add Item
                  </button>
                </div>

                {/* Custom Produce Form (if toggled) */}
                {showCustomItemInput && (
                  <div className="bg-white p-3 rounded-lg border border-blue-200 shadow-2xs space-y-2 animate-in fade-in">
                    <div className="text-[11px] font-bold text-blue-900 flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">post_add</span>
                      Add Custom / Mandi Unlisted Produce Line Item:
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                      <div className="sm:col-span-2">
                        <input
                          type="text"
                          placeholder="Item Name (e.g. Fresh Coriander Bundles)"
                          value={customItemName}
                          onChange={(e) => setCustomItemName(e.target.value)}
                          className="w-full h-8 px-2.5 border border-gray-300 rounded-md text-xs focus:border-[#00478c] focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          placeholder="Qty"
                          min="0.001"
                          step="any"
                          value={customItemQty}
                          onChange={(e) => setCustomItemQty(parseFloat(e.target.value) || 0)}
                          className="w-16 h-8 px-2 border border-gray-300 rounded-md text-xs text-center font-bold"
                        />
                        <select
                          value={customItemUnit}
                          onChange={(e) => setCustomItemUnit(e.target.value)}
                          className="h-8 px-1.5 border border-gray-300 rounded-md text-xs bg-white font-medium"
                        >
                          <option value="kg">kg</option>
                          <option value="g">g</option>
                          <option value="L">L</option>
                          <option value="pcs">pcs</option>
                          <option value="bundle">bundle</option>
                          <option value="box">box</option>
                          <option value="bag">bag</option>
                          <option value="pack">pack</option>
                        </select>
                      </div>
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          placeholder="Est Cost"
                          min="0"
                          step="any"
                          value={customItemCost}
                          onChange={(e) => setCustomItemCost(parseFloat(e.target.value) || 0)}
                          className="w-full h-8 px-2 border border-gray-300 rounded-md text-xs text-center font-bold"
                        />
                        <button
                          type="button"
                          onClick={handleAddCustomItemToPo}
                          className="h-8 px-3 bg-blue-700 hover:bg-blue-800 text-white rounded-md font-bold text-xs shrink-0 cursor-pointer shadow-2xs"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Multi-Item Table */}
              <div className="border border-gray-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="bg-gray-100 px-3 py-2 border-b border-gray-200 flex items-center justify-between font-bold text-gray-700 text-xs">
                  <span>Selected PO Line Items</span>
                  <span className="text-[11px] text-gray-500 font-normal">
                    {poItems.length} item(s) in this order
                  </span>
                </div>
                <div className="overflow-x-auto max-h-60 overflow-y-auto scrollbar-thin">
                  <table className="w-full text-left text-xs min-w-[500px]">
                    <thead className="bg-gray-50 text-gray-600 font-bold border-b border-gray-200 sticky top-0 z-10">
                      <tr>
                        <th className="py-2.5 px-3 bg-gray-50">Item Description</th>
                        <th className="py-2.5 px-3 w-32 bg-gray-50">Qty Ordered</th>
                        <th className="py-2.5 px-3 w-28 bg-gray-50">Est. Cost (Rs.)</th>
                        <th className="py-2.5 px-3 text-right bg-gray-50">Line Total</th>
                        <th className="py-2.5 px-2 w-10 text-center bg-gray-50"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {poItems.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-gray-400">
                            <span className="material-symbols-outlined text-[32px] text-gray-300 block mb-1">
                              shopping_basket
                            </span>
                            No items added yet. Use the dropdown or quick-add buttons above to add items.
                          </td>
                        </tr>
                      ) : (
                        poItems.map((item, idx) => (
                          <tr key={item.id || idx} className="hover:bg-gray-50/70">
                            <td className="py-2.5 px-3">
                              <div className="font-bold text-gray-900">{item.productName}</div>
                              <div className="text-[10px] text-gray-500 font-mono">{item.sku}</div>
                            </td>
                            <td className="py-2.5 px-3">
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleUpdatePoItemQty(idx, item.quantityOrdered - 5)}
                                  className="w-6 h-7 bg-gray-200 hover:bg-gray-300 rounded text-gray-700 font-bold text-xs cursor-pointer flex items-center justify-center"
                                >
                                  -
                                </button>
                                <input
                                  type="number"
                                  min="0.001"
                                  step="any"
                                  value={item.quantityOrdered}
                                  onChange={(e) =>
                                    handleUpdatePoItemQty(idx, parseFloat(e.target.value) || 0)
                                  }
                                  className="w-14 h-7 px-1 border border-gray-300 rounded text-center font-mono font-bold text-xs"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleUpdatePoItemQty(idx, item.quantityOrdered + 5)}
                                  className="w-6 h-7 bg-gray-200 hover:bg-gray-300 rounded text-gray-700 font-bold text-xs cursor-pointer flex items-center justify-center"
                                >
                                  +
                                </button>
                                <span className="text-gray-500 font-medium text-[11px] pl-0.5">
                                  {item.unit}
                                </span>
                              </div>
                            </td>
                            <td className="py-2.5 px-3">
                              <input
                                type="number"
                                min="0"
                                step="any"
                                value={item.unitCost}
                                onChange={(e) =>
                                  handleUpdatePoItemCost(idx, parseFloat(e.target.value) || 0)
                                }
                                className="w-20 h-7 px-1.5 border border-gray-300 rounded text-center font-mono font-bold text-xs"
                              />
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-[#00478c]">
                              Rs. {item.totalCost.toFixed(2)}
                            </td>
                            <td className="py-2.5 px-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleRemovePoItem(idx)}
                                className="text-red-500 hover:text-red-700 cursor-pointer p-1 rounded hover:bg-red-50"
                                title="Remove item"
                              >
                                <span className="material-symbols-outlined text-[18px]">delete</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                    {poItems.length > 0 && (
                      <tfoot className="bg-blue-50/70 font-bold border-t border-gray-200 sticky bottom-0 z-10">
                        <tr>
                          <td colSpan={3} className="py-2.5 px-3 text-right text-gray-700">
                            Grand Total PO Value ({poItems.length} items):
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-sm text-[#00478c]">
                            Rs. {poItems.reduce((s, it) => s + it.totalCost, 0).toFixed(2)}
                          </td>
                          <td></td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>

              {/* Submit & Cancel */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setIsCreatePoModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={poItems.length === 0}
                  className="px-5 py-2 bg-[#00478c] hover:bg-[#005eb7] disabled:opacity-50 text-white rounded-lg font-bold cursor-pointer flex items-center gap-1.5 shadow-sm"
                >
                  <span className="material-symbols-outlined text-[16px]">send</span>
                  Issue Multi-Item Purchase Order ({poItems.length} items)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------- */}
      {/* MODAL 4: GOODS RECEIPT NOTE (GRN) WITH PARTIAL INTAKE     */}
      {/* --------------------------------------------------------- */}
      {isGrnModalOpen && grnTargetPo && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 shadow-2xl border border-gray-200 space-y-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-200 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-emerald-700 text-xl">fact_check</span>
                  <h3 className="font-bold text-base text-[#09090B]">
                    Goods Receipt Note (GRN) Intake &amp; Verification
                  </h3>
                  {grnTargetPo.status === 'PARTIALLY_RECEIVED' && (
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-900 border border-amber-300 rounded text-[10px] font-bold">
                      Subsequent Delivery (GRN Intake #2+)
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-0.5">
                  Verify shipment against PO <strong className="font-mono text-[#00478c]">{grnTargetPo.poNumber}</strong> ({grnTargetPo.supplierName}). If lesser quantity arrived, enter received count and the rest remains pending.
                </p>
              </div>
              <button
                onClick={() => setIsGrnModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 cursor-pointer p-1 rounded hover:bg-gray-100"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleProcessGRN} className="space-y-4 text-xs overflow-y-auto flex-1 pr-1">
              {/* Delivery Stats & Invoice Info */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200">
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Vendor Invoice / Bill No *</label>
                  <input
                    type="text"
                    required
                    value={grnInvoiceNumber}
                    onChange={(e) => setGrnInvoiceNumber(e.target.value)}
                    placeholder="e.g. INV-9812"
                    className="w-full h-8 px-2.5 border border-gray-300 rounded-lg bg-white font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">This Invoice Amount (Rs.)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={grnInvoiceAmount}
                    onChange={(e) => setGrnInvoiceAmount(parseFloat(e.target.value) || 0)}
                    className="w-full h-8 px-2.5 border border-gray-300 rounded-lg bg-white font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-gray-700 mb-1">Original PO Value</label>
                  <div className="h-8 px-2.5 bg-gray-100 border border-gray-300 rounded-lg flex items-center font-mono font-bold text-gray-700">
                    Rs. {Number(grnTargetPo.totalAmount).toFixed(2)}
                  </div>
                </div>
                <div>
                  <label className="block font-bold text-emerald-800 mb-1">This Intake Value (Stock)</label>
                  <div className="h-8 px-2.5 bg-emerald-50 border border-emerald-300 rounded-lg flex items-center font-mono font-bold text-emerald-800">
                    Rs.{' '}
                    {grnItems
                      .filter((i) => i.disposition === 'ACCEPT')
                      .reduce((s, it) => s + it.quantityReceived * it.unitCost, 0)
                      .toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Add Non-PO Item Bar */}
              <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3 flex items-center justify-between gap-3 flex-wrap">
                <div>
                  <div className="font-bold text-amber-900 flex items-center gap-1">
                    <span className="material-symbols-outlined text-[16px]">emergency_home</span>
                    Items delivered that were NOT on the Purchase Order?
                  </div>
                  <div className="text-[11px] text-amber-700">
                    Add extra items here to quarantine on HOLD or record for return/disposition.
                  </div>
                </div>
                <select
                  value={nonPoProductToAdd}
                  onChange={(e) => {
                    if (e.target.value) handleAddNonPoItemToGrn(e.target.value);
                  }}
                  className="h-8 px-2.5 border border-amber-300 rounded-lg bg-white font-medium text-xs text-amber-900"
                >
                  <option value="">+ Add Extra / Non-PO Line Item...</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.sku})
                    </option>
                  ))}
                </select>
              </div>

              {/* Receiving Items Table */}
              <div className="border border-gray-200 rounded-xl overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-gray-100 text-gray-700 font-bold border-b border-gray-200">
                    <tr>
                      <th className="py-2.5 px-3">Item &amp; Details</th>
                      <th className="py-2.5 px-2 text-center w-20">Ordered</th>
                      <th className="py-2.5 px-2 text-center w-20">Prev Rec</th>
                      <th className="py-2.5 px-2 text-center w-20">Pending</th>
                      <th className="py-2.5 px-3 w-40">This Delivery Intake</th>
                      <th className="py-2.5 px-3 w-40">Disposition</th>
                      <th className="py-2.5 px-3 text-right">Accepted Stock Value</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {grnItems.map((item, idx) => {
                      const prevRec = item.quantityAlreadyReceived || 0;
                      const thisRec = item.quantityReceived || 0;
                      const totalCumulative = prevRec + (item.disposition === 'ACCEPT' ? thisRec : 0);
                      const pendingAfter = Math.max(0, item.quantityOrdered - totalCumulative);
                      const isPartial = !item.isNonPoItem && pendingAfter > 0;
                      const isExcess = !item.isNonPoItem && totalCumulative > item.quantityOrdered;

                      return (
                        <tr
                          key={item.id || idx}
                          className={
                            item.disposition === 'HOLD'
                              ? 'bg-amber-50/50'
                              : item.disposition === 'REJECT'
                              ? 'bg-red-50/50'
                              : isPartial
                              ? 'bg-blue-50/20 hover:bg-blue-50/40'
                              : 'hover:bg-gray-50/70'
                          }
                        >
                          {/* Item Name */}
                          <td className="py-2.5 px-3">
                            <div className="font-bold text-gray-900">{item.productName}</div>
                            <div className="text-[10px] text-gray-500 font-mono">
                              {item.sku} • @ Rs. {item.unitCost.toFixed(2)}/{item.unit}
                            </div>
                            {item.isNonPoItem && (
                              <span className="inline-block px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded text-[9px] font-bold mt-0.5">
                                NON-PO ITEM
                              </span>
                            )}
                          </td>

                          {/* Ordered */}
                          <td className="py-2.5 px-2 text-center font-mono text-gray-700">
                            {item.quantityOrdered} {item.unit}
                          </td>

                          {/* Prev Rec */}
                          <td className="py-2.5 px-2 text-center font-mono text-emerald-700 font-bold">
                            {prevRec > 0 ? `${prevRec} ${item.unit}` : '0'}
                          </td>

                          {/* Pending */}
                          <td className="py-2.5 px-2 text-center font-mono font-bold">
                            {item.quantityPending > 0 ? (
                              <span className="text-amber-800 bg-amber-100/80 px-1.5 py-0.5 rounded text-[10px]">
                                {item.quantityPending} {item.unit}
                              </span>
                            ) : (
                              <span className="text-gray-400 font-normal">0</span>
                            )}
                          </td>

                          {/* This Delivery Intake */}
                          <td className="py-2.5 px-3">
                            <div className="space-y-1">
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  min="0"
                                  step="any"
                                  value={item.quantityReceived}
                                  onChange={(e) => {
                                    const val = parseFloat(e.target.value) || 0;
                                    setGrnItems(
                                      grnItems.map((it, i) =>
                                        i === idx ? { ...it, quantityReceived: val } : it
                                      )
                                    );
                                  }}
                                  className="w-20 h-7 px-2 border border-gray-300 rounded font-mono font-bold text-center bg-white shadow-2xs focus:ring-1 focus:ring-blue-500"
                                />
                                <span className="text-gray-500 text-[11px] font-mono">{item.unit}</span>

                                {item.quantityPending > 0 && item.quantityReceived !== item.quantityPending && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setGrnItems(
                                        grnItems.map((it, i) =>
                                          i === idx ? { ...it, quantityReceived: it.quantityPending } : it
                                        )
                                      );
                                    }}
                                    className="px-1.5 py-0.5 text-[9px] bg-gray-100 hover:bg-gray-200 text-gray-700 rounded border border-gray-300 font-bold cursor-pointer"
                                    title="Set intake to full pending balance"
                                  >
                                    Max
                                  </button>
                                )}
                              </div>

                              {/* Status Tag */}
                              {!item.isNonPoItem && (
                                <div className="text-[10px]">
                                  {isPartial ? (
                                    <span className="text-amber-700 font-bold flex items-center gap-0.5">
                                      <span className="material-symbols-outlined text-[12px]">hourglass_top</span>
                                      Partial: {pendingAfter} {item.unit} pending
                                    </span>
                                  ) : isExcess ? (
                                    <span className="text-purple-700 font-bold">
                                      +{(totalCumulative - item.quantityOrdered).toFixed(1)} {item.unit} excess
                                    </span>
                                  ) : (
                                    <span className="text-emerald-700 font-bold flex items-center gap-0.5">
                                      <span className="material-symbols-outlined text-[12px]">check</span>
                                      100% Received
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                          </td>

                          {/* Disposition */}
                          <td className="py-2.5 px-3">
                            <select
                              value={item.disposition}
                              onChange={(e) =>
                                handleUpdateGrnItemDisposition(idx, e.target.value as any)
                              }
                              className={`w-full h-7 px-2 border rounded text-xs font-bold ${
                                item.disposition === 'ACCEPT'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                  : item.disposition === 'HOLD'
                                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                                  : 'bg-red-50 text-red-800 border-red-300'
                              }`}
                            >
                              <option value="ACCEPT">✅ Accept (Add to Stock)</option>
                              <option value="HOLD">⚠️ Put On Hold (Quarantine)</option>
                              <option value="REJECT">❌ Reject / Return</option>
                            </select>
                            {item.disposition !== 'ACCEPT' && (
                              <input
                                type="text"
                                placeholder="Reason for hold / rejection..."
                                value={item.holdReason || ''}
                                onChange={(e) => {
                                  const reason = e.target.value;
                                  setGrnItems(
                                    grnItems.map((it, i) =>
                                      i === idx ? { ...it, holdReason: reason } : it
                                    )
                                  );
                                }}
                                className="w-full mt-1 h-6 px-1.5 text-[10px] border border-gray-300 rounded bg-white"
                              />
                            )}
                          </td>

                          {/* Line Accepted Value */}
                          <td className="py-2.5 px-3 text-right font-mono font-bold">
                            {item.disposition === 'ACCEPT' ? (
                              <span className="text-emerald-700">
                                Rs. {(item.quantityReceived * item.unitCost).toFixed(2)}
                              </span>
                            ) : (
                              <span className="text-gray-400 line-through">
                                Rs. {(item.quantityReceived * item.unitCost).toFixed(2)}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot className="bg-emerald-50 font-bold border-t border-gray-200">
                    <tr>
                      <td colSpan={6} className="py-2.5 px-3 text-right text-gray-700">
                        Total Verified Stock Intake (Accepted Items Only):
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-sm text-emerald-800">
                        Rs.{' '}
                        {grnItems
                          .filter((i) => i.disposition === 'ACCEPT')
                          .reduce((s, it) => s + it.quantityReceived * it.unitCost, 0)
                          .toFixed(2)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Partial Delivery Resolution Setting */}
              {grnItems.some(
                (i) =>
                  !i.isNonPoItem &&
                  i.quantityAlreadyReceived + (i.disposition === 'ACCEPT' ? i.quantityReceived : 0) <
                    i.quantityOrdered
              ) && (
                <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center gap-2 text-blue-900 font-bold">
                    <span className="material-symbols-outlined text-[18px] text-blue-700">hourglass_top</span>
                    <span>Partial Delivery Detected: Lesser Quantity Received Than Ordered</span>
                  </div>
                  <p className="text-[11px] text-blue-800">
                    Some items in this intake have remaining pending balance that may arrive later. Choose how you would like to treat this Purchase Order:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    <label
                      className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-all ${
                        grnKeepPoOpenOption === 'keep_open'
                          ? 'bg-white border-blue-500 shadow-xs ring-1 ring-blue-500'
                          : 'bg-blue-50/50 border-blue-200 hover:bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="keepPoOption"
                        value="keep_open"
                        checked={grnKeepPoOpenOption === 'keep_open'}
                        onChange={() => setGrnKeepPoOpenOption('keep_open')}
                        className="mt-0.5 text-blue-600"
                      />
                      <div>
                        <div className="font-bold text-gray-900 flex items-center gap-1">
                          <span>🟢 Keep PO Open (PARTIALLY RECEIVED)</span>
                        </div>
                        <div className="text-[10px] text-gray-600 mt-0.5">
                          Remaining quantities will arrive in a subsequent delivery. Keep PO open so we can create another GRN later.
                        </div>
                      </div>
                    </label>

                    <label
                      className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-all ${
                        grnKeepPoOpenOption === 'force_close'
                          ? 'bg-white border-blue-500 shadow-xs ring-1 ring-blue-500'
                          : 'bg-blue-50/50 border-blue-200 hover:bg-white'
                      }`}
                    >
                      <input
                        type="radio"
                        name="keepPoOption"
                        value="force_close"
                        checked={grnKeepPoOpenOption === 'force_close'}
                        onChange={() => setGrnKeepPoOpenOption('force_close')}
                        className="mt-0.5 text-blue-600"
                      />
                      <div>
                        <div className="font-bold text-gray-900 flex items-center gap-1">
                          <span>⚪ Short-Close PO (FULFILLED)</span>
                        </div>
                        <div className="text-[10px] text-gray-600 mt-0.5">
                          The vendor will NOT deliver remaining balance. Close and complete this Purchase Order now.
                        </div>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block font-bold text-gray-700 mb-1">Intake / Receiving Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Partial delivery (crate 1 of 2). Quality inspected and verified."
                  value={grnNotes}
                  onChange={(e) => setGrnNotes(e.target.value)}
                  className="w-full h-8 px-3 border border-gray-300 rounded-lg"
                />
              </div>

              {/* Submit & Cancel */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setIsGrnModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold cursor-pointer flex items-center gap-1.5 shadow-sm"
                >
                  <span className="material-symbols-outlined text-[16px]">task_alt</span>
                  {grnItems.some(
                    (i) =>
                      !i.isNonPoItem &&
                      i.quantityAlreadyReceived + (i.disposition === 'ACCEPT' ? i.quantityReceived : 0) <
                        i.quantityOrdered
                  ) && grnKeepPoOpenOption === 'keep_open'
                    ? 'Finalize Partial GRN (Keep PO Open)'
                    : 'Finalize GRN & Complete PO'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};
