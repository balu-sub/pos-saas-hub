import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';
import { generateReportPDF } from '../../utils/pdfExport';

interface SavedZReport {
  zReportId: string;
  closedAt: string;
  operatorName: string;
  terminalId: string;
  openingFloat: number;
  cashSales: number;
  upiSales: number;
  cardSales: number;
  midShiftDrops: number;
  expectedBalance: number;
  actualCounted: number;
  variance: number;
  notes: string;
  denominations: {
    bills: Record<string, number>;
    coins: number;
  };
}

export const ReconciliationScreen: React.FC = () => {
  const {
    currentShift,
    updateShiftDenomination,
    recordCashDrop,
    closeCurrentShift,
    currentOperator,
    outletProfile,
  } = usePOS();

  const [cashDropAmount, setCashDropAmount] = useState('');
  const [cashDropReason, setCashDropReason] = useState('Safe Deposit to Owner');
  const [isDropModalOpen, setIsDropModalOpen] = useState(false);
  const [closingNotes, setClosingNotes] = useState('');
  const [isCloseModalOpen, setIsCloseModalOpen] = useState(false);

  // Active Z-Report Preview Modal state & Saved Z-Reports Archive
  const [activeZReport, setActiveZReport] = useState<SavedZReport | null>(null);
  const [savedZReports, setSavedZReports] = useState<SavedZReport[]>(() => {
    try {
      const raw = localStorage.getItem('pos_z_reports_history');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('pos_z_reports_history', JSON.stringify(savedZReports));
    } catch {
      // ignore storage errors
    }
  }, [savedZReports]);

  // Indian Rupee Notes List
  const billDenoms = [
    { key: 'd2000', label: 'Rs. 2000 Notes', multiplier: 2000, count: currentShift.denominations.bills?.d2000 || 0 },
    { key: 'd500', label: 'Rs. 500 Notes', multiplier: 500, count: currentShift.denominations.bills?.d500 || 0 },
    { key: 'd200', label: 'Rs. 200 Notes', multiplier: 200, count: currentShift.denominations.bills?.d200 || 0 },
    { key: 'd100', label: 'Rs. 100 Notes', multiplier: 100, count: currentShift.denominations.bills?.d100 || 0 },
    { key: 'd50', label: 'Rs. 50 Notes', multiplier: 50, count: currentShift.denominations.bills?.d50 || 0 },
    { key: 'd20', label: 'Rs. 20 Notes', multiplier: 20, count: currentShift.denominations.bills?.d20 || 0 },
    { key: 'd10', label: 'Rs. 10 Notes', multiplier: 10, count: currentShift.denominations.bills?.d10 || 0 },
  ];

  const coinsValue =
    typeof currentShift.denominations?.coins === 'number'
      ? currentShift.denominations.coins
      : 0;

  const unknownCash = Number(currentShift.denominations.bills?.unknown || 0);

  const handleBillCountChange = (key: string, val: string) => {
    const count = parseInt(val, 10) || 0;
    updateShiftDenomination('bills', key, count);
  };

  const handleUnknownCashChange = (val: string) => {
    const amount = Math.max(0, parseFloat(val) || 0);
    updateShiftDenomination('bills', 'unknown', amount);
  };

  const handleCoinsValueChange = (val: string) => {
    const amount = parseFloat(val) || 0;
    updateShiftDenomination('coins', amount);
  };

  const handleExecuteCashDrop = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(cashDropAmount) || 0;
    if (amount <= 0) return;
    await recordCashDrop(amount, cashDropReason);
    setCashDropAmount('');
    setIsDropModalOpen(false);
  };

  // Generate & Download Official A4 Z-Report PDF into the user's Downloads folder
  const downloadZReportPDF = (report: SavedZReport) => {
    const dateStr = new Date(report.closedAt).toLocaleString('en-IN');
    const fileDate = report.closedAt.slice(0, 16).replace(/[:T]/g, '-');
    const bills = report.denominations?.bills || {};

    const denomRows: (string | number)[][] = [
      ['Shift Summary — Opening Float', '1', `Rs. ${report.openingFloat.toFixed(2)}`, `Rs. ${report.openingFloat.toFixed(2)}`],
      ['Shift Summary — Cash Sales Collected', '-', `Rs. ${report.cashSales.toFixed(2)}`, `Rs. ${report.cashSales.toFixed(2)}`],
      ['Shift Summary — UPI / QR Sales (Direct Bank)', '-', `Rs. ${report.upiSales.toFixed(2)}`, `Rs. ${report.upiSales.toFixed(2)}`],
      ['Shift Summary — Card / EDC Sales', '-', `Rs. ${(report.cardSales || 0).toFixed(2)}`, `Rs. ${(report.cardSales || 0).toFixed(2)}`],
      ['Shift Summary — Safe Drops / Payouts', '-', `- Rs. ${report.midShiftDrops.toFixed(2)}`, `- Rs. ${report.midShiftDrops.toFixed(2)}`],
      ['Shift Summary — Expected Cash in Drawer', '-', '-', `Rs. ${report.expectedBalance.toFixed(2)}`],
      ['Physical Count — Rs. 2000 Notes', String(bills.d2000 || 0), 'Rs. 2000', `Rs. ${((bills.d2000 || 0) * 2000).toFixed(2)}`],
      ['Physical Count — Rs. 500 Notes', String(bills.d500 || 0), 'Rs. 500', `Rs. ${((bills.d500 || 0) * 500).toFixed(2)}`],
      ['Physical Count — Rs. 200 Notes', String(bills.d200 || 0), 'Rs. 200', `Rs. ${((bills.d200 || 0) * 200).toFixed(2)}`],
      ['Physical Count — Rs. 100 Notes', String(bills.d100 || 0), 'Rs. 100', `Rs. ${((bills.d100 || 0) * 100).toFixed(2)}`],
      ['Physical Count — Rs. 50 Notes', String(bills.d50 || 0), 'Rs. 50', `Rs. ${((bills.d50 || 0) * 50).toFixed(2)}`],
      ['Physical Count — Rs. 20 Notes', String(bills.d20 || 0), 'Rs. 20', `Rs. ${((bills.d20 || 0) * 20).toFixed(2)}`],
      ['Physical Count — Rs. 10 Notes', String(bills.d10 || 0), 'Rs. 10', `Rs. ${((bills.d10 || 0) * 10).toFixed(2)}`],
      ['Physical Count — Loose Coins Total', '-', '-', `Rs. ${(report.denominations?.coins || 0).toFixed(2)}`],
      ['Physical Count — Unclassified / Other Cash', '-', '-', `Rs. ${(bills.unknown || 0).toFixed(2)}`],
      ['FINAL AUDIT — Total Physically Counted Cash', '-', '-', `Rs. ${report.actualCounted.toFixed(2)}`],
      [
        'FINAL AUDIT — Cash Drawer Variance',
        '-',
        '-',
        Math.abs(report.variance) < 0.01
          ? 'Rs. 0.00 (BALANCED)'
          : `Rs. ${report.variance.toFixed(2)}`,
      ],
    ];

    generateReportPDF({
      title: `END-OF-DAY SHIFT Z-REPORT (${report.zReportId})`,
      subtitle: `Terminal: ${report.terminalId}  |  Cashier: ${report.operatorName}  |  Closed At: ${dateStr}  |  Notes: ${report.notes || 'None'}`,
      periodLabel: dateStr,
      outletProfile,
      summaryMetrics: [
        { label: 'Opening Float', value: `Rs. ${report.openingFloat.toFixed(2)}` },
        { label: 'Cash Sales', value: `Rs. ${report.cashSales.toFixed(2)}` },
        { label: 'UPI / QR Sales', value: `Rs. ${report.upiSales.toFixed(2)}` },
        { label: 'Expected Drawer', value: `Rs. ${report.expectedBalance.toFixed(2)}` },
        { label: 'Counted / Variance', value: `Rs. ${report.actualCounted.toFixed(2)} (${report.variance >= 0 ? '+' : ''}${report.variance.toFixed(2)})` },
      ],
      columns: ['Z-Report Line Item / Denomination', 'Note Count', 'Denomination', 'Amount (Rs.)'],
      data: denomRows,
      fileName: `Z-Report_${report.zReportId}`,
      footNote: `Official Immutable Z-Report (${report.zReportId}) • Verified by Cashier: ${report.operatorName}`,
    });
  };

  // Print 80mm Thermal Z-Report Slip on Receipt Printer
  const print80mmZReport = (report: SavedZReport) => {
    const storeName = outletProfile?.outletName || 'PLANNEST RETAIL POS';
    const branch = outletProfile?.branchName || 'Main Counter';
    const gstin = outletProfile?.gstin || '';
    const dateStr = new Date(report.closedAt).toLocaleString('en-IN');
    const bills = report.denominations?.bills || {};

    const printWin = window.open('', '_blank', 'width=420,height=720');
    if (!printWin) {
      window.print();
      return;
    }

    const html = `<!DOCTYPE html>
<html>
<head>
  <title>Z-Report ${report.zReportId}</title>
  <style>
    @page { size: 80mm auto; margin: 0; }
    body {
      font-family: 'Courier New', Courier, monospace;
      width: 74mm;
      margin: 0 auto;
      padding: 4mm 2mm;
      color: #000;
      font-size: 12px;
      line-height: 1.35;
    }
    .center { text-align: center; }
    .bold { font-weight: bold; }
    .title { font-size: 15px; font-weight: bold; }
    .divider { border-top: 1px dashed #000; margin: 6px 0; }
    .row { display: flex; justify-content: space-between; margin: 2px 0; }
    .total-row { display: flex; justify-content: space-between; font-weight: bold; font-size: 13px; margin: 4px 0; }
  </style>
</head>
<body>
  <div class="center title">${storeName}</div>
  <div class="center">${branch}</div>
  ${gstin ? `<div class="center">GSTIN: ${gstin}</div>` : ''}
  <div class="divider"></div>
  <div class="center bold">*** OFFICIAL SHIFT Z-REPORT ***</div>
  <div class="row"><span>Z-Report No:</span><span class="bold">${report.zReportId}</span></div>
  <div class="row"><span>Terminal:</span><span>${report.terminalId}</span></div>
  <div class="row"><span>Cashier:</span><span>${report.operatorName}</span></div>
  <div class="row"><span>Closed At:</span><span>${dateStr}</span></div>
  <div class="divider"></div>
  <div class="bold">1. SHIFT TENDER SUMMARY</div>
  <div class="row"><span>Opening Float:</span><span>Rs. ${report.openingFloat.toFixed(2)}</span></div>
  <div class="row"><span>+ Cash Sales:</span><span>Rs. ${report.cashSales.toFixed(2)}</span></div>
  <div class="row"><span>+ UPI / QR Sales:</span><span>Rs. ${report.upiSales.toFixed(2)}</span></div>
  <div class="row"><span>+ Card Sales:</span><span>Rs. ${(report.cardSales || 0).toFixed(2)}</span></div>
  <div class="row"><span>- Safe Drops:</span><span>Rs. ${report.midShiftDrops.toFixed(2)}</span></div>
  <div class="divider"></div>
  <div class="total-row"><span>TOTAL REVENUE:</span><span>Rs. ${(report.cashSales + report.upiSales + (report.cardSales || 0)).toFixed(2)}</span></div>
  <div class="total-row"><span>EXPECTED DRAWER:</span><span>Rs. ${report.expectedBalance.toFixed(2)}</span></div>
  <div class="divider"></div>
  <div class="bold">2. PHYSICAL INR DENOMINATIONS</div>
  <div class="row"><span>Rs. 2000 x ${bills.d2000 || 0}</span><span>Rs. ${((bills.d2000 || 0) * 2000).toFixed(2)}</span></div>
  <div class="row"><span>Rs. 500  x ${bills.d500 || 0}</span><span>Rs. ${((bills.d500 || 0) * 500).toFixed(2)}</span></div>
  <div class="row"><span>Rs. 200  x ${bills.d200 || 0}</span><span>Rs. ${((bills.d200 || 0) * 200).toFixed(2)}</span></div>
  <div class="row"><span>Rs. 100  x ${bills.d100 || 0}</span><span>Rs. ${((bills.d100 || 0) * 100).toFixed(2)}</span></div>
  <div class="row"><span>Rs. 50   x ${bills.d50 || 0}</span><span>Rs. ${((bills.d50 || 0) * 50).toFixed(2)}</span></div>
  <div class="row"><span>Rs. 20   x ${bills.d20 || 0}</span><span>Rs. ${((bills.d20 || 0) * 20).toFixed(2)}</span></div>
  <div class="row"><span>Rs. 10   x ${bills.d10 || 0}</span><span>Rs. ${((bills.d10 || 0) * 10).toFixed(2)}</span></div>
  <div class="row"><span>Coins Total:</span><span>Rs. ${(report.denominations?.coins || 0).toFixed(2)}</span></div>
  <div class="row"><span>Other / Split Cash:</span><span>Rs. ${(bills.unknown || 0).toFixed(2)}</span></div>
  <div class="divider"></div>
  <div class="total-row"><span>COUNTED CASH:</span><span>Rs. ${report.actualCounted.toFixed(2)}</span></div>
  <div class="total-row"><span>VARIANCE:</span><span>${Math.abs(report.variance) < 0.01 ? 'Rs. 0.00 (BALANCED)' : `Rs. ${report.variance.toFixed(2)}`}</span></div>
  ${report.notes ? `<div class="divider"></div><div><strong>Notes:</strong> ${report.notes}</div>` : ''}
  <div class="divider"></div>
  <div class="center" style="margin-top:16px;">__________________________</div>
  <div class="center">Cashier / Manager Sign</div>
  <script>
    window.onload = function() {
      window.print();
      setTimeout(function() { window.close(); }, 600);
    };
  </script>
</body>
</html>`;

    printWin.document.open();
    printWin.document.write(html);
    printWin.document.close();
  };

  const handleFinalShiftClose = async () => {
    const nowIso = new Date().toISOString();
    const zReportId = `Z-${nowIso.slice(2, 10).replace(/-/g, '')}-${nowIso.slice(11, 16).replace(':', '')}`;

    const newZReport: SavedZReport = {
      zReportId,
      closedAt: nowIso,
      operatorName: currentOperator.name,
      terminalId: 'POS-01',
      openingFloat: currentShift.openingFloat,
      cashSales: currentShift.cashSales,
      upiSales: currentShift.upiSales,
      cardSales: currentShift.cardSales || 0,
      midShiftDrops: currentShift.midShiftDrops || 0,
      expectedBalance: currentShift.expectedBalance,
      actualCounted: currentShift.actualCounted,
      variance: currentShift.variance,
      notes: closingNotes.trim() || 'End-of-day shift closed and reconciled.',
      denominations: {
        bills: { ...(currentShift.denominations.bills || {}) },
        coins: coinsValue,
      },
    };

    await closeCurrentShift(closingNotes);
    setSavedZReports((prev) => [newZReport, ...prev]);
    setIsCloseModalOpen(false);
    setClosingNotes('');
    setActiveZReport(newZReport);
    playSuccessChime();

    // Automatically save PDF to computer's Downloads folder immediately
    try {
      downloadZReportPDF(newZReport);
    } catch (err) {
      console.warn('PDF auto-download error:', err);
    }
  };

  const isBalanced = Math.abs(currentShift.variance) < 0.01;

  return (
    <div className="flex-1 w-full h-full min-h-0 bg-[#F4F4F5] p-4 lg:p-8 pb-24 overflow-y-auto flex flex-col gap-6 font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-[#09090B]">Cash Drawer &amp; Shift Reconciliation</h1>
            <span className="px-2.5 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold rounded-full">
              Single Store • Terminal POS-01
            </span>
            {currentShift.status === 'closed' && (
              <span className="px-2.5 py-0.5 bg-amber-100 border border-amber-300 text-amber-900 text-xs font-bold rounded-full">
                Last Shift Closed ({savedZReports[0]?.zReportId || 'Z-Report Saved'})
              </span>
            )}
          </div>
          <p className="text-xs text-[#5c403c] mt-0.5">
            Physical INR denomination counter, UPI settlements, float tracking, and end-of-day Z-Report (auto-saves PDF to Downloads &amp; Shift Archive below)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              playKeypadClick();
              setIsDropModalOpen(true);
            }}
            className="px-4 py-2 bg-white border border-[#D4D4D8] hover:bg-[#E4E4E7] text-[#09090B] rounded font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">account_balance</span>
            Record Safe Drop
          </button>

          <button
            onClick={() => {
              playKeypadClick();
              setIsCloseModalOpen(true);
            }}
            className="px-4 py-2 bg-[#ba1a1a] hover:bg-[#93000a] text-white rounded font-bold text-xs flex items-center gap-1.5 industrial-shadow transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">lock</span>
            Close Shift &amp; Print Z-Report
          </button>
        </div>
      </div>

      {/* KPI Cards: Shift Summary in Rs. */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {/* Opening Float */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">OPENING FLOAT</span>
          <div className="text-xl font-bold font-tabular-numeric text-[#09090B] mt-1">
            Rs. {currentShift.openingFloat.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Morning cash drawer start</div>
        </div>

        {/* Cash Sales */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">CASH SALES</span>
          <div className="text-xl font-bold font-tabular-numeric text-[#00478c] mt-1">
            Rs. {currentShift.cashSales.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Cash collected in drawer</div>
        </div>

        {/* UPI Sales */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">UPI / QR SALES</span>
          <div className="text-xl font-bold font-tabular-numeric text-purple-700 mt-1">
            Rs. {currentShift.upiSales.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Direct bank settlement</div>
        </div>

        {/* Expected Cash in Drawer */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">EXPECTED CASH</span>
          <div className="text-xl font-bold font-tabular-numeric text-[#09090B] mt-1">
            Rs. {currentShift.expectedBalance.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Float + Net Cash - Drops</div>
        </div>

        {/* Variance Status */}
        <div
          className={`border p-4 rounded-lg shadow-xs ${
            isBalanced
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-[#ffdad6] border-[#ba1a1a] text-[#ba1a1a]'
          }`}
        >
          <span className="text-[11px] font-bold uppercase">PHYSICAL VARIANCE</span>
          <div className="text-xl font-bold font-tabular-numeric mt-1">
            {isBalanced ? 'Rs. 0.00 (Balanced)' : `Rs. ${currentShift.variance.toFixed(2)}`}
          </div>
          <div className="text-[10px] mt-0.5 font-medium">
            {isBalanced ? 'Drawer matches ledger 100%' : 'Discrepancy detected in count'}
          </div>
        </div>
      </div>

      {/* INR Physical Denomination Counting Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Currency Notes (Left 6 Cols) */}
        <div className="lg:col-span-6 bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-2">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00478c]">payments</span>
              <h3 className="font-bold text-sm text-[#09090B]">Indian Currency Notes (₹)</h3>
            </div>
            <span className="text-xs text-[#5c403c]">Physical denomination count</span>
          </div>

          <div className="space-y-2">
            {billDenoms.map((b) => {
              const subtotal = b.count * b.multiplier;
              return (
                <div
                  key={b.key}
                  className="flex items-center justify-between gap-3 p-2 bg-[#F4F4F5] rounded"
                >
                  <span className="font-bold text-xs text-[#09090B] w-32">{b.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">×</span>
                    <input
                      type="number"
                      min="0"
                      value={b.count || ''}
                      onChange={(e) => handleBillCountChange(b.key, e.target.value)}
                      placeholder="0"
                      className="w-20 h-8 bg-white border border-[#D4D4D8] rounded text-center font-bold text-xs text-[#09090B] focus:border-[#00478c] focus:outline-none"
                    />
                  </div>
                  <div className="w-28 text-right font-bold text-xs text-[#00478c] font-tabular-numeric">
                    = Rs. {subtotal.toFixed(2)}
                  </div>
                </div>
              );
            })}

            {/* Unknown / Unclassified Denominations */}
            <div className="flex items-center justify-between gap-3 p-2 bg-amber-50/60 border border-dashed border-amber-300 rounded mt-1">
              <div className="flex flex-col">
                <span className="font-bold text-xs text-amber-950">Unknown / Other Cash (₹)</span>
                <span className="text-[10px] text-amber-800">Direct cash splits without note breakdown</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-900">Rs.</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={unknownCash || ''}
                  onChange={(e) => handleUnknownCashChange(e.target.value)}
                  placeholder="0.00"
                  className="w-24 h-8 bg-white border border-amber-300 rounded text-right px-2 font-bold text-xs text-amber-950 focus:border-amber-600 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Currency Coins & Total Count Verification (Right 6 Cols) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Coins Box: Single Total Coins Value */}
          <div className="bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c]">monetization_on</span>
                <h3 className="font-bold text-sm text-[#09090B]">Indian Currency Coins (₹)</h3>
              </div>
              <span className="text-xs text-[#5c403c]">Total loose coins value</span>
            </div>

            <div className="p-3 bg-[#F4F4F5] rounded space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex flex-col">
                  <span className="font-bold text-xs text-[#09090B]">Total Coins in Drawer:</span>
                  <span className="text-[10px] text-gray-500">Directly enter total value of all coins combined</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-gray-600">Rs.</span>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={coinsValue || ''}
                    onChange={(e) => handleCoinsValueChange(e.target.value)}
                    placeholder="0.00"
                    className="w-32 h-9 bg-white border border-[#D4D4D8] rounded px-3 text-right font-bold text-sm text-[#00478c] focus:border-[#00478c] focus:outline-none"
                  />
                </div>
              </div>

              {/* Quick coin adjustment helper buttons */}
              <div className="flex items-center gap-1.5 pt-2 border-t border-gray-200 flex-wrap">
                <span className="text-[10px] text-gray-500 font-medium">Quick add:</span>
                {[5, 10, 20, 50, 100].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      playKeypadClick();
                      updateShiftDenomination('coins', Number(((coinsValue || 0) + c).toFixed(2)));
                    }}
                    className="px-2 py-1 bg-white hover:bg-gray-100 border border-[#D4D4D8] rounded text-[10px] font-bold text-[#09090B] transition-colors cursor-pointer"
                  >
                    +{c}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    updateShiftDenomination('coins', 0);
                  }}
                  className="ml-auto px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-[10px] font-bold transition-colors cursor-pointer"
                >
                  Reset (0)
                </button>
              </div>
            </div>
          </div>

          {/* Audit Verification Summary */}
          <div className="bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
            <div className="font-bold text-xs uppercase tracking-wider text-[#5c403c]">
              DRAWER AUDIT VERIFICATION SUMMARY
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-gray-700">
                <span>Total Physically Counted Cash:</span>
                <span className="font-bold font-tabular-numeric text-[#09090B]">
                  Rs. {currentShift.actualCounted.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>Total Expected Cash in Register:</span>
                <span className="font-bold font-tabular-numeric text-[#09090B]">
                  Rs. {currentShift.expectedBalance.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-sm font-black pt-2 border-t border-[#D4D4D8]">
                <span>CASH VARIANCE:</span>
                <span
                  className={`font-tabular-numeric ${
                    isBalanced ? 'text-emerald-700' : 'text-[#ba1a1a]'
                  }`}
                >
                  {isBalanced ? 'Rs. 0.00 (Exact Match)' : `Rs. ${currentShift.variance.toFixed(2)}`}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SAVED Z-REPORTS & CLOSED SHIFTS ARCHIVE TABLE */}
      <div className="bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#D4D4D8] pb-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00478c]">receipt_long</span>
            <div>
              <h3 className="font-bold text-sm text-[#09090B]">
                Saved Z-Reports &amp; Closed Shift Archive ({savedZReports.length})
              </h3>
              <p className="text-[11px] text-[#5c403c]">
                Every closed shift Z-Report is automatically downloaded as a PDF into your computer&apos;s <strong>Downloads</strong> folder and saved here for reprinting anytime.
              </p>
            </div>
          </div>
        </div>

        {savedZReports.length === 0 ? (
          <div className="p-6 text-center text-xs text-gray-500 bg-[#F4F4F5] rounded-lg">
            No Z-Reports generated yet today. Click <strong>Close Shift &amp; Print Z-Report</strong> above to finalize the shift, print the 80mm Z-Report slip, and download the PDF report.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#F4F4F5] text-[#5c403c] border-b border-[#D4D4D8] uppercase text-[10px]">
                  <th className="py-2.5 px-3">Z-Report ID</th>
                  <th className="py-2.5 px-3">Closed Date &amp; Time</th>
                  <th className="py-2.5 px-3">Cashier</th>
                  <th className="py-2.5 px-3 text-right">Cash Sales</th>
                  <th className="py-2.5 px-3 text-right">UPI Sales</th>
                  <th className="py-2.5 px-3 text-right">Expected Cash</th>
                  <th className="py-2.5 px-3 text-right">Counted Cash</th>
                  <th className="py-2.5 px-3 text-right">Variance</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D4D4D8]">
                {savedZReports.map((rep) => {
                  const repBalanced = Math.abs(rep.variance) < 0.01;
                  return (
                    <tr key={rep.zReportId} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono font-bold text-[#00478c]">{rep.zReportId}</td>
                      <td className="py-2.5 px-3 text-gray-700">
                        {new Date(rep.closedAt).toLocaleString('en-IN')}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-[#09090B]">{rep.operatorName}</td>
                      <td className="py-2.5 px-3 text-right font-tabular-numeric">
                        Rs. {rep.cashSales.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-tabular-numeric text-purple-700">
                        Rs. {rep.upiSales.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-tabular-numeric font-semibold">
                        Rs. {rep.expectedBalance.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-tabular-numeric font-bold">
                        Rs. {rep.actualCounted.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-tabular-numeric">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            repBalanced
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {repBalanced ? 'Balanced' : `Rs. ${rep.variance.toFixed(2)}`}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setActiveZReport(rep)}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-[#00478c] border border-blue-200 rounded font-bold text-[11px] cursor-pointer"
                          >
                            View / Print 80mm
                          </button>
                          <button
                            type="button"
                            onClick={() => downloadZReportPDF(rep)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded font-bold text-[11px] cursor-pointer"
                          >
                            Download PDF
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* RECORD SAFE DROP MODAL */}
      {isDropModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setIsDropModalOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-md p-5 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <h3 className="font-bold text-base text-[#09090B]">Record Cash Drop / Safe Transfer</h3>
              <button
                onClick={() => setIsDropModalOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleExecuteCashDrop} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">
                  DROP AMOUNT (RS.) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={cashDropAmount}
                  onChange={(e) => setCashDropAmount(e.target.value)}
                  placeholder="e.g. 5000"
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">REASON / NOTE</label>
                <input
                  type="text"
                  value={cashDropReason}
                  onChange={(e) => setCashDropReason(e.target.value)}
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-xs text-[#09090B]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#00478c] hover:bg-[#005eb7] text-white rounded font-bold text-xs cursor-pointer"
                >
                  Confirm Cash Drop
                </button>
                <button
                  type="button"
                  onClick={() => setIsDropModalOpen(false)}
                  className="px-4 py-2 bg-[#F4F4F5] text-[#09090B] rounded font-bold text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CLOSE SHIFT CONFIRMATION MODAL */}
      {isCloseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setIsCloseModalOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-md p-5 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <h3 className="font-bold text-base text-[#09090B]">End-of-Day Shift Close &amp; Z-Report</h3>
              <button
                onClick={() => setIsCloseModalOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-gray-700">
                Shift will be finalized for <span className="font-bold">{currentOperator.name}</span>. The official{' '}
                <strong>Z-Report PDF</strong> will automatically download to your computer&apos;s{' '}
                <strong>Downloads</strong> folder, and the <strong>80mm Thermal Z-Report Preview</strong> will open for printing.
              </p>

              <div className="p-3 bg-[#F4F4F5] rounded-lg space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>Expected Cash in Drawer:</span>
                  <strong>Rs. {currentShift.expectedBalance.toFixed(2)}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Physically Counted Cash:</span>
                  <strong>Rs. {currentShift.actualCounted.toFixed(2)}</strong>
                </div>
                <div className="flex justify-between pt-1 border-t border-gray-300 font-bold">
                  <span>Variance:</span>
                  <span className={isBalanced ? 'text-emerald-700' : 'text-[#ba1a1a]'}>
                    {isBalanced ? 'Rs. 0.00 (Balanced)' : `Rs. ${currentShift.variance.toFixed(2)}`}
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">
                  SHIFT CLOSING NOTES
                </label>
                <textarea
                  value={closingNotes}
                  onChange={(e) => setClosingNotes(e.target.value)}
                  placeholder="e.g. Evening peak completed. Vegetable stock reconciled."
                  rows={3}
                  className="w-full border border-[#D4D4D8] rounded p-2 text-xs text-[#09090B]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleFinalShiftClose}
                  className="flex-1 py-2.5 bg-[#ba1a1a] hover:bg-[#93000a] text-white rounded font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">print</span>
                  Lock Shift, Save PDF &amp; Open Z-Report
                </button>
                <button
                  onClick={() => setIsCloseModalOpen(false)}
                  className="px-4 py-2.5 bg-[#F4F4F5] text-[#09090B] rounded font-bold text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* OFFICIAL Z-REPORT PREVIEW & PRINT MODAL */}
      {activeZReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setActiveZReport(null)}
          />
          <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-lg p-6 shadow-2xl space-y-4 animate-in fade-in max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600">verified</span>
                <div>
                  <h3 className="font-extrabold text-base text-[#09090B]">
                    Z-Report Generated ({activeZReport.zReportId})
                  </h3>
                  <p className="text-[11px] text-emerald-700 font-semibold">
                    ✓ Saved to Shift Archive &amp; downloaded to your computer&apos;s Downloads folder
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveZReport(null)}
                className="text-gray-400 hover:text-gray-700 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {/* 80mm Thermal Slip Preview Box */}
            <div className="bg-[#FAFAFA] border border-dashed border-gray-400 rounded-lg p-4 font-mono text-xs space-y-2 text-[#09090B]">
              <div className="text-center font-bold text-sm">
                {outletProfile?.outletName || 'PLANNEST RETAIL POS'}
              </div>
              <div className="text-center text-[11px] text-gray-600">
                {outletProfile?.branchName || 'Main Counter'} • Terminal {activeZReport.terminalId}
              </div>
              <div className="border-t border-dashed border-gray-400 my-1.5" />
              <div className="flex justify-between">
                <span>Z-Report ID:</span>
                <span className="font-bold">{activeZReport.zReportId}</span>
              </div>
              <div className="flex justify-between">
                <span>Cashier:</span>
                <span>{activeZReport.operatorName}</span>
              </div>
              <div className="flex justify-between">
                <span>Closed At:</span>
                <span>{new Date(activeZReport.closedAt).toLocaleString('en-IN')}</span>
              </div>
              <div className="border-t border-dashed border-gray-400 my-1.5" />
              <div className="font-bold">SHIFT TENDER SUMMARY</div>
              <div className="flex justify-between">
                <span>Opening Float:</span>
                <span>Rs. {activeZReport.openingFloat.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>+ Cash Sales:</span>
                <span>Rs. {activeZReport.cashSales.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>+ UPI / QR Sales:</span>
                <span>Rs. {activeZReport.upiSales.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>+ Card Sales:</span>
                <span>Rs. {(activeZReport.cardSales || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>- Safe Drops:</span>
                <span>Rs. {activeZReport.midShiftDrops.toFixed(2)}</span>
              </div>
              <div className="border-t border-dashed border-gray-400 my-1.5" />
              <div className="flex justify-between font-bold">
                <span>EXPECTED CASH IN DRAWER:</span>
                <span>Rs. {activeZReport.expectedBalance.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>PHYSICALLY COUNTED CASH:</span>
                <span>Rs. {activeZReport.actualCounted.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-sm pt-1 border-t border-dashed border-gray-400">
                <span>VARIANCE:</span>
                <span className={Math.abs(activeZReport.variance) < 0.01 ? 'text-emerald-700' : 'text-[#ba1a1a]'}>
                  {Math.abs(activeZReport.variance) < 0.01
                    ? 'Rs. 0.00 (BALANCED)'
                    : `Rs. ${activeZReport.variance.toFixed(2)}`}
                </span>
              </div>
              {activeZReport.notes && (
                <div className="pt-1 text-[11px] text-gray-600">
                  <strong>Notes:</strong> {activeZReport.notes}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2 pt-2">
              <button
                type="button"
                onClick={() => print80mmZReport(activeZReport)}
                className="flex-1 py-2.5 px-3 bg-[#00478c] hover:bg-[#003870] text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">print</span>
                <span>Print 80mm Thermal Slip</span>
              </button>
              <button
                type="button"
                onClick={() => downloadZReportPDF(activeZReport)}
                className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">download</span>
                <span>Download A4 PDF Again</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveZReport(null)}
                className="py-2.5 px-4 bg-[#F4F4F5] hover:bg-gray-200 text-[#09090B] rounded-lg font-bold text-xs cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
