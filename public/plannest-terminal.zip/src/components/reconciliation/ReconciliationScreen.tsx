import React, { useState } from 'react';
import { usePOS } from '../../context/POSContext';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';

export const ReconciliationScreen: React.FC = () => {
  const {
    currentShift,
    updateShiftDenomination,
    recordCashDrop,
    closeCurrentShift,
    currentOperator
  } = usePOS();

  const [cashDropAmount, setCashDropAmount] = useState('');
  const [cashDropReason, setCashDropReason] = useState('Safe Deposit to Owner');
  const [isDropModalOpen, setIsDropModalOpen] = useState(false);
  const [closingNotes, setClosingNotes] = useState('');
  const [isCloseModalOpen, setIsCloseModalOpen] = useState(false);

  // Indian Rupee Notes List
  const billDenoms = [
    { key: 'd2000', label: 'Rs. 2000 Notes', multiplier: 2000, count: currentShift.denominations.bills?.d2000 || 0 },
    { key: 'd500', label: 'Rs. 500 Notes', multiplier: 500, count: currentShift.denominations.bills?.d500 || 0 },
    { key: 'd200', label: 'Rs. 200 Notes', multiplier: 200, count: currentShift.denominations.bills?.d200 || 0 },
    { key: 'd100', label: 'Rs. 100 Notes', multiplier: 100, count: currentShift.denominations.bills?.d100 || 0 },
    { key: 'd50', label: 'Rs. 50 Notes', multiplier: 50, count: currentShift.denominations.bills?.d50 || 0 },
    { key: 'd20', label: 'Rs. 20 Notes', multiplier: 20, count: currentShift.denominations.bills?.d20 || 0 },
    { key: 'd10', label: 'Rs. 10 Notes', multiplier: 10, count: currentShift.denominations.bills?.d10 || 0 }
  ];

  const coinsValue = typeof currentShift.denominations?.coins === 'number'
    ? currentShift.denominations.coins
    : 0;

  const unknownCash = Number(currentShift.denominations.bills?.unknown || 0);

  const handleBillCountChange = (key: string, val: string) => {
    const count = parseInt(val, 10) || 0;
    updateShiftDenomination('bills', key, count);
  };

  const handleUnknownCashChange = (val: string) => {
    const amount = Math.max(0, parseFloat(val) || 0);
    updateShiftDenomination('bills', 'unknown', amount);
  };

  const handleCoinsValueChange = (val: string) => {
    const amount = parseFloat(val) || 0;
    updateShiftDenomination('coins', amount);
  };

  const handleExecuteCashDrop = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(cashDropAmount) || 0;
    if (amount <= 0) return;
    await recordCashDrop(amount, cashDropReason);
    setCashDropAmount('');
    setIsDropModalOpen(false);
  };

  const handleFinalShiftClose = async () => {
    await closeCurrentShift(closingNotes);
    setIsCloseModalOpen(false);
  };

  const isBalanced = Math.abs(currentShift.variance) < 0.01;

  return (
    <div className="flex-1 w-full h-full min-h-0 bg-[#F4F4F5] p-4 lg:p-8 pb-24 overflow-y-auto flex flex-col gap-6 font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-[#09090B]">Cash Drawer &amp; Shift Reconciliation</h1>
            <span className="px-2.5 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold rounded-full">
              Single Store • Terminal POS-01
            </span>
          </div>
          <p className="text-xs text-[#5c403c] mt-0.5">
            Physical INR denomination counter, UPI settlements, float tracking, and end-of-day z-report
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              playKeypadClick();
              setIsDropModalOpen(true);
            }}
            className="px-4 py-2 bg-white border border-[#D4D4D8] hover:bg-[#E4E4E7] text-[#09090B] rounded font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">account_balance</span>
            Record Safe Drop
          </button>

          <button
            onClick={() => {
              playKeypadClick();
              setIsCloseModalOpen(true);
            }}
            className="px-4 py-2 bg-[#ba1a1a] hover:bg-[#93000a] text-white rounded font-bold text-xs flex items-center gap-1.5 industrial-shadow transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">lock</span>
            Close Shift &amp; Print Z-Report
          </button>
        </div>
      </div>

      {/* KPI Cards: Shift Summary in Rs. */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {/* Opening Float */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">OPENING FLOAT</span>
          <div className="text-xl font-bold font-tabular-numeric text-[#09090B] mt-1">
            Rs. {currentShift.openingFloat.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Morning cash drawer start</div>
        </div>

        {/* Cash Sales */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">CASH SALES</span>
          <div className="text-xl font-bold font-tabular-numeric text-[#00478c] mt-1">
            Rs. {currentShift.cashSales.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Cash collected in drawer</div>
        </div>

        {/* UPI Sales */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">UPI / QR SALES</span>
          <div className="text-xl font-bold font-tabular-numeric text-purple-700 mt-1">
            Rs. {currentShift.upiSales.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Direct bank settlement</div>
        </div>

        {/* Expected Cash in Drawer */}
        <div className="bg-white border border-[#D4D4D8] p-4 rounded-lg shadow-xs">
          <span className="text-[11px] font-bold text-[#5c403c] uppercase">EXPECTED CASH</span>
          <div className="text-xl font-bold font-tabular-numeric text-[#09090B] mt-1">
            Rs. {currentShift.expectedBalance.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mt-0.5">Float + Net Cash - Drops</div>
        </div>

        {/* Variance Status */}
        <div
          className={`border p-4 rounded-lg shadow-xs ${
            isBalanced
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-[#ffdad6] border-[#ba1a1a] text-[#ba1a1a]'
          }`}
        >
          <span className="text-[11px] font-bold uppercase">PHYSICAL VARIANCE</span>
          <div className="text-xl font-bold font-tabular-numeric mt-1">
            {isBalanced ? 'Rs. 0.00 (Balanced)' : `Rs. ${currentShift.variance.toFixed(2)}`}
          </div>
          <div className="text-[10px] mt-0.5 font-medium">
            {isBalanced ? 'Drawer matches ledger 100%' : 'Discrepancy detected in count'}
          </div>
        </div>
      </div>

      {/* INR Physical Denomination Counting Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Currency Notes (Left 6 Cols) */}
        <div className="lg:col-span-6 bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-2">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00478c]">payments</span>
              <h3 className="font-bold text-sm text-[#09090B]">Indian Currency Notes (₹)</h3>
            </div>
            <span className="text-xs text-[#5c403c]">Physical denomination count</span>
          </div>

          <div className="space-y-2">
            {billDenoms.map((b) => {
              const subtotal = b.count * b.multiplier;
              return (
                <div
                  key={b.key}
                  className="flex items-center justify-between gap-3 p-2 bg-[#F4F4F5] rounded"
                >
                  <span className="font-bold text-xs text-[#09090B] w-32">{b.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">×</span>
                    <input
                      type="number"
                      min="0"
                      value={b.count || ''}
                      onChange={(e) => handleBillCountChange(b.key, e.target.value)}
                      placeholder="0"
                      className="w-20 h-8 bg-white border border-[#D4D4D8] rounded text-center font-bold text-xs text-[#09090B] focus:border-[#00478c] focus:outline-none"
                    />
                  </div>
                  <div className="w-28 text-right font-bold text-xs text-[#00478c] font-tabular-numeric">
                    = Rs. {subtotal.toFixed(2)}
                  </div>
                </div>
              );
            })}

            {/* Unknown / Unclassified Denominations (from arbitrary split cash or untracked cash) */}
            <div className="flex items-center justify-between gap-3 p-2 bg-amber-50/60 border border-dashed border-amber-300 rounded mt-1">
              <div className="flex flex-col">
                <span className="font-bold text-xs text-amber-950">Unknown / Other Cash (₹)</span>
                <span className="text-[10px] text-amber-800">Direct cash splits without note breakdown</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-900">Rs.</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={unknownCash || ''}
                  onChange={(e) => handleUnknownCashChange(e.target.value)}
                  placeholder="0.00"
                  className="w-24 h-8 bg-white border border-amber-300 rounded text-right px-2 font-bold text-xs text-amber-950 focus:border-amber-600 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Currency Coins & Total Count Verification (Right 6 Cols) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Coins Box: Single Total Coins Value */}
          <div className="bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00478c]">monetization_on</span>
                <h3 className="font-bold text-sm text-[#09090B]">Indian Currency Coins (₹)</h3>
              </div>
              <span className="text-xs text-[#5c403c]">Total loose coins value</span>
            </div>

            <div className="p-3 bg-[#F4F4F5] rounded space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div className="flex flex-col">
                  <span className="font-bold text-xs text-[#09090B]">Total Coins in Drawer:</span>
                  <span className="text-[10px] text-gray-500">Directly enter total value of all coins combined</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-gray-600">Rs.</span>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={coinsValue || ''}
                    onChange={(e) => handleCoinsValueChange(e.target.value)}
                    placeholder="0.00"
                    className="w-32 h-9 bg-white border border-[#D4D4D8] rounded px-3 text-right font-bold text-sm text-[#00478c] focus:border-[#00478c] focus:outline-none"
                  />
                </div>
              </div>

              {/* Quick coin adjustment helper buttons */}
              <div className="flex items-center gap-1.5 pt-2 border-t border-gray-200 flex-wrap">
                <span className="text-[10px] text-gray-500 font-medium">Quick add:</span>
                {[5, 10, 20, 50, 100].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      playKeypadClick();
                      updateShiftDenomination('coins', Number(((coinsValue || 0) + c).toFixed(2)));
                    }}
                    className="px-2 py-1 bg-white hover:bg-gray-100 border border-[#D4D4D8] rounded text-[10px] font-bold text-[#09090B] transition-colors cursor-pointer"
                  >
                    +{c}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    playKeypadClick();
                    updateShiftDenomination('coins', 0);
                  }}
                  className="ml-auto px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-[10px] font-bold transition-colors cursor-pointer"
                >
                  Reset (0)
                </button>
              </div>
            </div>
          </div>

          {/* Audit Verification Summary */}
          <div className="bg-white border border-[#D4D4D8] rounded-lg p-5 shadow-xs space-y-3">
            <div className="font-bold text-xs uppercase tracking-wider text-[#5c403c]">
              DRAWER AUDIT VERIFICATION SUMMARY
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-gray-700">
                <span>Total Physically Counted Cash:</span>
                <span className="font-bold font-tabular-numeric text-[#09090B]">
                  Rs. {currentShift.actualCounted.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-gray-700">
                <span>Total Expected Cash in Register:</span>
                <span className="font-bold font-tabular-numeric text-[#09090B]">
                  Rs. {currentShift.expectedBalance.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-sm font-black pt-2 border-t border-[#D4D4D8]">
                <span>CASH VARIANCE:</span>
                <span
                  className={`font-tabular-numeric ${
                    isBalanced ? 'text-emerald-700' : 'text-[#ba1a1a]'
                  }`}
                >
                  {isBalanced ? 'Rs. 0.00 (Exact Match)' : `Rs. ${currentShift.variance.toFixed(2)}`}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* RECORD SAFE DROP MODAL */}
      {isDropModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setIsDropModalOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-md p-5 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <h3 className="font-bold text-base text-[#09090B]">Record Cash Drop / Safe Transfer</h3>
              <button
                onClick={() => setIsDropModalOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleExecuteCashDrop} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">
                  DROP AMOUNT (RS.) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={cashDropAmount}
                  onChange={(e) => setCashDropAmount(e.target.value)}
                  placeholder="e.g. 5000"
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-sm font-bold text-[#09090B]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">REASON / NOTE</label>
                <input
                  type="text"
                  value={cashDropReason}
                  onChange={(e) => setCashDropReason(e.target.value)}
                  className="w-full h-9 border border-[#D4D4D8] rounded px-3 text-xs text-[#09090B]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#00478c] hover:bg-[#005eb7] text-white rounded font-bold text-xs"
                >
                  Confirm Cash Drop
                </button>
                <button
                  type="button"
                  onClick={() => setIsDropModalOpen(false)}
                  className="px-4 py-2 bg-[#F4F4F5] text-[#09090B] rounded font-bold text-xs"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CLOSE SHIFT MODAL */}
      {isCloseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            onClick={() => setIsCloseModalOpen(false)}
          />
          <div className="relative z-50 bg-white rounded-lg border border-[#D4D4D8] w-full max-w-md p-5 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#D4D4D8] pb-3">
              <h3 className="font-bold text-base text-[#09090B]">End-of-Day Shift Close</h3>
              <button
                onClick={() => setIsCloseModalOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-gray-700">
                Shift will be finalized, cash drawer locked, and immutable Z-Report generated for{' '}
                <span className="font-bold">{currentOperator.name}</span>.
              </p>

              <div>
                <label className="block font-bold text-[#5c403c] mb-1 uppercase">
                  SHIFT CLOSING NOTES
                </label>
                <textarea
                  value={closingNotes}
                  onChange={(e) => setClosingNotes(e.target.value)}
                  placeholder="e.g. Evening peak completed. Vegetable stock reconciled."
                  rows={3}
                  className="w-full border border-[#D4D4D8] rounded p-2 text-xs text-[#09090B]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={handleFinalShiftClose}
                  className="flex-1 py-2.5 bg-[#ba1a1a] hover:bg-[#93000a] text-white rounded font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <span className="material-symbols-outlined text-[16px]">lock</span>
                  Lock &amp; Close Shift
                </button>
                <button
                  onClick={() => setIsCloseModalOpen(false)}
                  className="px-4 py-2.5 bg-[#F4F4F5] text-[#09090B] rounded font-bold text-xs"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
