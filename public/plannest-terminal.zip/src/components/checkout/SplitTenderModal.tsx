import React, { useState, useMemo, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useLanguage } from '../../context/LanguageContext';
import { CashDenominationBreakdown, TenderType } from '../../types/pos';
import { playKeypadClick, playSuccessChime } from '../../utils/audio';
import { sanitizeCurrencyInput } from '../../utils/unitQuantity';

export const SplitTenderModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    totalDue,
    totalPaid,
    remainingBalance,
    changeDue,
    paymentSplits,
    tenderAmountInput,
    setTenderAmountInput,
    activeTenderType,
    setActiveTenderType,
    addPaymentSplit,
    removePaymentSplit,
    completeTransaction,
    selectedCustomer,
    setSelectedCustomer,
    customers,
    loyaltyConfig,
    outletProfile
  } = usePOS();

  const { drawerConfig, kickOpenDrawer } = usePeripherals();

  const [isProcessing, setIsProcessing] = useState(false);
  const [customRefInput, setCustomRefInput] = useState('');
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [noteMode, setNoteMode] = useState<'add' | 'reduce' | 'set'>('add');
  const [selectedCashNotes, setSelectedCashNotes] = useState<{
    d2000: number;
    d500: number;
    d200: number;
    d100: number;
    d50: number;
    d20: number;
    d10: number;
  }>({
    d2000: 0,
    d500: 0,
    d200: 0,
    d100: 0,
    d50: 0,
    d20: 0,
    d10: 0,
  });

  const pointValue = loyaltyConfig.pointRedemptionValue || 1;

  // Track already redeemed points from active splits in this checkout session
  const redeemedSplits = useMemo(() => {
    return paymentSplits.filter((s) => s.tenderType === 'redeem');
  }, [paymentSplits]);

  const totalRedeemedSplitAmount = useMemo(() => {
    return redeemedSplits.reduce((acc, s) => acc + s.amount, 0);
  }, [redeemedSplits]);

  const totalRedeemedSplitPoints = useMemo(() => {
    return Math.round(totalRedeemedSplitAmount / pointValue);
  }, [totalRedeemedSplitAmount, pointValue]);

  const customerOriginalPoints = selectedCustomer?.loyaltyPoints || 0;
  const customerAvailablePoints = Math.max(0, customerOriginalPoints - totalRedeemedSplitPoints);
  const customerAvailableRedeemValue = Number((customerAvailablePoints * pointValue).toFixed(2));
  const maxRedeemableForBill = Number(Math.min(customerAvailableRedeemValue, remainingBalance).toFixed(2));

  const isLoyaltyEnabled = loyaltyConfig.enabled;
  const isMember = selectedCustomer ? (selectedCustomer.isLoyaltyMember ?? true) : false;
  const hasMinPoints = customerAvailablePoints >= (loyaltyConfig.minPointsToRedeem || 1);
  const isRedemptionExhausted = selectedCustomer ? (customerAvailablePoints < (loyaltyConfig.minPointsToRedeem || 1) || customerAvailablePoints === 0) : false;

  // Auto-fill tender amount when changing active tender type or balance
  useEffect(() => {
    if (isCheckoutOpen) {
      if (activeTenderType === 'redeem') {
        if (maxRedeemableForBill > 0) {
          setTenderAmountInput(maxRedeemableForBill.toFixed(2));
        } else {
          setTenderAmountInput('0.00');
        }
      } else {
        if (remainingBalance > 0) {
          setTenderAmountInput(remainingBalance.toFixed(2));
        } else {
          setTenderAmountInput('');
        }
      }
    }
  }, [isCheckoutOpen, activeTenderType, remainingBalance, maxRedeemableForBill, setTenderAmountInput]);

  if (!isCheckoutOpen) return null;

  const handleKeypadPress = (val: string) => {
    playKeypadClick();
    if (val === 'CLEAR') {
      setTenderAmountInput('');
      setSelectedCashNotes({ d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0 });
      return;
    }
    if (val === 'BACKSPACE') {
      setTenderAmountInput(tenderAmountInput.slice(0, -1));
      setSelectedCashNotes({ d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0 });
      return;
    }
    if (val === '.' && tenderAmountInput.includes('.')) return;
    
    // Prevent typing more than 2 decimals
    if (val !== '.' && tenderAmountInput.includes('.')) {
      const decimals = tenderAmountInput.split('.')[1];
      if (decimals && decimals.length >= 2) {
        return;
      }
    }
    
    const candidate = tenderAmountInput + val;
    const sanitized = sanitizeCurrencyInput(candidate);

    // If active tender is redeem, cap at max redeemable
    if (activeTenderType === 'redeem') {
      const num = parseFloat(sanitized) || 0;
      if (num > maxRedeemableForBill) {
        setTenderAmountInput(maxRedeemableForBill.toFixed(2));
        return;
      }
    }

    setTenderAmountInput(sanitized);
    // Custom keypad entry resets structured notes so unclassified cash gets logged as unknown denomination
    setSelectedCashNotes({ d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0 });
  };

  const handleQuickNote = (noteAmount: number) => {
    playKeypadClick();
    const noteKey = `d${noteAmount}` as keyof typeof selectedCashNotes;
    
    // In tender payment, clicking a note provides cash tender.
    // If noteMode is 'set', set the tender amount to the note value (or add note count)
    // If in default 'add' mode, clicking a note increments total tendered amount,
    // and note count is recorded for the cash drawer breakdown.
    const current = parseFloat(tenderAmountInput) || 0;
    const next = Number((current + noteAmount).toFixed(2));
    setTenderAmountInput(next.toFixed(2));
    
    if (noteKey in selectedCashNotes) {
      setSelectedCashNotes((prev) => ({
        ...prev,
        [noteKey]: (prev[noteKey] || 0) + 1,
      }));
    }
  };

  const handleReduceNote = (noteAmount: number) => {
    playKeypadClick();
    const noteKey = `d${noteAmount}` as keyof typeof selectedCashNotes;
    const current = parseFloat(tenderAmountInput) || 0;
    const next = Math.max(0, Number((current - noteAmount).toFixed(2)));
    setTenderAmountInput(next > 0 ? next.toFixed(2) : '');
    
    if (noteKey in selectedCashNotes && selectedCashNotes[noteKey] > 0) {
      setSelectedCashNotes((prev) => ({
        ...prev,
        [noteKey]: Math.max(0, prev[noteKey] - 1),
      }));
    }
  };

  const handleQuickRedeemFraction = (fraction: number) => {
    playKeypadClick();
    if (maxRedeemableForBill <= 0) return;
    const amount = Number((maxRedeemableForBill * fraction).toFixed(2));
    setTenderAmountInput(amount.toFixed(2));
  };

  const handleAddSplit = () => {
    const enteredAmount = parseFloat(tenderAmountInput);
    const amount = !isNaN(enteredAmount) && enteredAmount > 0 
      ? enteredAmount 
      : (activeTenderType === 'redeem' ? maxRedeemableForBill : remainingBalance);

    if (amount <= 0) return;

    if (activeTenderType === 'redeem') {
      if (!selectedCustomer) return;
      const actualAmount = Math.min(amount, maxRedeemableForBill);
      if (actualAmount <= 0) return;
      const pts = Math.round(actualAmount / pointValue);
      const ref = `⭐ Fresh Rewards (${pts} pts)`;
      addPaymentSplit('redeem', actualAmount, ref);
      setCustomRefInput('');

      // If there is still remaining balance after this redemption, switch to UPI/Cash for convenience
      const newRemaining = Number((remainingBalance - actualAmount).toFixed(2));
      if (newRemaining > 0) {
        setActiveTenderType('upi');
        setTenderAmountInput(newRemaining.toFixed(2));
      } else {
        setTenderAmountInput('0.00');
      }
      return;
    }

    let ref = customRefInput.trim();
    if (!ref) {
      if (activeTenderType === 'upi') ref = 'UPI QR Instant Pay';
      else if (activeTenderType === 'card') ref = 'POS EDC Card Terminal';
      else if (activeTenderType === 'store_credit') ref = `Khata Credit (${selectedCustomer?.name || 'Customer'})`;
      else ref = 'Cash Payment';
    }

    let splitDenominations: CashDenominationBreakdown | undefined = undefined;

    if (activeTenderType === 'cash') {
      const notesSum =
        (selectedCashNotes.d2000 * 2000) +
        (selectedCashNotes.d500 * 500) +
        (selectedCashNotes.d200 * 200) +
        (selectedCashNotes.d100 * 100) +
        (selectedCashNotes.d50 * 50) +
        (selectedCashNotes.d20 * 20) +
        (selectedCashNotes.d10 * 10);

      if (notesSum > 0 && Math.abs(notesSum - amount) < 0.01) {
        splitDenominations = {
          bills: { ...selectedCashNotes, unknown: 0 },
          coins: 0,
        };
      } else if (notesSum > 0 && amount > notesSum) {
        const unkDiff = Number((amount - notesSum).toFixed(2));
        splitDenominations = {
          bills: { ...selectedCashNotes, unknown: unkDiff },
          coins: 0,
        };
      } else {
        // Direct arbitrary keypad entry or exact change without note breakdown
        splitDenominations = {
          bills: {
            d2000: 0,
            d500: 0,
            d200: 0,
            d100: 0,
            d50: 0,
            d20: 0,
            d10: 0,
            unknown: amount,
          },
          coins: 0,
        };
      }
    }

    addPaymentSplit(activeTenderType, amount, ref, splitDenominations);
    setSelectedCashNotes({ d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0 });
    setCustomRefInput('');

    const newRemaining = Number((remainingBalance - amount).toFixed(2));
    if (newRemaining > 0) {
      setTenderAmountInput(newRemaining.toFixed(2));
    } else {
      const calculatedChange = Number((amount - remainingBalance).toFixed(2));
      if (calculatedChange > 0) {
        setTenderAmountInput(calculatedChange.toFixed(2));
      } else {
        setTenderAmountInput('0.00');
      }
    }
  };

  const handleFinishPayment = async () => {
    setIsProcessing(true);
    try {
      const hasCashTender = paymentSplits.some((s) => s.tenderType === 'cash') || activeTenderType === 'cash';
      if (hasCashTender && (drawerConfig.autoOpenOnCashPayment || drawerConfig.autoOpenOnSplitTender)) {
        kickOpenDrawer();
      }
      await completeTransaction();
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  const canFinalize = remainingBalance <= 0 || (paymentSplits.length > 0 && remainingBalance <= 0);

  // Filter customers for quick selection in modal if needed
  const filteredModalCustomers = customers.filter((c) => {
    const q = customerSearchQuery.toLowerCase().trim();
    if (!q) return (c.loyaltyPoints || 0) > 0;
    return c.name.toLowerCase().includes(q) || c.phone.includes(q);
  }).slice(0, 4);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 select-none">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs"
        onClick={() => setIsCheckoutOpen(false)}
      />

      {/* Modal Dialog */}
      <div className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col md:flex-row md:max-h-[88vh] industrial-shadow animate-in fade-in zoom-in-95">
        {/* Absolute Top-Right Close Button */}
        <button
          onClick={() => setIsCheckoutOpen(false)}
          className="absolute top-3 right-3 z-50 text-gray-400 hover:text-gray-700 bg-white/80 hover:bg-gray-100 p-1.5 rounded-full border border-gray-200 transition-all shadow-xs cursor-pointer"
          title="Close checkout"
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        {/* LEFT COLUMN: Payment Methods, Splits List & Totals */}
        <div className="flex-1 p-4 sm:p-5 flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#D4D4D8] overflow-y-auto">
          <div className="space-y-2.5">
            {/* Header */}
            <div className="flex items-center justify-between pb-2 border-b border-[#D4D4D8] pr-8">
              <div>
                <h2 className="text-lg font-bold text-[#09090B] leading-tight">Payment &amp; Split Tender</h2>
                <p className="text-[11px] text-[#5c403c]">
                  Multi-tender checkout for UPI, Cash, Card, Khata, and Loyalty Points Redemption
                </p>
              </div>
            </div>

            {/* Total Balance Due Banner */}
            <div className="p-2.5 bg-[#F4F4F5] border border-[#D4D4D8] rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] font-extrabold text-[#5c403c] uppercase tracking-wider block">
                  GROSS PAYABLE
                </span>
                <div className="text-2xl font-black text-[#00478c] font-tabular-numeric leading-tight">
                  {outletProfile?.currencySymbol || 'Rs.'} {totalDue.toFixed(2)}
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-extrabold text-[#5c403c] uppercase tracking-wider block">
                  BALANCE REMAINING
                </span>
                <div
                  className={`text-2xl font-black font-tabular-numeric leading-tight ${
                    remainingBalance > 0 ? 'text-[#ba1a1a]' : 'text-emerald-700'
                  }`}
                >
                  {outletProfile?.currencySymbol || 'Rs.'} {remainingBalance.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Tender Type Selector */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[11px] font-bold text-[#5c403c] uppercase tracking-wider">
                  SELECT TENDER METHOD
                </label>
                {activeTenderType === 'redeem' && remainingBalance > 0 && (
                  <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-ping"></span>
                    Redeem Active
                  </span>
                )}
              </div>

              {/* 5 Tender Choices Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                {[
                  { id: 'upi', label: 'UPI / QR', icon: 'qr_code_2', color: 'text-[#00478c]' },
                  { id: 'cash', label: 'Cash INR', icon: 'payments', color: 'text-emerald-700' },
                  { id: 'card', label: 'Card (EDC)', icon: 'credit_card', color: 'text-purple-700' },
                  { id: 'store_credit', label: 'Khata Credit', icon: 'account_balance_wallet', color: 'text-amber-700' },
                  { id: 'redeem', label: 'Redeem Points', icon: 'stars', color: 'text-amber-600' }
                ].map((tender) => {
                  const isSelected = activeTenderType === tender.id;
                  const isRedeem = tender.id === 'redeem';

                  return (
                    <button
                      key={tender.id}
                      type="button"
                      onClick={() => {
                        playKeypadClick();
                        setActiveTenderType(tender.id as TenderType);
                      }}
                      className={`p-1.5 rounded-lg border flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer relative ${
                        isSelected
                          ? isRedeem
                            ? 'bg-amber-600 text-white border-amber-600 shadow-sm ring-2 ring-amber-400/40'
                            : 'bg-[#00478c] text-white border-[#00478c] shadow-sm'
                          : 'bg-white border-[#D4D4D8] text-[#09090B] hover:bg-[#F4F4F5]'
                      } ${
                        isRedeem && !isSelected && isRedemptionExhausted && totalRedeemedSplitAmount > 0
                          ? 'opacity-70 border-emerald-300 bg-emerald-50/50'
                          : ''
                      }`}
                    >
                      <div className="flex items-center justify-center">
                        <span
                          className={`material-symbols-outlined text-[19px] ${
                            isSelected ? 'text-white' : tender.color
                          }`}
                        >
                          {tender.icon}
                        </span>
                      </div>
                      <span className="font-bold text-[10px] text-center leading-tight">{tender.label}</span>

                      {/* Small badge for points if redeem button */}
                      {isRedeem && (
                        <span
                          className={`text-[8.5px] font-black px-1 rounded-full leading-tight font-mono ${
                            isSelected
                              ? 'bg-white/25 text-white'
                              : customerAvailablePoints > 0
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : totalRedeemedSplitAmount > 0
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-gray-100 text-gray-500'
                          }`}
                        >
                          {totalRedeemedSplitAmount > 0 && customerAvailablePoints === 0
                            ? '✓ Done'
                            : customerAvailablePoints > 0
                            ? `${customerAvailablePoints} pts`
                            : '0 pts'}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ========================================================================= */}
            {/* REDEEM DEDICATED PANEL (When 'redeem' is selected) */}
            {/* ========================================================================= */}
            {activeTenderType === 'redeem' && (
              <div className="mt-3 p-3.5 bg-amber-50/90 border-2 border-amber-300 rounded-xl space-y-3 shadow-xs animate-in fade-in zoom-in-95">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-amber-500 text-white flex items-center justify-center font-black text-base shadow-xs shrink-0">
                      ⭐
                    </div>
                    <div>
                      <div className="font-black text-xs text-amber-950 flex items-center gap-2 flex-wrap">
                        <span>{selectedCustomer ? `${selectedCustomer.name} (Fresh Rewards)` : 'No Customer Attached'}</span>
                        {selectedCustomer && (
                          <span className="bg-amber-200 text-amber-900 text-[10px] font-extrabold px-1.5 py-0.5 rounded">
                            {selectedCustomer.memberTier || 'Member'}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-amber-900 mt-0.5">
                        {selectedCustomer ? (
                          <>
                            Available to redeem: <b>{customerAvailablePoints} pts</b> (Worth {outletProfile?.currencySymbol || 'Rs.'} {customerAvailableRedeemValue.toFixed(0)})
                            {totalRedeemedSplitPoints > 0 ? ` • ${totalRedeemedSplitPoints} pts applied in splits` : ''}
                          </>
                        ) : (
                          'Select or search a member customer below to redeem reward points'
                        )}
                      </div>
                    </div>
                  </div>

                  {selectedCustomer && (
                    <div className="text-right shrink-0">
                      <span className="text-[10px] text-amber-800 uppercase font-bold block">Max for Bill</span>
                      <span className="text-xs font-black text-amber-950 bg-amber-200/80 px-2 py-0.5 rounded font-tabular-numeric">
                        {outletProfile?.currencySymbol || 'Rs.'} {maxRedeemableForBill.toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>

                {/* Inline customer selection if no customer is selected */}
                {!selectedCustomer && (
                  <div className="bg-white p-3 rounded-lg border border-amber-200 space-y-2">
                    <div className="text-[11px] font-bold text-gray-700">Quick Select Customer with Points:</div>
                    <div className="relative">
                      <span className="material-symbols-outlined absolute left-2.5 top-2 text-gray-400 text-[16px]">search</span>
                      <input
                        type="text"
                        placeholder="Search by phone or name..."
                        value={customerSearchQuery}
                        onChange={(e) => setCustomerSearchQuery(e.target.value)}
                        className="w-full pl-8 pr-2.5 py-1.5 bg-gray-50 border border-gray-300 rounded text-xs focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-28 overflow-y-auto">
                      {filteredModalCustomers.map((cust) => (
                        <button
                          key={cust.id}
                          type="button"
                          onClick={() => {
                            playKeypadClick();
                            setSelectedCustomer(cust);
                          }}
                          className="p-2 bg-amber-50/50 hover:bg-amber-100 border border-amber-200 rounded text-left flex items-center justify-between cursor-pointer transition-colors"
                        >
                          <div className="truncate pr-1">
                            <div className="text-xs font-bold text-gray-900 truncate">{cust.name}</div>
                            <div className="text-[10px] text-gray-500 font-mono">{cust.phone}</div>
                          </div>
                          <span className="text-[11px] font-black text-amber-800 bg-amber-200 px-1.5 py-0.5 rounded font-mono shrink-0">
                            {cust.loyaltyPoints} pts
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick Partial Redemption Presets */}
                {selectedCustomer && customerAvailablePoints > 0 && maxRedeemableForBill > 0 && (
                  <div className="space-y-1.5 pt-1 border-t border-amber-200/70">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-extrabold text-amber-900 uppercase">
                        Select Part / Full Redemption:
                      </span>
                      <span className="text-[10px] text-amber-800">
                        1 Point = {outletProfile?.currencySymbol || 'Rs.'} {pointValue}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleQuickRedeemFraction(1.0)}
                        className="py-1.5 px-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-black text-[11px] shadow-2xs transition-all cursor-pointer text-center"
                      >
                        <div>Max (100%)</div>
                        <div className="text-[9px] opacity-90">Rs. {maxRedeemableForBill.toFixed(0)}</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickRedeemFraction(0.75)}
                        className="py-1.5 px-1 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded font-black text-[11px] transition-all cursor-pointer text-center"
                      >
                        <div>75% Pts</div>
                        <div className="text-[9px] text-amber-700">Rs. {(maxRedeemableForBill * 0.75).toFixed(0)}</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickRedeemFraction(0.5)}
                        className="py-1.5 px-1 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded font-black text-[11px] transition-all cursor-pointer text-center"
                      >
                        <div>50% Pts</div>
                        <div className="text-[9px] text-amber-700">Rs. {(maxRedeemableForBill * 0.5).toFixed(0)}</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickRedeemFraction(0.25)}
                        className="py-1.5 px-1 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 rounded font-black text-[11px] transition-all cursor-pointer text-center"
                      >
                        <div>25% Pts</div>
                        <div className="text-[9px] text-amber-700">Rs. {(maxRedeemableForBill * 0.25).toFixed(0)}</div>
                      </button>
                    </div>
                  </div>
                )}

                {/* Not eligible or points exhausted notes */}
                {selectedCustomer && customerAvailablePoints < (loyaltyConfig.minPointsToRedeem || 1) && (
                  <div className="p-2.5 bg-white/90 border border-amber-300 rounded text-xs text-amber-900 flex items-center gap-2">
                    <span className="material-symbols-outlined text-amber-700 text-lg">info</span>
                    <span>
                      {customerAvailablePoints === 0
                        ? 'All available points have been redeemed for this sale.'
                        : `Customer has ${customerAvailablePoints} pts. Minimum ${loyaltyConfig.minPointsToRedeem} points required to redeem.`}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* UPI QR Display if UPI is chosen */}
            {activeTenderType === 'upi' && (
              <div className="p-2 bg-blue-50/70 border border-blue-200 rounded-lg flex items-center gap-2.5 animate-in fade-in">
                <div className="w-11 h-11 bg-white border border-[#D4D4D8] rounded p-0.5 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-2xl text-[#00478c]">qr_code_2</span>
                </div>
                <div>
                  <div className="font-bold text-xs text-[#00478c] leading-tight">Instant UPI QR Code</div>
                  <div className="text-[10px] text-[#5c403c]">
                    UPI ID: <span className="font-mono font-bold">freshmart@upi</span>
                  </div>
                  <div className="text-[10px] text-emerald-800 font-medium">
                    Google Pay • PhonePe • Paytm • BHIM
                  </div>
                </div>
              </div>
            )}

            {/* Store Credit / Khata Display if Store Credit is chosen */}
            {activeTenderType === 'store_credit' && (
              <div className="p-2 bg-amber-50 border border-amber-300 rounded-lg flex items-center justify-between gap-2 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-amber-700 text-xl">account_balance_wallet</span>
                  <div>
                    <div className="font-bold text-xs text-amber-900 leading-tight">
                      {selectedCustomer ? `Khata: ${selectedCustomer.name}` : 'No Customer Selected for Khata'}
                    </div>
                    <div className="text-[10.5px] text-amber-800">
                      {selectedCustomer
                        ? `Available Credit: Rs. ${selectedCustomer.storeCredit.toFixed(2)}`
                        : 'Attach a customer to bill to debit this Khata balance'}
                    </div>
                  </div>
                </div>
                {selectedCustomer && (
                  <span
                    className={`text-[11px] font-black px-1.5 py-0.5 rounded font-tabular-numeric ${
                      selectedCustomer.storeCredit >= (parseFloat(tenderAmountInput) || remainingBalance)
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-rose-100 text-rose-800 border border-rose-300'
                    }`}
                  >
                    Rs. {selectedCustomer.storeCredit.toFixed(2)}
                  </span>
                )}
              </div>
            )}

            {/* Applied Payment Splits List */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-[#5c403c] uppercase tracking-wider">
                  PAYMENT BREAKDOWN ({paymentSplits.length})
                </span>
                {totalPaid > 0 && (
                  <span className="text-[11px] font-black text-emerald-700 font-tabular-numeric">
                    Paid: {outletProfile?.currencySymbol || 'Rs.'} {totalPaid.toFixed(2)}
                  </span>
                )}
              </div>

              <div className="space-y-1">
                {paymentSplits.length === 0 ? (
                  <div className="p-2 bg-[#F4F4F5] rounded-lg border border-dashed border-[#D4D4D8] text-center text-xs text-gray-500">
                    No payment splits added yet. Enter amount on the right or tap Full Pay.
                  </div>
                ) : (
                  paymentSplits.map((split) => (
                    <div
                      key={split.id}
                      className={`p-1.5 px-2.5 rounded-lg border flex items-center justify-between text-xs transition-all ${
                        split.tenderType === 'redeem'
                          ? 'bg-amber-50/70 border-amber-300'
                          : 'bg-[#F4F4F5] border-[#D4D4D8]'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`material-symbols-outlined text-[16px] ${
                            split.tenderType === 'redeem'
                              ? 'text-amber-600'
                              : split.tenderType === 'cash'
                              ? 'text-emerald-700'
                              : split.tenderType === 'upi'
                              ? 'text-[#00478c]'
                              : split.tenderType === 'card'
                              ? 'text-purple-700'
                              : 'text-amber-700'
                          }`}
                        >
                          {split.tenderType === 'cash'
                            ? 'payments'
                            : split.tenderType === 'upi'
                            ? 'qr_code_2'
                            : split.tenderType === 'card'
                            ? 'credit_card'
                            : split.tenderType === 'redeem'
                            ? 'stars'
                            : 'account_balance_wallet'}
                        </span>
                        <div>
                          <span
                            className={`font-bold uppercase mr-1.5 ${
                              split.tenderType === 'redeem' ? 'text-amber-950 font-black' : 'text-[#09090B]'
                            }`}
                          >
                            {split.tenderType === 'redeem' ? 'REDEEM' : split.tenderType}
                          </span>
                          <span className="text-gray-500 text-[10px]">{split.reference}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-bold font-tabular-numeric ${
                            split.tenderType === 'redeem' ? 'text-amber-950 font-black' : 'text-[#09090B]'
                          }`}
                        >
                          {outletProfile?.currencySymbol || 'Rs.'} {split.amount.toFixed(2)}
                        </span>
                        <button
                          type="button"
                          onClick={() => removePaymentSplit(split.id)}
                          className="text-gray-400 hover:text-red-600 p-0.5 cursor-pointer"
                          title="Remove this tender split"
                        >
                          <span className="material-symbols-outlined text-[15px]">close</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Finalization Action */}
          <div className="mt-2.5 pt-2 border-t border-[#D4D4D8]">
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                handleFinishPayment();
              }}
              disabled={!canFinalize || isProcessing}
              className="w-full py-3 bg-[#00478c] hover:bg-[#005eb7] active:bg-[#00366c] disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 industrial-shadow transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[19px]">check_circle</span>
              <span>{isProcessing ? 'Processing Transaction...' : 'COMPLETE SALE & PRINT RECEIPT'}</span>
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: Numeric Keypad & Quick Notes / Redemption Controls */}
        <div className="w-full md:w-[310px] bg-[#F4F4F5] p-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-bold uppercase tracking-wider">
                  {changeDue > 0 ? (
                    <span className="text-emerald-700 font-extrabold flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">payments</span>
                      CHANGE DUE TO CUSTOMER
                    </span>
                  ) : activeTenderType === 'redeem' ? (
                    <span className="text-[#5c403c]">REDEEM VALUE (RS.)</span>
                  ) : (
                    <span className="text-[#5c403c]">TENDER AMOUNT (RS.)</span>
                  )}
                </label>
                {activeTenderType === 'redeem' && (
                  <span className="text-[10px] font-bold text-amber-800">
                    ={Math.round((parseFloat(tenderAmountInput) || 0) / pointValue)} Pts
                  </span>
                )}
                {changeDue > 0 && (
                  <span className="text-[10px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded">
                    Return to Customer
                  </span>
                )}
              </div>
              <div className="relative">
                <span
                  className={`absolute left-3 top-2 font-bold text-sm ${
                    changeDue > 0 ? 'text-emerald-700' : 'text-gray-500'
                  }`}
                >
                  {outletProfile?.currencySymbol || 'Rs.'}
                </span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={tenderAmountInput}
                  onChange={(e) => {
                    const candidate = sanitizeCurrencyInput(e.target.value);
                    if (activeTenderType === 'redeem') {
                      const num = parseFloat(candidate) || 0;
                      if (num > maxRedeemableForBill) {
                        setTenderAmountInput(maxRedeemableForBill.toFixed(2));
                        return;
                      }
                    }
                    setTenderAmountInput(candidate);
                  }}
                  placeholder="0.00"
                  className={`w-full h-9.5 bg-white border rounded-lg pl-10 pr-3 text-right font-black text-lg font-tabular-numeric focus:outline-none transition-colors ${
                    changeDue > 0
                      ? 'border-emerald-500 text-emerald-700 bg-emerald-50/40 ring-1 ring-emerald-400/30'
                      : activeTenderType === 'redeem'
                      ? 'border-amber-400 text-amber-950 focus:border-amber-600'
                      : 'border-[#D4D4D8] text-[#09090B] focus:border-[#00478c]'
                  }`}
                />
              </div>
            </div>

            {/* Quick Currency Notes or Quick Points */}
            {activeTenderType !== 'redeem' ? (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-[#5c403c] uppercase">
                    CURRENCY NOTES
                  </span>
                  <div className="flex items-center gap-1 text-[9.5px] bg-white border border-[#D4D4D8] rounded p-0.5">
                    <button
                      type="button"
                      onClick={() => setNoteMode('add')}
                      className={`px-1.5 py-0.2 rounded font-bold transition-colors cursor-pointer ${
                        noteMode === 'add' ? 'bg-[#00478c] text-white' : 'text-gray-600 hover:text-black'
                      }`}
                      title="Add note to tender amount"
                    >
                      + Add
                    </button>
                    <button
                      type="button"
                      onClick={() => setNoteMode('reduce')}
                      className={`px-1.5 py-0.2 rounded font-bold transition-colors cursor-pointer ${
                        noteMode === 'reduce' ? 'bg-red-600 text-white' : 'text-gray-600 hover:text-black'
                      }`}
                      title="Reduce / subtract note from tender amount"
                    >
                      - Reduce
                    </button>
                    <button
                      type="button"
                      onClick={() => setNoteMode('set')}
                      className={`px-1.5 py-0.2 rounded font-bold transition-colors cursor-pointer ${
                        noteMode === 'set' ? 'bg-[#00478c] text-white' : 'text-gray-600 hover:text-black'
                      }`}
                      title="Set exact note amount"
                    >
                      Set
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  {[50, 100, 200, 500, 2000].map((note) => {
                    const noteCount = selectedCashNotes[`d${note}` as keyof typeof selectedCashNotes] || 0;
                    return (
                      <button
                        key={note}
                        type="button"
                        onClick={() => {
                          if (noteMode === 'reduce') {
                            handleReduceNote(note);
                          } else if (noteMode === 'set') {
                            playKeypadClick();
                            setTenderAmountInput(note.toFixed(2));
                            const noteKey = `d${note}` as keyof typeof selectedCashNotes;
                            setSelectedCashNotes({
                              d2000: 0,
                              d500: 0,
                              d200: 0,
                              d100: 0,
                              d50: 0,
                              d20: 0,
                              d10: 0,
                              ...(noteKey in selectedCashNotes ? { [noteKey]: 1 } : {}),
                            });
                          } else {
                            handleQuickNote(note);
                          }
                        }}
                        className={`relative py-1 border rounded-md font-bold text-xs font-tabular-numeric transition-colors cursor-pointer ${
                          noteCount > 0
                            ? 'bg-blue-50 border-[#00478c] text-[#00478c]'
                            : 'bg-white hover:bg-blue-50 border-[#D4D4D8] hover:border-[#00478c] text-[#09090B]'
                        }`}
                      >
                        {noteMode === 'add' ? `+ ₹${note}` : noteMode === 'reduce' ? `- ₹${note}` : `₹${note}`}
                        {noteCount > 0 && (
                          <span className="ml-1 px-1 py-0.2 bg-[#00478c] text-white text-[9px] rounded-full font-bold">
                            ×{noteCount}
                          </span>
                        )}
                      </button>
                    );
                  })}
                  <button
                    type="button"
                    onClick={() => {
                      playKeypadClick();
                      setTenderAmountInput(remainingBalance.toFixed(2));
                      setSelectedCashNotes({ d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0 });
                    }}
                    className="py-1 bg-[#00478c]/10 text-[#00478c] hover:bg-[#00478c]/20 border border-[#00478c]/30 rounded-md font-bold text-xs cursor-pointer"
                  >
                    Exact (₹{remainingBalance.toFixed(0)})
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <span className="block text-[10px] font-bold text-amber-900 uppercase mb-1">
                  QUICK REDEMPTION PRESETS
                </span>
                <div className="grid grid-cols-3 gap-1">
                  <button
                    type="button"
                    onClick={() => handleQuickRedeemFraction(1.0)}
                    className="py-1 bg-amber-600 hover:bg-amber-700 text-white border border-amber-600 rounded-md font-bold text-[11px] cursor-pointer"
                  >
                    Max (Rs. {maxRedeemableForBill.toFixed(0)})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickRedeemFraction(0.5)}
                    className="py-1 bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 rounded-md font-bold text-[11px] cursor-pointer"
                  >
                    50% (Rs. {(maxRedeemableForBill * 0.5).toFixed(0)})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickRedeemFraction(0.25)}
                    className="py-1 bg-white hover:bg-amber-50 text-amber-900 border border-amber-300 rounded-md font-bold text-[11px] cursor-pointer"
                  >
                    25% (Rs. {(maxRedeemableForBill * 0.25).toFixed(0)})
                  </button>
                </div>
              </div>
            )}

            {/* 10-Key Touch Keypad */}
            <div className="grid grid-cols-3 gap-1 pt-0.5">
              {['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '00', '.'].map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => handleKeypadPress(key)}
                  className="h-8.5 bg-white hover:bg-[#E4E4E7] border border-[#D4D4D8] rounded-md text-sm font-bold text-[#09090B] font-tabular-numeric flex items-center justify-center active:scale-95 transition-all shadow-2xs cursor-pointer"
                >
                  {key}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-1">
              <button
                type="button"
                onClick={() => handleKeypadPress('CLEAR')}
                className="py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md font-bold text-xs transition-colors cursor-pointer"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('BACKSPACE')}
                className="py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md font-bold text-xs transition-colors flex items-center justify-center cursor-pointer"
              >
                <span className="material-symbols-outlined text-[15px]">backspace</span>
              </button>
            </div>
          </div>

          {/* Add Tender Split Button */}
          <button
            type="button"
            onClick={handleAddSplit}
            disabled={
              activeTenderType === 'redeem'
                ? !selectedCustomer || maxRedeemableForBill <= 0 || (parseFloat(tenderAmountInput) || 0) <= 0
                : (parseFloat(tenderAmountInput) || remainingBalance) <= 0
            }
            className={`w-full mt-2 py-2.5 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              activeTenderType === 'redeem'
                ? 'bg-amber-600 hover:bg-amber-700'
                : 'bg-[#00478c] hover:bg-[#005eb7]'
            }`}
          >
            <span className="material-symbols-outlined text-[17px]">
              {activeTenderType === 'redeem' ? 'stars' : 'add'}
            </span>
            <span>
              {activeTenderType === 'redeem'
                ? `Apply Points (+ Rs. ${parseFloat(tenderAmountInput || '0').toFixed(2)})`
                : `Add Split (+ Rs. ${parseFloat(tenderAmountInput || '0').toFixed(2)})`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
