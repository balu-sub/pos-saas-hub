import React from 'react';
import { RECEIPT_LOCALIZED_LABELS, TENDER_NAME_LOCALIZED } from '../../locales/receiptTranslations';
import { getProductLocalizedName } from '../../locales/productTranslations';
import { LanguageCode } from '../../locales/en';
import { Order } from '../../types/pos';

interface ThermalReceiptTicketProps {
  order: Order;
  outletProfile?: any;
  printerConfig?: any;
  receiptLang: LanguageCode;
  isDuplicate?: boolean;
  isKiosk?: boolean;
  customer?: any;
  loyaltyConfig?: any;
}

export const ThermalReceiptTicket: React.FC<ThermalReceiptTicketProps> = ({
  order,
  outletProfile,
  printerConfig,
  receiptLang,
  isDuplicate = false,
  isKiosk = false,
  customer,
  loyaltyConfig,
}) => {
  const t = RECEIPT_LOCALIZED_LABELS[receiptLang] || RECEIPT_LOCALIZED_LABELS.en;
  const currency = outletProfile?.currencySymbol || 'Rs.';

  const outletName =
    outletProfile?.outletName?.trim() ||
    printerConfig?.headerText?.trim() ||
    'AMMA & APPA KADAI';

  const branchName = outletProfile?.branchName?.trim();
  const address =
    [
      outletProfile?.addressLine1,
      outletProfile?.addressLine2,
      outletProfile?.city,
      outletProfile?.state,
      outletProfile?.pincode,
    ]
      .filter(Boolean)
      .join(', ') || 'Shop #12, Market Complex, Chennai';

  const phone = outletProfile?.phone || '+91 98200 12345';
  const email = outletProfile?.email;

  const orderDate = new Date(order.createdAt || Date.now());
  const formattedDate = orderDate.toLocaleDateString('en-GB');
  const formattedTime = orderDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const items = order.items || [];
  const totalUnits = items.reduce((acc, it) => acc + Number(it.quantity || 1), 0);
  const totalMrp = items.reduce(
    (acc, it) => acc + (Number(it.mrp) || Number(it.unitPrice) || 0) * Number(it.quantity || 1),
    0
  );
  const totalSavings = Math.max(0, totalMrp - Number(order.subtotal || 0));

  const payments = (order.payments || (order as any).tenders || []) as any[];

  return (
    <div
      className="thermal-receipt-ticket"
      style={{
        width: '100%',
        maxWidth: '76mm',
        margin: '0 auto',
        padding: '0 1mm',
        color: '#000000',
        backgroundColor: '#ffffff',
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        fontSize: '11px',
        lineHeight: 1.3,
        boxSizing: 'border-box',
      }}
    >
      {/* DUPLICATE BANNER */}
      {isDuplicate && (
        <div
          style={{
            textAlign: 'center',
            fontWeight: 800,
            fontSize: '11px',
            padding: '2px 0 4px 0',
            borderBottom: '1px dashed #000',
            marginBottom: '4px',
            letterSpacing: '1px',
          }}
        >
          *** DUPLICATE RECEIPT COPY ***
        </div>
      )}

      {/* KIOSK TOKEN BANNER */}
      {isKiosk && (
        <div
          style={{
            border: '2px solid #000',
            borderRadius: '4px',
            padding: '4px',
            margin: '4px 0',
            textAlign: 'center',
            backgroundColor: '#f5f5f5',
          }}
        >
          <div style={{ fontSize: '10px', fontWeight: 800, textTransform: 'uppercase' }}>
            SELF-SERVICE KIOSK TOKEN
          </div>
          <div style={{ fontSize: '16px', fontWeight: 900, letterSpacing: '1px' }}>
            TOKEN #{order.orderNumber.slice(-4)}
          </div>
          <div style={{ fontSize: '9px', marginTop: '2px' }}>
            Please present this receipt at the counter to collect items.
          </div>
        </div>
      )}

      {/* OUTLET / STORE HEADER */}
      <div
        style={{
          textAlign: 'center',
          paddingBottom: '6px',
          borderBottom: '1px dashed #444',
        }}
      >
        <div
          style={{
            fontSize: '15px',
            fontWeight: 900,
            letterSpacing: '-0.3px',
            textTransform: 'uppercase',
            marginBottom: '2px',
          }}
        >
          {outletName}
        </div>
        {branchName && (
          <div style={{ fontSize: '10.5px', fontWeight: 700, color: '#333' }}>
            {branchName}
          </div>
        )}
        <div style={{ fontSize: '10px', color: '#333', marginTop: '1px' }}>{address}</div>
        <div style={{ fontSize: '10px', color: '#333' }}>
          Ph: {phone} {email ? `• ${email}` : ''}
        </div>
        {(outletProfile?.gstin || outletProfile?.panNumber) && (
          <div style={{ fontSize: '9.5px', color: '#333', marginTop: '1px' }}>
            {outletProfile.gstin && (
              <span>
                GSTIN: <b>{outletProfile.gstin}</b>{' '}
              </span>
            )}
            {outletProfile.panNumber && (
              <span>
                PAN: <b>{outletProfile.panNumber}</b>
              </span>
            )}
          </div>
        )}
        {outletProfile?.fssaiLicense && (
          <div style={{ fontSize: '9.5px', color: '#333' }}>
            FSSAI: <b>{outletProfile.fssaiLicense}</b>
          </div>
        )}
        {outletProfile?.receiptHeaderNote && (
          <div
            style={{
              fontSize: '9px',
              fontStyle: 'italic',
              color: '#555',
              marginTop: '2px',
              paddingTop: '2px',
              borderTop: '1px dotted #ccc',
            }}
          >
            {outletProfile.receiptHeaderNote}
          </div>
        )}
      </div>

      {/* BILL META */}
      <div
        style={{
          padding: '5px 0',
          borderBottom: '1px dashed #444',
          fontSize: '10.5px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>
            {t.billNo}: <b style={{ fontWeight: 800 }}>{order.orderNumber}</b>
          </span>
          <span>
            {t.cashier}: {order.cashierName?.split(' ')[0] || 'Alex'}
          </span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', color: '#444' }}>
          <span>
            {t.date}: {formattedDate}
          </span>
          <span>
            {t.time}: {formattedTime}
          </span>
        </div>
        {order.customerName && (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 700,
              fontSize: '10px',
              paddingTop: '2px',
            }}
          >
            <span>
              {t.customer}: {order.customerName}
            </span>
            {order.customerPhone && <span>{order.customerPhone}</span>}
          </div>
        )}
      </div>

      {/* LINE ITEMS TABLE (FIXED WIDTH TO PREVENT OVERLAP) */}
      <div style={{ padding: '4px 0', borderBottom: '1px dashed #444' }}>
        <table
          style={{
            width: '100%',
            tableLayout: 'fixed',
            borderCollapse: 'collapse',
            fontSize: '10.5px',
          }}
        >
          <thead>
            <tr
              style={{
                borderBottom: '1px dashed #666',
                fontWeight: 800,
                fontSize: '9.5px',
                textTransform: 'uppercase',
                color: '#333',
              }}
            >
              <th style={{ width: '44%', textAlign: 'left', padding: '2px 0' }}>
                {t.itemDescription || 'ITEM'}
              </th>
              <th style={{ width: '16%', textAlign: 'center', padding: '2px 0' }}>
                {t.qty || 'QTY'}
              </th>
              <th style={{ width: '20%', textAlign: 'right', padding: '2px 0' }}>
                {t.rate || 'RATE'}
              </th>
              <th style={{ width: '20%', textAlign: 'right', padding: '2px 0' }}>
                {t.amount || 'AMT'}
              </th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => {
              const localizedName = getProductLocalizedName(
                item.productName || (item as any).name || 'Item',
                receiptLang
              );
              const unitPrice = Number(item.unitPrice || 0);
              const qty = Number(item.quantity || 1);
              const rowAmt = unitPrice * qty;

              return (
                <tr key={idx} style={{ verticalAlign: 'top' }}>
                  <td
                    style={{
                      width: '44%',
                      textAlign: 'left',
                      padding: '2.5px 2px 2.5px 0',
                      wordBreak: 'break-word',
                    }}
                  >
                    <div style={{ fontWeight: 600, color: '#000' }}>{localizedName}</div>
                    {item.packSize && (
                      <div style={{ fontSize: '9px', color: '#555' }}>
                        {t.pack || 'Pack'}: {item.packSize}
                      </div>
                    )}
                  </td>
                  <td
                    style={{
                      width: '16%',
                      textAlign: 'center',
                      padding: '2.5px 0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {qty % 1 === 0 ? qty.toFixed(0) : qty.toFixed(2)}
                  </td>
                  <td
                    style={{
                      width: '20%',
                      textAlign: 'right',
                      padding: '2.5px 0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {currency} {unitPrice.toFixed(unitPrice % 1 === 0 ? 0 : 2)}
                  </td>
                  <td
                    style={{
                      width: '20%',
                      textAlign: 'right',
                      fontWeight: 700,
                      padding: '2.5px 0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {currency} {rowAmt.toFixed(2)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* TOTALS & TAX */}
      <div
        style={{
          padding: '5px 0',
          borderBottom: '1px dashed #444',
          fontSize: '10.5px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '1px 0' }}>
          <span>
            {t.itemsTotal || 'Subtotal'} ({totalUnits} {t.units || 'units'}):
          </span>
          <span style={{ fontWeight: 700 }}>
            {currency} {Number(order.subtotal || 0).toFixed(2)}
          </span>
        </div>

        {order.taxAmount && Number(order.taxAmount) > 0 ? (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              color: '#333',
              padding: '1px 0',
            }}
          >
            <span>
              {t.gstSummary || 'CGST + SGST'} ({(Number(order.taxRate || 0.05) * 100).toFixed(0)}%):
            </span>
            <span>
              {currency} {Number(order.taxAmount).toFixed(2)}
            </span>
          </div>
        ) : null}

        {order.loyaltyDiscountAmount && Number(order.loyaltyDiscountAmount) > 0 ? (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 700,
              padding: '1px 0',
            }}
          >
            <span>
              {t.loyaltyDiscount || 'Points Discount'} ({order.loyaltyPointsRedeemed || 0} pts):
            </span>
            <span>
              - {currency} {Number(order.loyaltyDiscountAmount).toFixed(2)}
            </span>
          </div>
        ) : null}

        {totalSavings > 0 && (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 800,
              padding: '1px 0',
            }}
          >
            <span>{t.youSaved || 'You Saved'}:</span>
            <span>
              {currency} {totalSavings.toFixed(2)}
            </span>
          </div>
        )}

        {/* GRAND TOTAL */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: '13.5px',
            fontWeight: 900,
            padding: '5px 0 2px 0',
            marginTop: '3px',
            borderTop: '1px solid #444',
          }}
        >
          <span>{t.grandTotal || 'GRAND TOTAL'}:</span>
          <span>
            {currency} {Number(order.total || 0).toFixed(2)}
          </span>
        </div>
      </div>

      {/* PAYMENT TENDER BREAKDOWN */}
      <div
        style={{
          padding: '4px 0',
          borderBottom: '1px dashed #444',
          fontSize: '10px',
        }}
      >
        <div style={{ fontWeight: 800, textTransform: 'uppercase', color: '#444' }}>
          {t.paymentBreakdown || 'Payment Breakdown'}:
        </div>
        {payments.map((p, pIdx) => {
          const tenderLabel =
            TENDER_NAME_LOCALIZED[p.tenderType || p.type]?.[receiptLang] ||
            (p.tenderType || p.type || 'CASH').toUpperCase();
          return (
            <div
              key={pIdx}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                padding: '1px 0',
              }}
            >
              <span>• {tenderLabel} ({p.reference || 'Paid'}):</span>
              <span style={{ fontWeight: 700 }}>
                {currency} {Number(p.amount || 0).toFixed(2)}
              </span>
            </div>
          );
        })}
        {Number(order.changeDue || 0) > 0 && (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 800,
              padding: '1px 0',
            }}
          >
            <span>{t.changeReturned || 'Change Returned'}:</span>
            <span>
              {currency} {Number(order.changeDue).toFixed(2)}
            </span>
          </div>
        )}
      </div>

      {/* CUSTOMER LOYALTY (IF APPLICABLE) */}
      {customer && (customer.isLoyaltyMember ?? true) && loyaltyConfig?.enabled && (
        <div
          style={{
            padding: '4px',
            borderBottom: '1px dashed #444',
            fontSize: '9.5px',
            backgroundColor: '#fbfbfb',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800 }}>
            <span>{t.loyaltyHeader || 'Loyalty Rewards'}</span>
            <span>{customer.memberTier || 'Member'}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>{t.pointsEarned || 'Points Earned'}:</span>
            <span style={{ fontWeight: 700 }}>
              +{order.loyaltyPointsEarned || Math.floor(Number(order.total || 0) / 100)} pts
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 800,
              borderTop: '1px dotted #ccc',
              marginTop: '2px',
              paddingTop: '2px',
            }}
          >
            <span>{t.availableBalance || 'Available Balance'}:</span>
            <span>{customer.loyaltyPoints} pts</span>
          </div>
        </div>
      )}

      {/* FOOTER & RETURN TERMS */}
      <div
        style={{
          paddingTop: '6px',
          textAlign: 'center',
          fontSize: '9.5px',
          color: '#333',
        }}
      >
        <div style={{ fontWeight: 800, fontSize: '10.5px', color: '#000' }}>
          {outletProfile?.receiptFooterNote ||
            printerConfig?.footerText ||
            t.footerDefault ||
            'Thank you for shopping with us! Visit again.'}
        </div>
        {outletProfile?.returnTerms && (
          <div
            style={{
              fontSize: '8.5px',
              color: '#555',
              marginTop: '3px',
              padding: '2px 4px',
              backgroundColor: '#f9f9f9',
              border: '1px solid #ddd',
              borderRadius: '2px',
            }}
          >
            <b>{t.termsHeader || 'Terms'}:</b> {outletProfile.returnTerms}
          </div>
        )}
        <div style={{ fontSize: '8.5px', color: '#666', marginTop: '4px' }}>
          {t.softwareTag || '*** Plannest POS Retail Enterprise ***'}
        </div>

        {/* FEED SPACING AT BOTTOM SO TEAR BAR DOES NOT CUT CONTENT */}
        <div style={{ height: '24px' }} />
      </div>
    </div>
  );
};
