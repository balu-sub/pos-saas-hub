import React from 'react';
import { RECEIPT_LOCALIZED_LABELS, TENDER_NAME_LOCALIZED } from '../../locales/receiptTranslations';
import { getProductLocalizedName } from '../../locales/productTranslations';
import { LanguageCode } from '../../locales/en';
import { Order } from '../../types/pos';

interface ThermalReceiptTicketProps {
  order: Order;
  outletProfile?: any;
  printerConfig?: any;
  receiptLang: LanguageCode;
  isDuplicate?: boolean;
  isKiosk?: boolean;
  customer?: any;
  loyaltyConfig?: any;
}

export const ThermalReceiptTicket: React.FC<ThermalReceiptTicketProps> = ({
  order,
  outletProfile,
  printerConfig,
  receiptLang,
  isDuplicate = false,
  isKiosk = false,
  customer,
  loyaltyConfig,
}) => {
  const t = RECEIPT_LOCALIZED_LABELS[receiptLang] || RECEIPT_LOCALIZED_LABELS.en;
  const currency = outletProfile?.currencySymbol || 'Rs.';

  const outletName =
    outletProfile?.outletName?.trim() ||
    printerConfig?.headerText?.trim() ||
    'AMMA & APPA KADAI';

  const branchName = outletProfile?.branchName?.trim();
  const address =
    [
      outletProfile?.addressLine1,
      outletProfile?.addressLine2,
      outletProfile?.city,
      outletProfile?.state,
      outletProfile?.pincode,
    ]
      .filter(Boolean)
      .join(', ') || 'Shop #12, Market Complex, Chennai';

  const phone = outletProfile?.phone || '+91 98200 12345';
  const email = outletProfile?.email;

  const orderDate = new Date(order.createdAt || Date.now());
  const formattedDate = orderDate.toLocaleDateString('en-GB');
  const formattedTime = orderDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const items = order.items || [];
  const totalMrp = items.reduce(
    (acc, it) => acc + (Number(it.mrp) || Number(it.unitPrice) || 0) * Number(it.quantity || 1),
    0
  );
  const totalSavings = Math.max(0, totalMrp - Number(order.subtotal || 0));

  const payments = (order.payments || (order as any).tenders || []) as any[];

  return (
    <div
      className="thermal-receipt-ticket font-mono text-xs text-black select-none"
      style={{
        width: '100%',
        maxWidth: '76mm',
        margin: '0 auto',
        padding: '0 1mm',
        color: '#000000',
        backgroundColor: '#fffdfa',
        fontFamily:
          'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
        fontSize: '11px',
        lineHeight: 1.25,
        boxSizing: 'border-box',
      }}
    >
      {/* DUPLICATE BANNER */}
      {isDuplicate && (
        <div
          style={{
            textAlign: 'center',
            fontWeight: 800,
            fontSize: '11px',
            padding: '2px 0 4px 0',
            borderBottom: '1px dashed #666',
            marginBottom: '4px',
            letterSpacing: '1px',
          }}
        >
          *** DUPLICATE RECEIPT COPY ***
        </div>
      )}

      {/* KIOSK TOKEN BANNER */}
      {isKiosk && (
        <div
          style={{
            border: '2px solid #000',
            borderRadius: '4px',
            padding: '4px',
            margin: '4px 0',
            textAlign: 'center',
            backgroundColor: '#f5f5f5',
          }}
        >
          <div style={{ fontSize: '10px', fontWeight: 800, textTransform: 'uppercase' }}>
            SELF-SERVICE KIOSK TOKEN
          </div>
          <div style={{ fontSize: '16px', fontWeight: 900, letterSpacing: '1px' }}>
            TOKEN #{order.orderNumber.slice(-4)}
          </div>
          <div style={{ fontSize: '9px', marginTop: '2px' }}>
            Please present this receipt at the counter to collect items.
          </div>
        </div>
      )}

      {/* OUTLET / STORE HEADER (Identical to Admin Hub Live Preview) */}
      <div
        className="text-center pb-2.5 border-b border-dashed border-gray-400 space-y-0.5"
        style={{ textAlign: 'center', paddingBottom: '6px', borderBottom: '1px dashed #666' }}
      >
        <div
          className="font-extrabold text-sm tracking-tight text-black font-sans uppercase"
          style={{
            fontFamily:
              '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
            fontSize: '14px',
            fontWeight: 900,
            letterSpacing: '-0.2px',
            textTransform: 'uppercase',
            color: '#000',
          }}
        >
          {outletName}
        </div>
        {branchName && (
          <div style={{ fontSize: '10px', fontWeight: 700, color: '#333' }}>
            {branchName}
          </div>
        )}
        <div style={{ fontSize: '9.5px', color: '#444', lineHeight: 1.2 }}>{address}</div>
        <div style={{ fontSize: '9.5px', color: '#444' }}>
          Ph: {phone} {email ? `• ${email}` : ''}
        </div>
        {(outletProfile?.gstin || outletProfile?.panNumber) && (
          <div style={{ fontSize: '9.5px', color: '#444', marginTop: '1px' }}>
            {outletProfile.gstin && (
              <span>
                GSTIN: <b>{outletProfile.gstin}</b>{' '}
              </span>
            )}
            {outletProfile.panNumber && (
              <span>
                PAN: <b>{outletProfile.panNumber}</b>
              </span>
            )}
          </div>
        )}
        {outletProfile?.fssaiLicense && (
          <div style={{ fontSize: '9.5px', color: '#444' }}>
            FSSAI: <b>{outletProfile.fssaiLicense}</b>
          </div>
        )}
        {outletProfile?.receiptHeaderNote && (
          <div
            style={{
              fontSize: '8.5px',
              fontStyle: 'italic',
              color: '#666',
              marginTop: '2px',
              paddingTop: '2px',
              borderTop: '1px dotted #ccc',
            }}
          >
            {outletProfile.receiptHeaderNote}
          </div>
        )}
      </div>

      {/* BILL META (Identical to Admin Hub Live Preview) */}
      <div
        style={{
          padding: '5px 0',
          borderBottom: '1px dashed #666',
          fontSize: '10px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>
            {t.billNo || 'Bill No'}: <b style={{ fontWeight: 800 }}>{order.orderNumber}</b>
          </span>
          <span>
            {t.cashier || 'Cashier'}: {order.cashierName?.split(' ')[0] || 'Alex'}
          </span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', color: '#444', marginTop: '1px' }}>
          <span>
            {t.date || 'Date'}: {formattedDate}
          </span>
          <span>
            {t.time || 'Time'}: {formattedTime}
          </span>
        </div>
        {order.customerName && (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 700,
              fontSize: '9.5px',
              paddingTop: '2px',
            }}
          >
            <span>
              {t.customer || 'Customer'}: {order.customerName}
            </span>
            {order.customerPhone && <span>{order.customerPhone}</span>}
          </div>
        )}
      </div>

      {/* LINE ITEMS TABLE (Headers: ITEM, QTY, RATE, AMT) */}
      <div style={{ padding: '4px 0', borderBottom: '1px dashed #666' }}>
        <table
          style={{
            width: '100%',
            tableLayout: 'fixed',
            borderCollapse: 'collapse',
            fontSize: '10px',
          }}
        >
          <thead>
            <tr
              style={{
                borderBottom: '1px solid #ccc',
                fontWeight: 800,
                fontSize: '9px',
                textTransform: 'uppercase',
                color: '#555',
              }}
            >
              <th style={{ width: '44%', textAlign: 'left', padding: '2px 0' }}>ITEM</th>
              <th style={{ width: '16%', textAlign: 'center', padding: '2px 0' }}>QTY</th>
              <th style={{ width: '20%', textAlign: 'right', padding: '2px 0' }}>RATE</th>
              <th style={{ width: '20%', textAlign: 'right', padding: '2px 0' }}>AMT</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => {
              const localizedName = getProductLocalizedName(
                item.productName || (item as any).name || 'Item',
                receiptLang
              );
              const unitPrice = Number(item.unitPrice || 0);
              const qty = Number(item.quantity || 1);
              const rowAmt = unitPrice * qty;

              return (
                <tr key={idx} style={{ verticalAlign: 'top' }}>
                  <td
                    style={{
                      width: '44%',
                      textAlign: 'left',
                      padding: '2px 2px 2px 0',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    <span style={{ fontWeight: 600 }}>{localizedName}</span>
                  </td>
                  <td
                    style={{
                      width: '16%',
                      textAlign: 'center',
                      padding: '2px 0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {qty.toFixed(qty % 1 === 0 ? 2 : 2)}
                  </td>
                  <td
                    style={{
                      width: '20%',
                      textAlign: 'right',
                      padding: '2px 0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {currency}{unitPrice.toFixed(0)}
                  </td>
                  <td
                    style={{
                      width: '20%',
                      textAlign: 'right',
                      fontWeight: 700,
                      padding: '2px 0',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {currency}{rowAmt.toFixed(2)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* SUBTOTAL, TAX, SAVINGS, AND GRAND TOTAL (Identical to Admin Hub Live Preview) */}
      <div
        style={{
          padding: '5px 0',
          borderBottom: '1px dashed #666',
          fontSize: '10px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '1px 0' }}>
          <span>Subtotal:</span>
          <span style={{ fontWeight: 700 }}>
            {currency} {Number(order.subtotal || 0).toFixed(2)}
          </span>
        </div>

        {order.taxAmount && Number(order.taxAmount) > 0 ? (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              color: '#444',
              padding: '1px 0',
            }}
          >
            <span>
              CGST + SGST ({(Number(order.taxRate || 0.05) * 100).toFixed(0)}%):
            </span>
            <span>
              {currency} {Number(order.taxAmount).toFixed(2)}
            </span>
          </div>
        ) : null}

        {order.loyaltyDiscountAmount && Number(order.loyaltyDiscountAmount) > 0 ? (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 700,
              padding: '1px 0',
            }}
          >
            <span>
              Points Discount ({order.loyaltyPointsRedeemed || 0} pts):
            </span>
            <span>
              - {currency} {Number(order.loyaltyDiscountAmount).toFixed(2)}
            </span>
          </div>
        ) : null}

        {totalSavings > 0 && (
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 700,
              padding: '1px 0',
            }}
          >
            <span>You Saved on MRP:</span>
            <span>
              {currency} {totalSavings.toFixed(2)}
            </span>
          </div>
        )}

        {/* GRAND TOTAL */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontFamily:
              '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
            fontSize: '13.5px',
            fontWeight: 900,
            padding: '4px 0 1px 0',
            marginTop: '3px',
            borderTop: '1px solid #444',
          }}
        >
          <span>GRAND TOTAL:</span>
          <span>
            {currency} {Number(order.total || 0).toFixed(2)}
          </span>
        </div>
      </div>

      {/* PAYMENT TENDER BREAKDOWN */}
      {payments.length > 0 && (
        <div
          style={{
            padding: '4px 0',
            borderBottom: '1px dashed #666',
            fontSize: '9.5px',
          }}
        >
          <div style={{ fontWeight: 800, textTransform: 'uppercase', color: '#555' }}>
            PAYMENT BREAKDOWN:
          </div>
          {payments.map((p, pIdx) => {
            const tenderLabel =
              TENDER_NAME_LOCALIZED[p.tenderType || p.type]?.[receiptLang] ||
              (p.tenderType || p.type || 'CASH').toUpperCase();
            return (
              <div
                key={pIdx}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '1px 0',
                }}
              >
                <span>• {tenderLabel} ({p.reference || 'Paid'}):</span>
                <span style={{ fontWeight: 700 }}>
                  {currency} {Number(p.amount || 0).toFixed(2)}
                </span>
              </div>
            );
          })}
          {Number(order.changeDue || 0) > 0 && (
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                fontWeight: 800,
                padding: '1px 0',
              }}
            >
              <span>Change Returned:</span>
              <span>
                {currency} {Number(order.changeDue).toFixed(2)}
              </span>
            </div>
          )}
        </div>
      )}

      {/* CUSTOMER LOYALTY (IF APPLICABLE) */}
      {customer && (customer.isLoyaltyMember ?? true) && loyaltyConfig?.enabled && (
        <div
          style={{
            padding: '4px',
            borderBottom: '1px dashed #666',
            fontSize: '9px',
            backgroundColor: '#fbfbfb',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800 }}>
            <span>Loyalty Rewards</span>
            <span>{customer.memberTier || 'Member'}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Points Earned:</span>
            <span style={{ fontWeight: 700 }}>
              +{order.loyaltyPointsEarned || Math.floor(Number(order.total || 0) / 100)} pts
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontWeight: 800,
              borderTop: '1px dotted #ccc',
              marginTop: '2px',
              paddingTop: '2px',
            }}
          >
            <span>Available Balance:</span>
            <span>{customer.loyaltyPoints} pts</span>
          </div>
        </div>
      )}

      {/* FOOTER & RETURN TERMS (Identical to Admin Hub Live Preview) */}
      <div
        style={{
          paddingTop: '6px',
          textAlign: 'center',
          fontSize: '9.5px',
          color: '#444',
          fontFamily:
            '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        }}
      >
        <div style={{ fontWeight: 800, fontSize: '10px', color: '#000' }}>
          {outletProfile?.receiptFooterNote ||
            printerConfig?.footerText ||
            'Thank you for shopping with us! Visit again.'}
        </div>
        {outletProfile?.returnTerms && (
          <div
            style={{
              fontSize: '8px',
              color: '#555',
              marginTop: '3px',
              padding: '2px 4px',
              backgroundColor: '#f9f9f9',
              border: '1px solid #ddd',
              borderRadius: '2px',
              lineHeight: 1.2,
            }}
          >
            <b>Terms:</b> {outletProfile.returnTerms}
          </div>
        )}
        <div style={{ fontSize: '8.5px', color: '#888', marginTop: '3px' }}>
          *** Software: Plannest POS Retail Enterprise ***
        </div>

        {/* FEED SPACING AT BOTTOM SO TEAR BAR DOES NOT CUT CONTENT */}
        <div style={{ height: '24px' }} />
      </div>
    </div>
  );
};
