import React, { useState, useEffect } from 'react';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../locales/en';
import { RECEIPT_LOCALIZED_LABELS, TENDER_NAME_LOCALIZED } from '../../locales/receiptTranslations';
import { getProductLocalizedName } from '../../locales/productTranslations';
import { playSuccessChime } from '../../utils/audio';

export const ReceiptModal: React.FC = () => {
  const { isReceiptOpen, setIsReceiptOpen, lastCompletedOrder, outletProfile, customers, loyaltyConfig, currentOperator } = usePOS();
  const { printerConfig } = usePeripherals();
  const { language: headerLanguage, setLanguage: setHeaderLanguage } = useLanguage();
  
  const isKiosk = currentOperator?.userRole === 'Customer Kiosk';
  
  // Local receipt language state initialized with header language
  const [receiptLang, setReceiptLang] = useState<LanguageCode>(headerLanguage);
  const [printStatus, setPrintStatus] = useState<'idle' | 'printed'>('idle');
  const [canDismissOnBackdrop, setCanDismissOnBackdrop] = useState(false);

  // Sync with header language when receipt modal opens
  useEffect(() => {
    if (isReceiptOpen) {
      setReceiptLang(headerLanguage);
      setPrintStatus('idle');
      // Delay backdrop clicks by 400ms to prevent accidental click-through from checkout button
      const timer = setTimeout(() => {
        setCanDismissOnBackdrop(true);
      }, 400);
      return () => clearTimeout(timer);
    } else {
      setCanDismissOnBackdrop(false);
    }
  }, [isReceiptOpen, headerLanguage]);

  if (!isReceiptOpen || !lastCompletedOrder) return null;

  const order = lastCompletedOrder;
  const customer = order.customerId ? customers.find((c) => c.id === order.customerId) : null;
  const totalMrp = order.items.reduce((acc, it) => acc + (it.mrp || it.unitPrice) * it.quantity, 0);
  const totalSavings = Math.max(0, totalMrp - order.subtotal);
  const t = RECEIPT_LOCALIZED_LABELS[receiptLang] || RECEIPT_LOCALIZED_LABELS.en;

  const handlePrint = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    playSuccessChime();
    setPrintStatus('printed');
    try {
      if (typeof window !== 'undefined' && window.print) {
        window.print();
      }
    } catch (err) {
      console.warn('System print blocked or unavailable in iframe:', err);
    }
  };

  const handleClose = () => {
    setPrintStatus('idle');
    setIsReceiptOpen(false);
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget && canDismissOnBackdrop) {
      handleClose();
    }
  };

  const currency = outletProfile?.currencySymbol || 'Rs.';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 select-none"
      onClick={handleBackdropClick}
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs pointer-events-none"
      />

      {/* Receipt Modal Card */}
      <div
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
        className={`relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full ${printerConfig.printerType === 'ESC_POS_58MM' ? 'max-w-sm' : 'max-w-md'} shadow-2xl p-4 sm:p-5 flex flex-col max-h-[94vh] overflow-hidden industrial-shadow animate-in fade-in zoom-in-95`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-[#D4D4D8]">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00478c]">receipt_long</span>
            <div>
              <h3 className="font-bold text-base text-[#09090B] leading-tight">
                {isKiosk ? 'Self-Service Kiosk Receipt & Token' : 'Receipt Preview & Print'}
              </h3>
              <p className="text-[11px] text-[#5c403c]">Bill #{order.orderNumber} • {order.items.length} items</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 p-1 cursor-pointer"
            title="Close receipt preview"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Kiosk Customer Pickup Instruction Banner */}
        {isKiosk && (
          <div className="my-2 p-3 bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-400 rounded-xl text-center shadow-xs">
            <div className="flex items-center justify-center gap-1.5 text-amber-950 font-black text-xs uppercase tracking-wide">
              <span className="material-symbols-outlined text-[18px] text-amber-600">storefront</span>
              <span>SELF-SERVICE KIOSK ORDER • TOKEN #{order.orderNumber.slice(-4)}</span>
            </div>
            <p className="text-[11px] font-bold text-amber-900 mt-1">
              Please take this printed receipt to the counter for collecting your items or show at the gate.
            </p>
          </div>
        )}

        {/* Language Selection & Print Confirmation Bar */}
        <div className="my-2 p-2 bg-blue-50/80 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs text-blue-900">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#00478c] text-[16px]">translate</span>
            <span className="text-[11px] font-bold text-gray-800">Print Language:</span>
            <div className="flex items-center bg-white border border-blue-300 rounded p-0.5 shadow-2xs">
              <button
                type="button"
                onClick={() => setReceiptLang('en')}
                className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                  receiptLang === 'en' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setReceiptLang('ta')}
                className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                  receiptLang === 'ta' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                தமிழ்
              </button>
              <button
                type="button"
                onClick={() => setReceiptLang('hi')}
                className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                  receiptLang === 'hi' ? 'bg-[#00478c] text-white' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                हिन्दी
              </button>
            </div>
          </div>
          {printStatus === 'printed' ? (
            <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-[10px] font-bold rounded-full flex items-center gap-1">
              <span className="material-symbols-outlined text-[13px]">done</span> Printed
            </span>
          ) : (
            <span className="text-[10px] text-blue-700 font-medium">Ready to print</span>
          )}
        </div>

        {/* Scrollable Printable Thermal Receipt Container */}
        <div className="printable-thermal-receipt flex-1 overflow-y-auto my-1 p-4 bg-[#fffdfa] border border-[#e5e5e5] rounded shadow-inner font-mono text-xs text-black leading-tight select-text">
          {/* Outlet Header */}
          <div className="text-center pb-3 border-b border-dashed border-gray-400 space-y-0.5">
            <div className="font-extrabold text-sm tracking-tight text-black font-sans uppercase">
              {outletProfile?.outletName || printerConfig.headerText || 'AMMA & APPA KADAI'}
            </div>
            {isKiosk && (
              <div className="my-1.5 p-1.5 border border-black bg-gray-100 text-center">
                <div className="text-[10px] font-black uppercase tracking-wider">SELF-SERVICE KIOSK TOKEN</div>
                <div className="text-base font-black tracking-tight">TOKEN #{order.orderNumber.slice(-4)}</div>
                <div className="text-[8.5px] font-medium leading-tight mt-0.5">
                  Show this receipt at the counter to collect items or show at the gate.
                </div>
              </div>
            )}
            {outletProfile?.branchName && (
              <div className="text-[10px] font-bold text-gray-800">
                {outletProfile.branchName}
              </div>
            )}
            <div className="text-[10px] text-gray-700">
              {[outletProfile?.addressLine1, outletProfile?.addressLine2, outletProfile?.city, outletProfile?.state, outletProfile?.pincode].filter(Boolean).join(', ') || 'Shop #12, Market Complex, Main Road, Chennai'}
            </div>
            <div className="text-[10px] text-gray-700 flex flex-wrap justify-center gap-x-2">
              {outletProfile?.gstin && <span>GSTIN: <span className="font-bold">{outletProfile.gstin}</span></span>}
              {outletProfile?.panNumber && <span>PAN: <span className="font-bold">{outletProfile.panNumber}</span></span>}
            </div>
            {outletProfile?.fssaiLicense && (
              <div className="text-[10px] text-gray-700">
                FSSAI Lic No: <span className="font-bold">{outletProfile.fssaiLicense}</span>
              </div>
            )}
            <div className="text-[10px] text-gray-700">
              Phone: {outletProfile?.phone || '+91 98200 12345'} {outletProfile?.email ? `• ${outletProfile.email}` : ''}
            </div>
            {outletProfile?.receiptHeaderNote && (
              <div className="text-[9px] italic text-gray-600 pt-1 border-t border-dotted border-gray-300">
                {outletProfile.receiptHeaderNote}
              </div>
            )}
          </div>

          {/* Invoice Meta */}
          <div className="py-2.5 border-b border-dashed border-gray-400 text-[11px] space-y-0.5">
            <div className="flex justify-between">
              <span>{t.billNo}: <span className="font-bold">{order.orderNumber}</span></span>
              <span>{t.cashier}: {order.cashierName?.split(' ')[0] || 'Staff'}</span>
            </div>
            <div className="flex justify-between text-gray-600">
              <span>{t.date}: {new Date(order.createdAt).toLocaleDateString('en-GB')}</span>
              <span>{t.time}: {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            {order.customerName && (
              <div className="flex justify-between text-gray-800 pt-0.5 font-sans font-bold text-[10px]">
                <span>{t.customer}: {order.customerName}</span>
                {order.customerPhone && <span>{order.customerPhone}</span>}
              </div>
            )}
          </div>

          {/* Line Items Table */}
          <div className="py-2.5 border-b border-dashed border-gray-400 space-y-2">
            <div className="flex justify-between font-bold text-[10px] uppercase border-b border-gray-300 pb-1 text-gray-700">
              <span className="w-1/2">{t.itemDescription}</span>
              <span className="w-1/6 text-center">{t.qty}</span>
              <span className="w-1/6 text-right">{t.rate}</span>
              <span className="w-1/6 text-right">{t.amount}</span>
            </div>

            {order.items.map((item, idx) => {
              const localizedName = getProductLocalizedName(item.productName, receiptLang);
              return (
                <div key={idx} className="flex justify-between items-baseline text-[11px]">
                  <div className="w-1/2 truncate pr-1">
                    <div className="font-sans font-medium text-black truncate">{localizedName}</div>
                    {item.packSize && (
                      <div className="text-[9px] text-gray-600">{t.pack}: {item.packSize}</div>
                    )}
                  </div>
                  <div className="w-1/6 text-center">{item.quantity}</div>
                  <div className="w-1/6 text-right font-tabular-numeric">{currency} {item.unitPrice.toFixed(0)}</div>
                  <div className="w-1/6 text-right font-bold font-tabular-numeric">
                    {currency} {(item.unitPrice * item.quantity).toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Totals & Tax Summary */}
          <div className="py-2.5 border-b border-dashed border-gray-400 space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span>{t.itemsTotal} ({order.items.reduce((a, b) => a + b.quantity, 0)} {t.units}):</span>
              <span className="font-bold">{currency} {order.subtotal.toFixed(2)}</span>
            </div>
            {printerConfig.printGstSummary && (
              <div className="flex justify-between text-gray-700">
                <span>{t.gstSummary} ({(order.taxRate * 100).toFixed(0)}%):</span>
                <span>{currency} {order.taxAmount.toFixed(2)}</span>
              </div>
            )}
            {order.loyaltyDiscountAmount && order.loyaltyDiscountAmount > 0 ? (
              <div className="flex justify-between text-blue-800 font-bold bg-blue-50 px-1 py-0.5 rounded text-[10px]">
                <span>{t.loyaltyDiscount} ({order.loyaltyPointsRedeemed || 0} pts):</span>
                <span>- {currency} {order.loyaltyDiscountAmount.toFixed(2)}</span>
              </div>
            ) : null}
            {totalSavings > 0 && (
              <div className="flex justify-between text-emerald-800 font-bold bg-emerald-50 px-1 py-0.5 rounded text-[10px]">
                <span>{t.youSaved}:</span>
                <span>{currency} {totalSavings.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-black pt-1.5 border-t border-gray-400 font-sans">
              <span>{t.grandTotal}:</span>
              <span>{currency} {order.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Payment Tender Details */}
          <div className="py-2 border-b border-dashed border-gray-400 text-[10px] space-y-0.5">
            <div className="font-bold uppercase tracking-wider text-gray-700">{t.paymentBreakdown}:</div>
            {order.payments.map((p, pIdx) => {
              const tenderLabel = TENDER_NAME_LOCALIZED[p.tenderType]?.[receiptLang] || p.tenderType.toUpperCase();
              return (
                <div key={pIdx} className="flex justify-between">
                  <span>• {tenderLabel} ({p.reference || 'Paid'}):</span>
                  <span className="font-bold">{currency} {p.amount.toFixed(2)}</span>
                </div>
              );
            })}
            {order.changeDue > 0 && (
              <div className="flex justify-between text-emerald-800 font-bold">
                <span>{t.changeReturned}:</span>
                <span>{currency} {order.changeDue.toFixed(2)}</span>
              </div>
            )}
          </div>

          {/* Customer Loyalty Program Summary */}
          {customer && (customer.isLoyaltyMember ?? true) && loyaltyConfig.enabled && (
            <div className="py-2 border-b border-dashed border-gray-400 text-[10px] bg-amber-50/70 p-1.5 rounded space-y-0.5">
              <div className="font-bold text-amber-900 flex items-center justify-between">
                <span>{t.loyaltyHeader}</span>
                <span className="text-[9px] bg-amber-200 px-1 rounded font-extrabold">{customer.memberTier || 'Member'}</span>
              </div>
              <div className="flex justify-between text-gray-800">
                <span>{t.pointsEarned}:</span>
                <span className="font-bold text-emerald-700">+{order.loyaltyPointsEarned || Math.floor(order.total / loyaltyConfig.spendAmountPerPoint)} pts</span>
              </div>
              {order.loyaltyPointsRedeemed ? (
                <div className="flex justify-between text-gray-800">
                  <span>{t.pointsRedeemed}:</span>
                  <span className="font-bold text-rose-700">-{order.loyaltyPointsRedeemed} pts</span>
                </div>
              ) : null}
              <div className="flex justify-between text-gray-900 font-bold pt-0.5 border-t border-amber-200">
                <span>{t.availableBalance}:</span>
                <span>{customer.loyaltyPoints} pts ({t.worth} {currency} {(customer.loyaltyPoints * loyaltyConfig.pointRedemptionValue).toFixed(0)})</span>
              </div>
              {customer.loyaltyExpiryDate && (
                <div className="text-[8px] text-gray-500 italic">
                  {t.validityTill}: {customer.loyaltyExpiryDate}
                </div>
              )}
            </div>
          )}

          {/* Footer Note & Return Terms */}
          <div className="pt-2 text-center text-[10px] text-gray-600 font-sans space-y-1">
            <div className="font-bold text-black">
              {outletProfile?.receiptFooterNote || printerConfig.footerText || t.footerDefault}
            </div>
            {outletProfile?.returnTerms && (
              <div className="text-[8.5px] text-gray-500 leading-tight bg-gray-50 p-1 rounded border border-gray-200">
                <span className="font-bold">{t.termsHeader}: </span>{outletProfile.returnTerms}
              </div>
            )}
            <div className="text-[9px] text-gray-500 pt-1">{t.softwareTag}</div>
          </div>
        </div>

        {/* Action Buttons: Explicit Confirmation / Cancel Flow */}
        <div className="flex flex-col sm:flex-row gap-2 pt-3 border-t border-[#D4D4D8]">
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 py-3 bg-[#00478c] hover:bg-[#005eb7] active:bg-[#00366c] text-white rounded-lg font-extrabold text-xs flex items-center justify-center gap-2 industrial-shadow transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">print</span>
            <span>
              {printStatus === 'printed'
                ? 'Print Again'
                : isKiosk
                ? 'Print Kiosk Receipt & Collect Items'
                : 'Confirm & Print Receipt'}
            </span>
          </button>
          <button
            type="button"
            onClick={handleClose}
            className="px-5 py-3 bg-[#F4F4F5] hover:bg-[#E4E4E7] text-[#09090B] border border-[#D4D4D8] rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">
              {isKiosk ? 'done_all' : 'close'}
            </span>
            <span>{isKiosk ? 'Done / Next Customer' : 'Cancel / Next Sale'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

