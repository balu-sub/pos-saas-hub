import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { usePOS } from '../../context/POSContext';
import { usePeripherals } from '../../context/PeripheralContext';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../locales/en';
import { playSuccessChime } from '../../utils/audio';
import { ThermalReceiptTicket } from './ThermalReceiptTicket';

export const ReceiptModal: React.FC = () => {
  const {
    isReceiptOpen,
    setIsReceiptOpen,
    lastCompletedOrder,
    outletProfile,
    customers,
    loyaltyConfig,
    currentOperator,
  } = usePOS();
  const { printerConfig } = usePeripherals();
  const { language: headerLanguage } = useLanguage();

  const isKiosk = currentOperator?.userRole === 'Customer Kiosk';

  // Local receipt language state initialized with header language
  const [receiptLang, setReceiptLang] = useState<LanguageCode>(headerLanguage);
  const [printStatus, setPrintStatus] = useState<'idle' | 'printed'>('idle');
  const [canDismissOnBackdrop, setCanDismissOnBackdrop] = useState(false);

  // Sync with header language when receipt modal opens
  useEffect(() => {
    if (isReceiptOpen) {
      setReceiptLang(headerLanguage);
      setPrintStatus('idle');
      // Delay backdrop clicks by 400ms to prevent accidental click-through from checkout button
      const timer = setTimeout(() => {
        setCanDismissOnBackdrop(true);
      }, 400);
      return () => clearTimeout(timer);
    } else {
      setCanDismissOnBackdrop(false);
    }
  }, [isReceiptOpen, headerLanguage]);

  if (!isReceiptOpen || !lastCompletedOrder) return null;

  const order = lastCompletedOrder;
  const customer = order.customerId ? customers.find((c) => c.id === order.customerId) : null;

  const handlePrint = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    playSuccessChime();
    setPrintStatus('printed');

    // 1. Programmatically sync Windows Default Printer to configured printer
    const targetPrinter = printerConfig.selectedPrinterName || 'RETSOL RTP-80';
    try {
      await fetch('/api/system/printers/set-default', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: targetPrinter }),
      });
    } catch (err) {
      console.warn('Printer default sync note:', err);
    }

    // 2. Trigger silent direct print (handled without preview dialog under --kiosk-printing)
    setTimeout(() => {
      try {
        if (typeof window !== 'undefined' && window.print) {
          window.print();
        }
      } catch (err) {
        console.warn('System print blocked or unavailable:', err);
      }
    }, 60);
  };

  const handleClose = () => {
    setPrintStatus('idle');
    setIsReceiptOpen(false);
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget && canDismissOnBackdrop) {
      handleClose();
    }
  };

  const printPortalNode =
    typeof document !== 'undefined' ? document.getElementById('pos-direct-print-root') : null;

  return (
    <>
      {/* DIRECT PRINT PORTAL: Attached directly to <body>#pos-direct-print-root for zero top margins & unclipped continuous thermal printing */}
      {printPortalNode &&
        createPortal(
          <ThermalReceiptTicket
            order={order}
            outletProfile={outletProfile}
            printerConfig={printerConfig}
            receiptLang={receiptLang}
            isDuplicate={false}
            isKiosk={isKiosk}
            customer={customer}
            loyaltyConfig={loyaltyConfig}
          />,
          printPortalNode
        )}

      {/* ON-SCREEN MODAL PREVIEW FOR CASHIER / KIOSK */}
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 select-none no-print"
        onClick={handleBackdropClick}
      >
        {/* Backdrop */}
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs pointer-events-none" />

        {/* Receipt Modal Card */}
        <div
          onClick={(e) => e.stopPropagation()}
          onMouseDown={(e) => e.stopPropagation()}
          className="relative z-50 bg-white rounded-xl border border-[#D4D4D8] w-full max-w-md shadow-2xl p-4 sm:p-5 flex flex-col max-h-[94vh] overflow-hidden industrial-shadow animate-in fade-in zoom-in-95"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2.5 border-b border-[#D4D4D8]">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#00478c]">receipt_long</span>
              <div>
                <h3 className="font-bold text-base text-[#09090B] leading-tight">
                  {isKiosk ? 'Self-Service Kiosk Receipt & Token' : 'Receipt Preview & Direct Print'}
                </h3>
                <p className="text-[11px] text-[#5c403c]">
                  Bill #{order.orderNumber} • {order.items.length} items
                </p>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600 p-1 cursor-pointer"
              title="Close receipt preview"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>

          {/* Kiosk Customer Pickup Instruction Banner */}
          {isKiosk && (
            <div className="my-2 p-3 bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-400 rounded-xl text-center shadow-xs">
              <div className="flex items-center justify-center gap-1.5 text-amber-950 font-black text-xs uppercase tracking-wide">
                <span className="material-symbols-outlined text-[18px] text-amber-600">
                  storefront
                </span>
                <span>SELF-SERVICE KIOSK ORDER • TOKEN #{order.orderNumber.slice(-4)}</span>
              </div>
              <p className="text-[11px] font-bold text-amber-900 mt-1">
                Please take this printed receipt to the counter for collecting your items.
              </p>
            </div>
          )}

          {/* Language Selection & Ready Indicator Bar */}
          <div className="my-2 p-2 bg-blue-50/80 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs text-blue-900">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#00478c] text-[16px]">translate</span>
              <span className="text-[11px] font-bold text-gray-800">Print Language:</span>
              <div className="flex items-center bg-white border border-blue-300 rounded p-0.5 shadow-2xs">
                <button
                  type="button"
                  onClick={() => setReceiptLang('en')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                    receiptLang === 'en'
                      ? 'bg-[#00478c] text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => setReceiptLang('ta')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                    receiptLang === 'ta'
                      ? 'bg-[#00478c] text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  தமிழ்
                </button>
                <button
                  type="button"
                  onClick={() => setReceiptLang('hi')}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold cursor-pointer transition-colors ${
                    receiptLang === 'hi'
                      ? 'bg-[#00478c] text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  हिन्दी
                </button>
              </div>
            </div>
            {printStatus === 'printed' ? (
              <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-[10px] font-bold rounded-full flex items-center gap-1">
                <span className="material-symbols-outlined text-[13px]">done</span> Printed
              </span>
            ) : (
              <span className="text-[10px] text-blue-700 font-semibold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Direct to {printerConfig.selectedPrinterName || 'RETSOL RTP-80'}
              </span>
            )}
          </div>

          {/* Scrollable Receipt Preview (Matches live bill preview) */}
          <div className="flex-1 overflow-y-auto my-1 p-3 bg-[#fffdfa] border border-[#e5e5e5] rounded shadow-inner select-text">
            <ThermalReceiptTicket
              order={order}
              outletProfile={outletProfile}
              printerConfig={printerConfig}
              receiptLang={receiptLang}
              isDuplicate={false}
              isKiosk={isKiosk}
              customer={customer}
              loyaltyConfig={loyaltyConfig}
            />
          </div>

          {/* Action Buttons: Confirm & Print / Done */}
          <div className="flex flex-col sm:flex-row gap-2 pt-3 border-t border-[#D4D4D8]">
            <button
              type="button"
              onClick={handlePrint}
              className="flex-1 py-3 bg-[#00478c] hover:bg-[#005eb7] active:bg-[#00366c] text-white rounded-lg font-extrabold text-xs flex items-center justify-center gap-2 industrial-shadow transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">print</span>
              <span>
                {printStatus === 'printed'
                  ? 'Print Again'
                  : isKiosk
                  ? 'Print Kiosk Receipt & Collect Items'
                  : 'Confirm & Print Receipt'}
              </span>
            </button>
            <button
              type="button"
              onClick={handleClose}
              className="px-5 py-3 bg-[#F4F4F5] hover:bg-[#E4E4E7] text-[#09090B] border border-[#D4D4D8] rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">
                {isKiosk ? 'done_all' : 'close'}
              </span>
              <span>{isKiosk ? 'Done / Next Customer' : 'Cancel / Next Sale'}</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
