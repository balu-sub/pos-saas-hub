export const APP_VERSION = '1.2.5';
export const UPDATE_CHECK_URL = 'https://pospro.plannestapp.com/version.json';
