export const APP_VERSION = '1.1.5';
export const UPDATE_CHECK_URL = 'https://pos.plannestapp.com/version.json';
