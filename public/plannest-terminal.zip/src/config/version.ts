export const APP_VERSION = '1.0.3';
export const UPDATE_CHECK_URL = 'https://pos.plannestapp.com/version.json';
