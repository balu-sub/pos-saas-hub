export const APP_VERSION = '1.1.4';
export const UPDATE_CHECK_URL = 'https://pos.plannestapp.com/version.json';
