import React, { createContext, useContext, useState, ReactNode } from 'react';
import { LanguageCode, LanguageOption, AVAILABLE_LANGUAGES, enTranslations } from '../locales/en';
import { taTranslations } from '../locales/ta';
import { hiTranslations } from '../locales/hi';
import {
  getProductLocalizedName,
  getCategoryLocalizedName,
  getOfferLocalizedTitle
} from '../locales/productTranslations';
import { Product } from '../types/pos';

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  availableLanguages: LanguageOption[];
  isTamil: boolean;
  isHindi: boolean;
  isSecondaryLanguage: boolean;
  getItemName: (productOrName: Product | string) => string;
  getCategoryName: (category: string) => string;
  getOfferTitle: (title?: string) => string;
  t: (key: string, fallback?: string) => string;
}

const STORAGE_KEY = 'alfa_pos_language_preference';

const translationsMap: Record<LanguageCode, Record<string, string>> = {
  en: enTranslations,
  ta: taTranslations,
  hi: hiTranslations,
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'ta' || saved === 'hi' || saved === 'en') {
        return saved as LanguageCode;
      }
    } catch {
      // ignore
    }
    return 'en';
  });

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {
      // ignore
    }
  };

  const isTamil = language === 'ta';
  const isHindi = language === 'hi';
  const isSecondaryLanguage = language !== 'en';

  const t = (key: string, fallback?: string): string => {
    const currentDict = translationsMap[language] || enTranslations;
    if (currentDict && currentDict[key]) {
      return currentDict[key];
    }
    if (enTranslations[key]) {
      return enTranslations[key];
    }
    return fallback !== undefined ? fallback : key;
  };

  const getItemName = (productOrName: Product | string): string => {
    const rawName = typeof productOrName === 'string' ? productOrName : productOrName?.name || '';
    if (!rawName) return '';
    return getProductLocalizedName(rawName, language);
  };

  const getCategoryName = (category: string): string => {
    if (!category) return '';
    return getCategoryLocalizedName(category, language);
  };

  const getOfferTitle = (title?: string): string => {
    if (!title) return '';
    return getOfferLocalizedTitle(title, language);
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        availableLanguages: AVAILABLE_LANGUAGES,
        isTamil,
        isHindi,
        isSecondaryLanguage,
        getItemName,
        getCategoryName,
        getOfferTitle,
        t,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
