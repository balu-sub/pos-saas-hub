import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { SaasUser, SaasLicense } from '../types/saas';

export type AppViewMode = 'home' | 'saas_hub' | 'customer_portal' | 'pos_terminal';

interface AuthContextType {
  currentUser: SaasUser | null;
  activeLicense: SaasLicense | null;
  currentView: AppViewMode;
  setCurrentView: (view: AppViewMode) => void;
  isLoadingAuth: boolean;
  login: (identifier: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (data: {
    businessName: string;
    email: string;
    phone?: string;
    password: string;
    role?: 'staff' | 'customer';
    planTier?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  refreshLicense: () => Promise<void>;
  quickLoginAsBalu: () => Promise<void>;
  quickLoginAsCustomer: () => Promise<void>;
  isStaff: boolean;
  isCustomer: boolean;
  hasFullPrivileges: boolean;
  isAuthorizedForSimulation: boolean;
  isSuperAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<SaasUser | null>(() => {
    try {
      const saved = localStorage.getItem('plannest_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [activeLicense, setActiveLicense] = useState<SaasLicense | null>(() => {
    try {
      const saved = localStorage.getItem('plannest_auth_license');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Primary default view is the counter POS Billing Terminal ('pos_terminal')
  const [currentView, setCurrentViewState] = useState<AppViewMode>(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const urlView = urlParams.get('view') as AppViewMode;
      if (urlView && ['home', 'saas_hub', 'customer_portal', 'pos_terminal'].includes(urlView)) {
        return urlView;
      }

      const savedView = localStorage.getItem('plannest_current_view') as AppViewMode;
      if (savedView === 'saas_hub' || savedView === 'customer_portal') {
        return savedView;
      }
    } catch {
      // ignore
    }
    return 'pos_terminal';
  });

  const isStaff = currentUser?.role === 'staff';
  const isCustomer = currentUser?.role === 'customer';
  const hasFullPrivileges = currentUser?.privileges === 'super_admin' || isStaff;
  const isSuperAdmin = Boolean(
    currentUser && (currentUser.privileges === 'super_admin' || currentUser.role === 'staff' || currentUser.email.toLowerCase().includes('balu'))
  );
  const isAuthorizedForSimulation = isSuperAdmin;

  const setCurrentView = useCallback((view: AppViewMode) => {
    setCurrentViewState(view);
    try {
      localStorage.setItem('plannest_current_view', view);
    } catch {
      // ignore
    }
  }, []);

  const [isLoadingAuth, setIsLoadingAuth] = useState(false);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem('plannest_auth_user', JSON.stringify(currentUser));
      } else {
        localStorage.removeItem('plannest_auth_user');
      }
    } catch {
      // ignore
    }
  }, [currentUser]);

  useEffect(() => {
    try {
      if (activeLicense) {
        localStorage.setItem('plannest_auth_license', JSON.stringify(activeLicense));
      } else {
        localStorage.removeItem('plannest_auth_license');
      }
    } catch {
      // ignore
    }
  }, [activeLicense]);

  useEffect(() => {
    try {
      localStorage.setItem('plannest_current_view', currentView);
    } catch {
      // ignore
    }
  }, [currentView]);

  const login = useCallback(async (identifier: string, password: string) => {
    setIsLoadingAuth(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to sign in' };
      }

      setCurrentUser(data.user);
      if (data.license) {
        setActiveLicense(data.license);
      }

      // Automatically route according to role:
      // If staff -> SaaS Cloud Hub
      // If customer -> Customer Portal
      if (data.user.role === 'staff') {
        setCurrentView('saas_hub');
      } else {
        setCurrentView('customer_portal');
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during sign in' };
    } finally {
      setIsLoadingAuth(false);
    }
  }, []);

  const signup = useCallback(
    async (data: {
      businessName: string;
      email: string;
      phone?: string;
      password: string;
      role?: 'staff' | 'customer';
      planTier?: string;
    }) => {
      setIsLoadingAuth(true);
      try {
        const res = await fetch('/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });
        const resp = await res.json();
        if (!res.ok || !resp.success) {
          return { success: false, error: resp.error || 'Failed to register account' };
        }

        setCurrentUser(resp.user);
        if (resp.license) {
          setActiveLicense(resp.license);
        }

        if (resp.user.role === 'staff') {
          setCurrentView('saas_hub');
        } else {
          setCurrentView('customer_portal');
        }

        return { success: true };
      } catch (err: any) {
        return { success: false, error: err.message || 'Network error during registration' };
      } finally {
        setIsLoadingAuth(false);
      }
    },
    []
  );

  const logout = useCallback(() => {
    setCurrentUser(null);
    setActiveLicense(null);
    setCurrentView('home');
    try {
      localStorage.removeItem('plannest_auth_user');
      localStorage.removeItem('plannest_auth_license');
      localStorage.removeItem('plannest_current_view');
    } catch {
      // ignore
    }
  }, []);

  const refreshLicense = useCallback(async () => {
    if (!currentUser?.email) return;
    try {
      const res = await fetch(`/api/auth/me?email=${encodeURIComponent(currentUser.email)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.license) {
          setActiveLicense({
            licenseKey: data.license.license_key || data.license.licenseKey,
            token: data.license.token,
            status: data.license.status,
            expiresAt: data.license.expires_at || data.license.expiresAt,
            planTier: data.license.plan_tier || data.license.planTier,
          });
        }
      }
    } catch {
      // ignore
    }
  }, [currentUser]);

  // Quick One-Click Login as Balu (Staff / Super Admin)
  const quickLoginAsBalu = useCallback(async () => {
    await login('balu.sub@gmail.com', '1234');
  }, [login]);

  // Quick One-Click Login as Demo Customer (Retail Store Owner)
  const quickLoginAsCustomer = useCallback(async () => {
    await login('ramesh@freshmart.in', '1234');
  }, [login]);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        activeLicense,
        currentView,
        setCurrentView,
        isLoadingAuth,
        login,
        signup,
        logout,
        refreshLicense,
        quickLoginAsBalu,
        quickLoginAsCustomer,
        isStaff,
        isCustomer,
        hasFullPrivileges,
        isAuthorizedForSimulation,
        isSuperAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
