import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { APP_VERSION, UPDATE_CHECK_URL } from '../config/version';

export interface UpdateInfo {
  version: string;
  minRequiredVersion?: string;
  releaseNotes?: string;
  downloadUrl?: string;
  publishedAt?: string;
}

interface UpdateContextType {
  currentVersion: string;
  isUpdateAvailable: boolean;
  remoteInfo: UpdateInfo | null;
  isUpdating: boolean;
  updateStatus: string;
  updateError: string | null;
  updateSuccess: boolean;
  isUpdateModalOpen: boolean;
  setIsUpdateModalOpen: (open: boolean) => void;
  checkForUpdates: () => Promise<void>;
  installUpdate: () => Promise<void>;
}

const UpdateContext = createContext<UpdateContextType | undefined>(undefined);

function compareSemver(a: string, b: string): number {
  const pa = a.replace(/^v/, '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = b.replace(/^v/, '').split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

export const UpdateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentVersion] = useState<string>(APP_VERSION);
  const [remoteInfo, setRemoteInfo] = useState<UpdateInfo | null>(null);
  const [isUpdateAvailable, setIsUpdateAvailable] = useState<boolean>(false);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [updateStatus, setUpdateStatus] = useState<string>('');
  const [updateError, setUpdateError] = useState<string | null>(null);
  const [updateSuccess, setUpdateSuccess] = useState<boolean>(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState<boolean>(false);

  const checkForUpdates = useCallback(async () => {
    try {
      const url = `${UPDATE_CHECK_URL}?_t=${Date.now()}`;
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) return;

      const data: UpdateInfo = await res.json();
      if (data && data.version) {
        setRemoteInfo(data);
        const hasNew = compareSemver(data.version, APP_VERSION) > 0;
        setIsUpdateAvailable(hasNew);
      }
    } catch (err) {
      console.warn('[UpdateChecker] Could not check remote version:', err);
    }
  }, []);

  // Check on mount and periodically every 15 minutes
  useEffect(() => {
    checkForUpdates();
    const interval = setInterval(checkForUpdates, 15 * 60 * 1000);
    return () => clearInterval(interval);
  }, [checkForUpdates]);

  const installUpdate = useCallback(async () => {
    if (isUpdating) return;
    setIsUpdating(true);
    setUpdateError(null);
    setUpdateStatus('Connecting to Plannest Edge & downloading update...');

    try {
      const downloadUrl = remoteInfo?.downloadUrl || 'https://pos.plannestapp.com/plannest-terminal.zip';
      const res = await fetch('/api/system/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ downloadUrl }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Update request failed with status ${res.status}`);
      }

      setUpdateStatus('Update verified! Plannest POS will now restart with the new version...');
      setUpdateSuccess(true);

      setTimeout(() => {
        try {
          window.close();
        } catch {
          window.location.reload();
        }
      }, 1500);
    } catch (err: any) {
      console.error('[Updater] Install error:', err);
      setUpdateError(err.message || 'Failed to install update. Please check internet connection.');
      setIsUpdating(false);
    }
  }, [isUpdating, remoteInfo]);

  return (
    <UpdateContext.Provider
      value={{
        currentVersion,
        isUpdateAvailable,
        remoteInfo,
        isUpdating,
        updateStatus,
        updateError,
        updateSuccess,
        isUpdateModalOpen,
        setIsUpdateModalOpen,
        checkForUpdates,
        installUpdate,
      }}
    >
      {children}
    </UpdateContext.Provider>
  );
};

export const useAppUpdate = (): UpdateContextType => {
  const context = useContext(UpdateContext);
  if (!context) {
    throw new Error('useAppUpdate must be used within an UpdateProvider');
  }
  return context;
};
