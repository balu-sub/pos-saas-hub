import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { playKeypadClick } from '../utils/audio';

export type KeyboardLayoutType = 'numpad' | 'qwerty';

export interface VirtualKeyboardContextType {
  // Master On/Off switch for Touchscreen on-screen keyboard / numpad
  isTouchKeyboardEnabled: boolean;
  setIsTouchKeyboardEnabled: React.Dispatch<React.SetStateAction<boolean>>;
  toggleTouchKeyboard: () => void;

  // Active keyboard state
  isKeyboardVisible: boolean;
  keyboardLayout: KeyboardLayoutType;
  inputTitle?: string;
  activeInputType?: string;
  inputUnit?: string;
  isDiscreteOnly?: boolean;

  // Register active input element for on-screen typing
  openForElement: (
    element: HTMLInputElement | HTMLTextAreaElement,
    layout?: KeyboardLayoutType,
    title?: string,
    unit?: string
  ) => void;
  closeKeyboard: () => void;

  // Manual key trigger (for custom components)
  sendKey: (key: string) => void;
}

const VirtualKeyboardContext = createContext<VirtualKeyboardContextType | undefined>(undefined);

const STORAGE_KEY_TOUCH_KEYBOARD = 'pos_touch_keyboard_enabled_v1';

export const VirtualKeyboardProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Enabled by default on touchscreen POS monitors; user can switch on/off in header
  const [isTouchKeyboardEnabled, setIsTouchKeyboardEnabled] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_TOUCH_KEYBOARD);
      return stored !== null ? stored === 'true' : true;
    } catch {
      return true;
    }
  });

  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
  const [keyboardLayout, setKeyboardLayout] = useState<KeyboardLayoutType>('numpad');
  const [inputTitle, setInputTitle] = useState<string>('');
  const [activeInputType, setActiveInputType] = useState<string>('text');
  const [inputUnit, setInputUnit] = useState<string>('');
  const [isDiscreteOnly, setIsDiscreteOnly] = useState<boolean>(false);
  const [targetElement, setTargetElement] = useState<HTMLInputElement | HTMLTextAreaElement | null>(null);

  // Sync to local storage
  const toggleTouchKeyboard = useCallback(() => {
    setIsTouchKeyboardEnabled((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(STORAGE_KEY_TOUCH_KEYBOARD, String(next));
      } catch {
        // ignore
      }
      if (!next) {
        setIsKeyboardVisible(false);
      }
      return next;
    });
  }, []);

  const closeKeyboard = useCallback(() => {
    setIsKeyboardVisible(false);
    setTargetElement(null);
  }, []);

  const openForElement = useCallback(
    (
      element: HTMLInputElement | HTMLTextAreaElement,
      layout?: KeyboardLayoutType,
      title?: string,
      unit?: string
    ) => {
      if (!isTouchKeyboardEnabled) return;

      const type = (element.getAttribute('type') || '').toLowerCase();
      const inputMode = (element.getAttribute('inputmode') || '').toLowerCase();
      const dataLayout = element.getAttribute('data-keyboard') as KeyboardLayoutType;
      const dataTitle = element.getAttribute('data-title') || element.getAttribute('placeholder') || '';
      const dataUnit = element.getAttribute('data-unit') || unit || '';

      const isNumeric =
        layout === 'numpad' ||
        dataLayout === 'numpad' ||
        type === 'number' ||
        type === 'tel' ||
        inputMode === 'numeric' ||
        inputMode === 'decimal';

      setTargetElement(element);
      setActiveInputType(type || 'text');
      setKeyboardLayout(layout || (isNumeric ? 'numpad' : 'qwerty'));
      setInputTitle(title || dataTitle || (isNumeric ? 'Number / Quantity Entry' : 'Touchscreen Typing'));
      setInputUnit(dataUnit);
      setIsDiscreteOnly(
        inputMode === 'numeric' ||
        element.getAttribute('data-discrete') === 'true' ||
        ['nos', 'pc', 'pack', 'box', 'bottle', 'can', 'tray', 'dozen'].includes(dataUnit.toLowerCase())
      );
      setIsKeyboardVisible(true);
    },
    [isTouchKeyboardEnabled]
  );

  // Send a keypress or text manipulation directly to the registered input
  const sendKey = useCallback(
    (key: string) => {
      playKeypadClick();
      if (!targetElement) return;

      const el = targetElement;
      const curVal = el.value || '';
      const start = el.selectionStart ?? curVal.length;
      const end = el.selectionEnd ?? curVal.length;

      let nextVal = curVal;
      let nextCursor = start;

      if (key === 'BACKSPACE') {
        if (start === end) {
          if (start > 0) {
            nextVal = curVal.slice(0, start - 1) + curVal.slice(end);
            nextCursor = start - 1;
          }
        } else {
          nextVal = curVal.slice(0, start) + curVal.slice(end);
          nextCursor = start;
        }
      } else if (key === 'CLEAR') {
        nextVal = '';
        nextCursor = 0;
      } else if (key === 'ENTER') {
        // Trigger submit or change and close
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
        closeKeyboard();
        return;
      } else if (key === '+1' || key === '+5' || key === '+10' || key === '+100' || key === '+500') {
        const delta = parseFloat(key.replace('+', '')) || 0;
        const currentNum = parseFloat(curVal) || 0;
        nextVal = String(Number((currentNum + delta).toFixed(3)));
        nextCursor = nextVal.length;
      } else {
        // Prevent multiple decimals
        if (key === '.' && curVal.includes('.')) {
          return;
        }
        // Prevent decimal if discrete unit
        if (key === '.' && isDiscreteOnly) {
          return;
        }
        nextVal = curVal.slice(0, start) + key + curVal.slice(end);
        nextCursor = start + key.length;
      }

      // Update native input value and trigger React's synthetic change event
      const nativeInputValueSetter =
        Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set ||
        Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;

      if (nativeInputValueSetter) {
        nativeInputValueSetter.call(el, nextVal);
      } else {
        el.value = nextVal;
      }

      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));

      // Keep focus and cursor position
      try {
        el.focus();
        el.setSelectionRange(nextCursor, nextCursor);
      } catch {
        // ignore
      }
    },
    [targetElement, isDiscreteOnly, closeKeyboard]
  );

  // Global listener: Auto-detect focus on text/number inputs across the whole app
  useEffect(() => {
    const handleFocusIn = (e: FocusEvent) => {
      if (!isTouchKeyboardEnabled) return;
      const target = e.target as HTMLElement | null;
      if (!target) return;

      // Ignore elements inside the virtual keyboard itself
      if (target.closest('[data-virtual-keyboard="true"]')) {
        return;
      }

      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
        const inputEl = target as HTMLInputElement | HTMLTextAreaElement;
        // Check if explicitly disabled for this input
        if (inputEl.getAttribute('data-no-keyboard') === 'true') {
          return;
        }

        const type = (inputEl.getAttribute('type') || '').toLowerCase();
        // Skip radio, checkbox, submit, button, file, etc.
        if (['checkbox', 'radio', 'button', 'submit', 'reset', 'file', 'image', 'range', 'color'].includes(type)) {
          return;
        }

        openForElement(inputEl);
      }
    };

    document.addEventListener('focusin', handleFocusIn);
    return () => {
      document.removeEventListener('focusin', handleFocusIn);
    };
  }, [isTouchKeyboardEnabled, openForElement]);

  return (
    <VirtualKeyboardContext.Provider
      value={{
        isTouchKeyboardEnabled,
        setIsTouchKeyboardEnabled,
        toggleTouchKeyboard,
        isKeyboardVisible,
        keyboardLayout,
        inputTitle,
        activeInputType,
        inputUnit,
        isDiscreteOnly,
        openForElement,
        closeKeyboard,
        sendKey,
      }}
    >
      {children}
    </VirtualKeyboardContext.Provider>
  );
};

export const useVirtualKeyboard = (): VirtualKeyboardContextType => {
  const context = useContext(VirtualKeyboardContext);
  if (!context) {
    throw new Error('useVirtualKeyboard must be used within a VirtualKeyboardProvider');
  }
  return context;
};
