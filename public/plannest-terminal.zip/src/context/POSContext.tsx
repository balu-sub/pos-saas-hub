import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  CartLine,
  CashDenominationBreakdown,
  Customer,
  InventoryLedgerEntry,
  Operator,
  Order,
  OutletProfile,
  LoyaltyProgramConfig,
  PaymentSplit,
  Product,
  PurchaseOrder,
  ShiftDenominations,
  ShiftRecord,
  SyncQueueItem,
  TenderType,
  DEFAULT_OPERATORS,
} from '../types/pos';
import { INITIAL_CATEGORIES, INITIAL_CUSTOMERS, INITIAL_PRODUCTS, INITIAL_PURCHASE_ORDERS, INITIAL_SHIFT } from '../data/seedData';
import { posDb } from '../services/db';
import { apiClient } from '../services/apiClient';
import { playBarcodeBeep, playKeypadClick, playSuccessChime, playWarningTone } from '../utils/audio';
import { getProductOfferInfo, isOfferActive } from '../utils/offers';
import { filterAndSortProducts } from '../utils/productSearch';
import { generateNextOrderNumber } from '../utils/billNumber';
import confetti from 'canvas-confetti';
import { useAuth } from './AuthContext';

export type NavTab = 'register' | 'inventory' | 'reconciliation' | 'replenishment' | 'analytics' | 'settings';

export interface CartLineItem extends CartLine {}

export interface POSContextType {
  // Navigation
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;

  // Catalog & Inventory
  products: Product[];
  isLoadingProducts: boolean;
  categories: string[];
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filteredProducts: Product[];
  refreshProducts: () => Promise<void>;
  updateProductStock: (variantId: string, quantityDelta: number, reason: string) => Promise<void>;
  createProductWithVariants: (product: Product) => Promise<void>;
  updateProduct: (product: Product) => Promise<void>;
  updateProductOffer: (
    productId: string,
    offerData: {
      isOfferActive: boolean;
      offerType?: 'percentage' | 'flat';
      offerValue?: number;
      offerTitle?: string;
      offerStartDate?: string | null;
      offerEndDate?: string | null;
    }
  ) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>;
  addCategory: (categoryName: string) => void;
  updateCategory: (oldName: string, newName: string) => Promise<void>;
  deleteCategory: (categoryName: string, reassignToCategory?: string) => Promise<void>;

  // Customers
  customers: Customer[];
  selectedCustomer: Customer | null;
  setSelectedCustomer: (cust: Customer | null) => void;
  searchCustomerQuery: string;
  setSearchCustomerQuery: (query: string) => void;
  filteredCustomers: Customer[];
  saveNewCustomer: (cust: Partial<Customer>) => Promise<Customer>;
  updateCustomer: (cust: Customer) => Promise<void>;
  deleteCustomer: (customerId: string) => Promise<void>;
  updateCustomerCredit: (customerId: string, newCredit: number, notes?: string) => Promise<void>;

  // Cart
  cart: CartLine[];
  addToCart: (product: Product, variantId?: string | any, quantity?: number, weightGrams?: number) => void;
  removeFromCart: (lineId: string) => void;
  updateCartQuantity: (lineId: string, quantity: number) => void;
  updateQuantity: (lineId: string, delta: number) => void;
  setQuantityDirect: (lineId: string, quantity: number) => void;
  updateCartDiscount: (lineId: string, discountPercent?: number, discountAmount?: number) => void;
  clearCart: () => void;

  // Financial Calculations
  subtotal: number;
  taxAmount: number;
  taxRate: number;
  totalDue: number;
  itemCount: number;

  // Checkout & Split Payments
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  paymentSplits: PaymentSplit[];
  activeTenderType: TenderType;
  setActiveTenderType: (type: TenderType) => void;
  tenderAmountInput: string;
  setTenderAmountInput: (val: string) => void;
  addPaymentSplit: (type: TenderType, amount: number, reference?: string, denominations?: CashDenominationBreakdown) => void;
  removePaymentSplit: (id: string) => void;
  totalPaid: number;
  remainingBalance: number;
  changeDue: number;
  completeTransaction: () => Promise<Order | null>;

  // Parked Orders
  parkedOrders: Order[];
  parkCurrentOrder: (reason?: string) => Promise<void>;
  resumeParkedOrder: (orderId: string) => Promise<void>;
  retrieveParkedOrder: (orderId: string) => Promise<void>;
  discardParkedOrder: (orderId: string) => Promise<void>;
  deleteParkedOrder: (orderId: string) => Promise<void>;

  // Receipts
  lastCompletedOrder: Order | null;
  isReceiptOpen: boolean;
  setIsReceiptOpen: (open: boolean) => void;

  // Shifts & Cash Reconciliation
  currentShift: ShiftRecord;
  updateShiftFloat: (newFloat: number) => Promise<void>;
  updateShiftDenomination: (type: 'bills' | 'coins', keyOrVal: string | number, countOrVal?: number) => Promise<void>;
  recordCashDrop: (amount: number, reason: string) => Promise<void>;
  recordShiftCount: (counted: number, denominations: any, notes?: string) => Promise<void>;
  closeCurrentShift: (notes?: string) => Promise<void>;

  // Barcode / Scanner
  isScannerReady: boolean;
  lastScannedCode: string;
  handleBarcodeInput: (code: string, quantity?: number) => boolean;
  scanBarcode: (code: string, quantity?: number) => boolean;

  // Offline / CRDT / LWW Queue
  isOnline: boolean;
  isSyncing: boolean;
  syncQueueCount: number;
  lastSyncTime: string | null;
  triggerManualSync: () => Promise<void>;

  // Store & Outlet Profile
  outletProfile: OutletProfile;
  updateOutletProfile: (profile: Partial<OutletProfile>) => Promise<void>;

  // Loyalty Program Config & Checkout Redemption
  loyaltyConfig: LoyaltyProgramConfig;
  updateLoyaltyConfig: (config: Partial<LoyaltyProgramConfig>) => Promise<void>;
  loyaltyRedeemedPoints: number;
  setLoyaltyRedeemedPoints: (points: number) => void;
  loyaltyDiscountAmount: number;

  // Current Operator & User Management
  currentOperator: Operator;
  operators: Operator[];
  switchOperator: (operator: Operator) => void;
  switchOperatorByPin: (pin: string) => boolean;
  addOperator: (operatorData: Omit<Operator, 'id'>) => Promise<Operator>;
  updateOperator: (operator: Operator) => Promise<void>;
  deleteOperator: (id: string) => Promise<boolean>;
  resetOperatorPin: (id: string, newPin: string) => Promise<void>;
  toggleOperatorStatus: (id: string) => Promise<void>;
  canManageUsers: boolean;
  canManageCatalog: boolean;
  canManageSettings: boolean;
  isDbConnected: boolean;
  dbDriver: 'sqlite' | 'mysql';
}

const POSContext = createContext<POSContextType | undefined>(undefined);

export const calculateDenominationsTotal = (denoms: ShiftDenominations | any): number => {
  if (!denoms) return 0;
  let total = 0;
  if (denoms.bills) {
    total += (Number(denoms.bills.d2000) || 0) * 2000;
    total += (Number(denoms.bills.d500) || 0) * 500;
    total += (Number(denoms.bills.d200) || 0) * 200;
    total += (Number(denoms.bills.d100) || 0) * 100;
    total += (Number(denoms.bills.d50) || 0) * 50;
    total += (Number(denoms.bills.d20) || 0) * 20;
    total += (Number(denoms.bills.d10) || 0) * 10;
    total += (Number(denoms.bills.unknown) || Number(denoms.bills.dUnknown) || Number(denoms.unknown) || 0);
  }
  if (typeof denoms.coins === 'number') {
    total += Number(denoms.coins) || 0;
  } else if (denoms.coins && typeof denoms.coins === 'object') {
    total += (Number(denoms.coins.c20) || 0) * 20;
    total += (Number(denoms.coins.c10) || 0) * 10;
    total += (Number(denoms.coins.c05) || 0) * 5;
    total += (Number(denoms.coins.c02) || 0) * 2;
    total += (Number(denoms.coins.c01) || 0) * 1;
    total += Number(denoms.coins.total) || 0;
  }
  return Number(total.toFixed(2));
};

export const decomposeCashToDenominations = (amount: number) => {
  let remaining = Math.max(0, Math.floor(amount));
  const coins = Number((amount - remaining).toFixed(2));

  const d2000 = Math.floor(remaining / 2000); remaining %= 2000;
  const d500 = Math.floor(remaining / 500); remaining %= 500;
  const d200 = Math.floor(remaining / 200); remaining %= 200;
  const d100 = Math.floor(remaining / 100); remaining %= 100;
  const d50 = Math.floor(remaining / 50); remaining %= 50;
  const d20 = Math.floor(remaining / 20); remaining %= 20;
  const d10 = Math.floor(remaining / 10); remaining %= 10;
  const coinRemainder = Number((remaining + coins).toFixed(2));

  return {
    bills: { d2000, d500, d200, d100, d50, d20, d10 },
    coins: coinRemainder,
  };
};

export const POSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthorizedForSimulation, isSuperAdmin } = useAuth();
  const isSuperAdminSim = Boolean(isAuthorizedForSimulation || isSuperAdmin);

  // Navigation State
  const [activeTab, setActiveTab] = useState<NavTab>('register');

  // Operators & User Management
  const [operators, setOperators] = useState<Operator[]>(() => {
    try {
      const stored = localStorage.getItem('alfa_pos_operators');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((op) => ({
            ...op,
            userRole: op.userRole || (op.role?.toLowerCase().includes('admin') ? 'Admin' : op.role?.toLowerCase().includes('supervisor') ? 'Supervisor' : 'Staff'),
            status: op.status || 'active',
          }));
        }
      }
    } catch {
      // Fallback
    }
    return DEFAULT_OPERATORS;
  });

  const [currentOperator, setCurrentOperator] = useState<Operator>(() => {
    try {
      const stored = localStorage.getItem('alfa_pos_current_operator');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.id) {
          return {
            ...parsed,
            userRole: parsed.userRole || (parsed.role?.toLowerCase().includes('admin') ? 'Admin' : parsed.role?.toLowerCase().includes('supervisor') ? 'Supervisor' : 'Staff'),
          };
        }
      }
    } catch {
      // Fallback
    }
    return DEFAULT_OPERATORS[0];
  });

  // Sync operators to DB and localStorage
  useEffect(() => {
    const loadOpsFromDb = async () => {
      try {
        await posDb.seedDefaultsIfEmpty();
        const dbUsers = await posDb.users.toArray();
        if (dbUsers.length > 0) {
          const normalized = dbUsers.map((op) => ({
            ...op,
            userRole: op.userRole || (op.role?.toLowerCase().includes('admin') ? 'Admin' : op.role?.toLowerCase().includes('supervisor') ? 'Supervisor' : op.role?.toLowerCase().includes('kiosk') ? 'Customer Kiosk' : 'Staff'),
            status: op.status || 'active',
          }));

          // Guarantee default Customer Kiosk operator exists in the operator list with non-colliding PIN (9999)
          if (!normalized.some((op) => op.userRole === 'Customer Kiosk')) {
            const kioskOp = DEFAULT_OPERATORS.find((op) => op.userRole === 'Customer Kiosk');
            if (kioskOp) {
              normalized.push(kioskOp);
              posDb.users.put(kioskOp).catch(() => {});
            }
          }

          const sanitized = normalized.map((op) => {
            if (op.id === 'kiosk_01' && op.pin === '0000') {
              const fixed = { ...op, pin: '9999' };
              posDb.users.put(fixed).catch(() => {});
              return fixed;
            }
            return op;
          });

          setOperators(sanitized);
          localStorage.setItem('alfa_pos_operators', JSON.stringify(sanitized));
          
          // Ensure current operator is in the list
          const found = sanitized.find((u) => u.id === currentOperator.id);
          if (found) {
            setCurrentOperator(found);
          } else {
            setCurrentOperator(sanitized[0] || DEFAULT_OPERATORS[0]);
          }
        } else {
          await posDb.users.bulkPut(DEFAULT_OPERATORS);
          setOperators(DEFAULT_OPERATORS);
          localStorage.setItem('alfa_pos_operators', JSON.stringify(DEFAULT_OPERATORS));
        }
      } catch (e) {
        console.warn('Error loading users from DB:', e);
        setOperators((prev) => (prev.length > 0 ? prev : DEFAULT_OPERATORS));
      }
    };
    loadOpsFromDb();
  }, []);

  // Save current operator selection
  useEffect(() => {
    localStorage.setItem('alfa_pos_current_operator', JSON.stringify(currentOperator));
  }, [currentOperator]);

  // Ensure Customer Kiosk always stays on the register tab
  useEffect(() => {
    if (currentOperator?.userRole === 'Customer Kiosk' && activeTab !== 'register') {
      setActiveTab('register');
    }
  }, [currentOperator?.userRole, activeTab]);

  // Ensure Super Admin during simulation has full Admin role & privileges
  useEffect(() => {
    if (isSuperAdminSim && currentOperator?.userRole !== 'Admin') {
      const adminOp = operators.find((op) => op.userRole === 'Admin' && op.status === 'active') || DEFAULT_OPERATORS[0];
      if (adminOp) {
        setCurrentOperator(adminOp);
      } else {
        setCurrentOperator((prev) => ({
          ...prev,
          userRole: 'Admin',
          roleTitle: 'Store Owner / Admin',
          role: 'Admin (Full Access & User Mgmt)',
        }));
      }
    }
  }, [isSuperAdminSim, operators]);

  // Permission Flags based on active User Role (Super Admin has all powers of Admin in POS to make changes even during simulation)
  const canManageUsers = isSuperAdminSim || (currentOperator.userRole === 'Admin') || (currentOperator.role?.toLowerCase().includes('admin') ?? false);
  const canManageCatalog = isSuperAdminSim || currentOperator.userRole === 'Admin' || currentOperator.userRole === 'Supervisor' || (currentOperator.role?.toLowerCase().includes('supervisor') ?? false);
  const canManageSettings = isSuperAdminSim || currentOperator.userRole === 'Admin' || currentOperator.userRole === 'Supervisor';

  // Catalog State
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(true);
  const [categories, setCategories] = useState<string[]>(INITIAL_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState<string>('All Items');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDbConnected, setIsDbConnected] = useState(false);
  const [dbDriver, setDbDriver] = useState<'sqlite' | 'mysql'>('sqlite');

  // Customer State
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchCustomerQuery, setSearchCustomerQuery] = useState('');

  // Cart
  const [cart, setCart] = useState<CartLine[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const taxRate = 0.05; // 5% standard

  // Checkout State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentSplits, setPaymentSplits] = useState<PaymentSplit[]>([]);
  const [tenderAmountInput, setTenderAmountInput] = useState('');
  const [activeTenderType, setActiveTenderType] = useState<TenderType>('upi');
  const [lastCompletedOrder, setLastCompletedOrderState] = useState<Order | null>(() => {
    try {
      const saved = localStorage.getItem('alfa_pos_last_order');
      if (saved) return JSON.parse(saved);
    } catch {}
    return null;
  });

  const setLastCompletedOrder = useCallback((order: Order | null) => {
    setLastCompletedOrderState(order);
    try {
      if (order) {
        localStorage.setItem('alfa_pos_last_order', JSON.stringify(order));
      } else {
        localStorage.removeItem('alfa_pos_last_order');
      }
    } catch {}
  }, []);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);

  // Parked & Shifts
  const [parkedOrders, setParkedOrders] = useState<Order[]>([]);
  const [currentShift, setCurrentShift] = useState<ShiftRecord>(INITIAL_SHIFT);

  // Barcode
  const [isScannerReady] = useState(true);
  const [lastScannedCode, setLastScannedCode] = useState('');

  // Offline / Sync
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncQueueCount, setSyncQueueCount] = useState(0);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);

  // Category management
  const addCategory = useCallback(
    (categoryName: string) => {
      const trimmed = categoryName.trim();
      if (trimmed && !categories.includes(trimmed)) {
        setCategories((prev) => [...prev, trimmed]);
      }
    },
    [categories]
  );

  const updateCategory = useCallback(
    async (oldName: string, newName: string) => {
      const oldTrim = oldName.trim();
      const newTrim = newName.trim();
      if (!oldTrim || !newTrim || oldTrim === newTrim) return;

      // 1. Update categories list
      setCategories((prev) => prev.map((c) => (c === oldTrim ? newTrim : c)));

      // 2. Reassign any existing products in local database & state
      const affected = products.filter((p) => p.category === oldTrim);
      if (affected.length > 0) {
        const updatedProds = products.map((p) => (p.category === oldTrim ? { ...p, category: newTrim } : p));
        setProducts(updatedProds);
        for (const p of affected) {
          const updated = { ...p, category: newTrim };
          await posDb.products.put(updated);
          try {
            await apiClient.updateProduct(p.id, updated);
          } catch (err) {
            console.warn('Category update sync pending for product:', p.id);
          }
        }
      }
      playSuccessChime();
    },
    [products]
  );

  const deleteCategory = useCallback(
    async (categoryName: string, reassignToCategory: string = 'Fresh Vegetables') => {
      const trimmed = categoryName.trim();
      if (!trimmed) return;

      const fallbackCat = reassignToCategory.trim() || 'Fresh Vegetables';

      // 1. Remove category from list
      setCategories((prev) => prev.filter((c) => c !== trimmed));

      // 2. Reassign any existing products in this category to fallback category
      const affected = products.filter((p) => p.category === trimmed);
      if (affected.length > 0) {
        const updatedProds = products.map((p) => (p.category === trimmed ? { ...p, category: fallbackCat } : p));
        setProducts(updatedProds);
        for (const p of affected) {
          const updated = { ...p, category: fallbackCat };
          await posDb.products.put(updated);
          try {
            await apiClient.updateProduct(p.id, updated);
          } catch (err) {
            console.warn('Product reassignment sync pending:', p.id);
          }
        }
      }
      playSuccessChime();
    },
    [products]
  );

  // Outlet Profile State
  const [outletProfile, setOutletProfile] = useState<OutletProfile>(() => {
    try {
      const cached = localStorage.getItem('alfa_pos_outlet_profile');
      if (cached) return JSON.parse(cached);
    } catch {}
    return {
      outletName: 'Store Terminal',
      branchName: 'Main Counter',
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      pincode: '',
      phone: '',
      email: '',
      gstin: '',
      panNumber: '',
      fssaiLicense: '',
      currencySymbol: 'Rs.',
      receiptHeaderNote: 'STORE BILLING TERMINAL',
      receiptFooterNote: 'Thank you for shopping with us! Visit again.',
      returnTerms: 'Goods once sold can be exchanged within 24 hours with original bill receipt.',
      billPrefix: 'INV/',
      billSuffix: '',
      billStartNumber: 1001,
      billIncrementStep: 1,
      billNextSequence: 1001,
      billNumberPadding: 0,
      billResetFrequency: 'never',
      billLastResetDate: '',
    };
  });

  // Loyalty Program Config & Checkout State
  const [loyaltyConfig, setLoyaltyConfig] = useState<LoyaltyProgramConfig>({
    enabled: true,
    spendAmountPerPoint: 100, // ₹100 = 1 point
    pointsEarnedPerSpend: 1,
    pointRedemptionValue: 1.0, // 1 point = ₹1
    minPointsToRedeem: 10,
    expiryPeriodDays: 90,
    autoEnrollOnRegistration: true,
  });

  const [loyaltyRedeemedPoints, setLoyaltyRedeemedPoints] = useState<number>(0);

  const updateOutletProfile = useCallback(async (newProfile: Partial<OutletProfile>) => {
    try {
      const res = await apiClient.saveOutletProfile(newProfile);
      if (res?.outletProfile) {
        setOutletProfile(res.outletProfile);
        localStorage.setItem('alfa_pos_outlet_profile', JSON.stringify(res.outletProfile));
      } else {
        setOutletProfile((prev) => {
          const updated = { ...prev, ...newProfile };
          localStorage.setItem('alfa_pos_outlet_profile', JSON.stringify(updated));
          return updated;
        });
      }
    } catch (err) {
      console.warn('Failed to save outlet profile to server, saving locally:', err);
      setOutletProfile((prev) => {
        const updated = { ...prev, ...newProfile };
        localStorage.setItem('alfa_pos_outlet_profile', JSON.stringify(updated));
        return updated;
      });
    }
  }, []);

  const updateLoyaltyConfig = useCallback(async (newConfig: Partial<LoyaltyProgramConfig>) => {
    try {
      const res = await apiClient.saveLoyaltySettings(newConfig);
      if (res?.loyaltyConfig) {
        setLoyaltyConfig(res.loyaltyConfig);
      } else {
        setLoyaltyConfig((prev) => ({ ...prev, ...newConfig }));
      }
      localStorage.setItem('alfa_pos_loyalty_config', JSON.stringify({ ...loyaltyConfig, ...newConfig }));
    } catch (err) {
      console.warn('Failed to save loyalty settings to server, saving locally:', err);
      setLoyaltyConfig((prev) => ({ ...prev, ...newConfig }));
      localStorage.setItem('alfa_pos_loyalty_config', JSON.stringify({ ...loyaltyConfig, ...newConfig }));
    }
  }, [loyaltyConfig]);

  // Initialize DB from Local Database via REST API, fallback to IndexedDB
  const refreshProducts = useCallback(async (force = false, silent = false) => {
    if (!silent) setIsLoadingProducts(true);
    try {
      // 1. Attempt database connection via backend API
      const prods = await apiClient.getProducts(force);
      if (Array.isArray(prods)) {
        setProducts(prods);
        setIsDbConnected(true);

        try {
          const status = await apiClient.getDatabaseStatus();
          if (status?.driver) {
            setDbDriver(status.driver);
          }
        } catch {
          // ignore status fetch error
        }

        // Fetch Outlet Profile from backend
        try {
          const profile = await apiClient.getOutletProfile();
          if (profile && profile.outletName) {
            setOutletProfile(profile);
            localStorage.setItem('alfa_pos_outlet_profile', JSON.stringify(profile));
          }
        } catch (oErr) {
          console.warn('Outlet profile fetch failed, using local/cached:', oErr);
          const cached = localStorage.getItem('alfa_pos_outlet_profile');
          if (cached) setOutletProfile(JSON.parse(cached));
        }

        // Fetch Loyalty Config
        try {
          const loyalty = await apiClient.getLoyaltySettings();
          if (loyalty) setLoyaltyConfig(loyalty);
        } catch (lErr) {
          console.warn('Loyalty settings fetch failed, using local/cached:', lErr);
          const cached = localStorage.getItem('alfa_pos_loyalty_config');
          if (cached) setLoyaltyConfig(JSON.parse(cached));
        }

        // Sync to local IndexedDB cache for offline readiness
        try {
          await posDb.products.clear();
          if (prods.length > 0) {
            await posDb.products.bulkPut(prods);
          }
        } catch (dbCacheErr) {
          console.warn('Failed to cache products locally:', dbCacheErr);
        }

        // Extract clean categories directly from database products
        const prodCategories = Array.from(new Set(prods.map((p) => p.category).filter(Boolean))).sort();
        setCategories(['All Items', ...prodCategories]);

        // Fetch customers
        try {
          const custs = await apiClient.getCustomers();
          if (Array.isArray(custs) && custs.length > 0) {
            setCustomers(custs);
            await posDb.customers.clear();
            await posDb.customers.bulkPut(custs);
          }
        } catch (cErr) {
          console.warn('Customer fetch failed:', cErr);
        }

        // Fetch / Restore active shift
        try {
          await posDb.seedDefaultsIfEmpty();
          const allShifts = await posDb.shifts.toArray();
          const activeShift = allShifts.find((s) => s.status === 'open') || allShifts[0];
          if (activeShift) {
            setCurrentShift(activeShift);
          } else {
            const cachedShift = localStorage.getItem('alfa_pos_current_shift');
            if (cachedShift) setCurrentShift(JSON.parse(cachedShift));
          }
        } catch (sErr) {
          console.warn('Shift restoration failed:', sErr);
        }
      } else {
        // Fallback: Local IndexedDB only if already saved from local DB
        const localProds = await posDb.products.toArray();
        setProducts(localProds);
        const prodCategories = Array.from(new Set(localProds.map((p) => p.category).filter(Boolean))).sort();
        setCategories(['All Items', ...prodCategories]);

        const custs = await posDb.customers.toArray();
        if (custs.length > 0) setCustomers(custs);

        const parked = await posDb.parkedOrders.toArray();
        setParkedOrders(parked);

        const shift = await posDb.shifts.get('shift_today');
        if (shift) setCurrentShift(shift);

        const queueCount = await posDb.syncQueue.where('status').equals('pending').count();
        setSyncQueueCount(queueCount);
      }
    } catch (apiErr) {
      console.warn('Local database API error, checking local Dexie cache:', apiErr);
      setIsDbConnected(false);

      // Fallback: Local IndexedDB only if already saved from local DB
      try {
        const prods = await posDb.products.toArray();
        setProducts(prods);
        const prodCategories = Array.from(new Set(prods.map((p) => p.category).filter(Boolean))).sort();
        setCategories(['All Items', ...prodCategories]);

        const custs = await posDb.customers.toArray();
        if (custs.length > 0) setCustomers(custs);

        const parked = await posDb.parkedOrders.toArray();
        setParkedOrders(parked);

        const shift = await posDb.shifts.get('shift_today');
        if (shift) setCurrentShift(shift);

        const queueCount = await posDb.syncQueue.where('status').equals('pending').count();
        setSyncQueueCount(queueCount);
      } catch (err) {
        console.error('Error initializing local POS database:', err);
      }
    } finally {
      setIsLoadingProducts(false);
    }
  }, []);

  useEffect(() => {
    refreshProducts(false);
  }, [refreshProducts]);

  // Live cloud sync: the local server pulls the store catalog from the cloud every 15s.
  // Poll its version and silently reload the catalog whenever something changed (e.g. item added in Cloud Manager).
  useEffect(() => {
    let lastVersion: number | null = null;
    let cancelled = false;
    const poll = async () => {
      try {
        const status = await apiClient.getSyncStatus();
        if (cancelled) return;
        if (lastVersion !== null && status.productsVersion !== lastVersion) {
          await refreshProducts(true, true);
        }
        lastVersion = status.productsVersion;
      } catch {
        // local server not reachable yet - ignore
      }
    };
    const timer = setInterval(poll, 8000);
    poll();
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [refreshProducts]);

  // Cart Calculations
  const subtotal = useMemo(() => {
    return cart.reduce((acc, item) => {
      const lineTotal = item.unitPrice * item.quantity;
      const discounted = lineTotal * (1 - (item.discountPercent || 0) / 100) - (item.discountAmount || 0);
      return acc + Math.max(0, discounted);
    }, 0);
  }, [cart]);

  const taxAmount = useMemo(() => {
    return Number((subtotal * taxRate).toFixed(2));
  }, [subtotal, taxRate]);

  const loyaltyDiscountAmount = useMemo(() => {
    const redeemSplitsAmount = paymentSplits
      .filter((s) => s.tenderType === 'redeem')
      .reduce((acc, s) => acc + s.amount, 0);
    if (redeemSplitsAmount > 0) {
      return Number(redeemSplitsAmount.toFixed(2));
    }
    if (!loyaltyConfig.enabled || loyaltyRedeemedPoints <= 0) return 0;
    return Number((loyaltyRedeemedPoints * loyaltyConfig.pointRedemptionValue).toFixed(2));
  }, [paymentSplits, loyaltyConfig, loyaltyRedeemedPoints]);

  const grossTotal = useMemo(() => {
    return Number((subtotal + taxAmount).toFixed(2));
  }, [subtotal, taxAmount]);

  const totalDue = useMemo(() => {
    const hasRedeemSplit = paymentSplits.some((s) => s.tenderType === 'redeem');
    if (hasRedeemSplit) {
      return grossTotal;
    }
    const rawTotal = subtotal + taxAmount - loyaltyDiscountAmount;
    return Number(Math.max(0, rawTotal).toFixed(2));
  }, [subtotal, taxAmount, loyaltyDiscountAmount, grossTotal, paymentSplits]);

  const itemCount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.quantity, 0);
  }, [cart]);

  // Payment Balance Calculations
  const totalPaid = useMemo(() => {
    return paymentSplits.reduce((acc, p) => acc + p.amount, 0);
  }, [paymentSplits]);

  const remainingBalance = useMemo(() => {
    const rem = totalDue - totalPaid;
    return Number((rem > 0 ? rem : 0).toFixed(2));
  }, [totalDue, totalPaid]);

  const changeDue = useMemo(() => {
    const diff = totalPaid - totalDue;
    return Number((diff > 0 ? diff : 0).toFixed(2));
  }, [totalDue, totalPaid]);

  // Default tender input
  useEffect(() => {
    if (isCheckoutOpen) {
      if (remainingBalance > 0) {
        setTenderAmountInput(remainingBalance.toFixed(2));
      } else {
        setTenderAmountInput('');
      }
    }
  }, [isCheckoutOpen, remainingBalance]);

  // Filtered Products with prefix priority and alphabetical sorting
  const filteredProducts = useMemo(() => {
    return filterAndSortProducts(
      products,
      searchQuery,
      selectedCategory,
      selectedCategory === '__OFFERS__',
      isOfferActive
    );
  }, [products, selectedCategory, searchQuery]);

  // Filtered Customers
  const filteredCustomers = useMemo(() => {
    const q = searchCustomerQuery.toLowerCase().trim();
    if (!q) return customers.slice(0, 10);
    return customers.filter(
      (c) => c.name.toLowerCase().includes(q) || c.phone.includes(q) || (c.email && c.email.toLowerCase().includes(q))
    );
  }, [customers, searchCustomerQuery]);

  // Keep selected customer synced with any changes in the customers list
  useEffect(() => {
    if (selectedCustomer) {
      const match = customers.find((c) => c.id === selectedCustomer.id);
      if (match && (match.storeCredit !== selectedCustomer.storeCredit || match.loyaltyPoints !== selectedCustomer.loyaltyPoints || match.name !== selectedCustomer.name)) {
        setSelectedCustomer(match);
      }
    }
  }, [customers, selectedCustomer]);

  const saveNewCustomer = useCallback(async (custData: Partial<Customer>): Promise<Customer> => {
    const newCust: Customer = {
      id: custData.id || `cust_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      name: custData.name || 'New Customer',
      phone: custData.phone || '',
      email: custData.email || '',
      loyaltyPoints: custData.loyaltyPoints || 0,
      storeCredit: custData.storeCredit || 0,
      totalSpent: custData.totalSpent || 0,
      memberTier: custData.memberTier || 'Regular',
      recentPurchasesCount: 0,
    };

    await posDb.customers.put(newCust);
    setCustomers((prev) => [newCust, ...prev.filter((c) => c.id !== newCust.id)]);
    setSelectedCustomer(newCust);

    try {
      await apiClient.saveCustomer(newCust);
    } catch (err) {
      console.warn('Customer saved locally, server sync pending:', err);
    }
    playSuccessChime();
    return newCust;
  }, []);

  const updateCustomer = useCallback(async (cust: Customer): Promise<void> => {
    await posDb.customers.put(cust);
    setCustomers((prev) => prev.map((c) => (c.id === cust.id ? cust : c)));
    if (selectedCustomer?.id === cust.id) {
      setSelectedCustomer(cust);
    }
    try {
      await apiClient.updateCustomer(cust.id, cust);
    } catch (err) {
      console.warn('Customer updated locally, server sync pending:', err);
    }
    playSuccessChime();
  }, [selectedCustomer]);

  const deleteCustomer = useCallback(
    async (customerId: string): Promise<void> => {
      await posDb.customers.delete(customerId);
      setCustomers((prev) => prev.filter((c) => c.id !== customerId));
      if (selectedCustomer?.id === customerId) {
        setSelectedCustomer(null);
      }
      try {
        await apiClient.deleteCustomer?.(customerId);
      } catch (err) {
        console.warn('Customer deleted locally, server sync pending:', err);
      }
      playSuccessChime();
    },
    [selectedCustomer]
  );

  const updateCustomerCredit = useCallback(async (customerId: string, newCredit: number, notes?: string): Promise<void> => {
    const cust = customers.find((c) => c.id === customerId);
    if (!cust) return;

    const updated: Customer = {
      ...cust,
      storeCredit: Number(newCredit.toFixed(2)),
    };

    await posDb.customers.put(updated);
    setCustomers((prev) => prev.map((c) => (c.id === customerId ? updated : c)));
    if (selectedCustomer?.id === customerId) {
      setSelectedCustomer(updated);
    }

    try {
      await apiClient.adjustCustomerCredit(customerId, newCredit);
    } catch (err) {
      console.warn('Customer credit adjusted locally, server sync pending:', err);
    }
    playSuccessChime();
  }, [customers, selectedCustomer]);

  // Add to Cart
  const addToCart = useCallback(
    (product: Product, variantId?: string | any, quantity: number = 1, weightGrams?: number) => {
      playBarcodeBeep();
      let selectedVariant = product.variants?.[0];
      if (variantId) {
        if (typeof variantId === 'string') {
          selectedVariant = product.variants.find((v) => v.id === variantId) || product.variants[0];
        } else if (variantId && typeof variantId === 'object' && variantId.id) {
          selectedVariant = product.variants.find((v) => v.id === variantId.id) || variantId;
        }
      }

      if (!selectedVariant) return;

      const qty = weightGrams ? weightGrams / 1000 : quantity;
      const existingIndex = cart.findIndex((item) => item.variantId === selectedVariant.id);

      if (existingIndex > -1) {
        setCart((prev) =>
          prev.map((item, idx) => {
            if (idx === existingIndex) {
              const newQty = Number((item.quantity + qty).toFixed(3));
              return {
                ...item,
                quantity: newQty,
              };
            }
            return item;
          })
        );
      } else {
        const offerInfo = getProductOfferInfo(product, selectedVariant);
        const originalPrice = selectedVariant.price || product.basePrice || 0;
        const effectiveUnitPrice = offerInfo.hasOffer ? offerInfo.discountedPrice : originalPrice;
        const discountAmount = offerInfo.hasOffer ? offerInfo.discountAmount : 0;
        const discountPercent = offerInfo.hasOffer ? offerInfo.discountPercent : 0;

        const newLine: CartLine = {
          id: `line_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          productId: product.id,
          variantId: selectedVariant.id,
          sku: selectedVariant.sku,
          barcode: selectedVariant.barcode,
          productName: product.name,
          unit: selectedVariant.unit || product.unit || 'kg',
          mrp: selectedVariant.mrp || product.baseMrp || selectedVariant.price,
          unitPrice: effectiveUnitPrice,
          originalPrice: offerInfo.hasOffer ? originalPrice : undefined,
          quantity: qty,
          discountPercent: discountPercent,
          discountAmount: discountAmount,
          offerTitle: offerInfo.hasOffer ? offerInfo.offerTitle : undefined,
          modifiers: [],
          appliedTaxRate: product.gstRate || 0,
          packSize: selectedVariant.attributes?.['Weight'] || selectedVariant.attributes?.['Pack Size'] || 'Standard',
        };
        setCart((prev) => [newLine, ...prev]);
      }
    },
    [cart]
  );

  const removeFromCart = useCallback((lineId: string) => {
    playKeypadClick();
    setCart((prev) => prev.filter((item) => item.id !== lineId));
  }, []);

  const updateCartQuantity = useCallback((lineId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.id !== lineId));
    } else {
      setCart((prev) =>
        prev.map((item) => (item.id === lineId ? { ...item, quantity: Number(quantity.toFixed(3)) } : item))
      );
    }
  }, []);

  const updateQuantity = useCallback((lineId: string, delta: number) => {
    setCart((prev) => {
      const item = prev.find((i) => i.id === lineId);
      if (!item) return prev;
      const newQty = Number((item.quantity + delta).toFixed(3));
      if (newQty <= 0) {
        return prev.filter((i) => i.id !== lineId);
      }
      return prev.map((i) => (i.id === lineId ? { ...i, quantity: newQty } : i));
    });
  }, []);

  const setQuantityDirect = useCallback((lineId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.id !== lineId));
    } else {
      setCart((prev) =>
        prev.map((item) => (item.id === lineId ? { ...item, quantity: Number(quantity.toFixed(3)) } : item))
      );
    }
  }, []);

  const updateCartDiscount = useCallback((lineId: string, discountPercent: number = 0, discountAmount: number = 0) => {
    setCart((prev) =>
      prev.map((item) => (item.id === lineId ? { ...item, discountPercent, discountAmount } : item))
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    setPaymentSplits([]);
    setSelectedCustomer(null);
  }, []);

  // Split Tender Management
  const addPaymentSplit = useCallback(
    (type: TenderType, amount: number, reference: string = '', denominations?: CashDenominationBreakdown) => {
      if (amount <= 0) return;
      playKeypadClick();
      const newSplit: PaymentSplit = {
        id: `split_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        tenderType: type,
        amount: Number(amount.toFixed(2)),
        reference: reference || `${type.toUpperCase()} Ref`,
        timestamp: new Date().toISOString(),
        status: 'completed',
        denominations: denominations || (type === 'cash' ? { bills: { unknown: Number(amount.toFixed(2)) } } : undefined),
      };
      setPaymentSplits((prev) => [...prev, newSplit]);
    },
    []
  );

  const removePaymentSplit = useCallback((id: string) => {
    playKeypadClick();
    setPaymentSplits((prev) => prev.filter((p) => p.id !== id));
  }, []);

  // Stock deduction helper
  const updateProductStock = useCallback(
    async (variantId: string, quantityDelta: number, reason: string = 'SALE') => {
      const matchedProduct = products.find((p) => p.variants.some((v) => v.id === variantId));
      if (!matchedProduct) return;

      const matchedVariant = matchedProduct.variants.find((v) => v.id === variantId);
      if (!matchedVariant) return;

      const newOnHand = Math.max(0, Number((matchedVariant.onHand + quantityDelta).toFixed(3)));
      const newAvailable = Math.max(0, Number((matchedVariant.available + quantityDelta).toFixed(3)));

      const updatedProduct: Product = {
        ...matchedProduct,
        variants: matchedProduct.variants.map((v) =>
          v.id === variantId ? { ...v, onHand: newOnHand, available: newAvailable, version: v.version + 1 } : v
        ),
      };

      await posDb.products.put(updatedProduct);

      const ledgerEntry: InventoryLedgerEntry = {
        id: `ldg_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        sku: matchedVariant.sku,
        variantId: matchedVariant.id,
        productName: matchedProduct.name,
        delta: quantityDelta,
        balanceAfter: newOnHand,
        mutationType: reason as any,
        referenceId: `TX-${Date.now().toString().slice(-6)}`,
        operator: currentOperator.name,
        timestamp: new Date().toISOString(),
        notes: `Produce Retail: ${reason}`,
      };
      await posDb.inventoryLedger.add(ledgerEntry);

      setProducts((prev) => prev.map((p) => (p.id === updatedProduct.id ? updatedProduct : p)));
    },
    [products, currentOperator.name]
  );

  const createProductWithVariants = useCallback(
    async (product: Product) => {
      await posDb.products.put(product);
      setProducts((prev) => [product, ...prev.filter((p) => p.id !== product.id)]);
      try {
        await apiClient.saveProduct(product);
      } catch (err) {
        console.warn('Saved product to local cache, API sync pending:', err);
      }
      playSuccessChime();
    },
    []
  );

  const updateProduct = useCallback(
    async (product: Product) => {
      await posDb.products.put(product);
      setProducts((prev) => prev.map((p) => (p.id === product.id ? product : p)));
      try {
        await apiClient.updateProduct(product.id, product);
      } catch (err) {
        console.warn('Updated product in local cache, API sync pending:', err);
      }
      playSuccessChime();
    },
    []
  );

  const updateProductOffer = useCallback(
    async (
      productId: string,
      offerData: {
        isOfferActive: boolean;
        offerType?: 'percentage' | 'flat';
        offerValue?: number;
        offerTitle?: string;
        offerStartDate?: string | null;
        offerEndDate?: string | null;
      }
    ) => {
      setProducts((prev) =>
        prev.map((p) => {
          if (p.id === productId) {
            const updated = {
              ...p,
              isOfferActive: offerData.isOfferActive,
              offerType: offerData.offerType || 'percentage',
              offerValue: offerData.offerValue !== undefined ? offerData.offerValue : 0,
              offerTitle: offerData.offerTitle || 'Offer of the Day',
              offerStartDate: offerData.offerStartDate || undefined,
              offerEndDate: offerData.offerEndDate || undefined,
            };
            posDb.products.put(updated).catch(() => {});
            return updated;
          }
          return p;
        })
      );

      try {
        await apiClient.updateProductOffer(productId, offerData);
      } catch (err) {
        console.warn('Updated offer in local cache, server sync failed:', err);
      }
      playSuccessChime();
    },
    []
  );

  const deleteProduct = useCallback(
    async (productId: string) => {
      await posDb.products.delete(productId);
      setProducts((prev) => prev.filter((p) => p.id !== productId));
      try {
        await apiClient.deleteProduct(productId);
      } catch (err) {
        console.warn('Deleted product from local cache, API sync pending:', err);
      }
      playSuccessChime();
    },
    []
  );

  // Complete Transaction (Saves directly to Local Database + local Dexie)
  const completeTransaction = useCallback(async (): Promise<Order | null> => {
    if (cart.length === 0) return null;

    let finalSplits = [...paymentSplits];
    if (finalSplits.length === 0) {
      finalSplits.push({
        id: `split_${Date.now()}`,
        tenderType: 'upi',
        amount: totalDue,
        reference: 'UPI QR Payment',
        timestamp: new Date().toISOString(),
        status: 'completed',
      });
    }

    const currentTotalPaid = finalSplits.reduce((acc, p) => acc + p.amount, 0);
    const finalChange = Math.max(0, Number((currentTotalPaid - totalDue).toFixed(2)));
    
    // Generate Bill / Order Number using customizable Outlet Profile Bill Rules
    const { orderNumber, profileUpdate } = generateNextOrderNumber(outletProfile);
    
    // Auto increment bill sequence in background
    updateOutletProfile(profileUpdate).catch((err) => {
      console.warn('Could not auto-increment bill sequence on server:', err);
    });

    // Loyalty points calculations
    const redeemSplitsAmount = finalSplits
      .filter((s) => s.tenderType === 'redeem')
      .reduce((acc, s) => acc + s.amount, 0);
    const pointsFromSplits = Math.round(redeemSplitsAmount / (loyaltyConfig.pointRedemptionValue || 1));
    const effectivePointsRedeemed = Math.max(loyaltyRedeemedPoints, pointsFromSplits);
    const effectiveLoyaltyDiscount = Number((effectivePointsRedeemed * (loyaltyConfig.pointRedemptionValue || 1)).toFixed(2));

    const newOrder: Order = {
      id: `order_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      orderNumber,
      terminalId: 'TERM-01',
      cashierId: currentOperator.id,
      cashierName: currentOperator.name,
      customerId: selectedCustomer?.id,
      customerName: selectedCustomer?.name,
      customerPhone: selectedCustomer?.phone,
      items: [...cart],
      subtotal,
      taxAmount,
      taxRate,
      discountTotal: 0,
      loyaltyPointsRedeemed: effectivePointsRedeemed,
      loyaltyDiscountAmount: effectiveLoyaltyDiscount,
      total: totalDue,
      payments: finalSplits,
      amountPaid: currentTotalPaid,
      changeDue: finalChange,
      status: 'completed',
      createdAt: new Date().toISOString(),
      synced: isOnline,
    };

    try {
      // 1. Post to Server SQLite Database via REST API
      try {
        await apiClient.createOrder(newOrder);
      } catch (apiErr) {
        console.warn('Direct Server save failed, buffered in offline queue:', apiErr);
      }

      // 2. Save Order to local IndexedDB
      try {
        await posDb.orders.put(newOrder);
      } catch (dbErr) {
        console.warn('Local IndexedDB order save failed:', dbErr);
      }

      // 3. Update stock levels locally
      for (const item of cart) {
        try {
          await updateProductStock(item.variantId, -item.quantity, 'SALE');
        } catch (stockErr) {
          console.warn('Stock update error:', stockErr);
        }
      }

      // 4. Update Shift and Drawer
      const cashSplits = finalSplits.filter((s) => s.tenderType === 'cash');
      const cashPortion = cashSplits.reduce((acc, s) => acc + s.amount, 0);
      const upiPortion = finalSplits.filter((s) => s.tenderType === 'upi').reduce((acc, s) => acc + s.amount, 0);
      const cardPortion = finalSplits.filter((s) => s.tenderType === 'card').reduce((acc, s) => acc + s.amount, 0);
      const netCashAdded = cashPortion > 0 ? Number((cashPortion - finalChange).toFixed(2)) : 0;

      let updatedBills = { ...(currentShift.denominations?.bills || { d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0, unknown: 0 }) };
      let updatedCoins = typeof currentShift.denominations?.coins === 'number' 
        ? currentShift.denominations.coins 
        : calculateDenominationsTotal({ bills: { d2000:0, d500:0, d200:0, d100:0, d50:0, d20:0, d10:0, unknown:0 }, coins: currentShift.denominations?.coins });

      if (cashPortion > 0) {
        for (const split of cashSplits) {
          if (split.denominations?.bills) {
            updatedBills.d2000 = (updatedBills.d2000 || 0) + (split.denominations.bills.d2000 || 0);
            updatedBills.d500 = (updatedBills.d500 || 0) + (split.denominations.bills.d500 || 0);
            updatedBills.d200 = (updatedBills.d200 || 0) + (split.denominations.bills.d200 || 0);
            updatedBills.d100 = (updatedBills.d100 || 0) + (split.denominations.bills.d100 || 0);
            updatedBills.d50 = (updatedBills.d50 || 0) + (split.denominations.bills.d50 || 0);
            updatedBills.d20 = (updatedBills.d20 || 0) + (split.denominations.bills.d20 || 0);
            updatedBills.d10 = (updatedBills.d10 || 0) + (split.denominations.bills.d10 || 0);
            const unk = Number(split.denominations.bills.unknown || split.denominations.unknown || 0);
            if (unk > 0) {
              updatedBills.unknown = Number(((updatedBills.unknown || 0) + unk).toFixed(2));
            }
            if (split.denominations.coins) {
              updatedCoins = Number(((Number(updatedCoins) || 0) + split.denominations.coins).toFixed(2));
            }
          } else {
            // If denominations weren't specified, log as unknown denomination
            updatedBills.unknown = Number(((updatedBills.unknown || 0) + split.amount).toFixed(2));
          }
        }

        // Deduct change from drawer count so physical cash tallies
        if (finalChange > 0) {
          let changeToDeduct = finalChange;
          if ((updatedBills.unknown || 0) >= changeToDeduct) {
            updatedBills.unknown = Number(((updatedBills.unknown || 0) - changeToDeduct).toFixed(2));
            changeToDeduct = 0;
          } else if ((updatedBills.unknown || 0) > 0) {
            changeToDeduct = Number((changeToDeduct - (updatedBills.unknown || 0)).toFixed(2));
            updatedBills.unknown = 0;
          }

          if (changeToDeduct > 0 && updatedCoins >= changeToDeduct) {
            updatedCoins = Number((updatedCoins - changeToDeduct).toFixed(2));
            changeToDeduct = 0;
          } else if (changeToDeduct > 0 && updatedCoins > 0) {
            changeToDeduct = Number((changeToDeduct - updatedCoins).toFixed(2));
            updatedCoins = 0;
          }

          if (changeToDeduct > 0) {
            updatedBills.unknown = Number(((updatedBills.unknown || 0) - changeToDeduct).toFixed(2));
          }
        }
      }

      const nextDenominations: ShiftDenominations = {
        bills: updatedBills,
        coins: updatedCoins,
      };

      const newExpectedBalance = Number((currentShift.expectedBalance + netCashAdded).toFixed(2));
      const newActualCounted = calculateDenominationsTotal(nextDenominations);
      const newVariance = Number((newActualCounted - newExpectedBalance).toFixed(2));

      const updatedShift: ShiftRecord = {
        ...currentShift,
        cashSales: Number((currentShift.cashSales + netCashAdded).toFixed(2)),
        upiSales: Number((currentShift.upiSales + upiPortion).toFixed(2)),
        cardSales: Number((currentShift.cardSales + cardPortion).toFixed(2)),
        expectedBalance: newExpectedBalance,
        actualCounted: newActualCounted,
        variance: newVariance,
        denominations: nextDenominations,
      };

      try {
        await posDb.shifts.put(updatedShift);
        localStorage.setItem('alfa_pos_current_shift', JSON.stringify(updatedShift));
        setCurrentShift(updatedShift);
      } catch (shiftErr) {
        console.warn('Shift save error:', shiftErr);
      }

      // 5. Update Customer loyalty and Khata store credit
      if (selectedCustomer) {
        const isMember = selectedCustomer.isLoyaltyMember ?? true;
        const earnedPoints = isMember && loyaltyConfig.enabled
          ? Math.floor(totalDue / loyaltyConfig.spendAmountPerPoint) * loyaltyConfig.pointsEarnedPerSpend
          : 0;

        const storeCreditPaid = finalSplits
          .filter((s) => s.tenderType === 'store_credit')
          .reduce((acc, s) => acc + s.amount, 0);

        const nextStoreCredit = Number((selectedCustomer.storeCredit - storeCreditPaid).toFixed(2));
        const nextPoints = Math.max(0, selectedCustomer.loyaltyPoints + earnedPoints - effectivePointsRedeemed);

        const updatedCust: Customer = {
          ...selectedCustomer,
          loyaltyPoints: nextPoints,
          totalSpent: selectedCustomer.totalSpent + totalDue,
          recentPurchasesCount: selectedCustomer.recentPurchasesCount + 1,
          storeCredit: nextStoreCredit,
        };
        newOrder.loyaltyPointsEarned = earnedPoints;
        try {
          await posDb.customers.put(updatedCust);
          setCustomers((prev) => prev.map((c) => (c.id === updatedCust.id ? updatedCust : c)));
          setSelectedCustomer(updatedCust);
        } catch (custErr) {
          console.warn('Customer update error:', custErr);
        }
      }

      try {
        playSuccessChime();
      } catch {}

      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {}
    } catch (generalErr) {
      console.warn('Transaction processed with non-fatal warning:', generalErr);
    }

    // Always guarantee states are updated and receipt preview opens smoothly
    setLastCompletedOrder(newOrder);
    setIsReceiptOpen(true);
    setIsCheckoutOpen(false);
    setCart([]);
    setSelectedCustomer(null);
    setPaymentSplits([]);
    setLoyaltyRedeemedPoints(0);

    return newOrder;
  }, [
    cart,
    paymentSplits,
    totalDue,
    subtotal,
    taxAmount,
    taxRate,
    loyaltyConfig,
    loyaltyRedeemedPoints,
    loyaltyDiscountAmount,
    currentOperator,
    selectedCustomer,
    isOnline,
    currentShift,
    updateProductStock,
  ]);

  // Park Order
  const parkCurrentOrder = useCallback(
    async (reason: string = 'Customer browsing') => {
      if (cart.length === 0) return;
      playKeypadClick();
      const parkedOrder: Order = {
        id: `parked_${Date.now()}`,
        orderNumber: `PRK-${Date.now().toString().slice(-4)}`,
        terminalId: 'POS-01',
        cashierId: currentOperator.id,
        cashierName: currentOperator.name,
        customerId: selectedCustomer?.id,
        customerName: selectedCustomer?.name,
        customerPhone: selectedCustomer?.phone,
        items: [...cart],
        subtotal,
        taxAmount,
        taxRate,
        discountTotal: 0,
        total: totalDue,
        payments: [],
        amountPaid: 0,
        changeDue: 0,
        status: 'parked',
        createdAt: new Date().toISOString(),
        synced: false,
      };

      await posDb.parkedOrders.put(parkedOrder);
      setParkedOrders((prev) => [parkedOrder, ...prev]);
      clearCart();
    },
    [cart, currentOperator, selectedCustomer, subtotal, taxAmount, taxRate, totalDue, clearCart]
  );

  const resumeParkedOrder = useCallback(
    async (orderId: string) => {
      const order = parkedOrders.find((o) => o.id === orderId);
      if (!order) return;

      playKeypadClick();
      setCart(order.items);
      if (order.customerId) {
        const cust = customers.find((c) => c.id === order.customerId);
        if (cust) setSelectedCustomer(cust);
      }
      await posDb.parkedOrders.delete(orderId);
      setParkedOrders((prev) => prev.filter((o) => o.id !== orderId));
    },
    [parkedOrders, customers]
  );

  const discardParkedOrder = useCallback(async (orderId: string) => {
    playWarningTone();
    await posDb.parkedOrders.delete(orderId);
    setParkedOrders((prev) => prev.filter((o) => o.id !== orderId));
  }, []);

  // Barcode Scanning & SKU lookup logic with leading-zero tolerance
  const scanBarcode = useCallback(
    (barcode: string, quantity: number = 1): boolean => {
      const cleanCode = barcode.trim();
      if (!cleanCode) return false;
      setLastScannedCode(cleanCode);

      // 1. Weighted produce barcode pattern (e.g. 99 or 02 + 4 digit code + 4 digit grams)
      if ((cleanCode.startsWith('99') || cleanCode.startsWith('02')) && cleanCode.length >= 10) {
        const itemCode = cleanCode.substring(2, 6);
        const weightGrams = parseInt(cleanCode.substring(6, 10), 10);

        const foundProd = products.find((p) =>
          p.baseBarcode?.includes(itemCode) ||
          p.baseSku?.includes(itemCode) ||
          p.variants.some((v) => (v.barcode && v.barcode.includes(itemCode)) || (v.sku && v.sku.includes(itemCode)))
        );
        if (foundProd) {
          addToCart(foundProd, foundProd.variants[0]?.id, quantity, weightGrams);
          return true;
        }
      }

      // 2. Exact match on baseBarcode, baseSku, variant barcode, or variant sku
      for (const prod of products) {
        if (prod.baseBarcode === cleanCode || (prod.baseSku && prod.baseSku.toLowerCase() === cleanCode.toLowerCase())) {
          addToCart(prod, prod.variants[0]?.id, quantity);
          return true;
        }
        for (const variant of prod.variants) {
          if (variant.barcode === cleanCode || (variant.sku && variant.sku.toLowerCase() === cleanCode.toLowerCase())) {
            addToCart(prod, variant.id, quantity);
            return true;
          }
        }
      }

      // 3. Leading-zero tolerant match (e.g. user typed "1" for "001" or "01", or "42" for "0042")
      const digitsOnly = cleanCode.replace(/\D/g, '');
      const unpadded = digitsOnly.replace(/^0+/, '');
      if (digitsOnly) {
        for (const prod of products) {
          for (const variant of prod.variants) {
            const vDigits = (variant.sku || '').replace(/\D/g, '');
            const vUnpadded = vDigits.replace(/^0+/, '');
            const bDigits = (variant.barcode || '').replace(/\D/g, '');
            const bUnpadded = bDigits.replace(/^0+/, '');

            if (
              (vDigits && (vDigits === digitsOnly || vUnpadded === unpadded)) ||
              (bDigits && (bDigits === digitsOnly || bUnpadded === unpadded || bDigits.endsWith(digitsOnly)))
            ) {
              addToCart(prod, variant.id, quantity);
              return true;
            }
          }
        }

        // Check PLU index match (e.g. typing "1" or "001" matches 1st product)
        const itemIdx = parseInt(digitsOnly, 10) - 1;
        if (itemIdx >= 0 && itemIdx < products.length) {
          const matchedProd = products[itemIdx];
          if (matchedProd) {
            addToCart(matchedProd, matchedProd.variants[0]?.id, quantity);
            return true;
          }
        }
      }

      // 4. Name fallback match if typed in search box and Enter pressed
      const matchedByName = products.find(
        (p) => p.name.toLowerCase() === cleanCode.toLowerCase()
      );
      if (matchedByName) {
        addToCart(matchedByName, matchedByName.variants[0]?.id, quantity);
        return true;
      }

      playWarningTone();
      return false;
    },
    [products, addToCart]
  );

  const handleBarcodeInput = scanBarcode;
  const retrieveParkedOrder = resumeParkedOrder;
  const deleteParkedOrder = discardParkedOrder;

  // Operator Switching
  const switchOperator = useCallback((operator: Operator) => {
    setCurrentOperator(operator);
    if (operator.userRole === 'Customer Kiosk') {
      setActiveTab('register');
      setIsCheckoutOpen(false);
    }
    playSuccessChime();
  }, []);

  const switchOperatorByPin = useCallback((pin: string): boolean => {
    const cleanPin = pin.trim();
    if (!cleanPin) return false;

    // Super Admin Master PIN unlock (1234 or 0000) during simulation or super admin session
    if (isSuperAdminSim && (cleanPin === '1234' || cleanPin === '0000')) {
      const adminMatch = operators.find((op) => op.userRole === 'Admin' && op.status !== 'inactive')
        || DEFAULT_OPERATORS.find((op) => op.userRole === 'Admin');
      if (adminMatch) {
        setCurrentOperator(adminMatch);
        playSuccessChime();
        return true;
      }
    }

    // 1. Check exact PIN on live operators list
    const directMatch = operators.find((op) => op.pin === cleanPin && op.status !== 'inactive');
    if (directMatch) {
      setCurrentOperator(directMatch);
      if (directMatch.userRole === 'Customer Kiosk') {
        setActiveTab('register');
        setIsCheckoutOpen(false);
      }
      playSuccessChime();
      return true;
    }

    // 2. Direct match on default operator fallback
    const defaultMatch = DEFAULT_OPERATORS.find((op) => op.pin === cleanPin);
    if (defaultMatch) {
      setCurrentOperator(defaultMatch);
      if (defaultMatch.userRole === 'Customer Kiosk') {
        setActiveTab('register');
        setIsCheckoutOpen(false);
      }
      playSuccessChime();
      return true;
    }

    playWarningTone();
    return false;
  }, [operators, isSuperAdminSim]);

  // User & Operator Management
  const addOperator = useCallback(async (operatorData: Omit<Operator, 'id'>): Promise<Operator> => {
    const newId = `emp_${Date.now().toString().slice(-6)}`;
    const initials = operatorData.initials || operatorData.name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase() || 'OP';
    const roleTitle = operatorData.roleTitle || (
      operatorData.userRole === 'Admin' ? 'Store Owner / Admin' :
      operatorData.userRole === 'Supervisor' ? 'Floor Supervisor' :
      operatorData.userRole === 'Customer Kiosk' ? 'Self-Service Customer Kiosk' : 'POS Cashier'
    );
    const roleDesc = operatorData.role || (
      operatorData.userRole === 'Admin' ? 'Admin (Full Access & User Mgmt)' :
      operatorData.userRole === 'Supervisor' ? 'Supervisor (Catalog & Operations)' :
      operatorData.userRole === 'Customer Kiosk' ? 'Customer Kiosk (Self-Service Ordering & Checkout)' : 'Staff (POS, PO, GRN & Reports)'
    );

    const newOperator: Operator = {
      ...operatorData,
      id: newId,
      initials,
      roleTitle,
      role: roleDesc,
      status: operatorData.status || 'active',
      createdAt: operatorData.createdAt || new Date().toISOString().split('T')[0],
    };

    const updated = [...operators, newOperator];
    setOperators(updated);
    try {
      await posDb.users.put(newOperator);
      localStorage.setItem('alfa_pos_operators', JSON.stringify(updated));
    } catch (err) {
      console.error('Error saving user to DB:', err);
    }
    playSuccessChime();
    return newOperator;
  }, [operators]);

  const updateOperator = useCallback(async (updatedOp: Operator): Promise<void> => {
    const roleDesc = updatedOp.role || (
      updatedOp.userRole === 'Admin' ? 'Admin (Full Access & User Mgmt)' :
      updatedOp.userRole === 'Supervisor' ? 'Supervisor (Catalog & Operations)' :
      updatedOp.userRole === 'Customer Kiosk' ? 'Customer Kiosk (Self-Service Ordering & Checkout)' : 'Staff (POS, PO, GRN & Reports)'
    );
    const finalOp: Operator = {
      ...updatedOp,
      role: roleDesc,
    };

    const updatedList = operators.map((op) => (op.id === finalOp.id ? finalOp : op));
    setOperators(updatedList);
    
    // Always persist to localStorage immediately
    try {
      localStorage.setItem('alfa_pos_operators', JSON.stringify(updatedList));
      if (currentOperator.id === finalOp.id) {
        setCurrentOperator(finalOp);
        localStorage.setItem('alfa_pos_current_operator', JSON.stringify(finalOp));
      }
    } catch (lsErr) {
      console.warn('LocalStorage save error:', lsErr);
    }

    try {
      await posDb.users.put(finalOp);
    } catch (err) {
      console.warn('Error updating user in IndexedDB:', err);
    }
    playSuccessChime();
  }, [operators, currentOperator]);

  const deleteOperator = useCallback(async (id: string): Promise<boolean> => {
    // Prevent deleting the last Admin
    const opToDelete = operators.find((op) => op.id === id);
    if (!opToDelete) return false;

    if (opToDelete.userRole === 'Admin' && !isSuperAdminSim) {
      const adminCount = operators.filter((op) => op.userRole === 'Admin' && op.status === 'active').length;
      if (adminCount <= 1) {
        playWarningTone();
        return false;
      }
    }

    const updatedList = operators.filter((op) => op.id !== id);
    setOperators(updatedList);

    // If current operator was deleted, switch to the first available admin or operator
    if (currentOperator.id === id) {
      const fallback = updatedList.find((op) => op.userRole === 'Admin') || updatedList[0] || DEFAULT_OPERATORS[0];
      setCurrentOperator(fallback);
    }

    try {
      await posDb.users.delete(id);
      localStorage.setItem('alfa_pos_operators', JSON.stringify(updatedList));
    } catch (err) {
      console.error('Error deleting user from DB:', err);
    }
    playSuccessChime();
    return true;
  }, [operators, currentOperator]);

  const resetOperatorPin = useCallback(async (id: string, newPin: string): Promise<void> => {
    const op = operators.find((u) => u.id === id);
    if (!op) return;

    const updatedOp = { ...op, pin: newPin };
    await updateOperator(updatedOp);
  }, [operators, updateOperator]);

  const toggleOperatorStatus = useCallback(async (id: string): Promise<void> => {
    const op = operators.find((u) => u.id === id);
    if (!op) return;

    const newStatus = op.status === 'active' ? 'inactive' : 'active';
    const updatedOp = { ...op, status: newStatus as 'active' | 'inactive' };
    await updateOperator(updatedOp);
  }, [operators, updateOperator]);

  // Shift & Drawer
  const updateShiftFloat = useCallback(
    async (newFloat: number) => {
      const updated: ShiftRecord = {
        ...currentShift,
        openingFloat: newFloat,
        expectedBalance: newFloat + currentShift.cashSales,
        variance: Number((currentShift.actualCounted - (newFloat + currentShift.cashSales)).toFixed(2)),
      };
      await posDb.shifts.put(updated);
      setCurrentShift(updated);
    },
    [currentShift]
  );

  const updateShiftDenomination = useCallback(
    async (type: 'bills' | 'coins', keyOrVal: string | number, countOrVal?: number) => {
      let nextBills = { ...(currentShift.denominations?.bills || { d2000: 0, d500: 0, d200: 0, d100: 0, d50: 0, d20: 0, d10: 0, unknown: 0 }) };
      let nextCoins = typeof currentShift.denominations?.coins === 'number' ? currentShift.denominations.coins : 0;

      if (type === 'bills' && typeof keyOrVal === 'string') {
        nextBills = {
          ...nextBills,
          [keyOrVal]: Math.max(0, countOrVal ?? 0),
        };
      } else if (type === 'coins') {
        const coinsAmount = typeof keyOrVal === 'number' ? keyOrVal : parseFloat(String(countOrVal ?? keyOrVal)) || 0;
        nextCoins = Math.max(0, coinsAmount);
      }

      const nextDenominations: ShiftDenominations = {
        bills: nextBills,
        coins: nextCoins,
      };

      const actualCounted = calculateDenominationsTotal(nextDenominations);
      const variance = Number((actualCounted - currentShift.expectedBalance).toFixed(2));

      const updated: ShiftRecord = {
        ...currentShift,
        denominations: nextDenominations,
        actualCounted,
        variance,
      };

      await posDb.shifts.put(updated);
      setCurrentShift(updated);
    },
    [currentShift]
  );

  const recordCashDrop = useCallback(
    async (amount: number, reason: string) => {
      const safeAmount = Math.max(0, Number(amount) || 0);
      const newMidShiftDrops = currentShift.midShiftDrops + safeAmount;
      const newExpected = currentShift.expectedBalance - safeAmount;
      const variance = Number((currentShift.actualCounted - newExpected).toFixed(2));

      const updated: ShiftRecord = {
        ...currentShift,
        midShiftDrops: newMidShiftDrops,
        expectedBalance: newExpected,
        variance,
        notes: currentShift.notes ? `${currentShift.notes} | Drop: Rs.${safeAmount} (${reason})` : `Drop: Rs.${safeAmount} (${reason})`,
      };

      await posDb.shifts.put(updated);
      setCurrentShift(updated);
      playSuccessChime();
    },
    [currentShift]
  );

  const recordShiftCount = useCallback(
    async (counted: number, denominations: any, notes?: string) => {
      const variance = Number((counted - currentShift.expectedBalance).toFixed(2));
      const updated: ShiftRecord = {
        ...currentShift,
        actualCounted: counted,
        variance,
        denominations,
        notes: notes || currentShift.notes,
      };
      await posDb.shifts.put(updated);
      setCurrentShift(updated);
    },
    [currentShift]
  );

  const closeCurrentShift = useCallback(
    async (notes?: string) => {
      const closedShift: ShiftRecord = {
        ...currentShift,
        status: 'closed',
        closedAt: new Date().toISOString(),
        notes: notes || currentShift.notes,
      };
      await posDb.shifts.put(closedShift);
      setCurrentShift(closedShift);
      playSuccessChime();
    },
    [currentShift]
  );

  // Offline Sync
  const triggerManualSync = useCallback(async () => {
    setIsSyncing(true);
    try {
      await refreshProducts();
      setLastSyncTime(new Date().toLocaleTimeString());
      playSuccessChime();
    } catch (err) {
      console.error('Sync failed:', err);
    } finally {
      setIsSyncing(false);
    }
  }, [refreshProducts]);

  return (
    <POSContext.Provider
      value={{
        activeTab,
        setActiveTab,
        products,
        isLoadingProducts,
        categories,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        filteredProducts,
        refreshProducts,
        updateProductStock,
        createProductWithVariants,
        updateProduct,
        updateProductOffer,
        deleteProduct,
        addCategory,
        updateCategory,
        deleteCategory,
        customers,
        selectedCustomer,
        setSelectedCustomer,
        searchCustomerQuery,
        setSearchCustomerQuery,
        filteredCustomers,
        saveNewCustomer,
        updateCustomer,
        deleteCustomer,
        updateCustomerCredit,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        updateQuantity,
        setQuantityDirect,
        updateCartDiscount,
        clearCart,
        subtotal,
        taxAmount,
        taxRate,
        totalDue,
        itemCount,
        isCheckoutOpen,
        setIsCheckoutOpen,
        paymentSplits,
        activeTenderType,
        setActiveTenderType,
        tenderAmountInput,
        setTenderAmountInput,
        addPaymentSplit,
        removePaymentSplit,
        totalPaid,
        remainingBalance,
        changeDue,
        completeTransaction,
        parkedOrders,
        parkCurrentOrder,
        resumeParkedOrder,
        retrieveParkedOrder,
        discardParkedOrder,
        deleteParkedOrder,
        lastCompletedOrder,
        isReceiptOpen,
        setIsReceiptOpen,
        currentShift,
        updateShiftFloat,
        updateShiftDenomination,
        recordCashDrop,
        recordShiftCount,
        closeCurrentShift,
        isScannerReady,
        lastScannedCode,
        handleBarcodeInput,
        scanBarcode,
        isOnline,
        isSyncing,
        syncQueueCount,
        lastSyncTime,
        triggerManualSync,
        outletProfile,
        updateOutletProfile,
        loyaltyConfig,
        updateLoyaltyConfig,
        loyaltyRedeemedPoints,
        setLoyaltyRedeemedPoints,
        loyaltyDiscountAmount,
        currentOperator,
        operators,
        switchOperator,
        switchOperatorByPin,
        addOperator,
        updateOperator,
        deleteOperator,
        resetOperatorPin,
        toggleOperatorStatus,
        canManageUsers,
        canManageCatalog,
        canManageSettings,
        isDbConnected,
        dbDriver,
      }}
    >
      {children}
    </POSContext.Provider>
  );
};

export const usePOS = () => {
  const context = useContext(POSContext);
  if (!context) {
    throw new Error('usePOS must be used within a POSProvider');
  }
  return context;
};

export const useOptionalPOS = () => {
  return useContext(POSContext);
};
