import { LanguageCode } from './en';

export interface ReceiptTextTokens {
  billNo: string;
  cashier: string;
  date: string;
  time: string;
  customer: string;
  itemDescription: string;
  qty: string;
  rate: string;
  amount: string;
  itemsTotal: string;
  units: string;
  gstSummary: string;
  loyaltyDiscount: string;
  youSaved: string;
  grandTotal: string;
  paymentBreakdown: string;
  changeReturned: string;
  loyaltyHeader: string;
  pointsEarned: string;
  pointsRedeemed: string;
  availableBalance: string;
  worth: string;
  validityTill: string;
  footerDefault: string;
  termsHeader: string;
  pack: string;
  cash: string;
  upi: string;
  card: string;
  khata: string;
  redeem: string;
  softwareTag: string;
}

export const RECEIPT_LOCALIZED_LABELS: Record<LanguageCode, ReceiptTextTokens> = {
  en: {
    billNo: 'Bill No',
    cashier: 'Cashier',
    date: 'Date',
    time: 'Time',
    customer: 'Customer',
    itemDescription: 'Item Description',
    qty: 'Qty',
    rate: 'Rate',
    amount: 'Amount',
    itemsTotal: 'Items Total',
    units: 'units',
    gstSummary: 'CGST + SGST',
    loyaltyDiscount: 'Loyalty Points Discount',
    youSaved: 'YOU SAVED ON MRP',
    grandTotal: 'GRAND TOTAL',
    paymentBreakdown: 'Payment Breakdown',
    changeReturned: 'Change Returned',
    loyaltyHeader: '⭐ FRESH REWARDS LOYALTY',
    pointsEarned: 'Points Earned on this Bill',
    pointsRedeemed: 'Points Redeemed',
    availableBalance: 'Current Available Balance',
    worth: 'Worth',
    validityTill: 'Points validity till',
    footerDefault: 'Thank you for shopping with us! Visit again.',
    termsHeader: 'Terms',
    pack: 'Pack',
    cash: 'CASH',
    upi: 'UPI / QR',
    card: 'CARD / EDC',
    khata: 'KHATA CREDIT',
    redeem: 'REWARDS REDEEM',
    softwareTag: '*** Software: Plannest POS Retail Enterprise ***',
  },
  ta: {
    billNo: 'பில் எண் (Bill No)',
    cashier: 'காசாளர் (Cashier)',
    date: 'தேதி (Date)',
    time: 'நேரம் (Time)',
    customer: 'வாடிக்கையாளர் (Customer)',
    itemDescription: 'பொருள் விவரம் (Item)',
    qty: 'அளவு (Qty)',
    rate: 'விலை (Rate)',
    amount: 'தொகை (Amount)',
    itemsTotal: 'பொருட்கள் மொத்தம்',
    units: 'அளவுகள்',
    gstSummary: 'ஜிஎஸ்டி வரி (CGST+SGST)',
    loyaltyDiscount: 'ரிவார்டு புள்ளிகள் தள்ளுபடி',
    youSaved: 'உங்கள் மொத்த சேமிப்பு (MRP)',
    grandTotal: 'மொத்த தொகை (GRAND TOTAL)',
    paymentBreakdown: 'செலுத்திய முறை விவரம்',
    changeReturned: 'மீதம் வழங்கிய சில்லறை',
    loyaltyHeader: '⭐ பிரெஷ் ரிவார்ட்ஸ் (Fresh Rewards)',
    pointsEarned: 'இந்த பில்லில் பெற்ற புள்ளிகள்',
    pointsRedeemed: 'பயன்படுத்திய புள்ளிகள்',
    availableBalance: 'இருப்பு புள்ளிகள்',
    worth: 'மதிப்பு',
    validityTill: 'புள்ளிகள் செல்லுபடியாகும் நாள்',
    footerDefault: 'எங்கள் கடையில் வாங்கியமைக்கு நன்றி! மீண்டும் வருக!',
    termsHeader: 'விதிமுறைகள்',
    pack: 'பேக்',
    cash: 'ரொக்கம் (CASH)',
    upi: 'யுபிஐ (UPI)',
    card: 'கார்டு (CARD)',
    khata: 'காதா கடன் (KHATA)',
    redeem: 'புள்ளிகள் தள்ளுபடி (REDEEM)',
    softwareTag: '*** ஆல்பா பிஓஎஸ் ரீடெய்ல் மென்பொருள் ***',
  },
  hi: {
    billNo: 'बिल संख्या (Bill No)',
    cashier: 'कैशियर (Cashier)',
    date: 'दिनांक (Date)',
    time: 'समय (Time)',
    customer: 'ग्राहक (Customer)',
    itemDescription: 'विवरण (Item Description)',
    qty: 'मात्रा (Qty)',
    rate: 'दर (Rate)',
    amount: 'रकम (Amount)',
    itemsTotal: 'कुल वस्तुएं (Items Total)',
    units: 'नग/इकाई',
    gstSummary: 'जीएसटी कर (CGST+SGST)',
    loyaltyDiscount: 'लॉयल्टी रिवार्ड छूट',
    youSaved: 'एमआरपी पर आपकी कुल बचत',
    grandTotal: 'कुल देय राशि (GRAND TOTAL)',
    paymentBreakdown: 'भुगतान विवरण (Payment Breakdown)',
    changeReturned: 'वापस किया गया चिल्लर (Change)',
    loyaltyHeader: '⭐ फ्रेश रिवार्ड्स लॉयल्टी',
    pointsEarned: 'इस बिल पर मिले पॉइंट्स',
    pointsRedeemed: 'उपयोग किए गए पॉइंट्स',
    availableBalance: 'उपलब्ध पॉइंट्स शेष',
    worth: 'मूल्य',
    validityTill: 'पॉइंट्स वैधता तिथि',
    footerDefault: 'हमारी दुकान पर पधारने के लिए धन्यवाद! फिर आएं।',
    termsHeader: 'शर्तें',
    pack: 'पैक',
    cash: 'नकद (CASH)',
    upi: 'यूपीआई (UPI)',
    card: 'कार्ड (CARD)',
    khata: 'खाता क्रेडिट (KHATA)',
    redeem: 'रिवार्ड छूट (REDEEM)',
    softwareTag: '*** सॉफ्टवेयर: अल्फा पीओएस रिटेल ***',
  },
};

export const TENDER_NAME_LOCALIZED: Record<string, Record<LanguageCode, string>> = {
  cash: { en: 'CASH', ta: 'ரொக்கம் (Cash)', hi: 'नकद (Cash)' },
  upi: { en: 'UPI / QR', ta: 'யுபிஐ (UPI / QR)', hi: 'यूपीआई (UPI)' },
  card: { en: 'CARD / EDC', ta: 'கார்டு (Card)', hi: 'कार्ड (Card)' },
  store_credit: { en: 'KHATA / CREDIT', ta: 'காதா கடன் (Khata)', hi: 'खाता (Khata)' },
  redeem: { en: 'LOYALTY PTS', ta: 'ரிவார்டு புள்ளிகள்', hi: 'रिवार्ड पॉइंट्स' },
};
