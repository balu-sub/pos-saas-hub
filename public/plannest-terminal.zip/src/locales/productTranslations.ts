/**
 * Curated Colloquial Tamil & Hindi translations and phonetic Tanglish/Hinglish search keywords
 * for South Indian Retail Produce, Fruits, Vegetables, and Groceries.
 * Completely covers all 170+ store catalog items.
 */

export interface ProductLocalization {
  tamilName: string;
  hindiName: string;
  searchKeywords: string[];
}

export const PRODUCT_TRANSLATIONS_DICTIONARY: Record<string, ProductLocalization> = {
  // Fruits
  'Indian Apple': {
    tamilName: 'இந்திய ஆப்பிள்',
    hindiName: 'भारतीय सेब',
    searchKeywords: ['apple', 'aappil', 'appil', 'seb', 'seb fruit']
  },
  'USA Apple': {
    tamilName: 'அமெரிக்க ஆப்பிள்',
    hindiName: 'इम्पोर्टेड सेब (USA)',
    searchKeywords: ['usa apple', 'apple', 'appil', 'seb', 'imported seb']
  },
  'Royal Gala Apple': {
    tamilName: 'ராயல் காலா ஆப்பிள்',
    hindiName: 'रॉयल गाला सेब',
    searchKeywords: ['gala apple', 'royal gala', 'appil', 'gala seb']
  },
  'Royal Kash Apple': {
    tamilName: 'காஷ்மீர் ஆப்பிள்',
    hindiName: 'कश्मीरी सेब',
    searchKeywords: ['kashmir apple', 'kashmiri apple', 'appil', 'kashmiri seb']
  },
  'Sweet Lime': {
    tamilName: 'சாத்துக்குடி',
    hindiName: 'मौसंबी',
    searchKeywords: ['sathukudi', 'sathukodi', 'mosambi', 'saathukudi', 'mausambi']
  },
  'Sapota': {
    tamilName: 'சப்போட்டா',
    hindiName: 'चीकू (सपोटा)',
    searchKeywords: ['sapota', 'sapotta', 'chiku', 'chikoo']
  },
  'Green Grape': {
    tamilName: 'பச்சை திராட்சை',
    hindiName: 'हरा अंगूर',
    searchKeywords: ['pachai dratchai', 'thiratchai', 'pacha thiratchai', 'grapes', 'hara angoor', 'angoor']
  },
  'Juice Grape': {
    tamilName: 'பன்னீர் திராட்சை',
    hindiName: 'काला अंगूर (जूस)',
    searchKeywords: ['paneer dratchai', 'juice thiratchai', 'karuppu thiratchai', 'grapes', 'kala angoor']
  },
  'Australian Grape': {
    tamilName: 'ஆஸ்திரேலியன் திராட்சை',
    hindiName: 'ऑस्ट्रेलियन अंगूर',
    searchKeywords: ['australian dratchai', 'seedless grapes', 'angoor']
  },
  'Blue Berry': {
    tamilName: 'ப்ளூபெர்ரி பழம்',
    hindiName: 'ब्लूबेरी फल',
    searchKeywords: ['blueberry', 'berry', 'blue berry']
  },
  'China Pear': {
    tamilName: 'பேரிக்காய்',
    hindiName: 'नाशपाती (बब्बूगोशा)',
    searchKeywords: ['berikai', 'pear', 'perikai', 'peerikai', 'nashpati', 'nashpati fruit']
  },
  'Mulberry': {
    tamilName: 'மல்பெரி பழம்',
    hindiName: 'शहतूत (मलबेरी)',
    searchKeywords: ['mulberry', 'mulberi', 'shahtoot', 'sahtoot']
  },
  'Plums': {
    tamilName: 'பிளம்ஸ் பழம்',
    hindiName: 'आलूबुखारा (प्लम)',
    searchKeywords: ['plums', 'alam', 'aaloo bukhara', 'plum']
  },
  'Papaya': {
    tamilName: 'பப்பாளி பழம்',
    hindiName: 'पपीता',
    searchKeywords: ['pappali', 'pappalipazham', 'papaya', 'papita']
  },
  'Rambutan': {
    tamilName: 'ரம்புட்டான்',
    hindiName: 'रामबुतान फल',
    searchKeywords: ['rambutan', 'rambuttan']
  },
  'Watermelon': {
    tamilName: 'தர்பூசணி',
    hindiName: 'तरबूज',
    searchKeywords: ['tharboosani', 'dharboosani', 'thanneer pazham', 'watermelon', 'tarbooj', 'tarbuj']
  },
  'Green Watermelon': {
    tamilName: 'வரி தர்பூசணி',
    hindiName: 'हरा तरबूज',
    searchKeywords: ['vari dharboosani', 'pachai dharboosani', 'tarbuj']
  },
  'Butter Fruit': {
    tamilName: 'வெண்ணெய் பழம் (அவகேடோ)',
    hindiName: 'एवोकाडो (बटर फ्रूट)',
    searchKeywords: ['butter fruit', 'avocado', 'vennai pazham', 'avocado fruit']
  },
  'Litchi': {
    tamilName: 'லிச்சி பழம்',
    hindiName: 'लीची',
    searchKeywords: ['litchi', 'lichi', 'lychee']
  },
  'Amla': {
    tamilName: 'பெரிய நெல்லிக்காய்',
    hindiName: 'आंवला (बड़ा)',
    searchKeywords: ['nelli', 'nellikkai', 'periya nellikkai', 'amla', 'aanwala']
  },
  'Mangosteen': {
    tamilName: 'மங்குஸ்தான் பழம்',
    hindiName: 'मैंगोस्टीन फल',
    searchKeywords: ['mangosteen', 'mangusthan']
  },
  'Naval Pazham': {
    tamilName: 'நாவல் பழம் (ஜாமூன்)',
    hindiName: 'जामुन फल',
    searchKeywords: ['naval pazham', 'naaval', 'jamun', 'jamun fruit']
  },
  'Custard Apple': {
    tamilName: 'சீதாப்பழம்',
    hindiName: 'सीताफल (शरीफा)',
    searchKeywords: ['seethapazham', 'seetha', 'aathapazham', 'sitaphal', 'sharifa']
  },
  'Elantha Pazham': {
    tamilName: 'இலந்தை பழம்',
    hindiName: 'बेर फल (जुजुबे)',
    searchKeywords: ['elandhai', 'elanthapazham', 'jujube', 'elantha', 'ber']
  },
  'Passion Fruit': {
    tamilName: 'பேஷன் ஃப்ரூட்',
    hindiName: 'पैशन फ्रूट',
    searchKeywords: ['passion fruit']
  },
  'Yellow Banana': {
    tamilName: 'மஞ்சள் வாழைப்பழம்',
    hindiName: 'पीला केला',
    searchKeywords: ['manjal vazhai', 'banana', 'vazhaipazham', 'kela', 'peela kela']
  },
  'Rasthali': {
    tamilName: 'ரஸ்தாளி வாழைப்பழம்',
    hindiName: 'रसथाली केला',
    searchKeywords: ['rasthali', 'rasthali vazhai', 'banana', 'kela']
  },
  'Karpuravalli': {
    tamilName: 'கற்பூரவள்ளி வாழைப்பழம்',
    hindiName: 'कर्पूरवल्ली केला',
    searchKeywords: ['karpuravalli', 'karpooravalli', 'banana', 'kela']
  },
  'Hill Banana': {
    tamilName: 'மலை வாழைப்பழம்',
    hindiName: 'पहाड़ी केला',
    searchKeywords: ['malai vazhai', 'sirumalai vazhai', 'hill banana', 'pahadi kela']
  },
  'Elaki Banana': {
    tamilName: 'ஏலக்கி வாழைப்பழம்',
    hindiName: 'इलायची केला (छोटा)',
    searchKeywords: ['elakki', 'yelakki', 'elakki vazhai', 'elakki kela']
  },
  'Morris': {
    tamilName: 'மாரிஸ் வாழைப்பழம்',
    hindiName: 'मॉरिस केला',
    searchKeywords: ['morris', 'morris vazhai', 'green banana', 'kela']
  },
  'Nendhiram': {
    tamilName: 'நேந்திரம் பழம் (கேரளா)',
    hindiName: 'नेन्द्रन केला (केरल)',
    searchKeywords: ['nendran', 'nendhiran', 'kerala banana', 'nendran kela']
  },
  'Red Banana': {
    tamilName: 'செவ்வாழைப்பழம்',
    hindiName: 'लाल केला',
    searchKeywords: ['sevvaazhai', 'sevazhai', 'red banana', 'laal kela']
  },
  'Kirini': {
    tamilName: 'கிர்ணி பழம்',
    hindiName: 'खरबूजा (किरणी)',
    searchKeywords: ['kirni', 'muskmelon', 'kirini pazham', 'kharbooja', 'kharbuja']
  },
  'Pineapple': {
    tamilName: 'அன்னாசிப்பழம்',
    hindiName: 'अनानास',
    searchKeywords: ['annasi', 'annasipazham', 'pineapple', 'ananas']
  },
  'Strawberry': {
    tamilName: 'ஸ்ட்ராபெர்ரி',
    hindiName: 'स्ट्रॉबेरी',
    searchKeywords: ['strawberry', 'strawberi']
  },
  'Kiwi': {
    tamilName: 'கிவி பழம்',
    hindiName: 'कीवी फल',
    searchKeywords: ['kiwi', 'kivi']
  },
  'Anar Box': {
    tamilName: 'மாதுளம்பழம் (பெட்டி)',
    hindiName: 'अनार (बॉक्स)',
    searchKeywords: ['mathulai', 'madhulam', 'pomegranate', 'anar']
  },
  'Anar Loose': {
    tamilName: 'மாதுளம்பழம் (உதிரி)',
    hindiName: 'अनार (खुला)',
    searchKeywords: ['mathulai', 'madhulampazham', 'pomegranate', 'anar']
  },
  'Green Banana': {
    tamilName: 'பச்சை வாழைப்பழம்',
    hindiName: 'हरा केला',
    searchKeywords: ['pachai vazhai', 'green banana', 'kela', 'hara kela']
  },
  'Jack Fruit': {
    tamilName: 'பலாப்பழம் சுளை',
    hindiName: 'कटहल फल (मीठा)',
    searchKeywords: ['pala', 'palapazham', 'jackfruit', 'kathal']
  },
  'Cherry Fruit': {
    tamilName: 'செர்ரி பழம்',
    hindiName: 'चेरी फल',
    searchKeywords: ['cherry', 'cherri']
  },
  'Lychee Fruit': {
    tamilName: 'லிச்சி பழம்',
    hindiName: 'लीची फल',
    searchKeywords: ['lychee', 'lichi']
  },
  'USA Orange': {
    tamilName: 'அமெரிக்க ஆரஞ்சு',
    hindiName: 'इम्पोर्टेड संतरा (USA)',
    searchKeywords: ['orange', 'aranju', 'usa orange', 'santra']
  },
  'Orange': {
    tamilName: 'நாக்பூர் ஆரஞ்சு',
    hindiName: 'नागपुर संतरा',
    searchKeywords: ['orange', 'aranju', 'nagpur orange', 'santra']
  },
  'Kamala Big': {
    tamilName: 'கமலா ஆரஞ்சு (பெரியது)',
    hindiName: 'कमला संतरा (बड़ा)',
    searchKeywords: ['kamala', 'kamala orange', 'mandarin', 'santra']
  },
  'Kamala': {
    tamilName: 'கமலா ஆரஞ்சு',
    hindiName: 'कमला संतरा',
    searchKeywords: ['kamala', 'kamala orange', 'santra']
  },
  'Kalaaka': {
    tamilName: 'களாக்காய்',
    hindiName: 'करौंदा फल',
    searchKeywords: ['kalakai', 'kalakkai', 'cranberry', 'karonda']
  },
  'Uilanga': {
    tamilName: 'விளாம்பழம்',
    hindiName: 'बेल / कैथ फल (Wood Apple)',
    searchKeywords: ['vilampazham', 'wood apple', 'vilam', 'bael', 'kaith']
  },
  'Mulampazham': {
    tamilName: 'முலாம் பழம்',
    hindiName: 'ककड़ी / खरबूजा',
    searchKeywords: ['mulampazham', 'muskmelon', 'mulaam', 'kharbuja']
  },
  'Dragon Fruit': {
    tamilName: 'டிராகன் பழம்',
    hindiName: 'ड्रैगन फ्रूट',
    searchKeywords: ['dragon fruit', 'dragon']
  },
  'Dry Cherry': {
    tamilName: 'உலர் செர்ரி பழம்',
    hindiName: 'सूखी चेरी (ड्राई फ्रूट)',
    searchKeywords: ['dry cherry', 'cherries', 'dry fruits']
  },

  // Mangoes
  'Mango': {
    tamilName: 'நாட்டு மாம்பழம்',
    hindiName: 'देसी आम',
    searchKeywords: ['mambazham', 'manga', 'mango', 'aam', 'desi aam']
  },
  'Banganapalli': {
    tamilName: 'பங்கனப்பள்ளி மாம்பழம்',
    hindiName: 'बंगनापल्ली आम (सफेदा)',
    searchKeywords: ['banganapalli', 'benishan', 'mambazham', 'safeda aam', 'aam']
  },
  'Alphonso': {
    tamilName: 'அல்போன்சா மாம்பழம்',
    hindiName: 'अल्फांसो आम (हापुस)',
    searchKeywords: ['alphonso', 'happus', 'mambazham', 'alphonso aam', 'hapus']
  },
  'Javvadhu': {
    tamilName: 'ஜவ்வாது மாம்பழம்',
    hindiName: 'जव्वादु आम',
    searchKeywords: ['javvadhu', 'javadhu mango', 'aam']
  },
  'Malgova': {
    tamilName: 'மல்கோவா மாம்பழம்',
    hindiName: 'मालगोवा आम',
    searchKeywords: ['malgova', 'malgoa', 'mambazham', 'aam']
  },
  'Kalapadi': {
    tamilName: 'காலாப்பாடி மாம்பழம்',
    hindiName: 'कालापाड़ी आम',
    searchKeywords: ['kalapadi', 'kalapadi mango', 'aam']
  },
  'Sindhooram': {
    tamilName: 'செந்தூரம் மாம்பழம்',
    hindiName: 'सिंदूरी आम',
    searchKeywords: ['sindooram', 'senthooram', 'mambazham', 'sindoori aam', 'aam']
  },
  'Bangalora': {
    tamilName: 'பெங்களூரா (கிளிமூக்கு)',
    hindiName: 'तोतापरी / बेंगलोरा आम',
    searchKeywords: ['bangalora', 'kilimooku', 'totapuri', 'manga', 'totapuri aam']
  },
  'Imam Pasand': {
    tamilName: 'இமாம் பசந்த் மாம்பழம்',
    hindiName: 'इमाम पसंद आम (हिमायत)',
    searchKeywords: ['imam pasand', 'himayat', 'mambazham', 'aam']
  },
  'Neelam': {
    tamilName: 'நீலம் மாம்பழம்',
    hindiName: 'नीलम आम',
    searchKeywords: ['neelam', 'neelam mango', 'mambazham', 'neelam aam']
  },
  'Maavu': {
    tamilName: 'மாவு மாம்பழம்',
    hindiName: 'मावू आम',
    searchKeywords: ['maavu', 'maavu mango', 'aam']
  },
  'Kurinji': {
    tamilName: 'குறிஞ்சி மாம்பழம்',
    hindiName: 'कुरिंजी आम',
    searchKeywords: ['kurinji', 'kurinji mango', 'aam']
  },
  'Rumani': {
    tamilName: 'ருமானி மாம்பழம்',
    hindiName: 'रुमानी आम',
    searchKeywords: ['rumani', 'roomani', 'mambazham', 'aam']
  },

  // Vegetables
  'Onion': {
    tamilName: 'பெரிய வெங்காயம் (பல்லாரி)',
    hindiName: 'प्याज (कांदा)',
    searchKeywords: ['vengayam', 'bellary', 'onion', 'periya vengayam', 'pyaaz', 'kanda']
  },
  'Tomato': {
    tamilName: 'தக்காளி பழம்',
    hindiName: 'टमाटर',
    searchKeywords: ['thakkali', 'thakkaali', 'tomato', 'nattu thakkali', 'tamatar']
  },
  'Small Tomato': {
    tamilName: 'நாட்டு தக்காளி',
    hindiName: 'देसी टमाटर',
    searchKeywords: ['nattu thakkali', 'small tomato', 'thakkali', 'desi tamatar']
  },
  'Potato': {
    tamilName: 'உருளைக்கிழங்கு',
    hindiName: 'आलू',
    searchKeywords: ['urulai', 'urulaikilangu', 'potato', 'aalu', 'aloo']
  },
  'Sweet Potato': {
    tamilName: 'சர்க்கரைவள்ளிக் கிழங்கு',
    hindiName: 'शकरकंद',
    searchKeywords: ['sakkaravalli', 'sakkaravallikilangu', 'sweet potato', 'shakarkand']
  },
  'Panankilangu': {
    tamilName: 'பனங்கிழங்கு',
    hindiName: 'ताड़ की जड़ (पाम रूट)',
    searchKeywords: ['panangilangu', 'panankilangu', 'palmyra root']
  },
  'Coconut': {
    tamilName: 'தேங்காய்',
    hindiName: 'ताजा नारियल (पानी वाला)',
    searchKeywords: ['thengai', 'thenga', 'coconut', 'koottu thengai', 'nariyal']
  },
  'Poosani': {
    tamilName: 'வெள்ளை பூசணிக்காய்',
    hindiName: 'पेठा / सफेद कद्दू',
    searchKeywords: ['poosanikai', 'vella poosani', 'ash gourd', 'petha', 'safed kaddu']
  },
  'Corn': {
    tamilName: 'மக்காச்சோளம் (ஸ்வீட் கார்ன்)',
    hindiName: 'भुट्टा / मकई (स्वीट कॉर्न)',
    searchKeywords: ['solam', 'makkacholam', 'sweet corn', 'corn', 'bhutta', 'makka']
  },
  'Lemon': {
    tamilName: 'எலுமிச்சம்பழம்',
    hindiName: 'नींबू',
    searchKeywords: ['elumichai', 'elumichampazham', 'lemon', 'nimbu']
  },
  'Vellarikkai': {
    tamilName: 'வெள்ளரிக்காய்',
    hindiName: 'खीरा / ककड़ी',
    searchKeywords: ['vellarika', 'vellarikkai', 'cucumber', 'kheera', 'kakdi']
  },
  'Mushroom': {
    tamilName: 'காளான் பாக்கெட்',
    hindiName: 'मशरूम (कुकुरमुत्ता)',
    searchKeywords: ['kalan', 'kaalaan', 'mushroom', 'mashrum']
  },
  'Mangai': {
    tamilName: 'பச்சை மாங்காய்',
    hindiName: 'कच्चा आम (अमचूर / केरी)',
    searchKeywords: ['mangai', 'manga', 'raw mango', 'kaccha aam', 'keri']
  },
  'Surakkai': {
    tamilName: 'சுரைக்காய்',
    hindiName: 'लौकी / घिया',
    searchKeywords: ['surakkai', 'bottle gourd', 'suraikai', 'lauki', 'ghiya']
  },
  'Vazhaikkai': {
    tamilName: 'பச்சை வாழைக்காய்',
    hindiName: 'कच्चा केला',
    searchKeywords: ['vazhaikkai', 'vazhakkai', 'raw banana', 'kaccha kela']
  },
  'Kothavarangai': {
    tamilName: 'கொத்தவரங்காய்',
    hindiName: 'ग्वार फली',
    searchKeywords: ['kothavarangai', 'cluster beans', 'gwar phali', 'gwar']
  },
  'Seppankizhangu': {
    tamilName: 'சேப்பங்கிழங்கு',
    hindiName: 'अरबी (अरवी जड़)',
    searchKeywords: ['seppankizhangu', 'seppan kizhangu', 'taro', 'arbi', 'arvi']
  },
  'Pattani': {
    tamilName: 'பச்சை பட்டாணி',
    hindiName: 'ताजा हरी मटर',
    searchKeywords: ['pattani', 'peas', 'green peas', 'matar', 'hari matar']
  },
  'Mullangi': {
    tamilName: 'முள்ளங்கி',
    hindiName: 'सफेद मूली',
    searchKeywords: ['mullangi', 'radish', 'mooli']
  },
  'Cabbage': {
    tamilName: 'முட்டைக்கோஸ்',
    hindiName: 'पत्ता गोभी / बंदगोभी',
    searchKeywords: ['muttaikose', 'cabbage', 'kose', 'patta gobhi', 'band gobhi']
  },
  'Kovaikkai': {
    tamilName: 'கோவக்காய்',
    hindiName: 'कुंदरू (टिंडोरा)',
    searchKeywords: ['kovaikkai', 'kovakai', 'ivy gourd', 'kundru', 'tindora']
  },
  'Vendakkai': {
    tamilName: 'வெண்டைக்காய்',
    hindiName: 'भिंडी (लेडी फिंगर)',
    searchKeywords: ['vendakkai', 'vendakai', 'ladys finger', 'okra', 'bhindi']
  },
  'Kathirikkai': {
    tamilName: 'கத்தரிக்காய்',
    hindiName: 'बैंगन (भट्टा)',
    searchKeywords: ['kathirikkai', 'kathirikai', 'brinjal', 'eggplant', 'baingan']
  },
  'Sundaikkai': {
    tamilName: 'சுண்டைக்காய்',
    hindiName: 'सुंडईकाई (टर्की बेरी)',
    searchKeywords: ['sundaikkai', 'sundakai', 'turkey berry']
  },
  'Karunai': {
    tamilName: 'கருணைக்கிழங்கு',
    hindiName: 'जिमीकंद / सूरन (ओल)',
    searchKeywords: ['karunai', 'karunaikilangu', 'yam', 'senai', 'suran', 'jimikand']
  },
  'Green Chilli': {
    tamilName: 'பச்சை மிளகாய்',
    hindiName: 'हरी मिर्च',
    searchKeywords: ['pachai milagai', 'green chilli', 'milagai', 'hari mirch', 'mirchi']
  },
  'Ginger': {
    tamilName: 'இஞ்சி',
    hindiName: 'ताजा अदरक',
    searchKeywords: ['inji', 'ginger', 'adrak']
  },
  'Carrot': {
    tamilName: 'கேரட்',
    hindiName: 'गाजर',
    searchKeywords: ['carrot', 'kerat', 'gajar']
  },
  'Beans': {
    tamilName: 'பீன்ஸ்',
    hindiName: 'फ्रेंच बीन्स / फलियां',
    searchKeywords: ['beans', 'french beans', 'phali']
  },
  'Drumstick': {
    tamilName: 'முருங்கைக்காய்',
    hindiName: 'सहजन की फली (ड्रमस्टिक)',
    searchKeywords: ['murungaikkai', 'drumstick', 'murungai', 'sahjan', 'sehjan']
  },
  'Avarakkai': {
    tamilName: 'அவரைக்காய்',
    hindiName: 'सेम की फली',
    searchKeywords: ['avarakkai', 'broad beans', 'avarai', 'sem phali']
  },
  'Beetroot': {
    tamilName: 'பீட்ரூட்',
    hindiName: 'चुकंदर (बीटरूट)',
    searchKeywords: ['beetroot', 'bitroot', 'chukandar']
  },
  'Broccoli': {
    tamilName: 'ப்ராக்கோலி',
    hindiName: 'ब्रोकोली (हरी गोभी)',
    searchKeywords: ['broccoli', 'brokoli']
  },
  'Cauliflower': {
    tamilName: 'காலிஃப்ளவர்',
    hindiName: 'फूल गोभी',
    searchKeywords: ['cauliflower', 'kaliflower', 'phool gobhi', 'gobhi']
  },
  'Chow Chow': {
    tamilName: 'சௌ சௌ காய்',
    hindiName: 'चाउ चाउ / इस्कुस',
    searchKeywords: ['chow chow', 'chayote', 'sawo sawo', 'iskus']
  },
  'Snake Gourd': {
    tamilName: 'புடலங்காய்',
    hindiName: 'चिचिंडा (पड़वल / स्नेक गॉर्ड)',
    searchKeywords: ['pudalangai', 'snake gourd', 'podalangai', 'chichinda']
  },
  'Capsicum': {
    tamilName: 'குடைமிளகாய்',
    hindiName: 'शिमला मिर्च',
    searchKeywords: ['kudaimilagai', 'capsicum', 'bell pepper', 'shimla mirch']
  },
  'Malli': {
    tamilName: 'கொத்தமல்லி தழை',
    hindiName: 'ताजा हरा धनिया',
    searchKeywords: ['malli', 'kothamalli', 'coriander', 'hara dhaniya', 'kothmir']
  },
  'Pudina': {
    tamilName: 'புதினா தழை',
    hindiName: 'ताजा पुदीना पत्ता',
    searchKeywords: ['pudina', 'mint', 'pudina patta']
  },
  'Garlic': {
    tamilName: 'பூண்டு',
    hindiName: 'लहसुन (देसी)',
    searchKeywords: ['poondu', 'garlic', 'vellapoondu', 'lahsun', 'lasan']
  },
  'Sambar Onion': {
    tamilName: 'சாம்பார் சின்ன வெங்காயம்',
    hindiName: 'छोटा प्याज (सांभर प्याज)',
    searchKeywords: ['sambar vengayam', 'chinna vengayam', 'shallots', 'chhota pyaaz']
  },
  'Pavakkai': {
    tamilName: 'பாகற்காய்',
    hindiName: 'करेला',
    searchKeywords: ['pavakkai', 'pavakai', 'bitter gourd', 'karela']
  },
  'Vazhai Ilai': {
    tamilName: 'தலை வாழை இலை',
    hindiName: 'केले का पत्ता',
    searchKeywords: ['vazhai ilai', 'banana leaf', 'ilai', 'kele ka patta']
  },
  'Vazhai Poo': {
    tamilName: 'வாழைப்பூ',
    hindiName: 'केले का फूल',
    searchKeywords: ['vazhai poo', 'banana flower', 'kele ka phool']
  },
  'Noolkol': {
    tamilName: 'நூல்கோல் கிழங்கு',
    hindiName: 'गांठ गोभी (नवलकोल)',
    searchKeywords: ['noolkol', 'kohlrabi', 'ganth gobhi']
  },
  'Alwalli': {
    tamilName: 'மரவள்ளிக்கிழங்கு (ஆல்வள்ளி)',
    hindiName: 'कसावा / कप्पा (साबूदाना कंद)',
    searchKeywords: ['alwalli', 'maravalli', 'kizhangu', 'allwalli', 'tapioca', 'kasava', 'kappa']
  },
  'Mudauattukal': {
    tamilName: 'முடவாட்டுக்கால் கிழங்கு',
    hindiName: 'मुदावट्टुकल जड़',
    searchKeywords: ['mudavattukal', 'mudavattu', 'mudakathan']
  },
  'Sakkarai Valli': {
    tamilName: 'சர்க்கரைவள்ளிக் கிழங்கு',
    hindiName: 'शकरकंद (मीठा आलू)',
    searchKeywords: ['sakkarai valli', 'sweet potato', 'shakarkand']
  },
  'Peerkangai': {
    tamilName: 'பீர்க்கங்காய்',
    hindiName: 'तोरई (तुरई)',
    searchKeywords: ['peerkangai', 'peerkankai', 'ridge gourd', 'torai', 'turai']
  },
  'Keerai': {
    tamilName: 'பசலை / அரைக்கீரை கட்டு',
    hindiName: 'हरी साग / पालक गड्डी',
    searchKeywords: ['keerai', 'greens', 'spinach', 'araikeerai', 'palak', 'saag']
  },

  // Groceries & Provisions
  'Paagu Vellam': {
    tamilName: 'பாகு வெல்லம் (மண்டை வெல்லம்)',
    hindiName: 'देसी गुड़ (गुड़ भेली)',
    searchKeywords: ['vellam', 'jaggery', 'paagu vellam', 'nattu vellam', 'gud', 'jaggery']
  },
  'Aval': {
    tamilName: 'அவல் பாக்கெட்',
    hindiName: 'पोहा (चिवड़ा)',
    searchKeywords: ['aval', 'poha', 'flattened rice', 'chivda']
  },
  'Kadala': {
    tamilName: 'சுண்டல் கடலை (கருப்பு கடலை)',
    hindiName: 'काला चना (देसी चना)',
    searchKeywords: ['kadalai', 'kadala', 'chana', 'kondakadalai', 'kala chana']
  },
  'Country Sugar': {
    tamilName: 'நாட்டுச் சர்க்கரை',
    hindiName: 'देशी खांड / भूरा शक्कर',
    searchKeywords: ['nattu sakkarai', 'brown sugar', 'organic sugar', 'desi khand', 'shakkar']
  },
  'Kambu': {
    tamilName: 'நாட்டு கம்பு தானியம்',
    hindiName: 'बाजरा अनाज (देसी)',
    searchKeywords: ['kambu', 'bajra', 'pearl millet', 'bajra anaj']
  },
  'Puli': {
    tamilName: 'நாட்டு புளி',
    hindiName: 'देसी इमली',
    searchKeywords: ['puli', 'tamarind', 'nattu puli', 'imli']
  },
  'Puli 500gm': {
    tamilName: 'நாட்டு புளி 500g',
    hindiName: 'देसी इमली (500g)',
    searchKeywords: ['puli 500g', 'tamarind', 'puli', 'imli 500g']
  },
  'Gram Dal': {
    tamilName: 'கடலைப்பருப்பு',
    hindiName: 'चना दाल',
    searchKeywords: ['kadalai paruppu', 'chana dal', 'paruppu', 'dal']
  },
  'Toor Daal': {
    tamilName: 'துவரம்பருப்பு (முதல் தரம்)',
    hindiName: 'अरहर / तुवर दाल',
    searchKeywords: ['toor dal', 'thuvaram paruppu', 'paruppu', 'arhar dal', 'tuvar dal']
  },
  'Rajas Dates': {
    tamilName: 'ராஜாஸ் பேரீச்சம்பழம்',
    hindiName: 'राजास खजूर',
    searchKeywords: ['dates', 'perichampazham', 'rajas dates', 'khajoor']
  },
  'Lion Dates': {
    tamilName: 'லயன் பேரீச்சம்பழம்',
    hindiName: 'लायन खजूर',
    searchKeywords: ['lion dates', 'perichampazham', 'dates', 'khajoor']
  },
  'Gokulam Dates': {
    tamilName: 'கோகுலம் பேரீச்சம்பழம்',
    hindiName: 'गोकुलम खजूर',
    searchKeywords: ['gokulam dates', 'dates', 'perichai', 'khajoor']
  },
  'Kimia Dates': {
    tamilName: 'கீமியா கருப்பு பேரீச்சம்பழம்',
    hindiName: 'कीमिया काला खजूर',
    searchKeywords: ['kimia dates', 'dates', 'kamia dates', 'perichai', 'khajoor']
  },
  'Ground Nut': {
    tamilName: 'வேர்க்கடலை / நிலக்கடலை',
    hindiName: 'कच्ची मूंगफली दाना',
    searchKeywords: ['verkkadalai', 'peanuts', 'groundnut', 'kadalai', 'moongfali']
  },
  'K.P. Grocery': {
    tamilName: 'கே.பி. மளிகைப் பொருட்கள்',
    hindiName: 'के.पी. किराना सामान',
    searchKeywords: ['grocery', 'maligai', 'kirana']
  },
  'K.P. Dry Fruit': {
    tamilName: 'கே.பி. உலர் பழங்கள்',
    hindiName: 'के.पी. ड्राई फ्रूट्स',
    searchKeywords: ['dry fruits', 'kismis', 'badam', 'cashew']
  },
  'Nuts N Dry Fruit': {
    tamilName: 'நட்ஸ் & உலர் பழங்கள்',
    hindiName: 'ड्राई फ्रूट्स और नट्स',
    searchKeywords: ['nuts', 'dry fruits', 'mundhiri', 'badam', 'kaju']
  },
  'K.P. Oil': {
    tamilName: 'கே.பி. சமையல் எண்ணெய்',
    hindiName: 'के.पी. कुकिंग ऑयल',
    searchKeywords: ['oil', 'ennai', 'cooking oil', 'tel']
  },
  'Oil': {
    tamilName: 'சமையல் எண்ணெய்',
    hindiName: 'शुद्ध खाद्य तेल',
    searchKeywords: ['oil', 'ennai', 'cooking oil', 'sunflower oil', 'tel']
  },
  'U U Health': {
    tamilName: 'யு யு ஹெல்த் மிக்ஸ் சத்துமாவு',
    hindiName: 'यू यू हेल्थ मिक्स (सत्तू पाउडर)',
    searchKeywords: ['health mix', 'sathu maavu', 'u u health', 'sattu']
  },
  'Diamond Tea': {
    tamilName: 'டைமண்ட் டீத்தூள்',
    hindiName: 'डायमंड चाय पत्ती',
    searchKeywords: ['diamond tea', 'tea', 'theeneer', 'chai patti', 'chai']
  },
  'Badam Small': {
    tamilName: 'பாதாம் பருப்பு (சிறியது)',
    hindiName: 'बादाम गिरी (छोटा)',
    searchKeywords: ['badam', 'badham', 'almonds']
  },
  'Badam Big': {
    tamilName: 'பாதாம் பருப்பு (பெரியது)',
    hindiName: 'कैलिफोर्निया बादाम (बड़ा)',
    searchKeywords: ['badam big', 'badham', 'almonds']
  },
  'Mundhiri': {
    tamilName: 'முந்திரிப்பருப்பு (Cashew)',
    hindiName: 'काजू गिरी (W320)',
    searchKeywords: ['mundhiri', 'cashew', 'kaju']
  },
  'Dhiratchai': {
    tamilName: 'உலர் திராட்சை (கிஸ்மிஸ்)',
    hindiName: 'किशमिश (द्राक्ष)',
    searchKeywords: ['dhiratchai', 'kismis', 'raisins', 'dratchai', 'kishmish']
  },
  'Pista': {
    tamilName: 'பிஸ்தா பருப்பு',
    hindiName: 'पिस्ता गिरी',
    searchKeywords: ['pista', 'pistachio']
  },
  'Jauvadhu': {
    tamilName: 'ஜவ்வாது வாசனை பவுடர்',
    hindiName: 'जव्वादु खुशबूदार पाउडर',
    searchKeywords: ['javadhu', 'jauvadhu', 'fragrance']
  },
  'Red Chilli': {
    tamilName: 'காய்ந்த மிளகாய் (குண்டு/நீட்டு)',
    hindiName: 'सूखी लाल मिर्च (खड़ी)',
    searchKeywords: ['red chilli', 'kanja milagai', 'vara milagai', 'sukhi lal mirch']
  },
  'Dhaniya': {
    tamilName: 'தனியா (மல்லி விதை)',
    hindiName: 'साबुत धनिया बीज',
    searchKeywords: ['dhaniya', 'dhania', 'coriander seeds', 'malli', 'sabut dhaniya']
  },
  'Kadugu 100': {
    tamilName: 'கடுகு 100g பாக்கெட்',
    hindiName: 'राई / सरसों (100g)',
    searchKeywords: ['kadugu', 'mustard', 'sarson', 'rai']
  },
  'Seeragam 100': {
    tamilName: 'சீரகம் 100g பாக்கெட்',
    hindiName: 'साबुत जीरा (100g)',
    searchKeywords: ['seeragam', 'jeera', 'cumin', 'jeera 100g']
  },
  'Pepper 100': {
    tamilName: 'கருப்பு மிளகு 100g',
    hindiName: 'काली मिर्च (100g)',
    searchKeywords: ['pepper', 'milagu', 'black pepper', 'kali mirch']
  },
  'Vendhayam': {
    tamilName: 'வெந்தயம் பாக்கெட்',
    hindiName: 'मेथी दाना पैकेट',
    searchKeywords: ['vendhayam', 'vendayam', 'fenugreek', 'methi dana']
  },

  // Dairy
  'Curd': {
    tamilName: 'பிரெஷ் தயிர் பாக்கெட்',
    hindiName: 'ताजा पैकेट दही',
    searchKeywords: ['thayir', 'curd', 'dahi', 'yogurt']
  },
  'Paneer': {
    tamilName: 'பிரெஷ் பன்னீர் பாக்கெட்',
    hindiName: 'ताजा मलाई पनीर',
    searchKeywords: ['paneer', 'panir', 'cottage cheese']
  },
  'GRB Gheee': {
    tamilName: 'ஜி.ஆர்.பி சுத்த நெய்',
    hindiName: 'जी.आर.बी शुद्ध देसी घी',
    searchKeywords: ['grb ghee', 'nei', 'ghee', 'pure ghee', 'deshi ghee']
  },
  'Arun Ice Cream': {
    tamilName: 'அருண் ஐஸ்கிரீம்',
    hindiName: 'अरुण आइसक्रीम',
    searchKeywords: ['arun ice cream', 'ice cream', 'kulfi']
  },
  'Butter': {
    tamilName: 'சுத்த வெண்ணெய் பாக்கெட்',
    hindiName: 'ताजा मक्खन (बटर)',
    searchKeywords: ['butter', 'vennai', 'makkhan']
  },
  'Arokya Green': {
    tamilName: 'ஆரோக்கியா கிரீன் பால் (500ml)',
    hindiName: 'आरोग्या ग्रीन दूध (500ml)',
    searchKeywords: ['arokya green', 'arokya milk', 'pal', 'paal', 'green milk', 'doodh']
  },
  'Arokya Orange': {
    tamilName: 'ஆரோக்கியா ஆரஞ்சு பால் (500ml)',
    hindiName: 'आरोग्या ऑरेंज फुल क्रीम दूध (500ml)',
    searchKeywords: ['arokya orange', 'arokya milk', 'orange milk', 'paal', 'doodh']
  },

  // Beverages & Snacks
  'Milk Shake': {
    tamilName: 'மில்க் ஷேக்',
    hindiName: 'मिल्क शेक बोतल',
    searchKeywords: ['milk shake', 'shake', 'badam milk']
  },
  'Cool Drink': {
    tamilName: 'குளிர்பானம் பாட்டில்',
    hindiName: 'कोल्ड ड्रिंक',
    searchKeywords: ['cool drink', 'juice', 'soda', 'cold drink']
  },
  'Cool Drinks': {
    tamilName: 'குளிர்பானங்கள்',
    hindiName: 'कोल्ड ड्रिंक्स',
    searchKeywords: ['cool drinks', 'juice', 'soda', 'cold drinks']
  },
  'Hatsun Juice': {
    tamilName: 'ஹட்சன் பிரெஷ் ஜூஸ்',
    hindiName: 'हैटसन फ्रेश जूस',
    searchKeywords: ['hatsun juice', 'hatsun', 'juice']
  },
  'Biscuits': {
    tamilName: 'பிஸ்கட் பாக்கெட்',
    hindiName: 'बिस्कुट पैकेट',
    searchKeywords: ['biscuit', 'cookies', 'rusk', 'biskut']
  },
  'K.S. Snacks': {
    tamilName: 'கே.எஸ். கார சிற்றுண்டி',
    hindiName: 'के.एस. नमकीन व स्नैक्स',
    searchKeywords: ['snacks', 'mixture', 'murukku', 'kara sev', 'namkeen']
  },
  'Ellu Mittai': {
    tamilName: 'எள்ளு மிட்டாய்',
    hindiName: 'तिल की चिक्की / पट्टी',
    searchKeywords: ['ellu mittai', 'sesame chikki', 'mittai', 'til chikki', 'gajak']
  },
  'Pori': {
    tamilName: 'பொரி பாக்கெட்',
    hindiName: 'मुरमुरा / लाई',
    searchKeywords: ['pori', 'puffed rice', 'murmura', 'lai']
  },
  'Cheedai': {
    tamilName: 'சீடை பாக்கெட்',
    hindiName: 'सीडई नमकीन',
    searchKeywords: ['cheedai', 'seedai', 'snack']
  },

  // Others & Consumables
  'Water Bottle': {
    tamilName: 'குடிநீர் பாட்டில்',
    hindiName: 'पीने का पानी (बोतल)',
    searchKeywords: ['water bottle', 'mineral water', 'thanneer', 'paani']
  },
  'Egg': {
    tamilName: 'நாட்டு / கோழி முட்டை',
    hindiName: 'देसी / पोल्ट्री अंडा',
    searchKeywords: ['muttai', 'egg', 'nattu kozhi muttai', 'anda']
  },
  'Vazhai Elai': {
    tamilName: 'தலை வாழை இலை',
    hindiName: 'केले का पत्ता',
    searchKeywords: ['vazhai ilai', 'banana leaf', 'thalai vazhai elai', 'kele ka patta']
  },
  'Plate': {
    tamilName: 'பேப்பர் தட்டுகள் (Plates)',
    hindiName: 'डिस्पोजेबल प्लेट्स',
    searchKeywords: ['paper plates', 'plate', 'thattu', 'pattal']
  },
  'Paper Cup': {
    tamilName: 'பேப்பர் கப்புகள் (Cups)',
    hindiName: 'पेपर कप्स',
    searchKeywords: ['paper cups', 'tea cups', 'cup', 'chai cup']
  },
  'Packing': {
    tamilName: 'பேக்கிங் கவர் / பை',
    hindiName: 'पैकिंग बैग / कैरी बैग',
    searchKeywords: ['packing', 'cover', 'bag', 'carry bag']
  },
};

export const CATEGORY_TRANSLATIONS: Record<string, { ta: string; hi: string }> = {
  'All': { ta: 'அனைத்தும்', hi: 'सभी' },
  'All Items': { ta: 'அனைத்து பொருட்கள்', hi: 'सभी सामान' },
  'Fruits': { ta: 'பழங்கள்', hi: 'ताजा फल' },
  'Vegetables': { ta: 'காய்கறிகள்', hi: 'सब्जियां' },
  'Groceries': { ta: 'மளிகைப் பொருட்கள்', hi: 'किराना & राशन' },
  'Dairy': { ta: 'பால் & நெய் பொருட்கள்', hi: 'दूध, दही व घी' },
  'Beverages': { ta: 'குளிர்பானங்கள்', hi: 'कोल्ड ड्रिंक्स व जूस' },
  'Snacks': { ta: 'சிற்றுண்டிகள்', hi: 'नमकीन व स्नैक्स' },
  'Others': { ta: 'மற்றவை', hi: 'अन्य सामान' },
  'General': { ta: 'பொதுவானவை', hi: 'सामान्य' },
};

export const OFFER_TRANSLATIONS: Record<string, { ta: string; hi: string }> = {
  'Offer of the Day': { ta: '⚡ இன்றைய சிறப்பு தள்ளுபடி', hi: '⚡ आज का खास ऑफर' },
  'Super Deal of the Day': { ta: '🔥 இன்றைய சூப்பர் டீல்', hi: '🔥 आज की सुपर डील' },
  'Fresh Citrus Deal': { ta: '🍋 பிரெஷ் சிட்ரஸ் சலுகை', hi: '🍋 सिट्रस स्पेशल ऑफर' },
  'Weekend Berry Special': { ta: '🍓 வார இறுதி ஸ்பெஷல் ஆஃபர்', hi: '🍓 वीकेंड बेरी स्पेशल' },
  'Festival Offer': { ta: '🎉 திருவிழா சிறப்பு தள்ளுபடி', hi: '🎉 त्योहारी महा ऑफर' },
  'Special Discount': { ta: '⭐ சிறப்பு தள்ளுபடி', hi: '⭐ विशेष छूट' },
};

/**
 * Helper to get translated name for a product given language
 */
export function getProductLocalizedName(englishName: string, lang: 'en' | 'ta' | 'hi'): string {
  if (!englishName || lang === 'en') return englishName || '';
  const trimmed = englishName.trim();

  if (PRODUCT_TRANSLATIONS_DICTIONARY[trimmed]) {
    return lang === 'ta'
      ? PRODUCT_TRANSLATIONS_DICTIONARY[trimmed].tamilName
      : PRODUCT_TRANSLATIONS_DICTIONARY[trimmed].hindiName;
  }

  // Case-insensitive lookup
  const lower = trimmed.toLowerCase();
  for (const [key, val] of Object.entries(PRODUCT_TRANSLATIONS_DICTIONARY)) {
    if (key.toLowerCase() === lower) {
      return lang === 'ta' ? val.tamilName : val.hindiName;
    }
  }

  // Substring match
  for (const [key, val] of Object.entries(PRODUCT_TRANSLATIONS_DICTIONARY)) {
    const kLower = key.toLowerCase();
    if (lower.includes(kLower) || kLower.includes(lower)) {
      return lang === 'ta' ? val.tamilName : val.hindiName;
    }
  }

  return englishName;
}

/**
 * Returns phonetic Tanglish / Hinglish search keywords for fuzzy item matching
 */
export function getProductSearchKeywords(englishName: string): string[] {
  if (!englishName) return [];
  const trimmed = englishName.trim();
  if (PRODUCT_TRANSLATIONS_DICTIONARY[trimmed]) {
    return PRODUCT_TRANSLATIONS_DICTIONARY[trimmed].searchKeywords;
  }
  const lower = trimmed.toLowerCase();
  for (const [key, val] of Object.entries(PRODUCT_TRANSLATIONS_DICTIONARY)) {
    if (key.toLowerCase() === lower || lower.includes(key.toLowerCase())) {
      return val.searchKeywords;
    }
  }
  return [];
}

/**
 * Helper to get translated Category name
 */
export function getCategoryLocalizedName(englishCategory: string, lang: 'en' | 'ta' | 'hi'): string {
  if (!englishCategory || lang === 'en') return englishCategory || '';
  const trimmed = englishCategory.trim();
  if (CATEGORY_TRANSLATIONS[trimmed]) {
    return lang === 'ta' ? CATEGORY_TRANSLATIONS[trimmed].ta : CATEGORY_TRANSLATIONS[trimmed].hi;
  }
  const lower = trimmed.toLowerCase();
  for (const [key, val] of Object.entries(CATEGORY_TRANSLATIONS)) {
    if (key.toLowerCase() === lower) {
      return lang === 'ta' ? val.ta : val.hi;
    }
  }
  return englishCategory;
}

/**
 * Helper to get translated Offer Title
 */
export function getOfferLocalizedTitle(englishTitle: string, lang: 'en' | 'ta' | 'hi'): string {
  if (!englishTitle || lang === 'en') return englishTitle || '';
  const trimmed = englishTitle.trim();
  if (OFFER_TRANSLATIONS[trimmed]) {
    return lang === 'ta' ? OFFER_TRANSLATIONS[trimmed].ta : OFFER_TRANSLATIONS[trimmed].hi;
  }
  const lower = trimmed.toLowerCase();
  for (const [key, val] of Object.entries(OFFER_TRANSLATIONS)) {
    if (key.toLowerCase() === lower || lower.includes(key.toLowerCase())) {
      return lang === 'ta' ? val.ta : val.hi;
    }
  }
  return `⚡ ${englishTitle}`;
}
