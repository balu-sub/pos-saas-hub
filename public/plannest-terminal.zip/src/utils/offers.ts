import { Product, ProductVariant } from '../types/pos';

export interface OfferDiscountInfo {
  hasOffer: boolean;
  offerType: 'percentage' | 'flat';
  offerValue: number;
  offerTitle: string;
  originalPrice: number;
  discountedPrice: number;
  discountAmount: number;
  discountPercent: number;
  badgeLabel: string;
  isTodayOffer: boolean;
  validPeriodLabel: string;
}

/**
 * Formats a Date object to YYYY-MM-DD local format
 */
export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Checks if a product currently has an active, valid offer within today's date
 */
export function isOfferActive(product: Product | null | undefined): boolean {
  if (!product) return false;
  if (!product.isOfferActive) return false;
  if (!product.offerValue || product.offerValue <= 0) return false;

  const todayStr = getTodayDateString();

  if (product.offerStartDate) {
    const startStr = product.offerStartDate.slice(0, 10);
    if (todayStr < startStr) {
      return false;
    }
  }

  if (product.offerEndDate) {
    const endStr = product.offerEndDate.slice(0, 10);
    if (todayStr > endStr) {
      return false;
    }
  }

  return true;
}

/**
 * Calculates detailed promotional discount info for a product and optional variant
 */
export function getProductOfferInfo(product: Product, variant?: ProductVariant | null): OfferDiscountInfo {
  const originalPrice = variant?.price ?? product.basePrice ?? 0;
  const hasOffer = isOfferActive(product);

  if (!hasOffer) {
    return {
      hasOffer: false,
      offerType: 'percentage',
      offerValue: 0,
      offerTitle: '',
      originalPrice,
      discountedPrice: originalPrice,
      discountAmount: 0,
      discountPercent: 0,
      badgeLabel: '',
      isTodayOffer: false,
      validPeriodLabel: '',
    };
  }

  const offerType = product.offerType || 'percentage';
  const offerValue = Number(product.offerValue) || 0;
  const offerTitle = product.offerTitle || 'Offer of the Day';

  let discountAmount = 0;
  let discountPercent = 0;
  let discountedPrice = originalPrice;

  if (offerType === 'percentage') {
    discountPercent = Math.min(100, Math.max(0, offerValue));
    discountAmount = Number(((originalPrice * discountPercent) / 100).toFixed(2));
    discountedPrice = Math.max(0, Number((originalPrice - discountAmount).toFixed(2)));
  } else {
    // Flat discount amount
    discountAmount = Math.min(originalPrice, Math.max(0, offerValue));
    discountedPrice = Math.max(0, Number((originalPrice - discountAmount).toFixed(2)));
    discountPercent = originalPrice > 0 ? Math.round((discountAmount / originalPrice) * 100) : 0;
  }

  const badgeLabel = offerType === 'percentage'
    ? `${discountPercent}% OFF`
    : `₹${discountAmount.toFixed(0)} OFF`;

  const todayStr = getTodayDateString();
  const isTodayOffer =
    !product.offerStartDate ||
    (product.offerStartDate.slice(0, 10) === todayStr &&
      (!product.offerEndDate || product.offerEndDate.slice(0, 10) === todayStr));

  let validPeriodLabel = 'Limited Time';
  if (product.offerStartDate && product.offerEndDate) {
    if (product.offerStartDate.slice(0, 10) === product.offerEndDate.slice(0, 10)) {
      validPeriodLabel = 'Today Only';
    } else {
      validPeriodLabel = `Until ${product.offerEndDate.slice(0, 10)}`;
    }
  } else if (product.offerEndDate) {
    validPeriodLabel = `Till ${product.offerEndDate.slice(0, 10)}`;
  } else {
    validPeriodLabel = 'Active Offer';
  }

  return {
    hasOffer: true,
    offerType,
    offerValue,
    offerTitle,
    originalPrice,
    discountedPrice,
    discountAmount,
    discountPercent,
    badgeLabel,
    isTodayOffer,
    validPeriodLabel,
  };
}

/**
 * Filter list of products to only those with active offers
 */
export function getActiveOfferProducts(products: Product[]): Product[] {
  return products.filter((p) => isOfferActive(p));
}
