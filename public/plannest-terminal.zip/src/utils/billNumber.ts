import { OutletProfile } from '../types/pos';

/**
 * Returns Indian Financial Year format (e.g., '2026-27' or '26-27')
 */
export function getFinancialYear(date: Date = new Date(), short = false): string {
  const year = date.getFullYear();
  const month = date.getMonth(); // 0 = Jan, 3 = Apr
  const startYear = month >= 3 ? year : year - 1;
  const endYear = startYear + 1;

  if (short) {
    return `${startYear.toString().slice(-2)}-${endYear.toString().slice(-2)}`;
  }
  return `${startYear}-${endYear.toString().slice(-2)}`;
}

/**
 * Resolve dynamic placeholder tokens in prefix / suffix
 */
export function resolveTokens(
  template: string = '',
  branchName: string = '',
  date: Date = new Date()
): string {
  if (!template) return '';

  const yyyy = date.getFullYear().toString();
  const yy = date.getFullYear().toString().slice(-2);
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const fy = getFinancialYear(date, false);
  const fyShort = getFinancialYear(date, true);

  // Extract short branch code (e.g., "Main Market" -> "MAIN", "Anna Nagar" -> "ANNA")
  const branchClean = (branchName || 'STORE')
    .replace(/[^a-zA-Z0-9]/g, ' ')
    .trim()
    .split(/\s+/)[0]
    .toUpperCase()
    .slice(0, 5);

  return template
    .replace(/{YYYY}/g, yyyy)
    .replace(/{YY}/g, yy)
    .replace(/{MM}/g, mm)
    .replace(/{DD}/g, dd)
    .replace(/{FY}/g, fy)
    .replace(/{FY_SHORT}/g, fyShort)
    .replace(/{BRANCH}/g, branchClean);
}

/**
 * Formats a bill number according to outlet profile configuration
 */
export function formatBillNumber(
  profile: Partial<OutletProfile> = {},
  sequenceNum?: number,
  date: Date = new Date()
): string {
  const prefix = profile.billPrefix !== undefined ? profile.billPrefix : 'INV/';
  const suffix = profile.billSuffix !== undefined ? profile.billSuffix : '';
  const padding = profile.billNumberPadding !== undefined && profile.billNumberPadding !== null
    ? Number(profile.billNumberPadding)
    : 0;

  let seq = sequenceNum;
  if (seq === undefined || isNaN(seq)) {
    const rawNext = profile.billNextSequence;
    const rawStart = profile.billStartNumber;
    if (rawNext !== undefined && rawNext !== null && !isNaN(Number(rawNext))) {
      seq = Number(rawNext);
    } else if (rawStart !== undefined && rawStart !== null && !isNaN(Number(rawStart))) {
      seq = Number(rawStart);
    } else {
      seq = 1001;
    }
  }

  const resolvedPrefix = resolveTokens(prefix, profile.branchName, date);
  const resolvedSuffix = resolveTokens(suffix, profile.branchName, date);

  let formattedNumber: string;
  if (padding <= 0) {
    formattedNumber = String(seq);
  } else {
    formattedNumber = String(seq).padStart(padding, '0');
  }

  return `${resolvedPrefix}${formattedNumber}${resolvedSuffix}`;
}

/**
 * Computes next order number and returns incremented sequence for saving
 */
export function generateNextOrderNumber(
  profile: Partial<OutletProfile> = {},
  date: Date = new Date()
): { orderNumber: string; nextSequence: number; profileUpdate: Partial<OutletProfile> } {
  const startNum = profile.billStartNumber !== undefined && profile.billStartNumber !== null && !isNaN(Number(profile.billStartNumber))
    ? Number(profile.billStartNumber)
    : 1001;

  const incrementStep = profile.billIncrementStep !== undefined && profile.billIncrementStep !== null && !isNaN(Number(profile.billIncrementStep))
    ? Math.max(1, Number(profile.billIncrementStep))
    : 1;

  let currentSeq = profile.billNextSequence !== undefined && profile.billNextSequence !== null && !isNaN(Number(profile.billNextSequence))
    ? Number(profile.billNextSequence)
    : startNum;

  // Check reset frequency (e.g. daily, monthly, yearly)
  const resetFreq = profile.billResetFrequency || 'never';
  const todayStr = date.toISOString().slice(0, 10); // 'YYYY-MM-DD'
  const lastReset = profile.billLastResetDate || '';

  let shouldReset = false;
  if (resetFreq === 'daily' && lastReset && lastReset.slice(0, 10) !== todayStr) {
    shouldReset = true;
  } else if (resetFreq === 'monthly' && lastReset && lastReset.slice(0, 7) !== todayStr.slice(0, 7)) {
    shouldReset = true;
  } else if (resetFreq === 'yearly' && lastReset && lastReset.slice(0, 4) !== todayStr.slice(0, 4)) {
    shouldReset = true;
  }

  if (shouldReset) {
    currentSeq = startNum;
  }

  const orderNumber = formatBillNumber(profile, currentSeq, date);
  const nextSeq = currentSeq + incrementStep;

  return {
    orderNumber,
    nextSequence: nextSeq,
    profileUpdate: {
      billNextSequence: nextSeq,
      billLastResetDate: todayStr,
    },
  };
}
