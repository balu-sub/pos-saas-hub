import React from 'react';
import { CLOUDINARY_PRODUCTS } from '../../scripts/cloudinary-catalog';
import { Product, ProductVariant } from '../types/pos';

// Lookup dictionary for fast Cloudinary CDN URL retrieval
const CLOUDINARY_MAP = new Map<string, string>();
const LOCAL_MAP = new Map<string, string>();

CLOUDINARY_PRODUCTS.forEach((item) => {
  if (item.imageUrl) {
    CLOUDINARY_MAP.set(item.id, item.imageUrl);
    CLOUDINARY_MAP.set(item.name.toLowerCase().trim(), item.imageUrl);
    if (item.sku) CLOUDINARY_MAP.set(item.sku, item.imageUrl);
    if (item.barcode) CLOUDINARY_MAP.set(item.barcode, item.imageUrl);

    // Compute sanitized local path
    try {
      const urlObj = new URL(item.imageUrl);
      const originalFilename = urlObj.pathname.split('/').pop() || 'product.jpg';
      const sanitizedFilename = originalFilename.toLowerCase().replace(/[^a-z0-9._\-]/g, '_');
      const localPath = `/images/products/${sanitizedFilename}`;
      
      LOCAL_MAP.set(item.id, localPath);
      LOCAL_MAP.set(item.name.toLowerCase().trim(), localPath);
      if (item.sku) LOCAL_MAP.set(item.sku, localPath);
      if (item.barcode) LOCAL_MAP.set(item.barcode, localPath);
    } catch {
      // Ignore URL parsing errors
    }
  }
});

/**
 * Returns the best image URL for a product or variant
 */
export function getProductImageUrl(product: Partial<Product> | null | undefined, variant?: Partial<ProductVariant> | null): string {
  if (!product) return '';

  // 1. Direct explicit image field on product or variant
  const explicitImage = product.image || product.imageUrl || product.imagePath || variant?.image;
  if (explicitImage && explicitImage.trim().length > 0) {
    return explicitImage.trim();
  }

  // 2. Lookup by ID in LOCAL_MAP
  if (product.id && LOCAL_MAP.has(product.id)) {
    return LOCAL_MAP.get(product.id)!;
  }

  // 3. Lookup by Name in LOCAL_MAP
  if (product.name && LOCAL_MAP.has(product.name.toLowerCase().trim())) {
    return LOCAL_MAP.get(product.name.toLowerCase().trim())!;
  }

  // 4. Lookup by SKU or Barcode
  const sku = variant?.sku || product.baseSku;
  if (sku && LOCAL_MAP.has(sku)) {
    return LOCAL_MAP.get(sku)!;
  }

  // 5. Lookup in Cloudinary map
  if (product.id && CLOUDINARY_MAP.has(product.id)) {
    return CLOUDINARY_MAP.get(product.id)!;
  }

  if (product.name && CLOUDINARY_MAP.has(product.name.toLowerCase().trim())) {
    return CLOUDINARY_MAP.get(product.name.toLowerCase().trim())!;
  }

  return '';
}

/**
 * Graceful multi-tier image fallback error handler.
 * First tries Cloudinary CDN URL if local image fails, then reveals the styled icon fallback.
 */
export function handleProductImageError(
  e: React.SyntheticEvent<HTMLImageElement, Event>,
  product: Partial<Product> | null | undefined
) {
  const target = e.currentTarget as HTMLImageElement;
  const currentSrc = target.src || '';

  // Check if we can fallback to Cloudinary CDN URL
  const cdnUrl = product?.id ? CLOUDINARY_MAP.get(product.id) : (product?.name ? CLOUDINARY_MAP.get(product.name.toLowerCase().trim()) : null);

  if (cdnUrl && !currentSrc.includes('res.cloudinary.com')) {
    // Attempt CDN fallback
    target.src = cdnUrl;
    return;
  }

  // If already tried CDN or no CDN available, hide image and reveal styled fallback
  target.style.display = 'none';
  const parent = target.parentElement;
  if (parent) {
    const fallback = parent.querySelector('.img-fallback') as HTMLElement | null;
    if (fallback) {
      fallback.classList.remove('hidden');
      fallback.style.display = 'flex';
    }
  }
}
