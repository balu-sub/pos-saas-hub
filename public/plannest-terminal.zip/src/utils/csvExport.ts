/**
 * CSV Export Utility for Inventory, Mandi Vendor Orders & Store Sales
 */

export interface CSVColumn<T> {
  header: string;
  accessor: (item: T) => string | number | boolean | null | undefined;
}

/**
 * Escapes a field for CSV compliance (RFC 4180)
 */
function escapeCSVField(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Converts an array of objects into a CSV string
 */
export function generateCSV<T>(data: T[], columns: CSVColumn<T>[]): string {
  const headerRow = columns.map((col) => escapeCSVField(col.header)).join(',');
  const rows = data.map((item) =>
    columns.map((col) => escapeCSVField(col.accessor(item))).join(',')
  );
  return [headerRow, ...rows].join('\r\n');
}

/**
 * Triggers a browser download of a CSV file with UTF-8 BOM for Microsoft Excel & Google Sheets
 */
export function downloadCSV(filename: string, csvContent: string): void {
  // UTF-8 BOM helps Excel correctly parse special characters and UTF-8 strings
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename.endsWith('.csv') ? filename : `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Generic helper to export table data to CSV in one line
 */
export function exportToCSV<T>(filenamePrefix: string, data: T[], columns: CSVColumn<T>[]): void {
  const dateStr = new Date().toISOString().slice(0, 10);
  const filename = `${filenamePrefix}_${dateStr}.csv`;
  const csv = generateCSV(data, columns);
  downloadCSV(filename, csv);
}
