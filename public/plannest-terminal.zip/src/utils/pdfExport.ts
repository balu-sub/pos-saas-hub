import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { OutletProfile, Customer, Supplier, PurchaseOrder } from '../types/pos';

export interface PDFReportOptions {
  title: string;
  subtitle?: string;
  periodLabel?: string;
  outletProfile?: OutletProfile;
  summaryMetrics?: { label: string; value: string }[];
  columns: string[];
  data: (string | number)[][];
  fileName?: string;
  footNote?: string;
  isDuplicate?: boolean;
}

/**
 * Universal PDF Header Renderer
 * Guarantees every single report, PO, and export in the system has the identical header layout.
 */
function drawUniversalHeader(
  doc: jsPDF,
  title: string,
  subtitle?: string,
  periodLabel?: string,
  outletProfile?: OutletProfile,
  isDuplicate?: boolean
): number {
  const storeName = outletProfile?.outletName || 'RETAIL STORE OUTLET';
  const branch = outletProfile?.branchName || 'Main Outlet';
  const gstin = outletProfile?.gstin || '';
  const pan = outletProfile?.panNumber || '';
  const fssai = outletProfile?.fssaiLicense || '';
  const phone = outletProfile?.phone || '+91 98765 43210';
  const address = outletProfile?.addressLine1
    ? `${outletProfile.addressLine1}, ${outletProfile.city || ''} ${outletProfile.pincode || ''}`
    : 'APMC Yard, Vashi, Navi Mumbai - 400703';

  // --- Top primary Navy Blue bar (#00478c) ---
  doc.setFillColor(0, 71, 140);
  doc.rect(0, 0, 210, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text(storeName.toUpperCase(), 14, 11);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`${branch} • Phone: ${phone}`, 14, 17);

  // Right side generation date/time & Period
  doc.setFontSize(8);
  doc.text(`Generated: ${new Date().toLocaleString('en-IN')}`, 196, 11, { align: 'right' });
  if (periodLabel) {
    doc.text(`Period: ${periodLabel}`, 196, 17, { align: 'right' });
  }

  // --- DUPLICATE WATERMARK / BADGE ---
  if (isDuplicate) {
    doc.setFillColor(220, 38, 38); // Red
    doc.roundedRect(80, 5, 50, 8, 2, 2, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('*** DUPLICATE COPY ***', 105, 10.5, { align: 'center' });
  }

  // --- STORE TAX / STATUTORY SUB-BAR ---
  doc.setFillColor(244, 244, 245);
  doc.rect(0, 24, 210, 11, 'F');
  doc.setTextColor(70, 70, 70);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  const taxInfo = [
    gstin ? `GSTIN: ${gstin}` : '',
    pan ? `PAN: ${pan}` : '',
    fssai ? `FSSAI: ${fssai}` : '',
    `Address: ${address}`,
  ]
    .filter(Boolean)
    .join('  |  ');
  doc.text(taxInfo, 14, 31);

  // --- REPORT TITLE ---
  let currentY = 44;
  doc.setTextColor(9, 9, 11);
  doc.setFontSize(13.5);
  doc.setFont('helvetica', 'bold');
  doc.text(title, 14, currentY);

  if (subtitle) {
    currentY += 5;
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 100, 100);
    doc.text(subtitle, 14, currentY);
  }

  return currentY;
}

/**
 * Universal PDF Footer Renderer Hook for autoTable
 */
function attachUniversalFooter(doc: jsPDF, footNote?: string) {
  return (data: any) => {
    const totalPages = (doc as any).internal.getNumberOfPages();
    const str = `Page ${data.pageNumber} of ${totalPages}`;
    doc.setFontSize(7.5);
    doc.setTextColor(140, 140, 140);
    doc.text(str, 196, 287, { align: 'right' });
    doc.text(
      footNote || 'Confidential Store Document • Generated automatically by Plannest POS',
      14,
      287
    );
  };
}

/**
 * Universal Tabular Report PDF
 */
export function generateReportPDF(options: PDFReportOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  let currentY = drawUniversalHeader(
    doc,
    options.title,
    options.subtitle,
    options.periodLabel,
    options.outletProfile,
    options.isDuplicate
  );

  // --- SUMMARY KPI METRICS BOXES ---
  if (options.summaryMetrics && options.summaryMetrics.length > 0) {
    currentY += 6;
    const boxCount = options.summaryMetrics.length;
    const availableWidth = 182; // 210 - 28
    const gap = 3;
    const boxWidth = (availableWidth - gap * (boxCount - 1)) / boxCount;
    const boxHeight = 14;

    options.summaryMetrics.forEach((metric, index) => {
      const boxX = 14 + index * (boxWidth + gap);
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(212, 212, 216);
      doc.roundedRect(boxX, currentY, boxWidth, boxHeight, 2, 2, 'FD');

      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text(metric.label.toUpperCase(), boxX + 3.5, currentY + 4.5);

      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(0, 71, 140);
      doc.text(metric.value, boxX + 3.5, currentY + 11);
    });

    currentY += boxHeight + 4;
  } else {
    currentY += 5;
  }

  // --- DATA TABLE VIA AUTOTABLE ---
  autoTable(doc, {
    startY: currentY,
    head: [options.columns],
    body: options.data,
    theme: 'grid',
    headStyles: {
      fillColor: [0, 71, 140],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
      cellPadding: 2.2,
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [40, 40, 40],
      cellPadding: 1.8,
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      overflow: 'linebreak',
      lineColor: [228, 228, 231],
      lineWidth: 0.1,
    },
    margin: { left: 14, right: 14, bottom: 20 },
    didDrawPage: attachUniversalFooter(doc, options.footNote),
  });

  const finalFileName = `${options.fileName || options.title.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(finalFileName);
}

/**
 * Purchase Order PDF (Original Issued PO Document / Duplicate Print)
 * Represents the official raised Purchase Order for vendor procurement.
 * Ignores partial intakes and received statuses so it always prints the clean issued PO.
 */
export function generatePurchaseOrderPDF(
  po: PurchaseOrder,
  outletProfile?: OutletProfile,
  isDuplicate: boolean = false
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const currency = outletProfile?.currencySymbol || 'Rs.';
  const title = isDuplicate
    ? `PURCHASE ORDER #${po.poNumber} (DUPLICATE)`
    : `PURCHASE ORDER #${po.poNumber}`;
  const subtitle = `Supplier: ${po.supplierName} • Order Date: ${po.createdAt ? new Date(po.createdAt).toLocaleDateString('en-IN') : 'N/A'} • Expected Delivery: ${po.expectedDelivery || 'Immediate'}`;

  const totalOrderedQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
  const totalCost = (po.items || []).reduce(
    (s, i) => s + (Number(i.quantityOrdered) || 0) * (Number(i.unitCost) || 0),
    0
  );

  const summaryMetrics = [
    { label: 'PO Number', value: po.poNumber },
    { label: 'Order Date', value: po.createdAt ? new Date(po.createdAt).toLocaleDateString('en-IN') : 'N/A' },
    { label: 'Line Items', value: `${po.items?.length || 0} Products` },
    { label: 'Total Ordered Qty', value: `${totalOrderedQty} Units` },
    { label: 'Total PO Value', value: `${currency} ${totalCost.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` },
  ];

  let currentY = drawUniversalHeader(
    doc,
    title,
    subtitle,
    `Order Date: ${po.createdAt ? new Date(po.createdAt).toLocaleDateString('en-IN') : 'N/A'}`,
    outletProfile,
    isDuplicate
  );

  // Supplier & Dispatch Information Card
  currentY += 6;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(212, 212, 216);
  doc.roundedRect(14, currentY, 182, 16, 2, 2, 'FD');

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 71, 140);
  doc.text('SUPPLIER & DISPATCH DETAILS', 18, currentY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(60, 60, 60);
  doc.setFontSize(7);
  doc.text(
    `Vendor: ${po.supplierName}  |  PO Number: ${po.poNumber}  |  Order Status: ISSUED / APPROVED`,
    18,
    currentY + 10
  );
  doc.text(
    `Expected Delivery: ${po.expectedDelivery || 'Immediate'}  |  Total Lines: ${po.items?.length || 0} Products  |  Terms: Direct Store Delivery`,
    18,
    currentY + 14
  );

  currentY += 20;

  // Summary KPI Cards
  const boxCount = summaryMetrics.length;
  const availableWidth = 182;
  const gap = 3;
  const boxWidth = (availableWidth - gap * (boxCount - 1)) / boxCount;
  const boxHeight = 14;

  summaryMetrics.forEach((metric, index) => {
    const boxX = 14 + index * (boxWidth + gap);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(212, 212, 216);
    doc.roundedRect(boxX, currentY, boxWidth, boxHeight, 2, 2, 'FD');

    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 116, 139);
    doc.text(metric.label.toUpperCase(), boxX + 3, currentY + 4.5);

    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 71, 140);
    doc.text(metric.value, boxX + 3, currentY + 11);
  });

  currentY += boxHeight + 6;

  // Items Table (Pure PO Order Table - Clean Ordered Items)
  const columns = ['#', 'SKU', 'Product Name', 'Ordered Qty', 'Unit', 'Unit Cost', 'Total Cost'];
  const tableData = (po.items || []).map((item, idx) => {
    const ord = Number(item.quantityOrdered) || 0;
    const cost = Number(item.unitCost) || 0;
    const lineTotal = ord * cost;

    return [
      (idx + 1).toString(),
      item.sku || 'N/A',
      item.productName || 'N/A',
      ord.toString(),
      item.unit || 'units',
      `${currency} ${cost.toFixed(2)}`,
      `${currency} ${lineTotal.toFixed(2)}`,
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [columns],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [0, 71, 140],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
      cellPadding: 2,
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [40, 40, 40],
      cellPadding: 1.8,
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      overflow: 'linebreak',
      lineColor: [228, 228, 231],
      lineWidth: 0.1,
    },
    margin: { left: 14, right: 14, bottom: 20 },
    didDrawPage: attachUniversalFooter(
      doc,
      isDuplicate
        ? '*** OFFICIAL PURCHASE ORDER (DUPLICATE COPY) *** • Authorised Procurement Record'
        : 'Official Purchase Order Document • Authorised Procurement Record • Plannest POS'
    ),
  });

  const fileName = `PO_${po.poNumber}${isDuplicate ? '_DUPLICATE' : ''}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(fileName);
}

/**
 * All POs Comprehensive Master Report
 */
export function generateAllPOsReportPDF(
  purchaseOrders: PurchaseOrder[],
  outletProfile?: OutletProfile
) {
  const currency = outletProfile?.currencySymbol || 'Rs.';

  let totalPOs = purchaseOrders.length;
  let totalOrderValue = 0;
  let totalReceivedValue = 0;
  let totalPendingPOs = 0;
  let totalFulfilledPOs = 0;

  const tableData = purchaseOrders.map((po, idx) => {
    const ordQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityOrdered) || 0), 0);
    const recQty = (po.items || []).reduce((s, i) => s + (Number(i.quantityReceived) || 0), 0);
    const poValue = (po.items || []).reduce(
      (s, i) => s + (Number(i.quantityOrdered) || 0) * (Number(i.unitCost) || 0),
      0
    );
    const recValue = (po.items || []).reduce(
      (s, i) => s + (Number(i.quantityReceived) || 0) * (Number(i.unitCost) || 0),
      0
    );

    totalOrderValue += poValue;
    totalReceivedValue += recValue;
    if (recQty >= ordQty && ordQty > 0) totalFulfilledPOs++;
    else if (po.status !== 'CANCELLED') totalPendingPOs++;

    const dateStr = po.createdAt ? new Date(po.createdAt).toLocaleDateString('en-IN') : 'N/A';

    return [
      (idx + 1).toString(),
      po.poNumber,
      po.supplierName,
      dateStr,
      po.expectedDelivery || 'N/A',
      `${po.items?.length || 0} items`,
      ordQty.toString(),
      recQty.toString(),
      `${currency} ${poValue.toFixed(2)}`,
      po.status,
    ];
  });

  const summaryMetrics = [
    { label: 'Total POs', value: `${totalPOs} Orders` },
    { label: 'Pending / Partial', value: `${totalPendingPOs} Active` },
    { label: 'Fulfilled POs', value: `${totalFulfilledPOs} Done` },
    {
      label: 'Total PO Value',
      value: `${currency} ${totalOrderValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
    },
    {
      label: 'Intake Received',
      value: `${currency} ${totalReceivedValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
    },
  ];

  generateReportPDF({
    title: 'COMPREHENSIVE PURCHASE ORDERS & GRN INTAKE REPORT',
    subtitle: 'Consolidated procurement audit, supplier delivery schedules, and fulfillment ledger',
    outletProfile,
    summaryMetrics,
    columns: ['#', 'PO Number', 'Supplier', 'Order Date', 'Expected Date', 'Items', 'Ordered', 'Received', 'PO Value', 'Status'],
    data: tableData,
    fileName: `All_Purchase_Orders_Report_${new Date().toISOString().split('T')[0]}`,
    footNote: 'Confidential Procurement Audit • Generated by Plannest POS',
  });
}

/**
 * Customers Directory Export
 */
export function generateCustomerDirectoryPDF(
  customers: Customer[],
  outletProfile?: OutletProfile
) {
  const currency = outletProfile?.currencySymbol || 'Rs.';
  const totalCustomers = customers.length;
  const totalSpend = customers.reduce((s, c) => s + (Number(c.totalSpent) || 0), 0);
  const totalStoreCredit = customers.reduce((s, c) => s + (Number(c.storeCredit) || 0), 0);
  const totalLoyaltyPoints = customers.reduce((s, c) => s + (Number(c.loyaltyPoints) || 0), 0);

  const summaryMetrics = [
    { label: 'Registered Customers', value: `${totalCustomers} Profiles` },
    { label: 'Total Purchase Value', value: `${currency} ${totalSpend.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` },
    { label: 'Outstanding Khata', value: `${currency} ${totalStoreCredit.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` },
    { label: 'Total Loyalty Points', value: `${totalLoyaltyPoints.toLocaleString('en-IN')} pts` },
  ];

  const columns = ['#', 'Customer Name', 'Phone', 'Email', 'Tier', 'Loyalty Pts', 'Total Purchases', 'Khata Balance'];
  const tableData = customers.map((c, idx) => [
    (idx + 1).toString(),
    c.name,
    c.phone,
    c.email || 'N/A',
    c.memberTier || 'Regular',
    (c.loyaltyPoints || 0).toString(),
    `${currency} ${(c.totalSpent || 0).toFixed(2)}`,
    `${currency} ${(c.storeCredit || 0).toFixed(2)}`,
  ]);

  generateReportPDF({
    title: 'CUSTOMER DIRECTORY & PURCHASE VALUE REPORT',
    subtitle: 'Registered accounts, lifetime purchase contribution, loyalty points, and Khata credit balances',
    outletProfile,
    summaryMetrics,
    columns,
    data: tableData,
    fileName: `Customer_Directory_${new Date().toISOString().split('T')[0]}`,
    footNote: 'Confidential Customer Records • Generated by Plannest POS',
  });
}

/**
 * Supplier Directory Export
 */
export function generateSupplierDirectoryPDF(
  suppliers: Supplier[],
  outletProfile?: OutletProfile
) {
  const totalSuppliers = suppliers.length;

  const summaryMetrics = [
    { label: 'Registered Vendors', value: `${totalSuppliers} Suppliers` },
    { label: 'Average Lead Time', value: `${(suppliers.reduce((s, sup) => s + (sup.leadTimeDays || 0), 0) / (totalSuppliers || 1)).toFixed(1)} Days` },
    { label: 'Verified Ratings', value: '4.7 / 5.0' },
  ];

  const columns = ['#', 'Supplier / Vendor Name', 'Market Type', 'Contact Person', 'Phone', 'Lead Time', 'Payment Terms', 'Rating'];
  const tableData = suppliers.map((sup, idx) => [
    (idx + 1).toString(),
    sup.name,
    sup.marketType || 'Mandi Trader',
    sup.contactPerson || 'Representative',
    sup.phone || 'N/A',
    `${sup.leadTimeDays || 1} days`,
    sup.paymentTerms || 'Net 15',
    `${sup.rating || 4.5} ⭐`,
  ]);

  generateReportPDF({
    title: 'SUPPLIER DIRECTORY & VENDOR PROFILES REPORT',
    subtitle: 'Registered mandi vendors, procurement lead times, credit payment terms, and vendor contacts',
    outletProfile,
    summaryMetrics,
    columns,
    data: tableData,
    fileName: `Supplier_Directory_${new Date().toISOString().split('T')[0]}`,
    footNote: 'Confidential Supplier Profiles • Generated by Plannest POS',
  });
}
