// Android Tablet Utility Helpers (Haptics, Fullscreen Kiosk, Wake Lock, Orientation)

export type HapticType = 'light' | 'medium' | 'success' | 'warning' | 'error';

/**
 * Trigger subtle physical tactile vibration feedback for tablet touchscreens
 */
export function triggerHaptic(type: HapticType = 'light') {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      switch (type) {
        case 'light':
          navigator.vibrate(15);
          break;
        case 'medium':
          navigator.vibrate(35);
          break;
        case 'success':
          navigator.vibrate([15, 30, 20]);
          break;
        case 'warning':
          navigator.vibrate([30, 50, 30]);
          break;
        case 'error':
          navigator.vibrate([50, 50, 50, 50]);
          break;
      }
    } catch {
      // Haptics not allowed or unsupported in current container context
    }
  }
}

/**
 * Toggle Android Tablet Fullscreen Kiosk Mode (Hides address bar & OS status navigation)
 */
export async function toggleFullscreen(): Promise<boolean> {
  try {
    if (!document.fullscreenElement) {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
        triggerHaptic('medium');
        return true;
      }
    } else {
      if (document.exitFullscreen) {
        await document.exitFullscreen();
        triggerHaptic('light');
        return false;
      }
    }
  } catch (err) {
    console.warn('[Tablet Fullscreen] Failed to toggle fullscreen:', err);
  }
  return Boolean(document.fullscreenElement);
}

export function isFullscreen(): boolean {
  if (typeof document === 'undefined') return false;
  return Boolean(document.fullscreenElement);
}

/**
 * Screen Wake Lock API: Keeps Android tablet screen permanently awake during business hours
 */
let wakeLockSentinel: any = null;

export async function requestWakeLock(): Promise<boolean> {
  if (typeof window !== 'undefined' && 'wakeLock' in navigator) {
    try {
      if (wakeLockSentinel && !wakeLockSentinel.released) {
        return true;
      }
      wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
      wakeLockSentinel.addEventListener('release', () => {
        wakeLockSentinel = null;
      });
      return true;
    } catch (err) {
      console.warn('[Tablet Wake Lock] Could not acquire screen wake lock:', err);
      return false;
    }
  }
  return false;
}

export async function releaseWakeLock(): Promise<void> {
  if (wakeLockSentinel) {
    try {
      await wakeLockSentinel.release();
    } catch {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

export function isWakeLockActive(): boolean {
  return Boolean(wakeLockSentinel && !wakeLockSentinel.released);
}
