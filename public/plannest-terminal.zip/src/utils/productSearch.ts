import { Product } from '../types/pos';
import { getProductLocalizedName, getProductSearchKeywords } from '../locales/productTranslations';

export interface ProductSearchScore {
  product: Product;
  rank: number; // 1 = Name starts with query, 2 = Word in name starts with query, 3 = Multi-lingual / phonetic keyword match, 4 = SKU/Barcode, 5 = Substring match, 6 = Category match
}

/**
 * Filters and sorts products with intelligent multi-lingual (Tamil, Hindi, English), Tanglish/Hinglish, and prefix-first prioritization.
 * - Supports English names ("Tomato", "Apple", "Curd"),
 * - Supports Colloquial Tamil names ("தக்காளி", "ஆப்பிள்", "தயிர்"),
 * - Supports Hindi names ("टमाटर", "सेब", "दही", "आलू", "प्याज"),
 * - Supports Phonetic Tanglish & Hinglish queries ("thakkali", "vengayam", "tamatar", "aloo", "pyaaz", "chana"),
 * - Supports SKU & Barcodes.
 */
export function filterAndSortProducts(
  products: Product[],
  searchQuery: string,
  categoryFilter: string = 'All',
  onlyOffers: boolean = false,
  isOfferActiveFn?: (p: Product) => boolean
): Product[] {
  const q = (searchQuery || '').toLowerCase().trim();
  const cat = (categoryFilter || 'All').trim();

  // 1. Filter by category & active offers
  const categoryFiltered = products.filter((p) => {
    if (onlyOffers && isOfferActiveFn && !isOfferActiveFn(p)) {
      return false;
    }
    if (cat === '__OFFERS__' && isOfferActiveFn && !isOfferActiveFn(p)) {
      return false;
    }
    if (cat !== 'All' && cat !== 'All Items' && cat !== '__OFFERS__') {
      if (p.category.toLowerCase() !== cat.toLowerCase()) {
        return false;
      }
    }
    return true;
  });

  // 2. If no search query, return list cleanly sorted alphabetically (A-Z) by name
  if (!q) {
    return [...categoryFiltered].sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: 'base', numeric: true })
    );
  }

  // 3. Score and rank each candidate product
  const scoredList: ProductSearchScore[] = [];

  for (const p of categoryFiltered) {
    const nameLower = (p.name || '').toLowerCase().trim();
    const skuLower = (p.baseSku || '').toLowerCase().trim();
    const barcode = (p.baseBarcode || '').trim();
    const catLower = (p.category || '').toLowerCase().trim();

    const tamilName = getProductLocalizedName(p.name, 'ta').toLowerCase();
    const hindiName = getProductLocalizedName(p.name, 'hi').toLowerCase();
    const searchKeywords = getProductSearchKeywords(p.name);

    // Check variants
    const variantSkus = p.variants?.map((v) => (v.sku || '').toLowerCase().trim()) || [];
    const variantBarcodes = p.variants?.map((v) => (v.barcode || '').trim()) || [];
    const variantNames = p.variants?.map((v) => (v.name || '').toLowerCase().trim()) || [];

    let rank = 999;

    // Rank 1: Product English, Tamil, or Hindi Name starts exactly with query
    if (nameLower.startsWith(q) || tamilName.startsWith(q) || hindiName.startsWith(q)) {
      rank = 1;
    }
    // Rank 2: Any word in English, Tamil, or Hindi product name starts with query
    else if (
      nameLower
        .split(/[\s\-_/(),.]+/)
        .filter(Boolean)
        .some((word) => word.startsWith(q)) ||
      tamilName
        .split(/[\s\-_/(),.]+/)
        .filter(Boolean)
        .some((word) => word.startsWith(q)) ||
      hindiName
        .split(/[\s\-_/(),.]+/)
        .filter(Boolean)
        .some((word) => word.startsWith(q))
    ) {
      rank = 2;
    }
    // Rank 3: Phonetic Tanglish / Hinglish match starts with query (e.g. "thak", "tamatar", "aloo", "veng")
    else if (searchKeywords.some((kw) => kw.startsWith(q) || kw.split(' ').some((w) => w.startsWith(q)))) {
      rank = 3;
    }
    // Rank 4: Base SKU or Barcode starts with query (e.g. "0173" -> starts with "01")
    else if (
      skuLower.startsWith(q) ||
      barcode.startsWith(q) ||
      variantSkus.some((s) => s.startsWith(q)) ||
      variantBarcodes.some((b) => b.startsWith(q))
    ) {
      rank = 4;
    }
    // Rank 5: Query is contained inside English name, Tamil name, Hindi name, or keywords
    else if (
      nameLower.includes(q) ||
      tamilName.includes(q) ||
      hindiName.includes(q) ||
      searchKeywords.some((kw) => kw.includes(q)) ||
      variantNames.some((n) => n.includes(q))
    ) {
      rank = 5;
    }
    // Rank 6: Category match
    else if (catLower.includes(q)) {
      rank = 6;
    }

    if (rank <= 6) {
      scoredList.push({ product: p, rank });
    }
  }

  // 4. Sort strictly by rank ascending, then alphabetically by name
  return scoredList
    .sort((a, b) => {
      if (a.rank !== b.rank) {
        return a.rank - b.rank;
      }
      return a.product.name.localeCompare(b.product.name, undefined, {
        sensitivity: 'base',
        numeric: true,
      });
    })
    .map((item) => item.product);
}
