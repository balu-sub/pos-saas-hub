/**
 * Utility functions for Unit and Quantity handling in Plannest POS
 * Handles unit categorization (discrete/count vs weight/volume)
 * and decimal restrictions.
 */

// Discrete units that cannot have decimal quantities (whole numbers only)
const DISCRETE_UNITS = new Set([
  'nos',
  'no',
  'no.',
  'pc',
  'pcs',
  'piece',
  'pieces',
  'pack',
  'packet',
  'packets',
  'pkt',
  'pkts',
  'box',
  'boxes',
  'bag',
  'bags',
  'bottle',
  'bottles',
  'can',
  'cans',
  'strip',
  'strips',
  'bunch',
  'bunches',
  'pouch',
  'pouches',
  'unit',
  'units',
  'dozen',
  'doz',
  'tray',
  'trays',
  'item',
  'items',
  'carton',
  'cartons',
  'roll',
  'rolls',
  'jar',
  'jars',
  'cup',
  'cups',
]);

/**
 * Checks if a given unit is discrete (whole numbers only, no decimal allowed)
 */
export function isDiscreteUnit(unit?: string): boolean {
  if (!unit) return false;
  const clean = unit.toLowerCase().trim().replace(/s$/, ''); // normalize plural
  if (DISCRETE_UNITS.has(unit.toLowerCase().trim()) || DISCRETE_UNITS.has(clean)) {
    return true;
  }
  // Check common prefixes or sub-strings like '10 pcs' or 'pack of 4'
  if (/\b(pc|pcs|pack|packet|nos|bottle|can|box|bunch|dozen)\b/i.test(unit)) {
    return true;
  }
  return false;
}

/**
 * Gets the maximum number of decimal places allowed for a unit:
 * - Discrete units (nos, pc, pack) -> 0 decimal places (integers only)
 * - Weight & Volume units (kg, g, l, ml) -> 3 decimal places (e.g. 1.250)
 * - Other units -> 3 decimal places
 */
export function getMaxDecimalsForUnit(unit?: string): number {
  if (isDiscreteUnit(unit)) {
    return 0;
  }
  return 3;
}

/**
 * Sanitizes typed quantity input based on unit rules:
 * - If unit is discrete (pc, nos, pack), disallows decimal points and non-digits.
 * - If unit is weight/volume (kg, l), allows max 1 decimal point and up to 3 decimal digits.
 */
export function sanitizeQuantityInput(raw: string, unit?: string): string {
  if (!raw) return '';
  const maxDecimals = getMaxDecimalsForUnit(unit);

  if (maxDecimals === 0) {
    // Whole integers only: remove any dot, comma, or non-digit
    return raw.replace(/[^0-9]/g, '');
  }

  // Allow digits and up to 1 decimal point
  let cleaned = raw.replace(/[^0-9.]/g, '');
  const parts = cleaned.split('.');
  if (parts.length > 2) {
    cleaned = parts[0] + '.' + parts.slice(1).join('');
  }
  if (cleaned.includes('.')) {
    const [intPart, decPart] = cleaned.split('.');
    return `${intPart}.${decPart.slice(0, maxDecimals)}`;
  }
  return cleaned;
}

/**
 * Formats currency input to restrict to at most 2 decimal places.
 */
export function sanitizeCurrencyInput(raw: string): string {
  if (!raw) return '';
  let cleaned = raw.replace(/[^0-9.]/g, '');
  const parts = cleaned.split('.');
  if (parts.length > 2) {
    cleaned = parts[0] + '.' + parts.slice(1).join('');
  }
  if (cleaned.includes('.')) {
    const [intPart, decPart] = cleaned.split('.');
    return `${intPart}.${decPart.slice(0, 2)}`;
  }
  return cleaned;
}
