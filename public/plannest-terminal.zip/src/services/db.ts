import Dexie, { Table } from 'dexie';
import { INITIAL_CUSTOMERS, INITIAL_PRODUCTS, INITIAL_PURCHASE_ORDERS, INITIAL_SHIFTS } from '../data/seedData';
import { Customer, InventoryLedgerEntry, Operator, Order, Product, PurchaseOrder, ShiftRecord, SyncQueueItem, DEFAULT_OPERATORS } from '../types/pos';

export class PlannestPosDatabase extends Dexie {
  products!: Table<Product, string>;
  orders!: Table<Order, string>;
  parkedOrders!: Table<Order, string>;
  customers!: Table<Customer, string>;
  shifts!: Table<ShiftRecord, string>;
  inventoryLedger!: Table<InventoryLedgerEntry, string>;
  syncQueue!: Table<SyncQueueItem, string>;
  purchaseOrders!: Table<PurchaseOrder, string>;
  users!: Table<Operator, string>;

  constructor() {
    super('PlannestPOSDB_v1');
    this.version(3).stores({
      products: 'id, baseSku, category, status',
      orders: 'id, orderNumber, terminalId, status, createdAt, synced',
      parkedOrders: 'id, orderNumber, terminalId, createdAt',
      customers: 'id, phone, email, name',
      shifts: 'id, shiftId, terminalId, status, openedAt',
      inventoryLedger: 'id, sku, variantId, mutationType, timestamp',
      syncQueue: 'id, entityType, entityId, status, createdAt',
      purchaseOrders: 'id, poNumber, supplierId, status',
      users: 'id, name, userRole, pin, status',
    });
  }

  async clearAllCaches() {
    try {
      await this.products.clear();
    } catch (e) {
      console.warn('Error clearing products cache:', e);
    }
  }

  async seedDefaultsIfEmpty() {
    try {
      // Do NOT auto-seed dummy products. New stores start with 0 products.
      const custCount = await this.customers.count();
      if (custCount === 0) {
        await this.customers.bulkPut(INITIAL_CUSTOMERS);
      }
      const shiftCount = await this.shifts.count();
      if (shiftCount === 0 && INITIAL_SHIFTS.length > 0) {
        await this.shifts.bulkPut(INITIAL_SHIFTS);
      }
      const poCount = await this.purchaseOrders.count();
      if (poCount === 0) {
        await this.purchaseOrders.bulkPut(INITIAL_PURCHASE_ORDERS);
      }
      const userCount = await this.users.count();
      if (userCount === 0) {
        await this.users.bulkPut(DEFAULT_OPERATORS);
      }
    } catch (err) {
      console.error('Error during local defaults initialization:', err);
    }
  }
}

export const posDb = new PlannestPosDatabase();

