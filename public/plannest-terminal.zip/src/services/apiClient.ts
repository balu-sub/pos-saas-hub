import { Customer, InventoryLedgerEntry, Order, OutletProfile, LoyaltyProgramConfig, Product, PurchaseOrder, ShiftRecord } from '../types/pos';

export function getApiBase(): string {
  try {
    const customHost = localStorage.getItem('plannest_pos_custom_api_host') || localStorage.getItem('alfa_pos_custom_api_host');
    if (customHost && customHost.trim()) {
      let host = customHost.trim().replace(/\/+$/, '');
      if (!host.startsWith('http://') && !host.startsWith('https://')) {
        host = `http://${host}`;
      }
      return `${host}/api`;
    }
  } catch {}
  return '/api';
}

export function setCustomApiHost(host: string | null) {
  try {
    if (host && host.trim()) {
      localStorage.setItem('plannest_pos_custom_api_host', host.trim());
      localStorage.removeItem('alfa_pos_custom_api_host');
    } else {
      localStorage.removeItem('plannest_pos_custom_api_host');
      localStorage.removeItem('alfa_pos_custom_api_host');
    }
  } catch {}
}

export function getCustomApiHost(): string {
  try {
    return localStorage.getItem('plannest_pos_custom_api_host') || localStorage.getItem('alfa_pos_custom_api_host') || '';
  } catch {}
  return '';
}

// Dynamically evaluated in template strings: `${API_BASE}/endpoint`
const API_BASE = {
  toString() {
    return getApiBase();
  },
};

export const apiClient = {
  // Outlet Profile & Store Setup
  async getOutletProfile(): Promise<OutletProfile> {
    const res = await fetch(`${API_BASE}/outlet-profile`);
    if (!res.ok) throw new Error('Failed to fetch outlet profile');
    return res.json();
  },

  async saveOutletProfile(profile: Partial<OutletProfile>): Promise<{ success: boolean; outletProfile: OutletProfile }> {
    const res = await fetch(`${API_BASE}/outlet-profile`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile),
    });
    if (!res.ok) throw new Error('Failed to save outlet profile');
    return res.json();
  },

  // Loyalty Program Configuration
  async getLoyaltySettings(): Promise<LoyaltyProgramConfig> {
    const res = await fetch(`${API_BASE}/loyalty-settings`);
    if (!res.ok) throw new Error('Failed to fetch loyalty settings');
    return res.json();
  },

  async saveLoyaltySettings(config: Partial<LoyaltyProgramConfig>): Promise<{ success: boolean; loyaltyConfig: LoyaltyProgramConfig }> {
    const res = await fetch(`${API_BASE}/loyalty-settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    if (!res.ok) throw new Error('Failed to save loyalty settings');
    return res.json();
  },
  // Check health / connection
  async checkHealth(): Promise<{ status: string; database: string; host: string }> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);
    try {
      const res = await fetch(`${API_BASE}/health`, { signal: controller.signal });
      if (!res.ok) throw new Error('API server unreachable');
      return res.json();
    } finally {
      clearTimeout(timeout);
    }
  },

  // Categories
  async getCategories(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/categories`);
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  // Products with optional force refresh
  async getProducts(forceRefresh: boolean = false): Promise<Product[]> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const url = forceRefresh ? `${API_BASE}/products?refresh=true` : `${API_BASE}/products`;
      const res = await fetch(url, { signal: controller.signal });
      if (!res.ok) throw new Error('Failed to fetch products');
      return res.json();
    } finally {
      clearTimeout(timeout);
    }
  },

  // Save/Create Product
  async saveProduct(product: Partial<Product>): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    if (!res.ok) throw new Error('Failed to save product');
    return res.json();
  },

  // Upload Local Product Image (saves to public/images/products/)
  async uploadImage(imageBase64: string, filename?: string, sku?: string): Promise<{ success: boolean; imageUrl: string; imagePath: string; filename: string }> {
    const res = await fetch(`${API_BASE}/upload-image`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageBase64, filename, sku }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to upload product image to local storage');
    }
    return res.json();
  },

  // Update Product
  async updateProduct(id: string, product: Partial<Product>): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    if (!res.ok) throw new Error('Failed to update product');
    return res.json();
  },

  // Update Product Offer / Promotional Period
  async updateProductOffer(
    id: string,
    offerData: {
      isOfferActive: boolean;
      offerType?: 'percentage' | 'flat';
      offerValue?: number;
      offerTitle?: string;
      offerStartDate?: string | null;
      offerEndDate?: string | null;
    }
  ): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/products/${id}/offer`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(offerData),
    });
    if (!res.ok) throw new Error('Failed to update product offer');
    return res.json();
  },

  // Delete Product
  async deleteProduct(id: string): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/products/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete product');
    return res.json();
  },

  // Customers
  async getCustomers(): Promise<Customer[]> {
    const res = await fetch(`${API_BASE}/customers`);
    if (!res.ok) throw new Error('Failed to fetch customers');
    return res.json();
  },

  async saveCustomer(customer: Partial<Customer>): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/customers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(customer),
    });
    if (!res.ok) throw new Error('Failed to save customer');
    return res.json();
  },

  async updateCustomer(id: string, customer: Partial<Customer>): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/customers/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(customer),
    });
    if (!res.ok) throw new Error('Failed to update customer');
    return res.json();
  },

  async adjustCustomerCredit(id: string, storeCredit: number): Promise<{ success: boolean; customer: any }> {
    const res = await fetch(`${API_BASE}/customers/${id}/credit`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ storeCredit }),
    });
    if (!res.ok) throw new Error('Failed to update customer store credit');
    return res.json();
  },

  async deleteCustomer(id: string): Promise<{ success: boolean; id: string }> {
    const res = await fetch(`${API_BASE}/customers/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete customer');
    return res.json();
  },

  // Orders & Atomic checkout
  async getOrders(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/orders`);
    if (!res.ok) throw new Error('Failed to fetch orders');
    return res.json();
  },

  async createOrder(orderData: any): Promise<{ success: boolean; orderId: string }> {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Order creation failed' }));
      throw new Error(err.error || 'Failed to place order');
    }
    return res.json();
  },

  // Suppliers
  async getSuppliers(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/suppliers`);
    if (!res.ok) throw new Error('Failed to fetch suppliers');
    return res.json();
  },

  async createSupplier(supplier: any): Promise<any> {
    const res = await fetch(`${API_BASE}/suppliers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(supplier),
    });
    if (!res.ok) throw new Error('Failed to create supplier');
    return res.json();
  },

  async updateSupplier(id: string, supplier: any): Promise<any> {
    const res = await fetch(`${API_BASE}/suppliers/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(supplier),
    });
    if (!res.ok) throw new Error('Failed to update supplier');
    return res.json();
  },

  async deleteSupplier(id: string): Promise<any> {
    const res = await fetch(`${API_BASE}/suppliers/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete supplier');
    return res.json();
  },

  // Purchase Orders (Multi-Item POs)
  async getPurchaseOrders(): Promise<PurchaseOrder[]> {
    const res = await fetch(`${API_BASE}/purchase-orders`);
    if (!res.ok) throw new Error('Failed to fetch purchase orders');
    return res.json();
  },

  async seedDefaultPurchaseOrders(force = false): Promise<{ success: boolean; count: number }> {
    const res = await fetch(`${API_BASE}/purchase-orders/seed-defaults`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ force }),
    });
    if (!res.ok) throw new Error('Failed to seed default purchase orders');
    return res.json();
  },

  async createPurchaseOrder(poData: any): Promise<any> {
    const res = await fetch(`${API_BASE}/purchase-orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(poData),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to create purchase order' }));
      throw new Error(err.error || 'Failed to create purchase order');
    }
    return res.json();
  },

  async updatePurchaseOrder(id: string, poData: any): Promise<any> {
    const res = await fetch(`${API_BASE}/purchase-orders/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(poData),
    });
    if (!res.ok) throw new Error('Failed to update purchase order');
    return res.json();
  },

  // GRN Receipt with item disposition & hold/reject
  async receiveGRN(grnData: any): Promise<any> {
    const res = await fetch(`${API_BASE}/grn/receive`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(grnData),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to process GRN' }));
      throw new Error(err.error || 'Failed to process GRN');
    }
    return res.json();
  },

  // 3-Way Matches
  async getThreeWayMatches(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/three-way-matches`);
    if (!res.ok) throw new Error('Failed to fetch 3-way matches');
    return res.json();
  },

  async createThreeWayMatch(matchData: any): Promise<any> {
    const res = await fetch(`${API_BASE}/three-way-matches`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(matchData),
    });
    if (!res.ok) throw new Error('Failed to create 3-way match');
    return res.json();
  },

  // AI Visual Produce & Grocery Recognition
  async identifyItemVisually(imageBase64: string, mimeType: string = 'image/jpeg'): Promise<any> {
    const res = await fetch(`${API_BASE}/ai/vision-identify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: imageBase64, mimeType }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'AI visual recognition failed' }));
      throw new Error(err.error || 'AI visual recognition failed');
    }
    return res.json();
  },

  // AI Voice Natural Language POS Command Parser
  async parseVoiceCommand(speechText: string): Promise<any> {
    const res = await fetch(`${API_BASE}/ai/voice-command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ speechText }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'AI voice command parsing failed' }));
      throw new Error(err.error || 'AI voice command parsing failed');
    }
    return res.json();
  },

  // AI Direct Audio Stream Voice Command Parser
  async parseAudioVoiceCommand(audioBase64: string, mimeType: string = 'audio/webm'): Promise<any> {
    const res = await fetch(`${API_BASE}/ai/audio-voice-command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ audio: audioBase64, mimeType }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'AI audio voice recognition failed' }));
      throw new Error(err.error || 'AI audio voice recognition failed');
    }
    return res.json();
  },

  // Fast Direct Audio Speech Transcription to Text
  async transcribeSpeech(audioBase64: string, mimeType: string = 'audio/webm'): Promise<string> {
    const res = await fetch(`${API_BASE}/ai/transcribe-speech`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ audio: audioBase64, mimeType }),
    });
    if (!res.ok) {
      return '';
    }
    const data = await res.json();
    return data.transcript || '';
  },

  // Peripherals Status Diagnostic
  async getPeripheralsStatus(): Promise<any> {
    const res = await fetch(`${API_BASE}/peripherals/status`);
    if (!res.ok) throw new Error('Failed to fetch peripherals status');
    return res.json();
  },

  // Database Management
  async getDatabaseStatus(): Promise<any> {
    const res = await fetch(`${API_BASE}/database/status`);
    if (!res.ok) throw new Error('Failed to fetch database status');
    return res.json();
  },

  async getDatabaseConfig(): Promise<any> {
    const res = await fetch(`${API_BASE}/database/config`);
    if (!res.ok) throw new Error('Failed to fetch database config');
    return res.json();
  },

  async testMysqlConnection(config: any): Promise<{ success: boolean; message: string; version?: string }> {
    const res = await fetch(`${API_BASE}/database/test-mysql`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    return res.json();
  },

  async switchDatabaseDriver(driver: string, mysqlConfig?: any): Promise<{ success: boolean; message: string; status: any }> {
    const res = await fetch(`${API_BASE}/database/switch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ driver, mysql: mysqlConfig }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: 'Failed to switch database driver' }));
      throw new Error(err.message || 'Failed to switch database driver');
    }
    return res.json();
  },

  async migrateToMysql(mysqlConfig?: any): Promise<{ success: boolean; counts: Record<string, number>; message: string }> {
    const res = await fetch(`${API_BASE}/database/migrate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mysql: mysqlConfig }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: 'Failed to migrate data to MySQL' }));
      throw new Error(err.message || 'Failed to migrate data to MySQL');
    }
    return res.json();
  },
};
