import {
  Product,
  Customer,
  ShiftRecord,
  Supplier,
  PurchaseOrder,
  ThreeWayMatchRecord
} from '../types/pos';
import { CLOUDINARY_PRODUCTS } from '../../scripts/cloudinary-catalog';

export const INITIAL_CATEGORIES = [
  'Fruits',
  'Vegetables',
  'Groceries',
  'Dairy',
  'Beverages',
  'Snacks',
  'Others'
];

export const INITIAL_PRODUCTS: Product[] = CLOUDINARY_PRODUCTS.map((item) => {
  const urlObj = new URL(item.imageUrl);
  const originalFilename = urlObj.pathname.split('/').pop() || 'product.jpg';
  const sanitizedFilename = originalFilename.toLowerCase().replace(/[^a-z0-9._\-]/g, '_');
  const localPath = `/images/products/${sanitizedFilename}`;

  // Pre-seed some popular items with attractive Offers of the Day
  let isOfferActive = false;
  let offerType: 'percentage' | 'flat' = 'percentage';
  let offerValue = 0;
  let offerTitle = 'Offer of the Day';

  if (item.id === 'PROD-0001' || item.name.toLowerCase().includes('indian apple')) {
    isOfferActive = true;
    offerType = 'percentage';
    offerValue = 20; // 20% off
    offerTitle = 'Offer of the Day';
  } else if (item.id === 'PROD-0026' || item.name.toLowerCase().includes('watermelon')) {
    isOfferActive = true;
    offerType = 'flat';
    offerValue = 25; // ₹25 flat off
    offerTitle = 'Super Deal of the Day';
  } else if (item.id === 'PROD-0011' || item.name.toLowerCase().includes('sweet lime')) {
    isOfferActive = true;
    offerType = 'percentage';
    offerValue = 15; // 15% off
    offerTitle = 'Fresh Citrus Deal';
  } else if (item.id === 'PROD-0020' || item.name.toLowerCase().includes('blue berry')) {
    isOfferActive = true;
    offerType = 'flat';
    offerValue = 50; // ₹50 flat off
    offerTitle = 'Weekend Berry Special';
  } else if (item.id === 'PROD-0036' || item.name.toLowerCase().includes('yellow banana')) {
    isOfferActive = true;
    offerType = 'percentage';
    offerValue = 20; // 20% off
    offerTitle = 'Offer of the Day';
  }

  return {
    id: item.id,
    name: item.name,
    description: `${item.name} - Fresh and quality retail stock`,
    category: item.category || 'General',
    brand: 'Farm Fresh',
    unit: item.unit || 'kg',
    baseSku: item.sku,
    baseBarcode: item.barcode,
    basePrice: item.price,
    baseMrp: item.mrp,
    baseCost: item.cost,
    image: localPath,
    imagePath: localPath,
    imageUrl: localPath,
    taxable: true,
    gstRate: 0.05,
    isOfferActive,
    offerType,
    offerValue,
    offerTitle,
    attributes: [
      { id: `attr_${item.id}`, name: 'Standard Unit', values: ['1 Unit'] }
    ],
    status: 'active',
    dailyConsumptionRate: 15.0,
    leadTimeDays: 2,
    supplierId: 'SUP-16',
    totalOnHand: 100,
    totalAvailable: 100,
    variants: [
      {
        id: `VAR-${item.id}-1`,
        productId: item.id,
        sku: item.sku,
        barcode: item.barcode,
        name: `${item.name} (Standard)`,
        unit: item.unit || 'kg',
        attributes: { 'Standard Unit': '1 Unit' },
        mrp: item.mrp,
        price: item.price,
        cost: item.cost,
        marginPercent: Math.round(((item.price - item.cost) / (item.price || 1)) * 100),
        onHand: 100,
        available: 100,
        reserved: 0,
        reorderLevel: 10,
        isParent: true,
      }
    ]
  };
});

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust_walkin_cash',
    name: 'Walk-in Cash Customer',
    phone: '9876543210',
    email: 'customer@store.local',
    loyaltyPoints: 0,
    storeCredit: 0.0,
    totalSpent: 0,
    memberTier: 'Regular',
    recentPurchasesCount: 1,
  },
  {
    id: 'cust_rajesh_kumar',
    name: 'Rajesh Kumar',
    phone: '9840123456',
    email: 'rajesh.k@gmail.com',
    loyaltyPoints: 340,
    storeCredit: 50.0,
    totalSpent: 18450.0,
    memberTier: 'Gold',
    recentPurchasesCount: 24,
  },
  {
    id: 'cust_priya_sharma',
    name: 'Priya Sharma',
    phone: '9840987654',
    email: 'priya.sharma@yahoo.com',
    loyaltyPoints: 890,
    storeCredit: 120.0,
    totalSpent: 42100.0,
    memberTier: 'VIP',
    recentPurchasesCount: 52,
  },
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'SUP-16',
    name: 'Central Wholesale Mandi',
    contactPerson: 'Ramesh Patel',
    phone: '9840112233',
    contactEmail: 'orders@centralmandi.com',
    leadTimeDays: 2,
    rating: 4.8,
    paymentTerms: 'Net 15',
    marketType: 'Mandi Trader',
  },
  {
    id: 'SUP-19',
    name: 'Southern Fresh Produce Co.',
    contactPerson: 'K. Venkatesh',
    phone: '9840223344',
    contactEmail: 'dispatch@southernfresh.in',
    leadTimeDays: 1,
    rating: 4.9,
    paymentTerms: 'Net 7',
    marketType: 'Farmer Producer Group',
  }
];

export const DEFAULT_SHIFT_RECORD: ShiftRecord = {
  id: 'shift_default_current',
  shiftId: 'SHIFT-001',
  terminalId: 'POS-01',
  operatorId: 'op_balu',
  operatorName: 'Balu Sub (Owner)',
  openedAt: new Date().toISOString(),
  openingFloat: 2000,
  cashSales: 0,
  upiSales: 0,
  cardSales: 0,
  cashRefunds: 0,
  midShiftDrops: 0,
  paidInOut: 0,
  expectedBalance: 2000,
  actualCounted: 2000,
  variance: 0,
  denominations: {
    bills: {
      d2000: 0,
      d500: 2,
      d200: 3,
      d100: 3,
      d50: 2,
      d20: 0,
      d10: 0,
      unknown: 0,
    },
    coins: 0,
  },
  notes: 'Store opening shift',
  status: 'open',
};

export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [
  {
    id: 'PO-20260827-101',
    poNumber: 'PO-20260827-101',
    supplierId: 'SUP-16',
    supplierName: 'Central Wholesale Mandi',
    totalAmount: 6450.0,
    status: 'ISSUED',
    createdAt: new Date(Date.now() - 86400000).toISOString(), // Yesterday
    expectedDelivery: new Date(Date.now() - 43200000).toISOString().slice(0, 10),
    aiSuggested: true,
    aiReason: 'High daily sales velocity detected for Indian Apples & Sweet Lime',
    safetyStockTrigger: 15,
    items: [
      {
        id: 'POI-101-1',
        sku: 'SKU-PROD-0001',
        productName: 'Indian Apple (Shimla)',
        variantId: 'VAR-PROD-0001-1',
        quantityOrdered: 50,
        quantityReceived: 0,
        quantityPending: 50,
        unit: 'kg',
        unitCost: 65,
        totalCost: 3250,
      },
      {
        id: 'POI-101-2',
        sku: 'SKU-PROD-0011',
        productName: 'Sweet Lime (Mosambi)',
        variantId: 'VAR-PROD-0011-1',
        quantityOrdered: 40,
        quantityReceived: 0,
        quantityPending: 40,
        unit: 'kg',
        unitCost: 35,
        totalCost: 1400,
      },
      {
        id: 'POI-101-3',
        sku: 'SKU-PROD-0026',
        productName: 'Fresh Watermelon',
        variantId: 'VAR-PROD-0026-1',
        quantityOrdered: 60,
        quantityReceived: 0,
        quantityPending: 60,
        unit: 'kg',
        unitCost: 30,
        totalCost: 1800,
      },
    ],
  },
  {
    id: 'PO-20260826-204',
    poNumber: 'PO-20260826-204',
    supplierId: 'SUP-19',
    supplierName: 'Southern Fresh Produce Co.',
    totalAmount: 8120.0,
    status: 'FULFILLED',
    createdAt: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
    expectedDelivery: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
    aiSuggested: false,
    items: [
      {
        id: 'POI-204-1',
        sku: 'SKU-PROD-0036',
        productName: 'Yellow Banana (Robusta)',
        variantId: 'VAR-PROD-0036-1',
        quantityOrdered: 80,
        quantityReceived: 80,
        quantityPending: 0,
        unit: 'kg',
        unitCost: 28,
        totalCost: 2240,
        disposition: 'ACCEPT',
      },
      {
        id: 'POI-204-2',
        sku: 'SKU-PROD-0020',
        productName: 'Blue Berry (Imported Punnet)',
        variantId: 'VAR-PROD-0020-1',
        quantityOrdered: 25,
        quantityReceived: 25,
        quantityPending: 0,
        unit: 'punnet',
        unitCost: 140,
        totalCost: 3500,
        disposition: 'ACCEPT',
      },
      {
        id: 'POI-204-3',
        sku: 'SKU-PROD-0005',
        productName: 'Nagpur Oranges',
        variantId: 'VAR-PROD-0005-1',
        quantityOrdered: 40,
        quantityReceived: 40,
        quantityPending: 0,
        unit: 'kg',
        unitCost: 59.5,
        totalCost: 2380,
        disposition: 'ACCEPT',
      },
    ],
  },
  {
    id: 'PO-20260828-305',
    poNumber: 'PO-20260828-305',
    supplierId: 'SUP-16',
    supplierName: 'Central Wholesale Mandi',
    totalAmount: 7800.0,
    status: 'ISSUED',
    createdAt: new Date().toISOString(), // Today
    expectedDelivery: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
    aiSuggested: true,
    aiReason: 'Replenishment for weekend rush demand forecasting',
    safetyStockTrigger: 20,
    items: [
      {
        id: 'POI-305-1',
        sku: 'SKU-PROD-0015',
        productName: 'Pomegranate (Kesar)',
        variantId: 'VAR-PROD-0015-1',
        quantityOrdered: 30,
        quantityReceived: 0,
        quantityPending: 30,
        unit: 'kg',
        unitCost: 110,
        totalCost: 3300,
      },
      {
        id: 'POI-305-2',
        sku: 'SKU-PROD-0008',
        productName: 'Hybrid Farm Fresh Tomatoes',
        variantId: 'VAR-PROD-0008-1',
        quantityOrdered: 50,
        quantityReceived: 0,
        quantityPending: 50,
        unit: 'kg',
        unitCost: 30,
        totalCost: 1500,
      },
      {
        id: 'POI-305-3',
        sku: 'SKU-PROD-0003',
        productName: 'Alphonso Mango Box',
        variantId: 'VAR-PROD-0003-1',
        quantityOrdered: 20,
        quantityReceived: 0,
        quantityPending: 20,
        unit: 'box',
        unitCost: 150,
        totalCost: 3000,
      },
    ],
  },
  {
    id: 'PO-20260825-412',
    poNumber: 'PO-20260825-412',
    supplierId: 'SUP-19',
    supplierName: 'Southern Fresh Produce Co.',
    totalAmount: 3250.0,
    status: 'PARTIALLY_RECEIVED',
    createdAt: new Date(Date.now() - 259200000).toISOString(), // 3 days ago
    expectedDelivery: new Date(Date.now() - 172800000).toISOString().slice(0, 10),
    aiSuggested: false,
    items: [
      {
        id: 'POI-412-1',
        sku: 'SKU-PROD-0030',
        productName: 'Tender Coconut (Pack of 6)',
        variantId: 'VAR-PROD-0030-1',
        quantityOrdered: 20,
        quantityReceived: 10,
        quantityPending: 10,
        unit: 'pack',
        unitCost: 125,
        totalCost: 2500,
        disposition: 'ACCEPT',
      },
      {
        id: 'POI-412-2',
        sku: 'SKU-PROD-0032',
        productName: 'Fresh Mint & Coriander Bunch',
        variantId: 'VAR-PROD-0032-1',
        quantityOrdered: 50,
        quantityReceived: 50,
        quantityPending: 0,
        unit: 'bunch',
        unitCost: 15,
        totalCost: 750,
        disposition: 'ACCEPT',
      },
    ],
  },
];

export const INITIAL_THREE_WAY_MATCHES: ThreeWayMatchRecord[] = [
  {
    id: 'TWM-001',
    poId: 'PO-20260826-204',
    poNumber: 'PO-20260826-204',
    grnNumber: 'GRN-20260827-089',
    invoiceNumber: 'INV-SFP-8842',
    supplierName: 'Southern Fresh Produce Co.',
    poAmount: 8120.0,
    grnReceivedAmount: 8120.0,
    invoiceAmount: 8120.0,
    discrepancyAmount: 0.0,
    status: 'MATCHED',
    discrepancyNote: '100% 3-way reconciliation passed. Quantity and billing rate matched.',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    matchedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'TWM-002',
    poId: 'PO-20260827-101',
    poNumber: 'PO-20260827-101',
    grnNumber: 'GRN-20260828-012',
    invoiceNumber: 'INV-MANDI-9014',
    supplierName: 'Central Wholesale Mandi',
    poAmount: 6450.0,
    grnReceivedAmount: 4400.0,
    invoiceAmount: 4400.0,
    discrepancyAmount: 0.0,
    status: 'MATCHED',
    discrepancyNote: 'Partial GRN delivery accepted (₹4,400.00). Balance ₹2,050.00 pending delivery.',
    timestamp: new Date(Date.now() - 21600000).toISOString(),
    matchedAt: new Date(Date.now() - 21600000).toISOString(),
  },
  {
    id: 'TWM-003',
    poId: 'PO-20260825-412',
    poNumber: 'PO-20260825-412',
    grnNumber: 'GRN-20260826-041',
    invoiceNumber: 'INV-SFP-7719',
    supplierName: 'Southern Fresh Produce Co.',
    poAmount: 3250.0,
    grnReceivedAmount: 2000.0,
    invoiceAmount: 2200.0,
    discrepancyAmount: 200.0,
    status: 'DISCREPANCY_ALERT',
    discrepancyNote: 'Invoice amount (₹2,200.00) exceeds physically accepted GRN intake value (₹2,000.00) by ₹200.00.',
    timestamp: new Date(Date.now() - 129600000).toISOString(),
  },
];
export const INITIAL_THREE_WAY_MATCH = INITIAL_THREE_WAY_MATCHES;
export const SUPPLIERS = INITIAL_SUPPLIERS;
export const INITIAL_SHIFTS: ShiftRecord[] = [DEFAULT_SHIFT_RECORD];
export const INITIAL_SHIFT: ShiftRecord = DEFAULT_SHIFT_RECORD;

