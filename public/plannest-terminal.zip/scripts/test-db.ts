import pool, { sqliteClient } from '../server/db';

async function run() {
  console.log('Testing SQLite Local Database connection and tables...');

  try {
    const [result] = await pool.query("SELECT 1 as isLive, datetime('now') as currentTime");
    console.log('SQLite Ping Test Result:', result);

    const [tables] = await pool.query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;");
    console.log('Existing SQLite Tables:', tables);

    const [prods] = await pool.query('SELECT COUNT(*) as count FROM products');
    console.log('Products Count:', prods);

    const [vars] = await pool.query('SELECT COUNT(*) as count FROM product_variants');
    console.log('Variants Count:', vars);

    console.log('✅ SQLite Database is fully functional and ready!');
  } catch (err: any) {
    console.error('SQLite Test Error:', err.message);
  }
}

run();
