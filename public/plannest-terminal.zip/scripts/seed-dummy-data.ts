import pool from '../server/db';

async function inspectAndSeed() {
  console.log('[SQLite Seeder] Inspecting and verifying database seeds...');

  const [products]: any = await pool.query('SELECT * FROM products LIMIT 10');
  const [variants]: any = await pool.query('SELECT * FROM product_variants LIMIT 10');
  console.log(`[SQLite Seeder] ${products.length} products and ${variants.length} variants loaded.`);

  const [categories]: any = await pool.query('SELECT * FROM categories');
  console.log(`[SQLite Seeder] ${categories.length} categories found.`);

  const [customers]: any = await pool.query('SELECT * FROM customers');
  console.log(`[SQLite Seeder] ${customers.length} customers found.`);

  const [suppliers]: any = await pool.query('SELECT * FROM suppliers');
  console.log(`[SQLite Seeder] ${suppliers.length} suppliers found.`);

  const [pos]: any = await pool.query('SELECT * FROM purchase_orders');
  console.log(`[SQLite Seeder] ${pos.length} purchase orders found.`);

  console.log('✅ [SQLite Seeder] All seed verification completed successfully!');
}

inspectAndSeed().catch((err) => {
  console.error('Seeding check error:', err);
});
