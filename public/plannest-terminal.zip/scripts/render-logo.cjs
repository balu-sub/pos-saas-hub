const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const baseDir = 'E:/Plannest/Local_Web_POS';
const svgPath = path.join(baseDir, 'public/Logos/Logo 1.svg');
const htmlPath = path.join(baseDir, 'public/Logos/render.html');
const outPng = path.join(baseDir, 'public/Logos/Logo.png');

const svgContent = fs.readFileSync(svgPath, 'utf8');

const htmlContent = `<!DOCTYPE html>
<html>
<head>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; padding: 0; background: transparent; display: flex; align-items: center; justify-content: center; width: 600px; height: 260px; overflow: hidden; }
  svg { width: 565px; height: 236px; }
</style>
</head>
<body>
${svgContent}
</body>
</html>`;

fs.writeFileSync(htmlPath, htmlContent, 'utf8');

const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/');

console.log('Rendering via Edge:', fileUrl);
try {
  execSync(`"${edgePath}" --headless --disable-gpu --default-background-color=00000000 --window-size=600,260 --screenshot="${outPng}" "${fileUrl}"`, { stdio: 'inherit' });
  console.log('Screenshot written to:', outPng);
} catch (e) {
  console.error('Error running edge:', e.message);
}

if (fs.existsSync(outPng)) {
  const stat = fs.statSync(outPng);
  console.log('Resulting PNG size:', stat.size);
  // Copy to all needed destinations
  const targets = [
    path.join(baseDir, 'public/Logo.png'),
    path.join(baseDir, 'public/First.png'),
    path.join(baseDir, 'src/assets/Logo.png'),
    path.join(baseDir, 'src/assets/First.png'),
    path.join(baseDir, 'First.png')
  ];
  for (const t of targets) {
    fs.copyFileSync(outPng, t);
    console.log('Copied to:', t);
  }
}
