import fs from 'fs';
import path from 'path';
import https from 'https';
import pool, { sqliteClient } from '../server/db';
import { CLOUDINARY_PRODUCTS } from './cloudinary-catalog';

const targetDir = path.resolve(process.cwd(), 'public/images/products');
if (!fs.existsSync(targetDir)) {
  fs.mkdirSync(targetDir, { recursive: true });
}

function downloadImage(url: string, dest: string): Promise<void> {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        if (res.headers.location) {
          return downloadImage(res.headers.location, dest).then(resolve).catch(reject);
        }
      }

      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }

      const fileStream = fs.createWriteStream(dest);
      res.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close();
        resolve();
      });
      fileStream.on('error', (err) => {
        fs.unlink(dest, () => reject(err));
      });
    }).on('error', reject);
  });
}

async function cleanAndSyncCatalog() {
  console.log(`[Clean & Sync] Processing ${CLOUDINARY_PRODUCTS.length} authoritative products...`);

  // 1. Build set of valid filenames that must stay in public/images/products
  const validFilenames = new Set<string>();
  const productFileMap = new Map<string, string>(); // prodId -> localRelativePath

  for (const item of CLOUDINARY_PRODUCTS) {
    const urlObj = new URL(item.imageUrl);
    const originalFilename = path.basename(urlObj.pathname);
    const sanitizedFilename = originalFilename.toLowerCase().replace(/[^a-z0-9._\-]/g, '_');
    validFilenames.add(sanitizedFilename);
    productFileMap.set(item.id, `/images/products/${sanitizedFilename}`);
  }

  // 2. Remove any extraneous/placeholder files from public/images/products
  const existingFiles = fs.readdirSync(targetDir);
  let removedFilesCount = 0;
  for (const file of existingFiles) {
    if (!validFilenames.has(file)) {
      const filePath = path.join(targetDir, file);
      fs.unlinkSync(filePath);
      console.log(`🗑️ Removed placeholder/unused file: ${file}`);
      removedFilesCount++;
    }
  }

  // 3. Ensure all authoritative images are downloaded
  let downloadedCount = 0;
  for (let i = 0; i < CLOUDINARY_PRODUCTS.length; i++) {
    const item = CLOUDINARY_PRODUCTS[i];
    const urlObj = new URL(item.imageUrl);
    const originalFilename = path.basename(urlObj.pathname);
    const sanitizedFilename = originalFilename.toLowerCase().replace(/[^a-z0-9._\-]/g, '_');
    const destPath = path.join(targetDir, sanitizedFilename);

    if (!fs.existsSync(destPath) || fs.statSync(destPath).size < 200) {
      try {
        await downloadImage(item.imageUrl, destPath);
        const stats = fs.statSync(destPath);
        console.log(`[${i + 1}/${CLOUDINARY_PRODUCTS.length}] ✓ Downloaded ${sanitizedFilename} (${Math.round(stats.size / 1024)} KB)`);
        downloadedCount++;
      } catch (err: any) {
        console.warn(`[${i + 1}/${CLOUDINARY_PRODUCTS.length}] ! Cloudinary download failed for ${sanitizedFilename}, creating SVG:`, err.message);
        const svgFallback = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400"><rect width="400" height="400" fill="#f8fafc"/><circle cx="200" cy="180" r="60" fill="#e2e8f0"/><text x="50%" y="70%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-weight="bold" font-size="22" fill="#0f172a">${item.name}</text><text x="50%" y="80%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#64748b">${item.category}</text></svg>`;
        fs.writeFileSync(destPath, svgFallback);
      }
    }
  }

  // 4. Wipe old/dummy products and product_variants in SQLite
  console.log('[SQLite DB] Purging old sample/placeholder products from database...');
  await sqliteClient.execute('DELETE FROM product_variants');
  await sqliteClient.execute('DELETE FROM products');

  // 5. Insert ONLY the exact 170 products and variants
  for (const item of CLOUDINARY_PRODUCTS) {
    const localRelativePath = productFileMap.get(item.id)!;
    const categoryName = item.category || 'General';

    await sqliteClient.execute({
      sql: `INSERT INTO products (
        id, name, description, category, brand, unit,
        base_sku, base_barcode, base_price, base_mrp, base_cost,
        image_url, taxable, gst_rate, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
      args: [
        item.id,
        item.name,
        `${item.name} - Fresh and quality retail stock`,
        categoryName,
        'Alfa Retail',
        item.unit || 'kg',
        item.sku,
        item.barcode,
        item.price,
        item.mrp,
        item.cost,
        localRelativePath,
        1,
        0.05,
      ],
    });

    const variantId = `VAR-${item.id}-1`;
    await sqliteClient.execute({
      sql: `INSERT INTO product_variants (
        id, product_id, sku, barcode, name, unit,
        mrp, price, cost, on_hand, available, reorder_level, is_parent
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 100, 100, 10, 1)`,
      args: [
        variantId,
        item.id,
        item.sku,
        item.barcode,
        `${item.name} (Standard)`,
        item.unit || 'kg',
        item.mrp,
        item.price,
        item.cost,
      ],
    });
  }

  const [totalProducts]: any = await pool.query('SELECT COUNT(*) as count FROM products');
  const [totalVariants]: any = await pool.query('SELECT COUNT(*) as count FROM product_variants');
  const remainingFiles = fs.readdirSync(targetDir);

  console.log('====================================================');
  console.log(`✅ Cleanup & Catalog Synchronization Complete!`);
  console.log(`🗑️ Removed ${removedFilesCount} placeholder/unused files.`);
  console.log(`🖼️ Total Clean Images in /public/images/products: ${remainingFiles.length}`);
  console.log(`📦 Total Products in SQLite DB: ${totalProducts[0].count}`);
  console.log(`🏷️ Total Variants in SQLite DB: ${totalVariants[0].count}`);
  console.log('====================================================');
}

cleanAndSyncCatalog().catch((err) => {
  console.error('Error during cleanup:', err);
});
