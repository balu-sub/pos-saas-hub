const http = require('http');

async function crawl(url, visited = new Set()) {
  if (visited.has(url) || visited.size > 500) return;
  visited.add(url);
  try {
    const res = await fetch(url);
    if (!res.ok) {
      console.error('❌ FAILED URL:', url, 'STATUS:', res.status);
      const txt = await res.text();
      console.error('ERROR BODY:', txt.substring(0, 300));
      return;
    }
    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('javascript') || url.includes('.tsx') || url.includes('.ts') || url.includes('.js')) {
      const text = await res.text();
      const importRegex = /from\s+["']([^"']+)["']/g;
      let match;
      while ((match = importRegex.exec(text)) !== null) {
        let importPath = match[1];
        if (importPath.startsWith('/')) {
          await crawl('http://localhost:3000' + importPath, visited);
        }
      }
    }
  } catch (err) {
    console.error('❌ ERROR FETCHING:', url, err.message);
  }
}

crawl('http://localhost:3000/src/main.tsx').then(() => {
  console.log('✅ Crawling finished successfully without 404s/500s.');
});
