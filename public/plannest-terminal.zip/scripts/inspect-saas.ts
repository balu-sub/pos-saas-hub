import { Pool } from 'pg';
import 'dotenv/config';

const pool = new Pool({
  host: process.env.SUPABASE_HOST,
  port: Number(process.env.SUPABASE_PORT) || 5432,
  database: process.env.SUPABASE_DB,
  user: process.env.SUPABASE_USER,
  password: process.env.SUPABASE_PASSWORD,
  ssl: { rejectUnauthorized: false }
});

async function run() {
  const client = await pool.connect();
  try {
    await client.query("UPDATE stores SET apptype = 'esp' WHERE id = 'STORE-001'");
    console.log("Updated STORE-001 apptype to 'esp'");

    for (const t of ['stores', 'saas_licenses', 'saas_terminal_telemetry', 'devices', 'store_members']) {
      const cols = await client.query("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = $1", [t]);
      console.log(`\nTable ${t}:`);
      console.log(cols.rows.map(c => `${c.column_name} (${c.data_type})`).join(', '));
      const sample = await client.query(`SELECT * FROM "${t}" LIMIT 3`);
      console.log(`Sample (${sample.rows.length}):`, sample.rows);
    }
  } finally {
    client.release();
    await pool.end();
  }
}

run().catch(console.error);
