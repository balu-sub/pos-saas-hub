import { Pool } from 'pg';
import pool, { sqliteClient } from '../server/db';
import 'dotenv/config';

const storeId = process.env.STORE_ID || 'STORE-002';

const pgPool = new Pool({
  host: process.env.SUPABASE_HOST || 'aws-0-ap-northeast-1.pooler.supabase.com',
  port: Number(process.env.SUPABASE_PORT) || 5432,
  database: process.env.SUPABASE_DB || 'postgres',
  user: process.env.SUPABASE_USER || 'postgres.xcrndfislsbxzzkfrawp',
  password: process.env.SUPABASE_PASSWORD,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 10000,
});

async function sync() {
  console.log(`Starting sync from Local SQLite to Supabase for store: ${storeId}...`);
  const pg = await pgPool.connect();

  try {
    // 1. Ensure store exists in 'stores' table
    await pg.query(`
      INSERT INTO stores (id, name, apptype, is_active)
      VALUES ($1, $2, 'windows', true)
      ON CONFLICT (id) DO UPDATE SET apptype = 'windows', is_active = true
    `, [storeId, `Plannest POS Terminal (${storeId})`]);
    console.log(`✓ Store record verified for ${storeId} in 'stores' table.`);

    // 2. Sync Categories
    const [categories]: any = await pool.query('SELECT * FROM categories');
    console.log(`Syncing ${categories.length} categories...`);
    for (const cat of categories) {
      await pg.query(`
        INSERT INTO "Windows_categories" (id, store_id, name, description, icon, color, display_order, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (id, store_id) DO UPDATE SET
          name = EXCLUDED.name,
          description = EXCLUDED.description,
          icon = EXCLUDED.icon,
          color = EXCLUDED.color,
          display_order = EXCLUDED.display_order,
          status = EXCLUDED.status
      `, [
        cat.id,
        storeId,
        cat.name,
        cat.description || null,
        cat.icon || null,
        cat.color || null,
        cat.display_order || 0,
        cat.status || 'active',
      ]);
    }
    console.log(`✓ Synced ${categories.length} categories.`);

    // 3. Sync Suppliers
    const [suppliers]: any = await pool.query('SELECT * FROM suppliers');
    console.log(`Syncing ${suppliers.length} suppliers...`);
    for (const sup of suppliers) {
      await pg.query(`
        INSERT INTO "Windows_suppliers" (id, store_id, name, code, contact_person, email, phone, address, gst_number, payment_terms, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        ON CONFLICT (id, store_id) DO UPDATE SET
          name = EXCLUDED.name,
          code = EXCLUDED.code,
          contact_person = EXCLUDED.contact_person,
          email = EXCLUDED.email,
          phone = EXCLUDED.phone,
          address = EXCLUDED.address,
          gst_number = EXCLUDED.gst_number,
          payment_terms = EXCLUDED.payment_terms,
          status = EXCLUDED.status
      `, [
        sup.id,
        storeId,
        sup.name,
        sup.code,
        sup.contact_person || null,
        sup.email || null,
        sup.phone || null,
        sup.address || null,
        sup.gst_number || null,
        sup.payment_terms || 'Net 15',
        sup.status || 'active',
      ]);
    }
    console.log(`✓ Synced ${suppliers.length} suppliers.`);

    // 4. Sync Products
    const [products]: any = await pool.query('SELECT * FROM products');
    console.log(`Syncing ${products.length} products...`);
    for (const p of products) {
      await pg.query(`
        INSERT INTO "Windows_products" (
          id, store_id, name, description, category, brand, unit,
          base_sku, base_barcode, base_price, base_mrp, base_cost,
          image_url, taxable, gst_rate, status, daily_consumption_rate,
          lead_time_days, supplier_id, total_on_hand, total_available,
          is_offer_active, offer_type, offer_value, offer_title
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11, $12,
          $13, $14, $15, $16, $17,
          $18, $19, $20, $21,
          $22, $23, $24, $25
        )
        ON CONFLICT (id, store_id) DO UPDATE SET
          name = EXCLUDED.name,
          description = EXCLUDED.description,
          category = EXCLUDED.category,
          brand = EXCLUDED.brand,
          unit = EXCLUDED.unit,
          base_sku = EXCLUDED.base_sku,
          base_barcode = EXCLUDED.base_barcode,
          base_price = EXCLUDED.base_price,
          base_mrp = EXCLUDED.base_mrp,
          base_cost = EXCLUDED.base_cost,
          image_url = EXCLUDED.image_url,
          taxable = EXCLUDED.taxable,
          gst_rate = EXCLUDED.gst_rate,
          status = EXCLUDED.status,
          total_on_hand = EXCLUDED.total_on_hand,
          total_available = EXCLUDED.total_available
      `, [
        p.id,
        storeId,
        p.name,
        p.description || null,
        p.category,
        p.brand || 'Store Brand',
        p.unit || 'kg',
        p.base_sku || null,
        p.base_barcode || null,
        Number(p.base_price) || 0,
        Number(p.base_mrp) || 0,
        Number(p.base_cost) || 0,
        p.image_url || null,
        p.taxable ? 1 : 0,
        Number(p.gst_rate) || 0,
        p.status || 'active',
        Number(p.daily_consumption_rate) || 1.0,
        Number(p.lead_time_days) || 2,
        p.supplier_id || 'SUPP-001',
        Number(p.total_on_hand) || 50,
        Number(p.total_available) || 50,
        p.is_offer_active ? 1 : 0,
        p.offer_type || 'percentage',
        Number(p.offer_value) || 0,
        p.offer_title || 'Offer of the Day',
      ]);
    }
    console.log(`✓ Synced ${products.length} products.`);

    // 5. Sync Product Variants
    const [variants]: any = await pool.query('SELECT * FROM product_variants');
    console.log(`Syncing ${variants.length} product variants...`);
    for (const v of variants) {
      let attrs: any = null;
      try {
        attrs = typeof v.attributes === 'string' ? JSON.parse(v.attributes) : v.attributes;
      } catch {
        attrs = null;
      }

      await pg.query(`
        INSERT INTO "Windows_product_variants" (
          id, store_id, product_id, sku, barcode, name, unit,
          attributes, mrp, price, cost, margin_percent,
          on_hand, available, reserved, reorder_level, is_parent, version
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11, $12,
          $13, $14, $15, $16, $17, $18
        )
        ON CONFLICT (id, store_id) DO UPDATE SET
          name = EXCLUDED.name,
          sku = EXCLUDED.sku,
          barcode = EXCLUDED.barcode,
          mrp = EXCLUDED.mrp,
          price = EXCLUDED.price,
          cost = EXCLUDED.cost,
          on_hand = EXCLUDED.on_hand,
          available = EXCLUDED.available
      `, [
        v.id,
        storeId,
        v.product_id,
        v.sku,
        v.barcode || null,
        v.name,
        v.unit || 'kg',
        attrs ? JSON.stringify(attrs) : null,
        Number(v.mrp) || 0,
        Number(v.price) || 0,
        Number(v.cost) || 0,
        Number(v.margin_percent) || 0,
        Number(v.on_hand) || 50,
        Number(v.available) || 50,
        Number(v.reserved) || 0,
        Number(v.reorder_level) || 10,
        v.is_parent ? 1 : 0,
        Number(v.version) || 1,
      ]);
    }
    console.log(`✓ Synced ${variants.length} product variants.`);

    // 6. Sync Customers
    const [customers]: any = await pool.query('SELECT * FROM customers');
    console.log(`Syncing ${customers.length} customers...`);
    for (const c of customers) {
      await pg.query(`
        INSERT INTO "Windows_customers" (
          id, store_id, name, email, phone, loyalty_points, tier,
          member_tier, is_loyalty_member, total_spend, total_spent, store_credit,
          recent_purchases_count, gst_number, notes
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11, $12,
          $13, $14, $15
        )
        ON CONFLICT (id, store_id) DO UPDATE SET
          name = EXCLUDED.name,
          email = EXCLUDED.email,
          phone = EXCLUDED.phone,
          loyalty_points = EXCLUDED.loyalty_points,
          tier = EXCLUDED.tier
      `, [
        c.id,
        storeId,
        c.name,
        c.email || null,
        c.phone || null,
        Number(c.loyalty_points) || 0,
        c.tier || 'Standard',
        c.member_tier || 'Standard',
        c.is_loyalty_member ? 1 : 0,
        Number(c.total_spend) || 0,
        Number(c.total_spent) || 0,
        Number(c.store_credit) || 0,
        Number(c.recent_purchases_count) || 0,
        c.gst_number || null,
        c.notes || null,
      ]);
    }
    console.log(`✓ Synced ${customers.length} customers.`);

    // 7. Sync Users
    const [users]: any = await pool.query('SELECT * FROM users');
    console.log(`Syncing ${users.length} users/operators...`);
    for (const u of users) {
      await pg.query(`
        INSERT INTO "Windows_users" (
          id, store_id, name, pin, role, role_title, user_role,
          email, phone, initials, status
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11
        )
        ON CONFLICT (id, store_id) DO UPDATE SET
          name = EXCLUDED.name,
          pin = EXCLUDED.pin,
          role = EXCLUDED.role,
          status = EXCLUDED.status
      `, [
        u.id,
        storeId,
        u.name,
        u.pin,
        u.role || 'Cashier',
        u.role_title || null,
        u.user_role || 'Staff',
        u.email || null,
        u.phone || null,
        u.initials || 'OP',
        u.status || 'active',
      ]);
    }
    console.log(`✓ Synced ${users.length} users.`);

    // 8. Sync Outlet Profile & Loyalty Settings
    const [profiles]: any = await pool.query('SELECT * FROM outlet_profile');
    if (profiles.length > 0) {
      const prof = profiles[0];
      await pg.query(`
        INSERT INTO "Windows_outlet_profile" (
          id, store_id, outlet_name, tagline, gstin, fssai_lic_no, address, phone, email, currency_symbol
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        ON CONFLICT (id, store_id) DO UPDATE SET
          outlet_name = EXCLUDED.outlet_name,
          address = EXCLUDED.address,
          phone = EXCLUDED.phone
      `, [
        prof.id,
        storeId,
        prof.outlet_name || 'Plannest POS',
        prof.tagline || null,
        prof.gstin || null,
        prof.fssai_lic_no || null,
        prof.address || null,
        prof.phone || null,
        prof.email || null,
        prof.currency_symbol || '₹',
      ]);
      console.log('✓ Synced outlet profile.');
    }

    const [loyalty]: any = await pool.query('SELECT * FROM loyalty_settings');
    if (loyalty.length > 0) {
      const l = loyalty[0];
      await pg.query(`
        INSERT INTO "Windows_loyalty_settings" (
          id, store_id, program_name, is_active, points_per_currency, currency_per_point, min_redemption_points
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (id, store_id) DO UPDATE SET
          program_name = EXCLUDED.program_name,
          points_per_currency = EXCLUDED.points_per_currency,
          currency_per_point = EXCLUDED.currency_per_point
      `, [
        l.id,
        storeId,
        l.program_name || 'Plannest Rewards',
        l.is_active ? 1 : 0,
        Number(l.points_per_currency) || 1.0,
        Number(l.currency_per_point) || 0.25,
        Number(l.min_redemption_points) || 50,
      ]);
      console.log('✓ Synced loyalty settings.');
    }

    console.log('\n🎉 ALL LOCAL DATA SUCCESSFULLY SYNCED TO SUPABASE!');
  } finally {
    pg.release();
    await pgPool.end();
  }
}

sync().catch((e) => {
  console.error('❌ Sync failed:', e);
  process.exit(1);
});
