import { sqliteClient } from '../server/db';

async function updateDbImagePaths() {
  console.log('[SQLite DB] Updating existing product image_urls to exact local paths...');

  const updates: [string, string][] = [
    ['prod_tomato_hyb', '/images/products/tomatoes_hybrid.jpg'],
    ['prod_onion_nashik', '/images/products/nashik_red_onions.jpg'],
    ['prod_potato_jyoti', '/images/products/agra_jyoti_potatoes.jpg'],
    ['prod_chilli_green', '/images/products/green_chillies.jpg'],
    ['prod_banana_rob', '/images/products/robusta_bananas.jpg'],
    ['prod_apple_shimla', '/images/products/shimla_apples.jpg'],
    ['prod_rice_sona', '/images/products/sona_masoori_rice.jpg'],
    ['prod_atta_aashirvaad', '/images/products/aashirvaad_atta.jpg'],
    ['prod_dal_toor', '/images/products/tata_toor_dal.jpg'],
    ['prod_dal_moong', '/images/products/moong_dal.jpg'],
    ['prod_dairy_paneer', '/images/products/amul_paneer.jpg'],
    ['prod_dairy_milk', '/images/products/amul_taaza_milk.jpg'],
    ['prod_oil_fortune_sun', '/images/products/fortune_sunflower_oil.jpg'],
    ['prod_ghee_cow', '/images/products/amul_cow_ghee.jpg'],
    ['prod_spc_haldi', '/images/products/everest_turmeric.jpg'],
    ['prod_spc_jeera', '/images/products/catch_jeera.jpg'],
    ['prod_bev_tea_redlabel', '/images/products/red_label_tea.jpg'],
    ['prod_snk_bhujia', '/images/products/haldiram_bhujia.jpg'],
  ];

  for (const [id, path] of updates) {
    await sqliteClient.execute({
      sql: 'UPDATE products SET image_url = ? WHERE id = ?',
      args: [path, id],
    });
  }

  const res = await sqliteClient.execute('SELECT id, name, image_url FROM products');
  console.log(`✅ [SQLite DB] Successfully matched and updated all ${res.rows.length} products to exact local images:`);
  for (const row of res.rows) {
    console.log(`  ✓ ${(row as any).name}: ${(row as any).image_url}`);
  }
}

updateDbImagePaths().catch((err) => {
  console.error('Error updating images in DB:', err);
});
