import { Pool } from 'pg';
import 'dotenv/config';

const host = process.env.SUPABASE_HOST || 'aws-0-ap-northeast-1.pooler.supabase.com';
const port = Number(process.env.SUPABASE_PORT) || 5432;
const database = process.env.SUPABASE_DB || 'postgres';
const user = process.env.SUPABASE_USER || '';
const password = process.env.SUPABASE_PASSWORD || '';

const pool = new Pool({
  host,
  port,
  database,
  user,
  password,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 10000,
});

async function main() {
  try {
    console.log(`Connecting to Supabase host: ${host}:${port}...`);
    const client = await pool.connect();
    console.log('✅ Connected successfully to Supabase!');

    const res = await client.query('SELECT current_database(), current_user, version()');
    console.log('Database info:', res.rows[0]);

    const tables = await client.query(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name"
    );
    console.log('Tables in public schema:', tables.rows.map((r: any) => r.table_name));

    // Check stores table if present
    const hasStores = tables.rows.some((r: any) => r.table_name === 'stores');
    if (hasStores) {
      const storesCols = await client.query(
        "SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'stores'"
      );
      console.log('Stores table columns:', storesCols.rows);

      const storeRows = await client.query('SELECT * FROM stores LIMIT 5');
      console.log('Existing stores:', storeRows.rows);
    } else {
      console.log('No stores table found yet.');
    }

    const prodCount = await client.query('SELECT COUNT(*) as cnt FROM "Windows_products"');
    const catCount = await client.query('SELECT COUNT(*) as cnt FROM "Windows_categories"');
    console.log(`Supabase Windows_products count: ${prodCount.rows[0].cnt}, Windows_categories: ${catCount.rows[0].cnt}`);

    client.release();
    await pool.end();
  } catch (err: any) {
    console.error('❌ Connection error:', err.message || err);
  }
}

main();
