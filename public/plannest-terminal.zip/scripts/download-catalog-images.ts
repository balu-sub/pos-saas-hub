import fs from 'fs';
import path from 'path';
import https from 'https';

const IMAGES_TO_FETCH: { name: string; filename: string; url: string }[] = [
  {
    name: 'Fresh Farm Tomatoes',
    filename: 'tomatoes_hybrid.jpg',
    url: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Nashik Red Onions',
    filename: 'nashik_red_onions.jpg',
    url: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Agra Jyoti Potatoes',
    filename: 'agra_jyoti_potatoes.jpg',
    url: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Spicy Green Chillies',
    filename: 'green_chillies.jpg',
    url: 'https://images.unsplash.com/photo-1588252303782-cb80119abd6d?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Robusta Bananas',
    filename: 'robusta_bananas.jpg',
    url: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Royal Shimla Apples',
    filename: 'shimla_apples.jpg',
    url: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Sona Masoori Raw Rice',
    filename: 'sona_masoori_rice.jpg',
    url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Aashirvaad Sharbati Atta',
    filename: 'aashirvaad_atta.jpg',
    url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Tata Sampann Toor Dal',
    filename: 'tata_toor_dal.jpg',
    url: 'https://images.unsplash.com/photo-1585994192701-f1a505c817ea?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Organic Yellow Moong Dal',
    filename: 'moong_dal.jpg',
    url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Amul Fresh Malai Paneer',
    filename: 'amul_paneer.jpg',
    url: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Amul Taaza Milk',
    filename: 'amul_taaza_milk.jpg',
    url: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Fortune Sunlite Sunflower Oil',
    filename: 'fortune_sunflower_oil.jpg',
    url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Amul Pure Desi Cow Ghee',
    filename: 'amul_cow_ghee.jpg',
    url: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Everest Turmeric Powder',
    filename: 'everest_turmeric.jpg',
    url: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Catch Cumin Seeds Jeera',
    filename: 'catch_jeera.jpg',
    url: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Brooke Bond Red Label Tea',
    filename: 'red_label_tea.jpg',
    url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Haldiram Nagpur Aloo Bhujia',
    filename: 'haldiram_bhujia.jpg',
    url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Default Grocery Product',
    filename: 'default_product.jpg',
    url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80',
  },
];

const targetDir = path.resolve(process.cwd(), 'public/images/products');
if (!fs.existsSync(targetDir)) {
  fs.mkdirSync(targetDir, { recursive: true });
}

function downloadImage(url: string, dest: string): Promise<void> {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      // Handle redirect
      if (res.statusCode === 301 || res.statusCode === 302) {
        if (res.headers.location) {
          return downloadImage(res.headers.location, dest).then(resolve).catch(reject);
        }
      }

      if (res.statusCode !== 200) {
        return reject(new Error(`Failed to download ${url}, status: ${res.statusCode}`));
      }

      const fileStream = fs.createWriteStream(dest);
      res.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close();
        resolve();
      });
      fileStream.on('error', (err) => {
        fs.unlink(dest, () => reject(err));
      });
    }).on('error', reject);
  });
}

async function run() {
  console.log(`[Image Downloader] Downloading all 18 catalog images to local directory: ${targetDir}`);

  for (const item of IMAGES_TO_FETCH) {
    const destPath = path.join(targetDir, item.filename);
    try {
      await downloadImage(item.url, destPath);
      const stats = fs.statSync(destPath);
      console.log(`✓ Downloaded ${item.filename} (${Math.round(stats.size / 1024)} KB)`);
    } catch (err: any) {
      console.warn(`! Failed downloading ${item.filename}, creating SVG fallback:`, err.message);
      const svgFallback = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400"><rect width="400" height="400" fill="#f1f5f9"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="20" fill="#64748b">${item.name}</text></svg>`;
      fs.writeFileSync(destPath, svgFallback);
    }
  }

  console.log('✅ All product images are now stored locally in /public/images/products!');
}

run();
