import 'dotenv/config';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { execSync } from 'child_process';
import express from 'express';
import app from './server/app';
import { scaleService } from './server/scaleService';

function getWindowsMachineGuid(): string {
  if (process.platform !== 'win32') return 'NON-WIN';
  try {
    const out = execSync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid /reg:64',
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }
    );
    const m = out.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    if (m && m[1]) return m[1].trim().toUpperCase();
  } catch {
    // ignore
  }
  return '';
}

function verifyHardwareLock(): boolean {
  try {
    const lockPath = path.resolve(process.cwd(), 'data', 'license.lock');
    if (!fs.existsSync(lockPath)) return true;
    const raw = fs.readFileSync(lockPath, 'utf8').trim();
    const parts = raw.split('|');
    if (parts.length < 3) return false;
    const [storeId, licenseKey, savedSig] = parts;
    const machineGuid = getWindowsMachineGuid();
    if (!machineGuid) return true;
    const payload = `${storeId.trim().toUpperCase()}|${licenseKey.trim().toUpperCase()}|${machineGuid}`;
    const expectedSig = crypto
      .createHmac('sha256', 'PlannestPOS_India_Hardware_Lock_v2_9940630536')
      .update(payload, 'utf8')
      .digest('hex')
      .toLowerCase();
    return savedSig.trim().toLowerCase() === expectedSig;
  } catch {
    return true;
  }
}

if (!verifyHardwareLock()) {
  console.error(
    '[License Lock Error] Hardware License Lock Mismatch: This installation is bound to another billing machine.'
  );
  process.exit(1);
}

const PORT = Number(process.env.PORT) || 3000;

// Serve compiled production frontend from dist/
const distPath = path.resolve(process.cwd(), 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath, {
    maxAge: 0,
    etag: true,
    setHeaders: (res, pathStr) => {
      if (pathStr.endsWith('.html') || pathStr.endsWith('sw.js') || pathStr.endsWith('.json')) {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
    }
  }));

  // Fallback to index.html for SPA routing
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

const httpServer = app.listen(PORT, '0.0.0.0', () => {
  console.log(`Plannest POS Server running on port ${PORT}`);
});

httpServer.on('error', (err: any) => {
  console.error(`[Server Error] Port ${PORT}:`, err?.message || err);
});

const gracefulShutdown = () => {
  try {
    scaleService.disconnect();
  } catch {}
  httpServer.close(() => {
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 2000).unref();
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
