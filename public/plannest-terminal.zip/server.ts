import 'dotenv/config';
import path from 'path';
import express from 'express';
import app from './server/app';

const PORT = Number(process.env.PORT) || 3000;

// Serve static build in production
const distPath = path.resolve(process.cwd(), 'dist');
app.use(express.static(distPath));

// Fallback to index.html for SPA routing
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Plannest POS Server running on port ${PORT}`);
});

