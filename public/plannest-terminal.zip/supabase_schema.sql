-- ==============================================================================
-- PLANNEST POS - SUPABASE CLOUD SCHEMA (WINDOWS APP TABLES)
-- ==============================================================================
-- Project: Plannest POS (Supabase)
-- Target: Central Cloud Database coexisting with ESP / Android / Windows devices
-- ==============================================================================

-- 1. Ensure 'stores' table has 'apptype' column
ALTER TABLE IF EXISTS stores 
ADD COLUMN IF NOT EXISTS apptype VARCHAR(50) DEFAULT 'windows';

-- Comment on column
COMMENT ON COLUMN stores.apptype IS 'Identifies device or app tier: esp, android, windows, web';


-- ==============================================================================
-- 2. Windows_ Categories Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_categories" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    color TEXT,
    display_order INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_categories_store ON "Windows_categories"(store_id);


-- ==============================================================================
-- 3. Windows_ Products Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_products" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL,
    brand TEXT DEFAULT 'Store Brand',
    unit TEXT DEFAULT 'kg',
    base_sku TEXT,
    base_barcode TEXT,
    base_price NUMERIC(12, 2) DEFAULT 0,
    base_mrp NUMERIC(12, 2) DEFAULT 0,
    base_cost NUMERIC(12, 2) DEFAULT 0,
    image_url TEXT,
    taxable INTEGER DEFAULT 0,
    gst_rate NUMERIC(6, 4) DEFAULT 0,
    status TEXT DEFAULT 'active',
    daily_consumption_rate NUMERIC(10, 2) DEFAULT 1.0,
    lead_time_days INTEGER DEFAULT 2,
    supplier_id TEXT DEFAULT 'SUPP-001',
    total_on_hand NUMERIC(12, 3) DEFAULT 50.0,
    total_available NUMERIC(12, 3) DEFAULT 50.0,
    is_offer_active INTEGER DEFAULT 0,
    offer_type TEXT DEFAULT 'percentage',
    offer_value NUMERIC(10, 2) DEFAULT 0,
    offer_title TEXT DEFAULT 'Offer of the Day',
    offer_start_date TIMESTAMPTZ,
    offer_end_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_products_store ON "Windows_products"(store_id);
CREATE INDEX IF NOT EXISTS idx_win_products_category ON "Windows_products"(store_id, category);


-- ==============================================================================
-- 4. Windows_ Product Variants Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_product_variants" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    product_id TEXT NOT NULL,
    sku TEXT NOT NULL,
    barcode TEXT,
    name TEXT NOT NULL,
    unit TEXT DEFAULT 'kg',
    attributes JSONB,
    mrp NUMERIC(12, 2) DEFAULT 0,
    price NUMERIC(12, 2) DEFAULT 0,
    cost NUMERIC(12, 2) DEFAULT 0,
    margin_percent NUMERIC(8, 2) DEFAULT 0,
    on_hand NUMERIC(12, 3) DEFAULT 50.0,
    available NUMERIC(12, 3) DEFAULT 50.0,
    reserved NUMERIC(12, 3) DEFAULT 0.0,
    reorder_level NUMERIC(12, 3) DEFAULT 10.0,
    is_parent INTEGER DEFAULT 0,
    version INTEGER DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_variants_store_prod ON "Windows_product_variants"(store_id, product_id);
CREATE INDEX IF NOT EXISTS idx_win_variants_sku ON "Windows_product_variants"(store_id, sku);


-- ==============================================================================
-- 5. Windows_ Customers Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_customers" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    loyalty_points INTEGER DEFAULT 0,
    tier TEXT DEFAULT 'Standard',
    member_tier TEXT DEFAULT 'Standard',
    is_loyalty_member INTEGER DEFAULT 1,
    loyalty_joined_date TIMESTAMPTZ,
    loyalty_expiry_date TIMESTAMPTZ,
    total_spend NUMERIC(12, 2) DEFAULT 0.0,
    total_spent NUMERIC(12, 2) DEFAULT 0.0,
    store_credit NUMERIC(12, 2) DEFAULT 0.0,
    recent_purchases_count INTEGER DEFAULT 0,
    gst_number TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_customers_store_phone ON "Windows_customers"(store_id, phone);


-- ==============================================================================
-- 6. Windows_ Suppliers Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_suppliers" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    name TEXT NOT NULL,
    code TEXT NOT NULL,
    contact_person TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    gst_number TEXT,
    payment_terms TEXT DEFAULT 'Net 15',
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_suppliers_store ON "Windows_suppliers"(store_id);


-- ==============================================================================
-- 7. Windows_ Users & Operators Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_users" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    name TEXT NOT NULL,
    pin TEXT NOT NULL,
    role TEXT NOT NULL,
    role_title TEXT,
    user_role TEXT DEFAULT 'Staff',
    email TEXT,
    phone TEXT,
    initials TEXT DEFAULT 'OP',
    status TEXT DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_users_store ON "Windows_users"(store_id);


-- ==============================================================================
-- 8. Windows_ Orders Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_orders" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    order_number TEXT NOT NULL,
    terminal_id TEXT DEFAULT 'POS-TERM-01',
    shift_id TEXT,
    customer_id TEXT,
    customer_name TEXT,
    customer_phone TEXT,
    cashier_id TEXT,
    cashier_name TEXT,
    operator_id TEXT,
    subtotal NUMERIC(12, 2) DEFAULT 0.0,
    tax_amount NUMERIC(12, 2) DEFAULT 0.0,
    tax_rate NUMERIC(6, 4) DEFAULT 0.0,
    tax_total NUMERIC(12, 2) DEFAULT 0.0,
    discount_total NUMERIC(12, 2) DEFAULT 0.0,
    rounding_delta NUMERIC(8, 2) DEFAULT 0.0,
    total NUMERIC(12, 2) DEFAULT 0.0,
    grand_total NUMERIC(12, 2) DEFAULT 0.0,
    amount_paid NUMERIC(12, 2) DEFAULT 0.0,
    change_due NUMERIC(12, 2) DEFAULT 0.0,
    item_count INTEGER DEFAULT 0,
    status TEXT DEFAULT 'completed',
    synced INTEGER DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_orders_store_date ON "Windows_orders"(store_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_win_orders_number ON "Windows_orders"(store_id, order_number);


-- ==============================================================================
-- 9. Windows_ Order Items Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_order_items" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    order_id TEXT NOT NULL,
    product_id TEXT,
    variant_id TEXT,
    product_name TEXT NOT NULL,
    sku TEXT,
    barcode TEXT,
    unit TEXT DEFAULT 'kg',
    mrp NUMERIC(12, 2) DEFAULT 0.0,
    unit_price NUMERIC(12, 2) DEFAULT 0.0,
    quantity NUMERIC(12, 3) DEFAULT 1.0,
    discount_amount NUMERIC(12, 2) DEFAULT 0.0,
    discount_percent NUMERIC(6, 2) DEFAULT 0.0,
    applied_tax_rate NUMERIC(6, 4) DEFAULT 0.0,
    modifiers JSONB,
    pack_size TEXT,
    line_total NUMERIC(12, 2) DEFAULT 0.0,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_order_items_store_order ON "Windows_order_items"(store_id, order_id);


-- ==============================================================================
-- 10. Windows_ Payment Splits Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_payment_splits" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    order_id TEXT NOT NULL,
    tender_type TEXT NOT NULL,
    amount NUMERIC(12, 2) DEFAULT 0.0,
    reference TEXT,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'completed',
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_splits_store_order ON "Windows_payment_splits"(store_id, order_id);


-- ==============================================================================
-- 11. Windows_ Shifts Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_shifts" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    terminal_id TEXT DEFAULT 'POS-TERM-01',
    operator_id TEXT,
    operator_name TEXT,
    opened_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMPTZ,
    opening_float NUMERIC(12, 2) DEFAULT 5000.0,
    cash_sales NUMERIC(12, 2) DEFAULT 0.0,
    upi_sales NUMERIC(12, 2) DEFAULT 0.0,
    card_sales NUMERIC(12, 2) DEFAULT 0.0,
    store_credit_sales NUMERIC(12, 2) DEFAULT 0.0,
    total_sales NUMERIC(12, 2) DEFAULT 0.0,
    cash_drops NUMERIC(12, 2) DEFAULT 0.0,
    cash_payouts NUMERIC(12, 2) DEFAULT 0.0,
    expected_cash NUMERIC(12, 2) DEFAULT 5000.0,
    counted_cash NUMERIC(12, 2),
    variance NUMERIC(12, 2),
    notes TEXT,
    status TEXT DEFAULT 'open',
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_shifts_store ON "Windows_shifts"(store_id, opened_at DESC);


-- ==============================================================================
-- 12. Windows_ Inventory Ledger Table
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_inventory_ledger" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    product_id TEXT,
    variant_id TEXT,
    sku TEXT,
    product_name TEXT,
    delta NUMERIC(12, 3) DEFAULT 0.0,
    change_delta NUMERIC(12, 3) DEFAULT 0.0,
    balance_after NUMERIC(12, 3) DEFAULT 0.0,
    resulting_on_hand NUMERIC(12, 3) DEFAULT 0.0,
    mutation_type TEXT DEFAULT 'SALE',
    reason TEXT DEFAULT '',
    reference_id TEXT,
    operator TEXT,
    operator_id TEXT,
    notes TEXT,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_ledger_store_sku ON "Windows_inventory_ledger"(store_id, sku);


-- ==============================================================================
-- 13. Windows_ Purchase Orders & Items
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_purchase_orders" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    po_number TEXT NOT NULL,
    supplier_id TEXT NOT NULL,
    supplier_name TEXT NOT NULL,
    order_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    expected_delivery_date TIMESTAMPTZ,
    expected_delivery TEXT,
    total_amount NUMERIC(12, 2) DEFAULT 0.0,
    status TEXT DEFAULT 'DRAFT',
    ai_suggested INTEGER DEFAULT 0,
    ai_reason TEXT,
    safety_stock_trigger NUMERIC(12, 3),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);

CREATE TABLE IF NOT EXISTS "Windows_purchase_order_items" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    po_id TEXT NOT NULL,
    product_id TEXT,
    variant_id TEXT,
    sku TEXT NOT NULL,
    product_name TEXT NOT NULL,
    quantity_ordered NUMERIC(12, 3) NOT NULL DEFAULT 0.0,
    quantity_received NUMERIC(12, 3) DEFAULT 0.0,
    unit TEXT DEFAULT 'kg',
    unit_cost NUMERIC(12, 2) NOT NULL DEFAULT 0.0,
    total_cost NUMERIC(12, 2) NOT NULL DEFAULT 0.0,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_po_store ON "Windows_purchase_orders"(store_id);
CREATE INDEX IF NOT EXISTS idx_win_po_items_store ON "Windows_purchase_order_items"(store_id, po_id);


-- ==============================================================================
-- 14. Windows_ Three-Way Match Records
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_three_way_matches" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    po_id TEXT NOT NULL,
    po_number TEXT NOT NULL,
    grn_number TEXT NOT NULL,
    invoice_number TEXT NOT NULL,
    supplier_name TEXT NOT NULL,
    po_amount NUMERIC(12, 2) NOT NULL,
    grn_received_amount NUMERIC(12, 2) NOT NULL,
    invoice_amount NUMERIC(12, 2) NOT NULL,
    discrepancy_amount NUMERIC(12, 2) DEFAULT 0.0,
    status TEXT NOT NULL,
    discrepancy_note TEXT,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
CREATE INDEX IF NOT EXISTS idx_win_twm_store ON "Windows_three_way_matches"(store_id);


-- ==============================================================================
-- 15. Windows_ Outlet Profile & Loyalty Settings
-- ==============================================================================
CREATE TABLE IF NOT EXISTS "Windows_outlet_profile" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    outlet_name TEXT NOT NULL DEFAULT 'Plannest POS Store',
    tagline TEXT,
    gstin TEXT,
    fssai_lic_no TEXT,
    address TEXT,
    phone TEXT,
    email TEXT,
    currency_symbol TEXT DEFAULT '₹',
    receipt_header TEXT,
    receipt_footer TEXT,
    tax_type TEXT DEFAULT 'exclusive',
    round_off_mode TEXT DEFAULT 'nearest',
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);

CREATE TABLE IF NOT EXISTS "Windows_loyalty_settings" (
    id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    program_name TEXT DEFAULT 'Plannest Rewards',
    is_active INTEGER DEFAULT 1,
    points_per_currency NUMERIC(6, 2) DEFAULT 1.0,
    currency_per_point NUMERIC(6, 2) DEFAULT 0.25,
    min_redemption_points INTEGER DEFAULT 50,
    max_redemption_percentage NUMERIC(6, 2) DEFAULT 50.0,
    expiry_months INTEGER DEFAULT 12,
    signup_bonus_points INTEGER DEFAULT 100,
    birthday_bonus_points INTEGER DEFAULT 200,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, store_id)
);
