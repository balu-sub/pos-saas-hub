import fs from 'fs';
import path from 'path';
import { spawn, ChildProcess } from 'child_process';

export interface ScaleStatus {
  connected: boolean;
  port: string;
  baudRate: number;
  weight: number;
  unit: 'kg' | 'g';
  isStable: boolean;
  lastRaw: string;
  lastUpdated: number;
  error?: string;
}

class ScaleService {
  private currentStatus: ScaleStatus = {
    connected: false,
    port: 'COM6',
    baudRate: 9600,
    weight: 0.0,
    unit: 'kg',
    isStable: false,
    lastRaw: '',
    lastUpdated: 0,
  };

  private workerProcess: ChildProcess | null = null;
  private isShuttingDown: boolean = false;
  private reconnectTimer: any = null;

  constructor() {
    process.on('exit', () => this.disconnect());
    process.on('SIGINT', () => this.disconnect());
    process.on('SIGTERM', () => this.disconnect());
  }

  public getStatus(): ScaleStatus {
    return { ...this.currentStatus };
  }

  public disconnect(): void {
    this.isShuttingDown = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.workerProcess) {
      try {
        this.workerProcess.kill();
      } catch {}
      this.workerProcess = null;
    }
    this.currentStatus.connected = false;
    this.currentStatus.isStable = false;
  }

  public connect(portName: string = 'COM1', baudRate: number = 9600): boolean {
    if (process.platform !== 'win32') {
      console.warn('[ScaleService] Native COM reader only available on Windows');
      return false;
    }

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (this.workerProcess) {
      try {
        this.workerProcess.kill();
      } catch {}
      this.workerProcess = null;
    }

    const cleanPort = String(portName || 'COM6').trim().toUpperCase();
    if (!/^COM\d{1,3}$/.test(cleanPort)) {
      console.warn(`[ScaleService] Rejected invalid COM port name: ${portName}`);
      return false;
    }
    const cleanBaud = [1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200].includes(Number(baudRate))
      ? Number(baudRate)
      : 9600;

    this.isShuttingDown = false;
    this.currentStatus.port = cleanPort;
    this.currentStatus.baudRate = cleanBaud;
    this.currentStatus.error = undefined;

    // Robust PowerShell serial worker script
    // Note: Inside the while loop, we catch ALL exceptions (including MethodInvocationException on read timeouts)
    // so the worker never terminates on idle pauses.
    const psScript = `
$ErrorActionPreference = 'Stop'
$portName = '${this.currentStatus.port}'
$baudRate = ${this.currentStatus.baudRate}

try {
    $port = New-Object System.IO.Ports.SerialPort
    $port.PortName = $portName
    $port.BaudRate = $baudRate
    $port.Parity = 'None'
    $port.DataBits = 8
    $port.StopBits = 'One'
    $port.Handshake = 'None'
    $port.DtrEnable = $true
    $port.RtsEnable = $true
    $port.ReadTimeout = 1000
    $port.WriteTimeout = 1000
    $port.Open()
    Write-Output "CONNECTED"
    [Console]::Out.Flush()

    $buffer = ""
    $byteBuf = New-Object byte[] 64

    while ($port.IsOpen) {
        try {
            $bytesRead = $port.Read($byteBuf, 0, $byteBuf.Length)
            if ($bytesRead -gt 0) {
                for ($i = 0; $i -lt $bytesRead; $i++) {
                    $b = $byteBuf[$i] -band 0x7F
                    if ($b -eq 10 -or $b -eq 13 -or $b -eq 3) {
                        if ($buffer.Length -gt 0) {
                            $trimmed = $buffer.Trim()
                            if ($trimmed.Length -gt 0) {
                                Write-Output "RAW:$trimmed"
                                [Console]::Out.Flush()
                            }
                            $buffer = ""
                        }
                    } elseif ($b -ge 32 -and $b -le 126) {
                        $buffer += [char]$b
                        if ($buffer.Length -gt 120) {
                            $buffer = $buffer.Substring($buffer.Length - 60)
                        }
                    }
                }
            }
        } catch {
            # Catch ALL read timeouts & MethodInvocationException without breaking loop
            # Continue reading smoothly
        }
    }
} catch {
    Write-Output "ERROR:$($_.Exception.Message)"
    [Console]::Out.Flush()
} finally {
    if ($port -and $port.IsOpen) {
        $port.Close()
    }
}
`;

    try {
      this.workerProcess = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psScript]);

      this.workerProcess.stdout?.on('data', (data: Buffer) => {
        const lines = data.toString('utf8').split(/[\r\n]+/);
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;

          if (trimmed === 'CONNECTED') {
            this.currentStatus.connected = true;
            this.currentStatus.error = undefined;
            console.log(`[ScaleService] Successfully connected to native ${this.currentStatus.port} @ ${this.currentStatus.baudRate}`);
          } else if (trimmed.startsWith('ERROR:')) {
            this.currentStatus.connected = false;
            this.currentStatus.error = trimmed.replace('ERROR:', '').trim();
            console.warn(`[ScaleService] Port error on ${this.currentStatus.port}:`, this.currentStatus.error);
          } else if (trimmed.startsWith('RAW:')) {
            const raw = trimmed.replace('RAW:', '').trim();
            this.currentStatus.lastRaw = raw;
            this.currentStatus.lastUpdated = Date.now();
            this.parseWeightString(raw);
          }
        }
      });

      this.workerProcess.stderr?.on('data', (data: Buffer) => {
        const errStr = data.toString('utf8').trim();
        if (errStr) {
          console.warn('[ScaleService PS Error]:', errStr);
        }
      });

      this.workerProcess.on('close', (code) => {
        this.workerProcess = null;
        if (!this.isShuttingDown) {
          this.currentStatus.connected = false;
          console.log(`[ScaleService] Native port process closed (code: ${code}). Scheduling auto-reconnect in 3s...`);
          this.reconnectTimer = setTimeout(() => {
            if (!this.isShuttingDown && !this.currentStatus.connected) {
              console.log(`[ScaleService] Auto-reconnecting to ${this.currentStatus.port}...`);
              this.connect(this.currentStatus.port, this.currentStatus.baudRate);
            }
          }, 3000);
        }
      });

      return true;
    } catch (err: any) {
      this.currentStatus.connected = false;
      this.currentStatus.error = err.message || 'Failed to spawn serial worker';
      return false;
    }
  }

  private parseWeightString(raw: string) {
    // Protocol 1: XK3190 reversed string =005.20= -> 02.500
    const revMatch = raw.match(/=([0-9\.\s]+)=/);
    if (revMatch) {
      const revStr = revMatch[1].replace(/\s+/g, '').split('').reverse().join('');
      const val = parseFloat(revStr);
      if (!isNaN(val) && val >= 0) {
        this.currentStatus.weight = parseFloat(val.toFixed(3));
        this.currentStatus.isStable = true;
        return;
      }
    }

    // Protocol 2: Standard ASCII float with optional unit (e.g. ST,GS,+ 1.250kg, 1.250 kg, +001.25, - 0.005)
    const match = raw.match(/([+-]?\s*\d+\.\d{1,4})\s*(kg|g)?/i);
    if (match) {
      const numStr = match[1].replace(/\s+/g, '');
      const unit = (match[2] || '').toLowerCase();
      let val = parseFloat(numStr);
      if (!isNaN(val)) {
        if (unit === 'g') val = val / 1000;
        this.currentStatus.weight = parseFloat(Math.max(0, val).toFixed(3));
        this.currentStatus.isStable = !raw.includes('US');
        return;
      }
    }

    // Protocol 3: Raw integer grams (e.g. 001250)
    const intMatch = raw.match(/\b(\d{5,7})\b/);
    if (intMatch) {
      const intVal = parseInt(intMatch[1], 10);
      if (!isNaN(intVal) && intVal >= 0 && intVal < 500000) {
        this.currentStatus.weight = parseFloat((intVal / 1000).toFixed(3));
        this.currentStatus.isStable = true;
        return;
      }
    }
  }
}

export const scaleService = new ScaleService();
