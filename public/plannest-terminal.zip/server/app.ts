import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import pool, {
  getDatabaseStatus,
  switchDatabaseDriver,
  testMysqlConnection,
  migrateLocalDataToMysql,
  getConfig,
  seedPurchaseOrdersAndMatches,
} from './db';
import crypto from 'crypto';
import { startCloudSync, runSyncCycle, getSyncStatus, queueProductPush, queueProductDelete } from './cloudSync';
import path from 'path';
import fs from 'fs';
import { identifyVisualItem, parseVoiceCommand, parseAudioVoiceCommand, transcribeRawAudio } from './aiService';
import { authRouter, saasRouter } from './saasService';
import { applySystemUpdate } from './systemUpdate';

const app = express();

app.use(cors());
app.use(express.json({ limit: '25mb' })); // Support base64 camera and upload image payloads
app.use(express.urlencoded({ limit: '25mb', extended: true }));

// SaaS Hub & Authentication APIs with Rate Limiting
const authRateLimitMap = new Map<string, { count: number; resetTime: number }>();
const authRateLimiter = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const ip = String(req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1');
  const now = Date.now();
  const entry = authRateLimitMap.get(ip);
  if (!entry || now > entry.resetTime) {
    authRateLimitMap.set(ip, { count: 1, resetTime: now + 60000 });
    return next();
  }
  if (entry.count >= 30) {
    return res.status(429).json({
      error: 'Too many authentication attempts. Please try again after 1 minute.',
      retryAfterSeconds: Math.ceil((entry.resetTime - now) / 1000),
    });
  }
  entry.count += 1;
  next();
};

app.use('/api/auth', authRateLimiter, authRouter);
app.use('/api/saas', saasRouter);

// Ensure local product images directory exists
const publicDir = path.resolve(process.cwd(), 'public');
const imagesDir = path.resolve(process.cwd(), 'public/images/products');
if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir, { recursive: true });
}

// Serve product images directly from /images and /images/products static routes
app.use('/images/products', express.static(imagesDir, { maxAge: '1d', etag: true }));
app.use('/images', express.static(path.resolve(publicDir, 'images'), { maxAge: '1d', etag: true }));
app.use(express.static(publicDir, { maxAge: '1d', etag: true }));

// In-memory cache for ultra-fast instant POS catalog responses (< 5ms)
let cachedProducts: any[] | null = null;
let cacheTimestamp = 0;
const CACHE_TTL_MS = 60000; // 1 minute auto-refresh or instant on mutation/refresh

export function invalidateProductCache() {
  cachedProducts = null;
  cacheTimestamp = 0;
}

// -------------------------------------------------------------
// Cloud Store Identity & Catalog Synchronization
// -------------------------------------------------------------
const SUPABASE_REST_URL = 'https://xcrndfislsbxzzkfrawp.supabase.co/rest/v1';
const SUPABASE_KEY = 'sb_publishable_8eYBVChz4IW8bLEM6IhjaA_aB5HsJkR';

let hasSyncedStore = false;

export async function syncStoreFromCloud(targetStoreId?: string) {
  const storeId = targetStoreId || process.env.STORE_ID || 'STORE-002';
  try {
    console.log(`[Cloud Sync] Synchronizing terminal profile and catalog for Store ID: ${storeId}...`);
    // 1. Fetch store profile from Supabase
    const storeRes = await fetch(`${SUPABASE_REST_URL}/stores?id=eq.${encodeURIComponent(storeId)}`, {
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
      },
    });

    if (storeRes.ok) {
      const stores: any = await storeRes.json();
      if (Array.isArray(stores) && stores.length > 0) {
        const s = stores[0];
        console.log(`[Cloud Sync] Matched Cloud Store: "${s.name}" (${s.id})`);

        // Update local SQLite outlet_profile
        const [existing]: any = await pool.query('SELECT id FROM outlet_profile LIMIT 1');
        const pId = existing && existing.length > 0 ? existing[0].id : 'default_outlet';

        if (existing && existing.length > 0) {
          await pool.query(
            `UPDATE outlet_profile SET
              outlet_name = ?,
              branch_name = ?,
              address_line1 = ?,
              address_line2 = ?,
              phone = ?,
              gstin = ?,
              receipt_header_note = ?,
              bill_prefix = ?,
              bill_start_number = ?
            WHERE id = ?`,
            [
              s.name || 'Amma Appa Kadai',
              'Main Counter',
              s.address_line1 || '',
              s.address_line2 || '',
              s.phone || '',
              s.gstin || '',
              (s.name || 'Amma Appa Kadai').toUpperCase() + ' - BILLING COUNTER',
              s.bill_prefix || 'INV-',
              Number(s.starting_bill_no || 1001),
              pId,
            ]
          );
        } else {
          await pool.query(
            `INSERT INTO outlet_profile (
              id, outlet_name, branch_name, address_line1, address_line2, city, state, pincode,
              phone, email, gstin, pan_number, fssai_license, currency_symbol,
              receipt_header_note, receipt_footer_note, return_terms,
              bill_prefix, bill_start_number
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              'default_outlet',
              s.name || 'Amma Appa Kadai',
              'Main Counter',
              s.address_line1 || '',
              s.address_line2 || '',
              'Chennai',
              'Tamil Nadu',
              '600001',
              s.phone || '',
              '',
              s.gstin || '',
              '',
              '',
              'Rs.',
              (s.name || 'Amma Appa Kadai').toUpperCase() + ' - BILLING COUNTER',
              'Thank you for shopping with us! Visit again.',
              'Goods once sold cannot be returned.',
              s.bill_prefix || 'INV-',
              Number(s.starting_bill_no || 1001),
            ]
          );
        }
      }
    }

    // 2. Pull this store's catalog from the cloud (two-way sync runs continuously after boot)
    await runSyncCycle();

    hasSyncedStore = true;
  } catch (err: any) {
    console.warn('[Cloud Sync] Error syncing store from cloud:', err.message);
  }
}

// Auto-sync in background on server boot: store profile once, then live two-way catalog sync
setTimeout(() => {
  syncStoreFromCloud().catch(() => {});
  startCloudSync(process.env.STORE_ID, invalidateProductCache);
}, 1000);

// 0. Local Image Upload Endpoint (stores locally in public/images/products/)
app.post('/api/upload-image', async (req, res) => {
  try {
    const { imageBase64, filename, sku } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'imageBase64 is required' });
    }

    // Clean base64 prefix if present
    const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer: Buffer;
    let ext = 'jpg';

    if (matches && matches.length === 3) {
      const mime = matches[1];
      if (mime.includes('png')) ext = 'png';
      else if (mime.includes('webp')) ext = 'webp';
      else if (mime.includes('svg')) ext = 'svg';
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      buffer = Buffer.from(imageBase64, 'base64');
    }

    // Generate clean safe local filename
    const sanitizedSku = (sku || filename || 'prod')
      .toString()
      .toLowerCase()
      .replace(/[^a-z0-9_\-]/g, '_')
      .slice(0, 30);
    const uniqueSuffix = Date.now().toString().slice(-4);
    const finalFilename = `${sanitizedSku}_${uniqueSuffix}.${ext}`;
    const filePath = path.join(imagesDir, finalFilename);

    // Save image to local disk
    fs.writeFileSync(filePath, buffer);
    const localUrl = `/images/products/${finalFilename}`;

    console.log(`[Image Storage] Saved local product image: ${filePath} (${Math.round(buffer.length / 1024)} KB)`);

    res.json({
      success: true,
      imageUrl: localUrl,
      imagePath: localUrl,
      filename: finalFilename,
      sizeKb: Math.round(buffer.length / 1024),
    });
  } catch (error: any) {
    console.error('[Image Storage] Failed to upload image:', error);
    res.status(500).json({ error: error.message });
  }
});

// Health check & Database Status
app.get('/api/health', async (req, res) => {
  try {
    const status = await getDatabaseStatus();
    res.json({
      status: 'healthy',
      database: status.connected ? 'connected' : 'degraded',
      driver: status.driver,
      driverName: status.driverName,
      target: status.activeTarget,
    });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// Database Management APIs
app.get('/api/database/status', async (req, res) => {
  try {
    const status = await getDatabaseStatus();
    res.json(status);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/database/config', async (req, res) => {
  try {
    const config = getConfig();
    // Mask password in config response for safety
    res.json({
      driver: config.driver,
      mysql: {
        host: config.mysql.host,
        port: config.mysql.port,
        user: config.mysql.user,
        hasPassword: Boolean(config.mysql.password),
        database: config.mysql.database,
        ssl: config.mysql.ssl,
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/database/test-mysql', async (req, res) => {
  try {
    const { host, port, user, password, database, ssl } = req.body;
    const result = await testMysqlConnection({
      host: host || 'localhost',
      port: Number(port) || 3306,
      user: user || 'root',
      password: password || '',
      database: database || 'plannest_pos',
      ssl: Boolean(ssl),
    });
    res.json(result);
  } catch (error: any) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post('/api/database/switch', async (req, res) => {
  try {
    const { driver, mysql } = req.body;
    invalidateProductCache();
    const result = await switchDatabaseDriver(driver, mysql);
    const status = await getDatabaseStatus();
    res.json({ ...result, status });
  } catch (error: any) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post('/api/database/migrate', async (req, res) => {
  try {
    const { mysql } = req.body;
    const result = await migrateLocalDataToMysql(mysql);
    invalidateProductCache();
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 1. Categories
app.get('/api/categories', async (req, res) => {
  try {
    const [rows]: any = await pool.query('SELECT * FROM categories ORDER BY display_order ASC, name ASC');
    res.json(rows);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 2. Products and Variants (with Cache & DB fallback)
app.get('/api/products', async (req, res) => {
  const forceRefresh = req.query.refresh === 'true' || req.query.refresh === '1';
  const now = Date.now();

  if (!forceRefresh && cachedProducts && (now - cacheTimestamp < CACHE_TTL_MS)) {
    return res.json(cachedProducts);
  }

  try {
    const [products]: any = await pool.query('SELECT * FROM products ORDER BY name ASC');
    const [variants]: any = await pool.query('SELECT * FROM product_variants ORDER BY name ASC');

    const productsMap = products.map((prod: any) => {
      const prodVariants = variants.filter((v: any) => v.product_id === prod.id);

      // If no explicit variant rows exist in DB, provide default variant representation
      const mappedVariants = prodVariants.length > 0
        ? prodVariants.map((v: any) => ({
            id: v.id,
            productId: v.product_id,
            sku: v.sku || prod.base_sku || prod.id,
            barcode: v.barcode || prod.base_barcode || '',
            name: v.name || prod.name,
            unit: v.unit || prod.unit || 'kg',
            attributes: typeof v.attributes === 'string' ? JSON.parse(v.attributes || '{}') : (v.attributes || {}),
            mrp: Number(v.mrp || prod.base_mrp || prod.base_price || 0),
            price: Number(v.price || prod.base_price || 0),
            cost: Number(v.cost || prod.base_cost || 0),
            marginPercent: Number(v.margin_percent || 0),
            onHand: Number(v.on_hand !== undefined ? v.on_hand : 50),
            available: Number(v.available !== undefined ? v.available : 50),
            reserved: Number(v.reserved || 0),
            reorderLevel: Number(v.reorder_level || 10),
            image: prod.image_url || '',
            isParent: Boolean(v.is_parent),
            version: Number(v.version || 1),
          }))
        : [
            {
              id: `var_${prod.id}`,
              productId: prod.id,
              sku: prod.base_sku || `SKU-${prod.id}`,
              barcode: prod.base_barcode || '',
              name: prod.name,
              unit: prod.unit || 'kg',
              attributes: { 'Pack Size': prod.unit || 'kg' },
              mrp: Number(prod.base_mrp || prod.base_price || 0),
              price: Number(prod.base_price || 0),
              cost: Number(prod.base_cost || 0),
              marginPercent: 20,
              onHand: 50,
              available: 50,
              reserved: 0,
              reorderLevel: 10,
              image: prod.image_url || '',
              isParent: true,
              version: 1,
            },
          ];

      const totalOnHand = mappedVariants.reduce((sum: number, v: any) => sum + (v.onHand || 0), 0);
      const totalAvailable = mappedVariants.reduce((sum: number, v: any) => sum + (v.available || 0), 0);

      return {
        id: prod.id,
        name: prod.name,
        description: prod.description || '',
        categoryId: prod.category_id,
        category: prod.category || 'General',
        brand: prod.brand || 'Store Brand',
        unit: prod.unit || 'kg',
        baseSku: prod.base_sku || `SKU-${prod.id}`,
        baseBarcode: prod.base_barcode || '',
        basePrice: Number(prod.base_price || 0),
        baseMrp: Number(prod.base_mrp || prod.base_price || 0),
        baseCost: Number(prod.base_cost || 0),
        image: prod.image_url || '',
        imageUrl: prod.image_url || '',
        taxable: Boolean(prod.taxable),
        gstRate: Number(prod.gst_rate || 0),
        dailyConsumptionRate: Number(prod.daily_consumption_rate || 10),
        leadTimeDays: Number(prod.lead_time_days || 1),
        supplierId: prod.supplier_id || '',
        status: prod.status || 'active',
        totalOnHand,
        totalAvailable,
        isOfferActive: Boolean(prod.is_offer_active),
        offerType: prod.offer_type || 'percentage',
        offerValue: Number(prod.offer_value || 0),
        offerTitle: prod.offer_title || 'Offer of the Day',
        offerStartDate: prod.offer_start_date || undefined,
        offerEndDate: prod.offer_end_date || undefined,
        attributes: [
          {
            id: `attr_${prod.id}`,
            name: 'Weight / Pack',
            values: mappedVariants.map((v: any) => v.name),
          },
        ],
        variants: mappedVariants,
      };
    });

    cachedProducts = productsMap;
    cacheTimestamp = now;

    res.json(productsMap);
  } catch (error: any) {
    console.error('Error in /api/products:', error);
    res.status(500).json({ error: error.message });
  }
});

// Create or update product
app.post('/api/products', async (req, res) => {
  try {
    const {
      id,
      name,
      description,
      category,
      brand,
      unit,
      baseSku,
      baseBarcode,
      basePrice,
      baseMrp,
      baseCost,
      image,
      imageUrl,
      variants,
      isOfferActive,
      offerType,
      offerValue,
      offerTitle,
      offerStartDate,
      offerEndDate,
    } = req.body;

    // Standardize SKU format to SKU-XXXX (4 digits zero padded)
    let finalSku = (baseSku || '').trim().toUpperCase();
    let prodId = (id || '').trim();
    // Product ids are namespaced per store so two stores can never collide in the cloud catalog
    const storeTag = (process.env.STORE_ID || '').replace(/\D/g, '') ? (process.env.STORE_ID || '').replace(/\D/g, '') + '-' : '';

    if (!finalSku) {
      // Find highest number in DB
      const [allProds]: any = await pool.query('SELECT id, base_sku FROM products');
      let maxNum = 0;
      for (const p of allProds) {
        const idMatch = (p.id || '').match(/\d+/);
        if (idMatch) maxNum = Math.max(maxNum, parseInt(idMatch[0], 10));
        const skuMatch = (p.base_sku || '').match(/\d+/);
        if (skuMatch) maxNum = Math.max(maxNum, parseInt(skuMatch[0], 10));
      }
      const nextNum = maxNum + 1;
      finalSku = `SKU-${String(nextNum).padStart(4, '0')}`;
      if (!prodId) prodId = `PROD-${storeTag}${String(nextNum).padStart(4, '0')}`;
    } else {
      // Normalize entered SKU to SKU-XXXX if numbers are present
      const match = finalSku.match(/\d+/);
      if (match && !/^SKU-\d{4}$/.test(finalSku)) {
        finalSku = `SKU-${match[0].padStart(4, '0')}`;
      }
      if (!prodId) {
        const num = finalSku.replace('SKU-', '');
        prodId = `PROD-${storeTag}${num}`;
      }
    }

    const img = imageUrl || image || '';

    await pool.query(
      `INSERT INTO products (
        id, name, description, category, brand, unit, base_sku, base_barcode,
        base_price, base_mrp, base_cost, image_url, status,
        is_offer_active, offer_type, offer_value, offer_title, offer_start_date, offer_end_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name=excluded.name, description=excluded.description, category=excluded.category,
        unit=excluded.unit, base_sku=excluded.base_sku, base_price=excluded.base_price,
        base_mrp=excluded.base_mrp, base_cost=excluded.base_cost, image_url=excluded.image_url,
        is_offer_active=excluded.is_offer_active, offer_type=excluded.offer_type,
        offer_value=excluded.offer_value, offer_title=excluded.offer_title,
        offer_start_date=excluded.offer_start_date, offer_end_date=excluded.offer_end_date`,
      [
        prodId,
        name,
        description || '',
        category || 'Fresh Vegetables',
        brand || 'Store Brand',
        unit || 'kg',
        finalSku,
        baseBarcode || '',
        basePrice || 0,
        baseMrp || basePrice || 0,
        baseCost || 0,
        img,
        isOfferActive ? 1 : 0,
        offerType || 'percentage',
        offerValue || 0,
        offerTitle || 'Offer of the Day',
        offerStartDate || null,
        offerEndDate || null,
      ]
    );

    if (Array.isArray(variants) && variants.length > 0) {
      for (const v of variants) {
        const varId = v.id || `VAR-${prodId}-1`;
        let varSku = (v.sku || '').trim().toUpperCase();
        if (!varSku || varSku.includes('VAR-')) {
          varSku = finalSku;
        } else {
          const vMatch = varSku.match(/\d+/);
          if (vMatch && !/^SKU-\d{4}/.test(varSku)) {
            varSku = `SKU-${vMatch[0].padStart(4, '0')}`;
          }
        }
        await pool.query(
          `INSERT INTO product_variants (
            id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, on_hand, available, reorder_level
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET
            sku=excluded.sku, barcode=excluded.barcode, name=excluded.name, price=excluded.price, mrp=excluded.mrp, on_hand=excluded.on_hand`,
          [
            varId,
            prodId,
            varSku,
            v.barcode || '',
            v.name || name,
            v.unit || unit || 'kg',
            JSON.stringify(v.attributes || {}),
            v.mrp || baseMrp || 0,
            v.price || basePrice || 0,
            v.cost || baseCost || 0,
            v.onHand !== undefined ? v.onHand : 50,
            v.available !== undefined ? v.available : 50,
            v.reorderLevel || 10,
          ]
        );
      }
    } else {
      // Auto-insert default parent variant with finalSku
      const varId = `VAR-${prodId}-1`;
      await pool.query(
        `INSERT INTO product_variants (
          id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, on_hand, available, reorder_level, is_parent
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 100, 100, 10, 1)
        ON CONFLICT(id) DO UPDATE SET
          sku=excluded.sku, barcode=excluded.barcode, name=excluded.name, price=excluded.price, mrp=excluded.mrp`,
        [
          varId,
          prodId,
          finalSku,
          baseBarcode || '',
          `${name} (Standard)`,
          unit || 'kg',
          JSON.stringify({ 'Pack Size': `1 ${unit || 'kg'}` }),
          baseMrp || basePrice || 0,
          basePrice || 0,
          baseCost || 0,
        ]
      );
    }

    invalidateProductCache();
    queueProductPush(prodId);
    res.json({ success: true, id: prodId });
  } catch (error: any) {
    console.error('Error saving product:', error);
    res.status(500).json({ error: error.message });
  }
});

// Update product
app.put('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const {
      name,
      description,
      category,
      brand,
      unit,
      baseSku,
      baseBarcode,
      basePrice,
      baseMrp,
      baseCost,
      image,
      imageUrl,
      variants,
      isOfferActive,
      offerType,
      offerValue,
      offerTitle,
      offerStartDate,
      offerEndDate,
    } = req.body;

    const img = imageUrl || image || '';

    await pool.query(
      `UPDATE products SET
        name = COALESCE(?, name),
        description = COALESCE(?, description),
        category = COALESCE(?, category),
        brand = COALESCE(?, brand),
        unit = COALESCE(?, unit),
        base_sku = COALESCE(?, base_sku),
        base_barcode = COALESCE(?, base_barcode),
        base_price = COALESCE(?, base_price),
        base_mrp = COALESCE(?, base_mrp),
        base_cost = COALESCE(?, base_cost),
        image_url = COALESCE(?, image_url),
        is_offer_active = ?,
        offer_type = ?,
        offer_value = ?,
        offer_title = ?,
        offer_start_date = ?,
        offer_end_date = ?
      WHERE id = ?`,
      [
        name,
        description,
        category,
        brand,
        unit,
        baseSku,
        baseBarcode,
        basePrice,
        baseMrp,
        baseCost,
        img,
        isOfferActive !== undefined ? (isOfferActive ? 1 : 0) : 0,
        offerType || 'percentage',
        offerValue !== undefined ? Number(offerValue) : 0,
        offerTitle || 'Offer of the Day',
        offerStartDate || null,
        offerEndDate || null,
        id,
      ]
    );

    if (Array.isArray(variants) && variants.length > 0) {
      for (const v of variants) {
        const varId = v.id || `VAR-${id}-${Math.random().toString(36).slice(2, 6)}`;
        await pool.query(
          `INSERT INTO product_variants (
            id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, on_hand, available, reorder_level
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET
            sku=excluded.sku, barcode=excluded.barcode, name=excluded.name, price=excluded.price, mrp=excluded.mrp,
            cost=excluded.cost, on_hand=excluded.on_hand, available=excluded.available, reorder_level=excluded.reorder_level`,
          [
            varId,
            id,
            v.sku || `SKU-${varId}`,
            v.barcode || '',
            v.name || name,
            v.unit || unit || 'kg',
            JSON.stringify(v.attributes || {}),
            v.mrp || baseMrp || 0,
            v.price || basePrice || 0,
            v.cost || baseCost || 0,
            v.onHand !== undefined ? v.onHand : 50,
            v.available !== undefined ? v.available : 50,
            v.reorderLevel || 10,
          ]
        );
      }
    }

    invalidateProductCache();
    queueProductPush(id);
    res.json({ success: true, id });
  } catch (error: any) {
    console.error('Error updating product:', error);
    res.status(500).json({ error: error.message });
  }
});

// Fast Offer Toggle & Settings Update
app.patch('/api/products/:id/offer', async (req, res) => {
  const { id } = req.params;
  try {
    const {
      isOfferActive,
      offerType,
      offerValue,
      offerTitle,
      offerStartDate,
      offerEndDate,
    } = req.body;

    await pool.query(
      `UPDATE products SET
        is_offer_active = ?,
        offer_type = ?,
        offer_value = ?,
        offer_title = ?,
        offer_start_date = ?,
        offer_end_date = ?
      WHERE id = ?`,
      [
        isOfferActive ? 1 : 0,
        offerType || 'percentage',
        Number(offerValue) || 0,
        offerTitle || 'Offer of the Day',
        offerStartDate || null,
        offerEndDate || null,
        id,
      ]
    );

    invalidateProductCache();
    queueProductPush(id);
    res.json({ success: true, id, message: 'Offer updated successfully' });
  } catch (error: any) {
    console.error('Error updating product offer:', error);
    res.status(500).json({ error: error.message });
  }
});

// Delete product
app.delete('/api/products/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // Delete variants first due to foreign key constraint
    await pool.query('DELETE FROM product_variants WHERE product_id = ?', [id]);
    const [result]: any = await pool.query('DELETE FROM products WHERE id = ?', [id]);

    invalidateProductCache();
    queueProductDelete(id);
    res.json({ success: true, id, affectedRows: result?.affectedRows || 0 });
  } catch (error: any) {
    console.error('Error deleting product:', error);
    res.status(500).json({ error: error.message });
  }
});

// 2. Outlet Profile API
app.get('/api/outlet-profile', async (req, res) => {
  try {
    if (!hasSyncedStore) {
      await syncStoreFromCloud();
    }
    const defaultStoreName = process.env.STORE_NAME || 'Amma Appa Kadai';
    const defaultHeaderNote = (process.env.STORE_NAME || 'AMMA APPA KADAI').toUpperCase() + ' - BILLING COUNTER';
    const [rows]: any = await pool.query('SELECT * FROM outlet_profile LIMIT 1');
    if (rows && rows.length > 0) {
      const o = rows[0];
      res.json({
        outletName: o.outlet_name || defaultStoreName,
        branchName: o.branch_name || 'Main Counter',
        addressLine1: o.address_line1 || '',
        addressLine2: o.address_line2 || '',
        city: o.city || 'Chennai',
        state: o.state || 'Tamil Nadu',
        pincode: o.pincode || '600001',
        phone: o.phone || '',
        email: o.email || '',
        gstin: o.gstin || '',
        panNumber: o.pan_number || '',
        fssaiLicense: o.fssai_license || '',
        currencySymbol: o.currency_symbol || 'Rs.',
        receiptHeaderNote: o.receipt_header_note || defaultHeaderNote,
        receiptFooterNote: o.receipt_footer_note || 'Thank you for shopping with us! Visit again.',
        returnTerms: o.return_terms || 'Goods once sold can be exchanged within 24 hours with original bill receipt.',
        billPrefix: o.bill_prefix !== undefined && o.bill_prefix !== null ? o.bill_prefix : 'INV/',
        billSuffix: o.bill_suffix !== undefined && o.bill_suffix !== null ? o.bill_suffix : '',
        billStartNumber: o.bill_start_number !== null && o.bill_start_number !== undefined ? Number(o.bill_start_number) : 1001,
        billIncrementStep: o.bill_increment_step !== null && o.bill_increment_step !== undefined ? Math.max(1, Number(o.bill_increment_step)) : 1,
        billNextSequence: o.bill_next_sequence !== null && o.bill_next_sequence !== undefined ? Number(o.bill_next_sequence) : (o.bill_start_number !== null && o.bill_start_number !== undefined ? Number(o.bill_start_number) : 1001),
        billNumberPadding: o.bill_number_padding !== undefined && o.bill_number_padding !== null ? Number(o.bill_number_padding) : 4,
        billResetFrequency: o.bill_reset_frequency || 'never',
        billLastResetDate: o.bill_last_reset_date || '',
      });
    } else {
      res.json({
        outletName: defaultStoreName,
        branchName: 'Main Counter',
        addressLine1: '',
        addressLine2: '',
        city: 'Chennai',
        state: 'Tamil Nadu',
        pincode: '600001',
        phone: '',
        email: '',
        gstin: '',
        panNumber: '',
        fssaiLicense: '',
        currencySymbol: 'Rs.',
        receiptHeaderNote: defaultHeaderNote,
        receiptFooterNote: 'Thank you for shopping with us! Visit again.',
        returnTerms: 'Goods once sold can be exchanged within 24 hours with original bill receipt.',
        billPrefix: 'INV/',
        billSuffix: '',
        billStartNumber: 1001,
        billIncrementStep: 1,
        billNextSequence: 1001,
        billNumberPadding: 4,
        billResetFrequency: 'never',
        billLastResetDate: '',
      });
    }
  } catch (error: any) {
    console.error('Error fetching outlet profile:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/outlet-profile', async (req, res) => {
  try {
    const {
      outletName,
      branchName,
      addressLine1,
      addressLine2,
      city,
      state,
      pincode,
      phone,
      email,
      gstin,
      panNumber,
      fssaiLicense,
      currencySymbol,
      receiptHeaderNote,
      receiptFooterNote,
      returnTerms,
      billPrefix,
      billSuffix,
      billStartNumber,
      billIncrementStep,
      billNextSequence,
      billNumberPadding,
      billResetFrequency,
      billLastResetDate,
    } = req.body;

    const [existing]: any = await pool.query('SELECT id FROM outlet_profile LIMIT 1');
    const profileId = existing && existing.length > 0 ? existing[0].id : 'default_outlet';

    const safeStartNum = billStartNumber !== undefined ? Number(billStartNumber) : 1001;
    const safeIncrementStep = billIncrementStep !== undefined ? Math.max(1, Number(billIncrementStep)) : 1;
    const safeNextSeq = billNextSequence !== undefined ? Number(billNextSequence) : safeStartNum;

    if (existing && existing.length > 0) {
      await pool.query(
        `UPDATE outlet_profile SET
          outlet_name = ?,
          branch_name = ?,
          address_line1 = ?,
          address_line2 = ?,
          city = ?,
          state = ?,
          pincode = ?,
          phone = ?,
          email = ?,
          gstin = ?,
          pan_number = ?,
          fssai_license = ?,
          currency_symbol = ?,
          receipt_header_note = ?,
          receipt_footer_note = ?,
          return_terms = ?,
          bill_prefix = ?,
          bill_suffix = ?,
          bill_start_number = ?,
          bill_increment_step = ?,
          bill_next_sequence = ?,
          bill_number_padding = ?,
          bill_reset_frequency = ?,
          bill_last_reset_date = ?
        WHERE id = ?`,
        [
          outletName || process.env.STORE_NAME || 'Amma Appa Kadai',
          branchName || '',
          addressLine1 || '',
          addressLine2 || '',
          city || '',
          state || '',
          pincode || '',
          phone || '',
          email || '',
          gstin || '',
          panNumber || '',
          fssaiLicense || '',
          currencySymbol || 'Rs.',
          receiptHeaderNote || '',
          receiptFooterNote || '',
          returnTerms || '',
          billPrefix !== undefined ? billPrefix : 'INV/',
          billSuffix !== undefined ? billSuffix : '',
          safeStartNum,
          safeIncrementStep,
          safeNextSeq,
          billNumberPadding !== undefined ? Number(billNumberPadding) : 4,
          billResetFrequency || 'never',
          billLastResetDate || '',
          profileId,
        ]
      );
    } else {
      await pool.query(
        `INSERT INTO outlet_profile (
          id, outlet_name, branch_name, address_line1, address_line2, city, state, pincode,
          phone, email, gstin, pan_number, fssai_license, currency_symbol,
          receipt_header_note, receipt_footer_note, return_terms,
          bill_prefix, bill_suffix, bill_start_number, bill_increment_step, bill_next_sequence, bill_number_padding, bill_reset_frequency, bill_last_reset_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          profileId,
          outletName || process.env.STORE_NAME || 'Amma Appa Kadai',
          branchName || '',
          addressLine1 || '',
          addressLine2 || '',
          city || '',
          state || '',
          pincode || '',
          phone || '',
          email || '',
          gstin || '',
          panNumber || '',
          fssaiLicense || '',
          currencySymbol || 'Rs.',
          receiptHeaderNote || '',
          receiptFooterNote || '',
          returnTerms || '',
          billPrefix !== undefined ? billPrefix : 'INV/',
          billSuffix !== undefined ? billSuffix : '',
          safeStartNum,
          safeIncrementStep,
          safeNextSeq,
          billNumberPadding !== undefined ? Number(billNumberPadding) : 4,
          billResetFrequency || 'never',
          billLastResetDate || '',
        ]
      );
    }

    res.json({
      success: true,
      outletProfile: {
        outletName,
        branchName,
        addressLine1,
        addressLine2,
        city,
        state,
        pincode,
        phone,
        email,
        gstin,
        panNumber,
        fssaiLicense,
        currencySymbol,
        receiptHeaderNote,
        receiptFooterNote,
        returnTerms,
        billPrefix: billPrefix !== undefined ? billPrefix : 'INV/',
        billSuffix: billSuffix !== undefined ? billSuffix : '',
        billStartNumber: safeStartNum,
        billIncrementStep: safeIncrementStep,
        billNextSequence: safeNextSeq,
        billNumberPadding: billNumberPadding !== undefined ? Number(billNumberPadding) : 4,
        billResetFrequency: billResetFrequency || 'never',
        billLastResetDate: billLastResetDate || '',
      },
    });
  } catch (error: any) {
    console.error('Error saving outlet profile:', error);
    res.status(500).json({ error: error.message });
  }
});

// Explicit Store Synchronization Endpoint
// Live sync status (polled by the POS screen so cloud catalog changes appear without a manual refresh)
app.get('/api/sync/status', async (req, res) => {
  res.json(await getSyncStatus());
});

app.post('/api/store/sync', async (req, res) => {
  try {
    const targetStore = req.body?.storeId || process.env.STORE_ID;
    await syncStoreFromCloud(targetStore);
    const syncRes = await runSyncCycle();
    invalidateProductCache();
    const [rows]: any = await pool.query('SELECT * FROM outlet_profile LIMIT 1');
    const [pCount]: any = await pool.query('SELECT COUNT(*) as count FROM products');
    res.json({
      success: true,
      storeId: targetStore || 'STORE-002',
      outletProfile: rows && rows.length > 0 ? rows[0] : null,
      productCount: pCount && pCount.length > 0 ? pCount[0].count : 0,
    });
  } catch (err: any) {
    console.error('Error running store sync:', err);
    res.status(500).json({ error: err.message });
  }
});

// 2b. Customer Loyalty Settings API
app.get('/api/loyalty-settings', async (req, res) => {
  try {
    const [rows]: any = await pool.query('SELECT * FROM loyalty_settings LIMIT 1');
    if (rows && rows.length > 0) {
      const l = rows[0];
      res.json({
        enabled: Boolean(l.enabled === 1 || l.enabled === true),
        spendAmountPerPoint: Number(l.spend_amount_per_point || 100),
        pointsEarnedPerSpend: Number(l.points_earned_per_spend || 1),
        pointRedemptionValue: Number(l.point_redemption_value || 1.0),
        minPointsToRedeem: Number(l.min_points_to_redeem || 10),
        expiryPeriodDays: Number(l.expiry_period_days || 90),
        autoEnrollOnRegistration: Boolean(l.auto_enroll_on_registration === 1 || l.auto_enroll_on_registration === true),
      });
    } else {
      res.json({
        enabled: true,
        spendAmountPerPoint: 100,
        pointsEarnedPerSpend: 1,
        pointRedemptionValue: 1.0,
        minPointsToRedeem: 10,
        expiryPeriodDays: 90,
        autoEnrollOnRegistration: true,
      });
    }
  } catch (error: any) {
    console.error('Error fetching loyalty settings:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/loyalty-settings', async (req, res) => {
  try {
    const {
      enabled,
      spendAmountPerPoint,
      pointsEarnedPerSpend,
      pointRedemptionValue,
      minPointsToRedeem,
      expiryPeriodDays,
      autoEnrollOnRegistration,
    } = req.body;

    const [existing]: any = await pool.query('SELECT id FROM loyalty_settings LIMIT 1');
    const loyaltyId = existing && existing.length > 0 ? existing[0].id : 'default_loyalty';

    const enabledVal = enabled === false ? 0 : 1;
    const spendVal = Number(spendAmountPerPoint) || 100;
    const earnVal = Number(pointsEarnedPerSpend) || 1;
    const redeemVal = Number(pointRedemptionValue) || 1.0;
    const minVal = Number(minPointsToRedeem) || 10;
    const expiryVal = Number(expiryPeriodDays) || 90;
    const autoVal = autoEnrollOnRegistration === false ? 0 : 1;

    if (existing && existing.length > 0) {
      await pool.query(
        `UPDATE loyalty_settings SET
          enabled = ?,
          spend_amount_per_point = ?,
          points_earned_per_spend = ?,
          point_redemption_value = ?,
          min_points_to_redeem = ?,
          expiry_period_days = ?,
          auto_enroll_on_registration = ?
        WHERE id = ?`,
        [enabledVal, spendVal, earnVal, redeemVal, minVal, expiryVal, autoVal, loyaltyId]
      );
    } else {
      await pool.query(
        `INSERT INTO loyalty_settings (
          id, enabled, spend_amount_per_point, points_earned_per_spend,
          point_redemption_value, min_points_to_redeem, expiry_period_days, auto_enroll_on_registration
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [loyaltyId, enabledVal, spendVal, earnVal, redeemVal, minVal, expiryVal, autoVal]
      );
    }

    res.json({
      success: true,
      loyaltyConfig: {
        enabled: Boolean(enabledVal),
        spendAmountPerPoint: spendVal,
        pointsEarnedPerSpend: earnVal,
        pointRedemptionValue: redeemVal,
        minPointsToRedeem: minVal,
        expiryPeriodDays: expiryVal,
        autoEnrollOnRegistration: Boolean(autoVal),
      },
    });
  } catch (error: any) {
    console.error('Error saving loyalty settings:', error);
    res.status(500).json({ error: error.message });
  }
});

// 3. Customers
app.get('/api/customers', async (req, res) => {
  try {
    const [rows]: any = await pool.query('SELECT * FROM customers ORDER BY name ASC');
    res.json(
      rows.map((c: any) => ({
        id: c.id,
        name: c.name,
        email: c.email,
        phone: c.phone,
        loyaltyPoints: Number(c.loyalty_points || 0),
        isLoyaltyMember: c.is_loyalty_member !== undefined ? Boolean(c.is_loyalty_member) : true,
        loyaltyJoinedDate: c.loyalty_joined_date || null,
        loyaltyExpiryDate: c.loyalty_expiry_date || null,
        storeCredit: Number(c.store_credit || 0),
        totalSpent: Number(c.total_spent || 0),
        memberTier: c.member_tier || 'Regular',
        recentPurchasesCount: Number(c.recent_purchases_count || 0),
      }))
    );
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/customers', async (req, res) => {
  try {
    const { id, name, email, phone, loyaltyPoints, isLoyaltyMember, loyaltyJoinedDate, loyaltyExpiryDate, storeCredit, memberTier } = req.body;
    const custId = id || `cust_${Date.now()}`;
    const isMember = isLoyaltyMember === false ? 0 : 1;
    const joined = loyaltyJoinedDate || new Date().toISOString().slice(0, 10);
    
    // Calculate expiry date if not provided (e.g. 90 days from now)
    const expDate = loyaltyExpiryDate || new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

    await pool.query(
      `INSERT INTO customers (id, name, email, phone, loyalty_points, store_credit, member_tier, is_loyalty_member, loyalty_joined_date, loyalty_expiry_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         name=excluded.name,
         email=excluded.email,
         phone=excluded.phone,
         loyalty_points=excluded.loyalty_points,
         store_credit=excluded.store_credit,
         member_tier=excluded.member_tier,
         is_loyalty_member=excluded.is_loyalty_member,
         loyalty_joined_date=excluded.loyalty_joined_date,
         loyalty_expiry_date=excluded.loyalty_expiry_date`,
      [custId, name, email || '', phone, loyaltyPoints || 0, storeCredit || 0, memberTier || 'Regular', isMember, joined, expDate]
    );
    res.json({ success: true, id: custId });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/customers/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const { name, email, phone, loyaltyPoints, isLoyaltyMember, loyaltyExpiryDate, storeCredit, memberTier } = req.body;
    const isMember = isLoyaltyMember !== undefined ? (isLoyaltyMember ? 1 : 0) : null;
    await pool.query(
      `UPDATE customers SET
        name = COALESCE(?, name),
        email = COALESCE(?, email),
        phone = COALESCE(?, phone),
        loyalty_points = COALESCE(?, loyalty_points),
        is_loyalty_member = COALESCE(?, is_loyalty_member),
        loyalty_expiry_date = COALESCE(?, loyalty_expiry_date),
        store_credit = COALESCE(?, store_credit),
        member_tier = COALESCE(?, member_tier)
       WHERE id = ?`,
      [name, email, phone, loyaltyPoints, isMember, loyaltyExpiryDate, storeCredit, memberTier, id]
    );
    res.json({ success: true, id });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.patch('/api/customers/:id/credit', async (req, res) => {
  const { id } = req.params;
  try {
    const { storeCredit, delta } = req.body;
    if (storeCredit !== undefined) {
      await pool.query('UPDATE customers SET store_credit = ? WHERE id = ?', [Number(storeCredit), id]);
    } else if (delta !== undefined) {
      await pool.query('UPDATE customers SET store_credit = store_credit + ? WHERE id = ?', [Number(delta), id]);
    }
    const [rows]: any = await pool.query('SELECT * FROM customers WHERE id = ?', [id]);
    res.json({ success: true, customer: rows[0] });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/customers/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM customers WHERE id = ?', [id]);
    res.json({ success: true, id });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4. Suppliers (CRUD)
app.get('/api/suppliers', async (req, res) => {
  try {
    const [rows]: any = await pool.query('SELECT * FROM suppliers ORDER BY name ASC');
    const mapped = rows.map((s: any) => ({
      id: s.id,
      name: s.name,
      contactPerson: s.contact_person || '',
      contactEmail: s.contact_email || '',
      phone: s.phone || '',
      leadTimeDays: Number(s.lead_time_days || 1),
      rating: Number(s.rating || 4.5),
      paymentTerms: s.payment_terms || 'Net 15',
      marketType: s.market_type || 'Mandi Trader',
      createdAt: s.created_at,
    }));
    res.json(mapped);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/suppliers', async (req, res) => {
  try {
    const {
      id,
      name,
      contactPerson,
      contactEmail,
      phone,
      leadTimeDays,
      rating,
      paymentTerms,
      marketType,
    } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Supplier name is required' });
    }

    const supId = id || `SUP-${Date.now().toString().slice(-6)}`;

    await pool.query(
      `INSERT INTO suppliers (
        id, name, contact_person, contact_email, phone, lead_time_days, rating, payment_terms, market_type
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name=excluded.name, contact_person=excluded.contact_person, contact_email=excluded.contact_email,
        phone=excluded.phone, lead_time_days=excluded.lead_time_days, rating=excluded.rating,
        payment_terms=excluded.payment_terms, market_type=excluded.market_type`,
      [
        supId,
        name,
        contactPerson || '',
        contactEmail || '',
        phone || '',
        leadTimeDays ? Number(leadTimeDays) : 2,
        rating ? Number(rating) : 4.5,
        paymentTerms || 'Net 15',
        marketType || 'Mandi Trader',
      ]
    );

    res.json({
      success: true,
      supplier: {
        id: supId,
        name,
        contactPerson: contactPerson || '',
        contactEmail: contactEmail || '',
        phone: phone || '',
        leadTimeDays: leadTimeDays ? Number(leadTimeDays) : 2,
        rating: rating ? Number(rating) : 4.5,
        paymentTerms: paymentTerms || 'Net 15',
        marketType: marketType || 'Mandi Trader',
      },
    });
  } catch (error: any) {
    console.error('Error creating/updating supplier:', error);
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/suppliers/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const {
      name,
      contactPerson,
      contactEmail,
      phone,
      leadTimeDays,
      rating,
      paymentTerms,
      marketType,
    } = req.body;

    await pool.query(
      `UPDATE suppliers SET
        name = COALESCE(?, name),
        contact_person = COALESCE(?, contact_person),
        contact_email = COALESCE(?, contact_email),
        phone = COALESCE(?, phone),
        lead_time_days = COALESCE(?, lead_time_days),
        rating = COALESCE(?, rating),
        payment_terms = COALESCE(?, payment_terms),
        market_type = COALESCE(?, market_type)
      WHERE id = ?`,
      [
        name,
        contactPerson,
        contactEmail,
        phone,
        leadTimeDays !== undefined ? Number(leadTimeDays) : null,
        rating !== undefined ? Number(rating) : null,
        paymentTerms,
        marketType,
        id,
      ]
    );

    res.json({ success: true, id });
  } catch (error: any) {
    console.error('Error updating supplier:', error);
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/suppliers/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM suppliers WHERE id = ?', [id]);
    res.json({ success: true, message: 'Supplier deleted successfully', id });
  } catch (error: any) {
    console.error('Error deleting supplier:', error);
    res.status(500).json({ error: error.message });
  }
});

// 5. Orders & Transactions
app.get('/api/orders', async (req, res) => {
  try {
    const [orders]: any = await pool.query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 100');
    const [items]: any = await pool.query('SELECT * FROM order_items');
    const [payments]: any = await pool.query('SELECT * FROM payment_splits');

    const mapped = orders.map((o: any) => ({
      id: o.id,
      orderNumber: o.order_number,
      terminalId: o.terminal_id,
      cashierId: o.cashier_id,
      cashierName: o.cashier_name,
      customerId: o.customer_id,
      customerName: o.customer_name,
      customerPhone: o.customer_phone,
      subtotal: Number(o.subtotal),
      taxAmount: Number(o.tax_amount),
      taxRate: Number(o.tax_rate),
      discountTotal: Number(o.discount_total),
      total: Number(o.total),
      amountPaid: Number(o.amount_paid),
      changeDue: Number(o.change_due),
      status: o.status,
      synced: Boolean(o.synced),
      notes: o.notes,
      createdAt: o.created_at,
      items: items.filter((it: any) => it.order_id === o.id).map((it: any) => ({
        id: it.id,
        sku: it.sku,
        productName: it.product_name,
        unit: it.unit,
        mrp: Number(it.mrp),
        unitPrice: Number(it.unit_price),
        quantity: Number(it.quantity),
        discountAmount: Number(it.discount_amount),
        packSize: it.pack_size,
      })),
      payments: payments.filter((p: any) => p.order_id === o.id).map((p: any) => ({
        id: p.id,
        tenderType: p.tender_type,
        amount: Number(p.amount),
        reference: p.reference,
        status: p.status,
      })),
    }));

    res.json(mapped);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/orders', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const {
      id,
      orderNumber,
      terminalId,
      cashierId,
      cashierName,
      customerId,
      customerName,
      customerPhone,
      subtotal,
      taxAmount,
      taxRate,
      discountTotal,
      total,
      amountPaid,
      changeDue,
      status,
      items,
      payments,
      notes,
    } = req.body;

    const orderId = id || `ord_${Date.now()}`;

    // 1. Insert Order
    await conn.query(
      `INSERT INTO orders (
        id, order_number, terminal_id, cashier_id, cashier_name,
        customer_id, customer_name, customer_phone,
        subtotal, tax_amount, tax_rate, discount_total, total, amount_paid, change_due,
        status, synced, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE, ?)`,
      [
        orderId,
        orderNumber,
        terminalId || 'TERM-01',
        cashierId || 'emp_01',
        cashierName || 'Cashier',
        customerId || null,
        customerName || null,
        customerPhone || null,
        subtotal || 0,
        taxAmount || 0,
        taxRate || 0,
        discountTotal || 0,
        total,
        amountPaid,
        changeDue || 0,
        status || 'completed',
        notes || '',
      ]
    );

    // 2. Insert Order Items & Deduct Stock
    if (Array.isArray(items)) {
      for (const item of items) {
        const itemId = item.id || `item_${crypto.randomUUID()}`;
        const validProdId = item.productId || item.variantId || item.id || `prod_${Date.now()}`;
        const validVarId = item.variantId || item.productId || item.id || `var_${Date.now()}`;

        await conn.query(
          `INSERT INTO order_items (
            id, order_id, product_id, variant_id, sku, barcode, product_name, unit,
            mrp, unit_price, quantity, discount_amount, discount_percent, applied_tax_rate, modifiers, pack_size
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            itemId,
            orderId,
            validProdId,
            validVarId,
            item.sku || 'SKU',
            item.barcode || null,
            item.productName || item.name || 'Item',
            item.unit || 'kg',
            item.mrp || item.price || 0,
            item.unitPrice || item.price || 0,
            Number(item.quantity) || 1,
            item.discountAmount || 0,
            item.discountPercent || 0,
            item.appliedTaxRate || 0,
            JSON.stringify(item.modifiers || []),
            item.packSize || '',
          ]
        );

        if (item.variantId) {
          const [varRows]: any = await conn.query(
            'SELECT id, sku, name, on_hand, available, version FROM product_variants WHERE id = ? FOR UPDATE',
            [item.variantId]
          );

          if (varRows && varRows.length > 0) {
            const variant = varRows[0];
            const nextOnHand = Math.max(0, Number(variant.on_hand) - item.quantity);
            const nextAvailable = Math.max(0, Number(variant.available) - item.quantity);

            await conn.query(
              'UPDATE product_variants SET on_hand = ?, available = ?, version = version + 1, updated_at = CURRENT_TIMESTAMP(3) WHERE id = ?',
              [nextOnHand, nextAvailable, variant.id]
            );

            await conn.query(
              `INSERT INTO inventory_ledger (id, sku, variant_id, product_name, delta, balance_after, mutation_type, reference_id, operator, notes)
               VALUES (?, ?, ?, ?, ?, ?, 'SALE', ?, ?, 'POS Terminal Checkout')`,
              [
                `led_${crypto.randomUUID()}`,
                variant.sku,
                variant.id,
                variant.name,
                -item.quantity,
                nextOnHand,
                orderId,
                cashierName || 'Cashier',
              ]
            );
          }
        }
      }
    }

    // 3. Payment Splits
    if (Array.isArray(payments)) {
      for (const p of payments) {
        await conn.query(
          `INSERT INTO payment_splits (id, order_id, tender_type, amount, reference, status)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [p.id || `pay_${crypto.randomUUID()}`, orderId, p.tenderType, p.amount, p.reference || '', p.status || 'completed']
        );
      }
    }

    if (customerId) {
      const pointsEarned = req.body.loyaltyPointsEarned !== undefined
        ? Number(req.body.loyaltyPointsEarned)
        : Math.floor(total / 100);
      const pointsRedeemed = Number(req.body.loyaltyPointsRedeemed || 0);

      const storeCreditPaid = Array.isArray(payments)
        ? payments.filter((p: any) => p.tenderType === 'store_credit').reduce((acc: number, p: any) => acc + Number(p.amount || 0), 0)
        : 0;

      await conn.query(
        `UPDATE customers SET
          loyalty_points = MAX(0, loyalty_points + ? - ?),
          total_spent = total_spent + ?,
          recent_purchases_count = recent_purchases_count + 1,
          store_credit = store_credit - ?
         WHERE id = ?`,
        [pointsEarned, pointsRedeemed, total, storeCreditPaid, customerId]
      );
    }

    await conn.commit();
    invalidateProductCache();
    res.json({ success: true, orderId });
  } catch (error: any) {
    await conn.rollback();
    console.error('Order creation failed:', error);
    res.status(500).json({ error: error.message });
  } finally {
    conn.release();
  }
});

// 6. Shifts & Drawer Reconciliation
app.get('/api/shifts/active', async (req, res) => {
  try {
    const [rows]: any = await pool.query("SELECT * FROM shifts WHERE status = 'open' ORDER BY opened_at DESC LIMIT 1");
    if (rows.length > 0) {
      res.json(rows[0]);
    } else {
      res.json(null);
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 7. Purchase Orders & Replenishment (Multi-Item POs)
app.get('/api/purchase-orders', async (req, res) => {
  try {
    const [pos]: any = await pool.query('SELECT * FROM purchase_orders ORDER BY created_at DESC');
    const [items]: any = await pool.query('SELECT * FROM purchase_order_items');
    
    const mapped = [];
    for (const po of pos) {
      const poItems = items.filter((it: any) => it.po_id === po.id);
      const totalOrdered = poItems.reduce((s: number, it: any) => s + (Number(it.quantity_ordered) || 0), 0);
      const totalReceived = poItems.reduce((s: number, it: any) => s + (Number(it.quantity_received) || 0), 0);
      
      let computedStatus = po.status;
      if (po.status !== 'CANCELLED' && po.status !== 'CLOSED') {
        if (totalReceived === 0) {
          computedStatus = po.status === 'DRAFT' ? 'DRAFT' : 'ISSUED';
        } else if (totalReceived < totalOrdered) {
          computedStatus = 'PARTIALLY_RECEIVED';
        } else {
          computedStatus = 'FULFILLED';
        }
      }

      // If status mismatch in DB, passively update it
      if (computedStatus !== po.status && (po.status === 'FULFILLED' || po.status === 'ISSUED') && computedStatus === 'PARTIALLY_RECEIVED') {
        pool.query('UPDATE purchase_orders SET status = ? WHERE id = ?', [computedStatus, po.id]).catch(() => {});
      }

      mapped.push({
        id: po.id,
        poNumber: po.po_number,
        supplierId: po.supplier_id,
        supplierName: po.supplier_name,
        totalAmount: Number(po.total_amount),
        status: computedStatus,
        expectedDelivery: po.expected_delivery || po.expected_delivery_date || null,
        aiSuggested: Boolean(po.ai_suggested),
        aiReason: po.ai_reason,
        safetyStockTrigger: Number(po.safety_stock_trigger),
        createdAt: po.created_at,
        items: poItems.map((it: any) => ({
          id: it.id,
          sku: it.sku,
          productName: it.product_name,
          variantId: it.variant_id,
          quantityOrdered: Number(it.quantity_ordered),
          quantityReceived: Number(it.quantity_received),
          unit: it.unit,
          unitCost: Number(it.unit_cost),
          totalCost: Number(it.total_cost),
        })),
      });
    }

    res.json(mapped);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/purchase-orders/seed-defaults', async (req, res) => {
  try {
    const force = req.body?.force === true;
    const result = await seedPurchaseOrdersAndMatches(force);
    res.json({ success: true, count: result.count, message: 'Purchase orders and 3-way matches loaded into database' });
  } catch (error: any) {
    console.error('Error seeding default purchase orders:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/purchase-orders', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const {
      id,
      poNumber,
      supplierId,
      supplierName,
      items,
      totalAmount,
      status,
      expectedDelivery,
      aiSuggested,
      aiReason,
      safetyStockTrigger,
    } = req.body;

    const poId = id || `PO-${Date.now().toString().slice(-6)}`;
    const poNum = poNumber || `PO-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;

    let computedTotal = 0;
    if (Array.isArray(items)) {
      computedTotal = items.reduce((sum: number, it: any) => sum + (Number(it.totalCost) || (Number(it.quantityOrdered) * Number(it.unitCost))), 0);
    }
    const grandTotal = totalAmount !== undefined ? Number(totalAmount) : computedTotal;

    // Validate supplier_id to ensure foreign key integrity and not-null constraints
    let validSupplierId = supplierId || null;
    if (validSupplierId) {
      const [supRows]: any = await conn.query('SELECT id FROM suppliers WHERE id = ? LIMIT 1', [validSupplierId]);
      if (!supRows || supRows.length === 0) {
        const [firstSup]: any = await conn.query('SELECT id FROM suppliers LIMIT 1');
        validSupplierId = firstSup && firstSup.length > 0 ? firstSup[0].id : 'supp_1';
      }
    } else {
      const [firstSup]: any = await conn.query('SELECT id FROM suppliers LIMIT 1');
      validSupplierId = firstSup && firstSup.length > 0 ? firstSup[0].id : 'supp_1';
    }

    const expDelivStr = expectedDelivery
      ? (typeof expectedDelivery === 'string' ? expectedDelivery : new Date(expectedDelivery).toISOString().slice(0, 10))
      : new Date(Date.now() + 86400000).toISOString().slice(0, 10);

    await conn.query(
      `INSERT INTO purchase_orders (
        id, po_number, supplier_id, supplier_name, total_amount, status,
        expected_delivery, expected_delivery_date, ai_suggested, ai_reason, safety_stock_trigger, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(id) DO UPDATE SET
        supplier_name=excluded.supplier_name, total_amount=excluded.total_amount, status=excluded.status`,
      [
        poId,
        poNum,
        validSupplierId,
        supplierName || 'General Supplier',
        grandTotal,
        status || 'ISSUED',
        expDelivStr,
        expDelivStr,
        aiSuggested ? 1 : 0,
        aiReason || null,
        safetyStockTrigger || null,
      ]
    );

    if (Array.isArray(items) && items.length > 0) {
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        // Always generate a fresh unique primary key for each PO line item to prevent UNIQUE constraint collisions
        const itemId = `POI-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 9)}`;
        const qtyOrd = Number(item.quantityOrdered) || 0;
        const uCost = Number(item.unitCost) || 0;
        const lineTotal = Number(item.totalCost) || (qtyOrd * uCost);

        // Resolve and validate variant_id and product_id against product_variants to prevent foreign key errors
        let resolvedProductId = item.productId || null;
        let validVariantId: string | null = null;
        if (item.variantId) {
          const [chk]: any = await conn.query('SELECT id, product_id FROM product_variants WHERE id = ? LIMIT 1', [item.variantId]);
          if (chk && chk.length > 0) {
            validVariantId = chk[0].id;
            if (!resolvedProductId) resolvedProductId = chk[0].product_id;
          }
        }
        if (!validVariantId && item.sku) {
          const [chkSku]: any = await conn.query('SELECT id, product_id FROM product_variants WHERE sku = ? LIMIT 1', [item.sku]);
          if (chkSku && chkSku.length > 0) {
            validVariantId = chkSku[0].id;
            if (!resolvedProductId) resolvedProductId = chkSku[0].product_id;
          }
        }
        if (!resolvedProductId && item.id) {
          const [chkProd]: any = await conn.query('SELECT id FROM products WHERE id = ? LIMIT 1', [item.id]);
          if (chkProd && chkProd.length > 0) {
            resolvedProductId = chkProd[0].id;
          }
        }
        if (!resolvedProductId) {
          resolvedProductId = validVariantId || item.id || `PROD-${Date.now().toString().slice(-4)}`;
        }
        if (!validVariantId) {
          validVariantId = item.variantId || item.id || `VAR-${Date.now().toString().slice(-4)}`;
        }

        await conn.query(
          `INSERT INTO purchase_order_items (
            id, po_id, product_id, sku, product_name, variant_id, quantity_ordered, quantity_received, unit, unit_cost, total_cost
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET
            quantity_ordered = excluded.quantity_ordered,
            quantity_received = excluded.quantity_received,
            unit_cost = excluded.unit_cost,
            total_cost = excluded.total_cost`,
          [
            itemId,
            poId,
            resolvedProductId,
            item.sku || 'SKU-GEN',
            item.productName || 'Produce Item',
            validVariantId,
            qtyOrd,
            Number(item.quantityReceived) || 0,
            item.unit || 'kg',
            uCost,
            lineTotal,
          ]
        );
      }
    }

    await conn.commit();
    res.json({
      success: true,
      id: poId,
      poNumber: poNum,
      totalAmount: grandTotal,
    });
  } catch (error: any) {
    await conn.rollback();
    console.error('Error creating purchase order:', error);
    res.status(500).json({ error: error.message });
  } finally {
    conn.release();
  }
});

app.put('/api/purchase-orders/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const { status, totalAmount } = req.body;
    await pool.query(
      `UPDATE purchase_orders SET
        status = COALESCE(?, status),
        total_amount = COALESCE(?, total_amount)
      WHERE id = ?`,
      [status, totalAmount !== undefined ? Number(totalAmount) : null, id]
    );
    res.json({ success: true, id });
  } catch (error: any) {
    console.error('Error updating purchase order:', error);
    res.status(500).json({ error: error.message });
  }
});

// 8. Goods Receipt Note (GRN) Receiving & 3-Way Matching
app.post('/api/grn/receive', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const {
      poId,
      poNumber,
      grnNumber,
      invoiceNumber,
      supplierName,
      poAmount,
      invoiceAmount,
      receivedItems, // array of items with { id, sku, productName, variantId, quantityOrdered, quantityReceived, unit, unitCost, disposition: 'ACCEPT' | 'HOLD' | 'REJECT', isNonPoItem?: boolean, holdReason?: string }
      operatorName,
      notes,
      closePo, // boolean: force close PO even if partial
      poStatusOverride, // optional explicit status 'PARTIALLY_RECEIVED' | 'FULFILLED'
    } = req.body;

    const grnNum = grnNumber || `GRN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;
    const invNum = invoiceNumber || `INV-${Date.now().toString().slice(-4)}`;

    let acceptedTotalValue = 0;

    if (Array.isArray(receivedItems)) {
      for (const item of receivedItems) {
        const qtyReceivedInThisDelivery = Number(item.quantityReceived) || 0;
        const uCost = Number(item.unitCost) || 0;
        const disposition = item.disposition || 'ACCEPT'; // ACCEPT, HOLD, REJECT

        // Resolve variant ID safely
        let validVariantId: string | null = null;
        if (item.variantId) {
          const [chk]: any = await conn.query('SELECT id FROM product_variants WHERE id = ? LIMIT 1', [item.variantId]);
          if (chk && chk.length > 0) {
            validVariantId = chk[0].id;
          }
        }
        if (!validVariantId && item.sku) {
          const [chkSku]: any = await conn.query('SELECT id FROM product_variants WHERE sku = ? LIMIT 1', [item.sku]);
          if (chkSku && chkSku.length > 0) {
            validVariantId = chkSku[0].id;
          }
        }

        // If item is ACCEPTED, add to database stock and record inventory ledger for this intake
        if (disposition === 'ACCEPT' && qtyReceivedInThisDelivery > 0) {
          acceptedTotalValue += (qtyReceivedInThisDelivery * uCost);

          if (validVariantId) {
            await conn.query(
              `UPDATE product_variants
               SET on_hand = on_hand + ?, available = available + ?
               WHERE id = ?`,
              [qtyReceivedInThisDelivery, qtyReceivedInThisDelivery, validVariantId]
            );
          }

          const ledgerId = `LED-GRN-${Date.now().toString().slice(-4)}-${Math.random().toString(36).slice(2, 6)}`;
          await conn.query(
            `INSERT INTO inventory_ledger (
              id, sku, variant_id, product_name, delta, mutation_type, reference_id, operator, timestamp, notes
            ) VALUES (?, ?, ?, ?, ?, 'GOODS_RECEIPT', ?, ?, NOW(3), ?)`,
            [
              ledgerId,
              item.sku || 'SKU-GEN',
              validVariantId,
              item.productName,
              qtyReceivedInThisDelivery,
              grnNum,
              operatorName || 'Store Manager',
              `GRN Received against PO ${poNumber || ''}${item.isNonPoItem ? ' (Added Line Item)' : ''} - Intake: ${qtyReceivedInThisDelivery} ${item.unit || 'kg'}`,
            ]
          );
        }

        // Update purchase_order_items cumulative quantity_received if PO item
        if (poId && !item.isNonPoItem && qtyReceivedInThisDelivery > 0) {
          if (item.id) {
            await conn.query(
              `UPDATE purchase_order_items
               SET quantity_received = COALESCE(quantity_received, 0) + ?
               WHERE id = ? AND po_id = ?`,
              [qtyReceivedInThisDelivery, item.id, poId]
            );
          } else {
            await conn.query(
              `UPDATE purchase_order_items
               SET quantity_received = COALESCE(quantity_received, 0) + ?
               WHERE po_id = ? AND (variant_id = ? OR sku = ? OR product_name = ?)`,
              [qtyReceivedInThisDelivery, poId, validVariantId, item.sku, item.productName]
            );
          }
        }
      }
    }

    // Determine PO status (FULFILLED vs PARTIALLY_RECEIVED)
    let updatedPoStatus = 'FULFILLED';
    if (poId) {
      if (poStatusOverride) {
        updatedPoStatus = poStatusOverride;
      } else if (closePo === true) {
        updatedPoStatus = 'FULFILLED';
      } else {
        // Query remaining quantities on PO
        const [poItemRows]: any = await conn.query(
          'SELECT quantity_ordered, quantity_received FROM purchase_order_items WHERE po_id = ?',
          [poId]
        );
        let hasPendingQuantity = false;
        let totalReceivedAcrossPo = 0;

        if (Array.isArray(poItemRows) && poItemRows.length > 0) {
          for (const row of poItemRows) {
            const ord = Number(row.quantity_ordered) || 0;
            const rec = Number(row.quantity_received) || 0;
            totalReceivedAcrossPo += rec;
            if (rec < ord) {
              hasPendingQuantity = true;
            }
          }
        }

        if (hasPendingQuantity) {
          updatedPoStatus = 'PARTIALLY_RECEIVED';
        } else {
          updatedPoStatus = 'FULFILLED';
        }
      }

      await conn.query(
        `UPDATE purchase_orders SET status = ? WHERE id = ?`,
        [updatedPoStatus, poId]
      );
    }

    // Compute discrepancy & 3-Way Match
    const pAmt = Number(poAmount) || 0;
    const invAmt = Number(invoiceAmount) || acceptedTotalValue;
    const discrepancy = Math.abs(invAmt - acceptedTotalValue);
    const matchStatus = discrepancy < 0.01 ? 'MATCHED' : 'DISCREPANCY_ALERT';
    const matchId = `TWM-${Date.now().toString().slice(-6)}`;

    let discrepancyNote = '';
    const heldCount = (receivedItems || []).filter((i: any) => i.disposition === 'HOLD').length;
    const rejectedCount = (receivedItems || []).filter((i: any) => i.disposition === 'REJECT').length;
    if (updatedPoStatus === 'PARTIALLY_RECEIVED') {
      discrepancyNote += 'Partial delivery GRN intake. Remaining items pending arrival. ';
    }
    if (heldCount > 0) discrepancyNote += `${heldCount} items quarantined ON HOLD. `;
    if (rejectedCount > 0) discrepancyNote += `${rejectedCount} non-PO/damaged items REJECTED. `;
    if (discrepancy > 0.01) discrepancyNote += `Variance Rs. ${discrepancy.toFixed(2)} between Invoice and Verified GRN.`;

    await conn.query(
      `INSERT INTO three_way_matches (
        id, po_id, po_number, grn_number, invoice_number, supplier_name,
        po_amount, grn_received_amount, invoice_amount, discrepancy_amount,
        status, discrepancy_note, timestamp
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(3))`,
      [
        matchId,
        poId || null,
        poNumber || 'N/A',
        grnNum,
        invNum,
        supplierName || 'General Supplier',
        pAmt,
        acceptedTotalValue,
        invAmt,
        discrepancy,
        matchStatus,
        discrepancyNote || notes || (updatedPoStatus === 'PARTIALLY_RECEIVED' ? 'Partial GRN delivery accepted' : 'Verified GRN intake completed'),
      ]
    );

    await conn.commit();
    invalidateProductCache();

    res.json({
      success: true,
      grnNumber: grnNum,
      invoiceNumber: invNum,
      matchId,
      matchStatus,
      poStatus: updatedPoStatus,
      grnReceivedAmount: acceptedTotalValue,
      discrepancy,
    });
  } catch (error: any) {
    await conn.rollback();
    console.error('Error receiving GRN:', error);
    res.status(500).json({ error: error.message });
  } finally {
    conn.release();
  }
});

// 9. Three Way Matches (Read and Create)
app.get('/api/three-way-matches', async (req, res) => {
  try {
    const [rows]: any = await pool.query('SELECT * FROM three_way_matches ORDER BY timestamp DESC');
    res.json(
      rows.map((r: any) => ({
        id: r.id,
        poId: r.po_id,
        poNumber: r.po_number,
        grnNumber: r.grn_number,
        invoiceNumber: r.invoice_number,
        supplierName: r.supplier_name,
        poAmount: Number(r.po_amount),
        grnReceivedAmount: Number(r.grn_received_amount),
        invoiceAmount: Number(r.invoice_amount),
        discrepancyAmount: Number(r.discrepancy_amount),
        status: r.status,
        discrepancyNote: r.discrepancy_note,
        timestamp: r.timestamp,
      }))
    );
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/three-way-matches', async (req, res) => {
  try {
    const {
      id,
      poId,
      poNumber,
      grnNumber,
      invoiceNumber,
      supplierName,
      poAmount,
      grnReceivedAmount,
      invoiceAmount,
      discrepancyAmount,
      status,
      discrepancyNote,
    } = req.body;

    const matchId = id || `TWM-${Date.now().toString().slice(-6)}`;
    await pool.query(
      `INSERT INTO three_way_matches (
        id, po_id, po_number, grn_number, invoice_number, supplier_name,
        po_amount, grn_received_amount, invoice_amount, discrepancy_amount,
        status, discrepancy_note, timestamp
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(3))`,
      [
        matchId,
        poId || null,
        poNumber,
        grnNumber,
        invoiceNumber,
        supplierName,
        Number(poAmount) || 0,
        Number(grnReceivedAmount) || 0,
        Number(invoiceAmount) || 0,
        Number(discrepancyAmount) || 0,
        status || 'MATCHED',
        discrepancyNote || null,
      ]
    );

    res.json({ success: true, id: matchId });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 9. AI Computer Vision Produce Identification
app.post('/api/ai/vision-identify', async (req, res) => {
  try {
    const { image, mimeType } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Image base64 data is required' });
    }
    const result = await identifyVisualItem(image, mimeType || 'image/jpeg');
    res.json(result);
  } catch (error: any) {
    console.error('Vision identification error:', error);
    res.status(500).json({ error: error.message });
  }
});

// 10. AI Voice Command & Natural Language Query
app.post('/api/ai/voice-command', async (req, res) => {
  try {
    const { speechText } = req.body;
    if (!speechText || typeof speechText !== 'string') {
      return res.status(400).json({ error: 'speechText string is required' });
    }
    const result = await parseVoiceCommand(speechText);
    res.json(result);
  } catch (error: any) {
    console.error('Voice parsing error:', error);
    res.status(500).json({ error: error.message });
  }
});

// 10b. AI Direct Audio Voice Command (Processes raw speech recording from MediaRecorder via Gemini)
app.post('/api/ai/audio-voice-command', async (req, res) => {
  try {
    const { audio, mimeType } = req.body;
    if (!audio) {
      return res.status(400).json({ error: 'audio base64 data is required' });
    }
    const result = await parseAudioVoiceCommand(audio, mimeType || 'audio/webm');
    res.json(result);
  } catch (error: any) {
    console.error('Audio voice parsing error:', error);
    res.status(500).json({ error: error.message });
  }
});

// 10c. Fast Audio Speech Transcription to Text (Raw words straight to text box)
app.post('/api/ai/transcribe-speech', async (req, res) => {
  try {
    const { audio, mimeType } = req.body;
    if (!audio) {
      return res.status(400).json({ error: 'audio base64 data is required' });
    }
    const transcript = await transcribeRawAudio(audio, mimeType || 'audio/webm');
    res.json({ transcript });
  } catch (error: any) {
    console.error('Transcription error:', error);
    res.status(500).json({ error: error.message });
  }
});


// 11. Peripherals Status & Health Diagnostic
app.get('/api/peripherals/status', (req, res) => {
  res.json({
    camera: {
      status: 'available',
      aiEngine: 'gemini-3.7-flash',
      modes: ['optical_identification', 'barcode_qr_scan'],
    },
    microphone: {
      status: 'available',
      aiEngine: 'gemini-3.7-flash',
      supportedLanguages: ['en-IN', 'hi-IN', 'ta-IN', 'te-IN', 'mr-IN', 'auto'],
    },
    barcodeScanner: {
      status: 'listening',
      interface: 'WebHID / Keyboard Wedge',
      baudRate: 9600,
    },
    scale: {
      status: 'online',
      interface: 'WebSerial RS232',
      unit: 'kg',
      precision: '0.005kg',
    },
    printer: {
      status: 'ready',
      interface: 'ESC/POS 80mm',
    },
  });
});

// Media & Cloudinary Library Image Download to Local Storage
app.post('/api/media/download-library-image', async (req, res) => {
  try {
    const { url, name } = req.body;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: 'Image URL is required' });
    }

    const productsDir = path.resolve(publicDir, 'products');
    if (!fs.existsSync(productsDir)) {
      fs.mkdirSync(productsDir, { recursive: true });
    }

    const safeBase = (name || 'item')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_\-]/g, '_')
      .replace(/_+/g, '_');
    const ext = path.extname(url.split('?')[0]) || '.jpg';
    const finalFilename = `${safeBase}${ext}`;
    const destPath = path.resolve(productsDir, finalFilename);

    const { downloadFile } = await import('./systemUpdate');
    await downloadFile(url, destPath);

    const localUrl = `/products/${finalFilename}`;
    res.json({
      success: true,
      localUrl,
      cloudUrl: url,
      filename: finalFilename,
    });
  } catch (err: any) {
    console.error('Failed to download library image:', err);
    res.status(500).json({ error: err.message || 'Image download failed' });
  }
});

// Product Status Toggle (Active / Inactive)
app.post('/api/products/:id/toggle-status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const [existingRows]: any = await pool.query('SELECT status FROM products WHERE id = ?', [id]);
    if (!existingRows || existingRows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const currentStatus = existingRows[0].status || 'active';
    const newStatus = status ? status : (currentStatus === 'active' ? 'inactive' : 'active');
    const now = new Date().toISOString();

    await pool.query('UPDATE products SET status = ?, updated_at = ? WHERE id = ?', [newStatus, now, id]);
    invalidateProductCache();
    await queueProductPush(id);

    res.json({ success: true, id, status: newStatus });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to toggle product status' });
  }
});

// System OTA Software Update APIs
app.get('/api/system/version', (req, res) => {
  res.json({
    version: '1.0.0',
    platform: process.platform,
    arch: process.arch,
  });
});

app.post('/api/system/update', async (req, res) => {
  try {
    const downloadUrl = req.body?.downloadUrl || 'https://pos.plannestapp.com/plannest-terminal.zip';
    const result = await applySystemUpdate(downloadUrl);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Update failed' });
  }
});

// System Installed Printers Query API
app.get('/api/system/printers', async (req, res) => {
  try {
    if (process.platform === 'win32') {
      const { exec } = await import('child_process');
      const util = await import('util');
      const execPromise = util.promisify(exec);
      
      const { stdout } = await execPromise(
        'powershell -NoProfile -Command "Get-Printer | Select-Object -Property Name, PortName, Default | ConvertTo-Json"'
      );
      
      let parsed = JSON.parse(stdout || '[]');
      if (!Array.isArray(parsed)) {
        parsed = [parsed];
      }
      
      const printers = parsed.map((p: any) => ({
        name: p.Name,
        port: p.PortName,
        isDefault: Boolean(p.Default),
      }));
      
      return res.json({ printers });
    }
    
    // Non-windows fallback
    res.json({
      printers: [
        { name: 'System Default Printer', port: 'DEFAULT', isDefault: true },
        { name: 'Thermal ESC/POS 80mm', port: 'USB001', isDefault: false },
      ],
    });
  } catch (err: any) {
    console.warn('[PrinterAPI] Could not query system printers:', err.message);
    res.json({
      printers: [
        { name: 'System Default Printer', port: 'DEFAULT', isDefault: true },
      ],
    });
  }
});

// Global Production Error Handling Middleware (Suppresses stack traces in production)
// Set Windows Default Printer API (Ensures Chrome/Edge --kiosk-printing targets the user's receipt printer)
app.post('/api/system/printers/set-default', async (req, res) => {
  try {
    const { printerName } = req.body;
    if (!printerName) {
      return res.status(400).json({ error: 'printerName is required' });
    }
    if (process.platform === 'win32') {
      const { exec } = await import('child_process');
      const util = await import('util');
      const execPromise = util.promisify(exec);

      const safeName = String(printerName).replace(/['"\\]/g, '');
      await execPromise(
        `powershell -NoProfile -Command "(New-Object -ComObject WScript.Network).SetDefaultPrinter('${safeName}')"`
      );
      console.log(`[PrinterAPI] Set Windows default printer to: ${safeName}`);
      return res.json({ success: true, defaultPrinter: safeName });
    }
    res.json({ success: true, defaultPrinter: printerName });
  } catch (err: any) {
    console.warn('[PrinterAPI] Failed to set default printer:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  const isProduction = process.env.NODE_ENV === 'production';
  console.error(`[API Error] ${req.method} ${req.originalUrl || req.url}:`, err.message || err);
  if (res.headersSent) {
    return next(err);
  }
  res.status(err.status || 500).json({
    error: isProduction ? 'Internal server error occurred. Please contact system support.' : (err.message || 'Internal server error'),
    timestamp: new Date().toISOString(),
  });
});

export default app;
