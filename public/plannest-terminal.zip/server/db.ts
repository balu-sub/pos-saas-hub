import 'dotenv/config';
import mysql from 'mysql2/promise';
import { Pool as PgPool } from 'pg';
import { createClient, Client } from '@libsql/client';
import path from 'path';
import fs from 'fs';
import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOMERS,
  SUPPLIERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_THREE_WAY_MATCHES,
} from '../src/data/seedData';
import { DEFAULT_OPERATORS } from '../src/types/pos';
import { DatabaseConfig, DatabaseDriverType, DatabaseStatus } from '../src/types/database';

// Ensure data directory exists
const dbDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const configFilePath = path.join(dbDir, 'db_config.json');
const dbFilePath = path.join(dbDir, 'plannest_pos.db');
const legacyDbFilePath = path.join(dbDir, 'alfa_pos.db');
if (!fs.existsSync(dbFilePath) && fs.existsSync(legacyDbFilePath)) {
  try {
    ['', '-wal', '-shm'].forEach((ext) => {
      const src = legacyDbFilePath + ext;
      const dst = dbFilePath + ext;
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, dst);
      }
    });
  } catch (e) {
    console.warn('Could not copy legacy DB:', e);
  }
}
const dbUrl = `file:${dbFilePath}`;

// Default Database Config
const DEFAULT_CONFIG: DatabaseConfig = {
  driver: process.env.SUPABASE_HOST ? 'supabase' : 'sqlite',
  storeId: process.env.STORE_ID || 'STORE-002',
  supabase: {
    host: process.env.SUPABASE_HOST || 'aws-0-ap-northeast-1.pooler.supabase.com',
    port: Number(process.env.SUPABASE_PORT) || 5432,
    user: process.env.SUPABASE_USER || 'postgres.xcrndfislsbxzzkfrawp',
    password: process.env.SUPABASE_PASSWORD || '',
    database: process.env.SUPABASE_DB || 'postgres',
    ssl: true,
  },
  mysql: {
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '',
    database: 'plannest_pos',
    ssl: false,
  },
};

let currentConfig: DatabaseConfig = loadConfig();

function loadConfig(): DatabaseConfig {
  try {
    if (fs.existsSync(configFilePath)) {
      const data = fs.readFileSync(configFilePath, 'utf-8');
      const parsed = JSON.parse(data);
      return {
        driver: parsed.driver || DEFAULT_CONFIG.driver,
        storeId: process.env.STORE_ID || parsed.storeId || DEFAULT_CONFIG.storeId,
        supabase: {
          ...DEFAULT_CONFIG.supabase!,
          ...(parsed.supabase || {}),
        },
        mysql: {
          ...DEFAULT_CONFIG.mysql,
          ...(parsed.mysql || {}),
        },
      };
    }
  } catch (err) {
    console.error('[DB Config] Error loading db_config.json:', err);
  }
  return { ...DEFAULT_CONFIG };
}

export function saveConfig(newConfig: DatabaseConfig): void {
  try {
    currentConfig = {
      driver: newConfig.driver === 'mysql' ? 'mysql' : 'sqlite',
      mysql: {
        host: newConfig.mysql?.host || 'localhost',
        port: Number(newConfig.mysql?.port) || 3306,
        user: newConfig.mysql?.user || 'root',
        password: newConfig.mysql?.password || '',
        database: newConfig.mysql?.database || 'plannest_pos',
        ssl: Boolean(newConfig.mysql?.ssl),
      },
    };
    fs.writeFileSync(configFilePath, JSON.stringify(currentConfig, null, 2), 'utf-8');
    console.log(`[DB Config] Configuration saved successfully. Active Driver: ${currentConfig.driver.toUpperCase()}`);
  } catch (err: any) {
    console.error('[DB Config] Error saving db_config.json:', err.message);
    throw err;
  }
}

export function getConfig(): DatabaseConfig {
  return { ...currentConfig };
}

// -------------------------------------------------------------
// SQLite Client
// -------------------------------------------------------------
let internalSqliteClient: Client = createClient({ url: dbUrl });

export const sqliteClient = {
  execute: async (stmt: any) => internalSqliteClient.execute(stmt),
  batch: async (stmts: any[], mode?: any) => internalSqliteClient.batch(stmts, mode),
  transaction: async (mode?: any) => internalSqliteClient.transaction(mode),
  close: () => internalSqliteClient.close(),
} as unknown as Client;

let isRebuilding = false;

export async function repairCorruptDatabase(): Promise<void> {
  if (isRebuilding) return;
  isRebuilding = true;

  console.warn(`[SQLite DB] ⚠️ Repairing and restoring SQLite database at: ${dbFilePath}`);

  try {
    try {
      internalSqliteClient.close();
    } catch {
      // Ignore close error
    }

    const filesToRemove = [
      dbFilePath,
      `${dbFilePath}-wal`,
      `${dbFilePath}-shm`,
      `${dbFilePath}-journal`,
    ];

    for (const f of filesToRemove) {
      if (fs.existsSync(f)) {
        try {
          fs.unlinkSync(f);
        } catch (e: any) {
          console.error(`[SQLite DB] Could not unlink ${f}:`, e.message);
        }
      }
    }

    internalSqliteClient = createClient({ url: dbUrl });
    await createSqliteTablesAndSeed();
    console.log('[SQLite DB] ✅ Database successfully repaired and seeded!');
  } catch (err: any) {
    console.error('[SQLite DB] ❌ Failed to repair database:', err);
  } finally {
    isRebuilding = false;
  }
}

// -------------------------------------------------------------
// MySQL Client & Pool Management
// -------------------------------------------------------------
let mysqlPool: mysql.Pool | null = null;

export function getMysqlPool(): mysql.Pool {
  if (!mysqlPool) {
    const { host, port, user, password, database, ssl } = currentConfig.mysql;
    mysqlPool = mysql.createPool({
      host,
      port,
      user,
      password,
      database,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      connectTimeout: 5000,
      ssl: ssl ? { rejectUnauthorized: false } : undefined,
    });
  }
  return mysqlPool;
}

export async function closeMysqlPool(): Promise<void> {
  if (mysqlPool) {
    try {
      await mysqlPool.end();
    } catch {
      // ignore
    }
    mysqlPool = null;
  }
}

// -------------------------------------------------------------
// Supabase Client & Pool Management
// -------------------------------------------------------------
let supabasePool: PgPool | null = null;

export function getSupabasePool(): PgPool {
  if (!supabasePool) {
    const host = process.env.SUPABASE_HOST || currentConfig.supabase?.host || 'aws-0-ap-northeast-1.pooler.supabase.com';
    const port = Number(process.env.SUPABASE_PORT || currentConfig.supabase?.port) || 5432;
    const user = process.env.SUPABASE_USER || currentConfig.supabase?.user || 'postgres.xcrndfislsbxzzkfrawp';
    const password = process.env.SUPABASE_PASSWORD || currentConfig.supabase?.password || '';
    const database = process.env.SUPABASE_DB || currentConfig.supabase?.database || 'postgres';

    supabasePool = new PgPool({
      host,
      port,
      user,
      password,
      database,
      ssl: { rejectUnauthorized: false },
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    });
  }
  return supabasePool;
}

export async function closeSupabasePool(): Promise<void> {
  if (supabasePool) {
    try {
      await supabasePool.end();
    } catch {
      // ignore
    }
    supabasePool = null;
  }
}

const MANAGED_TABLES = [
  'categories',
  'products',
  'product_variants',
  'customers',
  'suppliers',
  'users',
  'orders',
  'order_items',
  'payment_splits',
  'shifts',
  'inventory_ledger',
  'purchase_orders',
  'purchase_order_items',
  'three_way_matches',
  'outlet_profile',
  'loyalty_settings',
];

export function transformSqlForSupabase(sql: string, params: any[] = []): { sql: string; args: any[] } {
  let transformed = sql;

  for (const t of MANAGED_TABLES) {
    const re = new RegExp(`(?<!Windows_)\\b${t}\\b`, 'gi');
    transformed = transformed.replace(re, `"Windows_${t}"`);
  }

  // Convert MySQL data types & table attributes to PostgreSQL compatible syntax
  transformed = transformed
    .replace(/\bTINYINT\s*\(\s*\d+\s*\)/gi, 'SMALLINT')
    .replace(/\bTINYINT\b/gi, 'SMALLINT')
    .replace(/\bINT\s*\(\s*\d+\s*\)/gi, 'INTEGER')
    .replace(/\bDATETIME\b/gi, 'TIMESTAMP')
    .replace(/\bJSON\b/gi, 'JSONB')
    .replace(/ENGINE\s*=\s*\w+/gi, '')
    .replace(/DEFAULT\s+CHARSET\s*=\s*[\w\d]+/gi, '')
    .replace(/COLLATE\s*=\s*[\w\d_]+/gi, '')
    .replace(/ON\s+UPDATE\s+CURRENT_TIMESTAMP/gi, '');

  // Convert MySQL / SQLite timestamp functions
  transformed = transformed
    .replace(/datetime\('now'\)/gi, 'CURRENT_TIMESTAMP')
    .replace(/NOW\(\d*\)/gi, 'CURRENT_TIMESTAMP');

  // Convert ? placeholders to $1, $2, ...
  let idx = 1;
  transformed = transformed.replace(/\?/g, () => `$${idx++}`);

  return { sql: transformed, args: params };
}

async function executeSupabaseQuery(sql: string, params: any[] = []): Promise<[any[], any]> {
  const p = getSupabasePool();
  const { sql: pgSql, args: pgArgs } = transformSqlForSupabase(sql, params);
  const result = await p.query(pgSql, pgArgs);
  const rows = result.rows || [];
  const meta: any = {
    affectedRows: result.rowCount || 0,
    rowCount: result.rowCount || 0,
    command: result.command,
  };
  return [rows, meta];
}

/**
 * Test MySQL connection with provided credentials
 */
export async function testMysqlConnection(testConfig: DatabaseConfig['mysql']): Promise<{ success: boolean; message: string; version?: string }> {
  let tempPool: mysql.Pool | null = null;
  try {
    tempPool = mysql.createPool({
      host: testConfig.host,
      port: Number(testConfig.port) || 3306,
      user: testConfig.user,
      password: testConfig.password || '',
      database: testConfig.database,
      waitForConnections: true,
      connectionLimit: 2,
      connectTimeout: 4000,
      ssl: testConfig.ssl ? { rejectUnauthorized: false } : undefined,
    });

    const [rows]: any = await tempPool.query('SELECT VERSION() as version, 1 as isLive');
    const version = rows?.[0]?.version || 'MySQL 8.x';
    return {
      success: true,
      message: `Successfully connected to MySQL server (${version}) at ${testConfig.host}:${testConfig.port}`,
      version,
    };
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Could not connect to MySQL server. Please verify host, port, user, and password.',
    };
  } finally {
    if (tempPool) {
      try {
        await tempPool.end();
      } catch {
        // ignore
      }
    }
  }
}

/**
 * Normalizes SQL queries and parameters for SQLite compatibility
 */
function normalizeSqlAndArgsForSqlite(sql: string, params: any[] = []): { sql: string; args: any[] } {
  const cleanedSql = sql
    .replace(/NOW\(\d*\)/gi, "datetime('now')")
    .replace(/CURRENT_TIMESTAMP\(\d*\)/gi, 'CURRENT_TIMESTAMP')
    .replace(/\s+FOR\s+UPDATE/gi, '');

  const normalizedArgs = params.map((arg) => {
    if (arg === undefined) return null;
    if (typeof arg === 'boolean') return arg ? 1 : 0;
    if (arg instanceof Date) return arg.toISOString();
    return arg;
  });

  return { sql: cleanedSql, args: normalizedArgs };
}

function isCorruptError(err: any): boolean {
  if (!err) return false;
  const msg = (err.message || '').toLowerCase();
  const code = (err.code || '').toLowerCase();
  return (
    code.includes('corrupt') ||
    msg.includes('corrupt') ||
    msg.includes('malformed') ||
    msg.includes('disk image is malformed') ||
    msg.includes('file is not a database')
  );
}

/**
 * Execute query via SQLite engine
 */
export async function executeSqliteQuery(sql: string, params: any[] = []): Promise<[any[], any]> {
  const { sql: nSql, args: nArgs } = normalizeSqlAndArgsForSqlite(sql, params);

  try {
    const result = await internalSqliteClient.execute({ sql: nSql, args: nArgs });

    const rows = result.rows.map((row) => {
      const obj: Record<string, any> = {};
      for (const key of Object.keys(row)) {
        obj[key] = (row as any)[key];
      }
      return obj;
    });

    const meta: any = {
      affectedRows: result.rowsAffected,
      insertId: result.lastInsertRowid !== undefined ? Number(result.lastInsertRowid) : 0,
      rowsAffected: result.rowsAffected,
    };

    return [rows, meta];
  } catch (err: any) {
    if (isCorruptError(err)) {
      console.error(`[SQLite DB] SQL execution hit corrupt error: ${err.message}. Triggering repair...`);
      await repairCorruptDatabase();
      const retryResult = await internalSqliteClient.execute({ sql: nSql, args: nArgs });
      const retryRows = retryResult.rows.map((row) => {
        const obj: Record<string, any> = {};
        for (const key of Object.keys(row)) {
          obj[key] = (row as any)[key];
        }
        return obj;
      });
      const meta: any = {
        affectedRows: retryResult.rowsAffected,
        insertId: retryResult.lastInsertRowid !== undefined ? Number(retryResult.lastInsertRowid) : 0,
        rowsAffected: retryResult.rowsAffected,
      };
      return [retryRows, meta];
    }
    throw err;
  }
}

/**
 * Execute query via MySQL engine
 */
async function executeMysqlQuery(sql: string, params: any[] = []): Promise<[any[], any]> {
  const p = getMysqlPool();
  const [rows, fields]: any = await p.query(sql, params);
  return [Array.isArray(rows) ? rows : [rows], fields];
}

/**
 * Unified Query Router
 */
export async function executeQuery(sql: string, params: any[] = []): Promise<[any[], any]> {
  if (currentConfig.driver === 'supabase') {
    try {
      return await executeSupabaseQuery(sql, params);
    } catch (sbErr: any) {
      if (process.env.DEBUG === 'true') {
        console.warn(`[Supabase DB] Query failed: ${sbErr.message}. Falling back to local SQLite...`);
      }
      return await executeSqliteQuery(sql, params);
    }
  }
  if (currentConfig.driver === 'mysql') {
    try {
      return await executeMysqlQuery(sql, params);
    } catch (mysqlErr: any) {
      if (process.env.DEBUG === 'true') {
        console.warn(`[MySQL DB] Query failed: ${mysqlErr.message}. Falling back to local SQLite...`);
      }
      return await executeSqliteQuery(sql, params);
    }
  }
  return await executeSqliteQuery(sql, params);
}

/**
 * Unified Database Pool interface
 */
export const pool = {
  query: async (sql: string, params: any[] = []) => {
    return executeQuery(sql, params);
  },
  getConnection: async () => {
    if (currentConfig.driver === 'supabase') {
      try {
        const client = await getSupabasePool().connect();
        return {
          query: async (sql: string, params: any[] = []) => {
            const { sql: pgSql, args: pgArgs } = transformSqlForSupabase(sql, params);
            const res = await client.query(pgSql, pgArgs);
            return [res.rows || [], { affectedRows: res.rowCount || 0 }] as [any[], any];
          },
          beginTransaction: async () => {
            await client.query('BEGIN');
          },
          commit: async () => {
            await client.query('COMMIT');
          },
          rollback: async () => {
            await client.query('ROLLBACK');
          },
          release: () => {
            client.release();
          },
        };
      } catch (err: any) {
        console.warn(`[Supabase Connection] Connection error (${err.message}). Using SQLite fallback connection.`);
      }
    }

    if (currentConfig.driver === 'mysql') {
      try {
        const conn = await getMysqlPool().getConnection();
        return {
          query: async (sql: string, params: any[] = []) => {
            const [rows, fields] = await conn.query(sql, params);
            return [Array.isArray(rows) ? rows : [rows], fields] as [any[], any];
          },
          beginTransaction: async () => conn.beginTransaction(),
          commit: async () => conn.commit(),
          rollback: async () => conn.rollback(),
          release: () => conn.release(),
        };
      } catch (err: any) {
        console.warn(`[MySQL Connection] Failed to get connection: ${err.message}. Using SQLite fallback connection.`);
      }
    }

    let inTransaction = false;
    return {
      query: async (sql: string, params: any[] = []) => {
        return executeSqliteQuery(sql, params);
      },
      beginTransaction: async () => {
        if (!inTransaction) {
          await internalSqliteClient.execute('BEGIN TRANSACTION');
          inTransaction = true;
        }
      },
      commit: async () => {
        if (inTransaction) {
          await internalSqliteClient.execute('COMMIT');
          inTransaction = false;
        }
      },
      rollback: async () => {
        if (inTransaction) {
          try {
            await internalSqliteClient.execute('ROLLBACK');
          } catch {
            // ignore
          }
          inTransaction = false;
        }
      },
      release: () => {
        // No-op for SQLite
      },
    };
  },
};

/**
 * Switch Active Database Driver
 */
export async function switchDatabaseDriver(newDriver: DatabaseDriverType, mysqlOptions?: DatabaseConfig['mysql']): Promise<{ success: boolean; message: string }> {
  if (newDriver === 'mysql') {
    const configToUse = mysqlOptions || currentConfig.mysql;
    const test = await testMysqlConnection(configToUse);
    if (!test.success) {
      throw new Error(`Cannot switch to MySQL: ${test.message}`);
    }

    // Close any previous pool and update config
    await closeMysqlPool();
    saveConfig({
      driver: 'mysql',
      mysql: configToUse,
    });

    // Initialize MySQL schemas if necessary
    await initMysqlDatabase();

    return {
      success: true,
      message: `Switched active database to Remote MySQL (${configToUse.host}:${configToUse.port}/${configToUse.database})`,
    };
  } else {
    // Switch to SQLite
    saveConfig({
      ...currentConfig,
      driver: 'sqlite',
    });

    return {
      success: true,
      message: `Switched active database to Local Embedded SQLite (${dbFilePath})`,
    };
  }
}

/**
 * Migrate local SQLite data into connected MySQL instance
 */
export async function migrateLocalDataToMysql(targetMysqlConfig?: DatabaseConfig['mysql']): Promise<{ success: boolean; counts: Record<string, number>; message: string }> {
  const configToUse = targetMysqlConfig || currentConfig.mysql;
  const test = await testMysqlConnection(configToUse);
  if (!test.success) {
    throw new Error(`Cannot migrate to MySQL: ${test.message}`);
  }

  // Create temporary connection to target MySQL
  const targetPool = mysql.createPool({
    host: configToUse.host,
    port: Number(configToUse.port) || 3306,
    user: configToUse.user,
    password: configToUse.password || '',
    database: configToUse.database,
    waitForConnections: true,
    connectionLimit: 5,
    ssl: configToUse.ssl ? { rejectUnauthorized: false } : undefined,
  });

  const counts: Record<string, number> = {
    categories: 0,
    products: 0,
    product_variants: 0,
    customers: 0,
    suppliers: 0,
    users: 0,
    orders: 0,
  };

  try {
    // 1. Create MySQL tables
    await createMysqlTablesOnPool(targetPool);

    // 2. Read from SQLite
    const [categories]: any = await executeSqliteQuery('SELECT * FROM categories');
    for (const c of categories) {
      await targetPool.query(
        `REPLACE INTO categories (id, name, description, icon, color, display_order, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [c.id, c.name, c.description, c.icon, c.color, c.display_order, c.status]
      );
      counts.categories++;
    }

    const [products]: any = await executeSqliteQuery('SELECT * FROM products');
    for (const p of products) {
      await targetPool.query(
        `REPLACE INTO products (id, name, description, category, brand, unit, base_sku, base_barcode, base_price, base_mrp, base_cost, image_url, taxable, gst_rate, status, daily_consumption_rate, lead_time_days, supplier_id, total_on_hand, total_available, is_offer_active, offer_type, offer_value, offer_title, offer_start_date, offer_end_date)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          p.id, p.name, p.description, p.category, p.brand, p.unit, p.base_sku, p.base_barcode,
          p.base_price, p.base_mrp, p.base_cost, p.image_url, p.taxable, p.gst_rate, p.status,
          p.daily_consumption_rate, p.lead_time_days, p.supplier_id, p.total_on_hand, p.total_available,
          p.is_offer_active || 0, p.offer_type || 'percentage', p.offer_value || 0, p.offer_title || 'Offer of the Day',
          p.offer_start_date || null, p.offer_end_date || null,
        ]
      );
      counts.products++;
    }

    const [variants]: any = await executeSqliteQuery('SELECT * FROM product_variants');
    for (const v of variants) {
      await targetPool.query(
        `REPLACE INTO product_variants (id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, margin_percent, on_hand, available, reserved, reorder_level, is_parent, version)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          v.id, v.product_id, v.sku, v.barcode, v.name, v.unit, v.attributes, v.mrp, v.price, v.cost,
          v.margin_percent, v.on_hand, v.available, v.reserved, v.reorder_level, v.is_parent, v.version,
        ]
      );
      counts.product_variants++;
    }

    const [customers]: any = await executeSqliteQuery('SELECT * FROM customers');
    for (const c of customers) {
      await targetPool.query(
        `REPLACE INTO customers (id, name, email, phone, loyalty_points, tier, total_spend, store_credit, gst_number, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [c.id, c.name, c.email, c.phone, c.loyalty_points, c.tier, c.total_spend, c.store_credit, c.gst_number, c.notes]
      );
      counts.customers++;
    }

    const [suppliers]: any = await executeSqliteQuery('SELECT * FROM suppliers');
    for (const s of suppliers) {
      await targetPool.query(
        `REPLACE INTO suppliers (id, name, code, contact_person, email, phone, address, gst_number, payment_terms, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [s.id, s.name, s.code, s.contact_person, s.email, s.phone, s.address, s.gst_number, s.payment_terms, s.status]
      );
      counts.suppliers++;
    }

    const [users]: any = await executeSqliteQuery('SELECT * FROM users');
    for (const u of users) {
      await targetPool.query(
        `REPLACE INTO users (id, name, pin, role, role_title, user_role, email, phone, initials, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [u.id, u.name, u.pin, u.role, u.role_title, u.user_role, u.email, u.phone, u.initials, u.status]
      );
      counts.users++;
    }

    return {
      success: true,
      counts,
      message: `Migrated ${counts.products} products, ${counts.product_variants} variants, ${counts.customers} customers, ${counts.categories} categories, and ${counts.users} users to MySQL!`,
    };
  } finally {
    await targetPool.end();
  }
}

/**
 * Get Comprehensive Database Status
 */
export async function getDatabaseStatus(): Promise<DatabaseStatus> {
  const driver = currentConfig.driver;
  let isOnline = false;
  let connected = false;
  let productCount = 0;
  let variantCount = 0;

  try {
    const [pRows]: any = await pool.query('SELECT COUNT(*) as count FROM products');
    const [vRows]: any = await pool.query('SELECT COUNT(*) as count FROM product_variants');
    productCount = Number(pRows?.[0]?.count || 0);
    variantCount = Number(vRows?.[0]?.count || 0);
    connected = true;
    isOnline = true;
  } catch (err) {
    connected = false;
    isOnline = false;
  }

  const storeId = process.env.STORE_ID || currentConfig.storeId || 'STORE-002';

  return {
    driver,
    driverName:
      driver === 'supabase'
        ? 'Supabase Cloud PostgreSQL'
        : driver === 'mysql'
        ? 'Remote MySQL Server'
        : 'Local Embedded SQLite',
    connected,
    isOnline,
    activeTarget:
      driver === 'supabase'
        ? `${process.env.SUPABASE_HOST || 'Supabase'} (Store: ${storeId})`
        : driver === 'mysql'
        ? `${currentConfig.mysql.host}:${currentConfig.mysql.port}/${currentConfig.mysql.database}`
        : dbFilePath,
    sqliteFile: dbFilePath,
    productCount,
    variantCount,
    lastChecked: new Date().toISOString(),
    storeId,
    supabaseConfigured: Boolean(process.env.SUPABASE_HOST || currentConfig.supabase?.host),
    mysqlConfigured: Boolean(currentConfig.mysql?.host),
    mysqlDetails: {
      host: currentConfig.mysql.host,
      port: currentConfig.mysql.port,
      user: currentConfig.mysql.user,
      database: currentConfig.mysql.database,
      ssl: currentConfig.mysql.ssl,
    },
  };
}

// -------------------------------------------------------------
// Table Creation Scripts
// -------------------------------------------------------------
async function createMysqlTablesOnPool(p: mysql.Pool): Promise<void> {
  await p.query(`
    CREATE TABLE IF NOT EXISTS categories (
      id VARCHAR(64) PRIMARY KEY,
      name VARCHAR(128) NOT NULL UNIQUE,
      description TEXT,
      icon VARCHAR(64),
      color VARCHAR(32),
      display_order INT DEFAULT 0,
      status VARCHAR(32) DEFAULT 'active',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS products (
      id VARCHAR(64) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      description TEXT,
      category VARCHAR(128) NOT NULL,
      brand VARCHAR(128) DEFAULT 'Store Brand',
      unit VARCHAR(32) DEFAULT 'kg',
      base_sku VARCHAR(64),
      base_barcode VARCHAR(64),
      base_price DECIMAL(12,2) DEFAULT 0.00,
      base_mrp DECIMAL(12,2) DEFAULT 0.00,
      base_cost DECIMAL(12,2) DEFAULT 0.00,
      image_url TEXT,
      taxable TINYINT(1) DEFAULT 0,
      gst_rate DECIMAL(6,4) DEFAULT 0.0000,
      status VARCHAR(32) DEFAULT 'active',
      daily_consumption_rate DECIMAL(10,2) DEFAULT 1.00,
      lead_time_days INT DEFAULT 2,
      supplier_id VARCHAR(64) DEFAULT 'SUPP-001',
      total_on_hand DECIMAL(12,2) DEFAULT 50.00,
      total_available DECIMAL(12,2) DEFAULT 50.00,
      is_offer_active TINYINT(1) DEFAULT 0,
      offer_type VARCHAR(32) DEFAULT 'percentage',
      offer_value DECIMAL(12,2) DEFAULT 0.00,
      offer_title VARCHAR(255) DEFAULT 'Offer of the Day',
      offer_start_date VARCHAR(64) DEFAULT NULL,
      offer_end_date VARCHAR(64) DEFAULT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS product_variants (
      id VARCHAR(64) PRIMARY KEY,
      product_id VARCHAR(64) NOT NULL,
      sku VARCHAR(64) NOT NULL UNIQUE,
      barcode VARCHAR(64),
      name VARCHAR(255) NOT NULL,
      unit VARCHAR(32) DEFAULT 'kg',
      attributes JSON,
      mrp DECIMAL(12,2) DEFAULT 0.00,
      price DECIMAL(12,2) DEFAULT 0.00,
      cost DECIMAL(12,2) DEFAULT 0.00,
      margin_percent DECIMAL(6,2) DEFAULT 0.00,
      on_hand DECIMAL(12,2) DEFAULT 50.00,
      available DECIMAL(12,2) DEFAULT 50.00,
      reserved DECIMAL(12,2) DEFAULT 0.00,
      reorder_level DECIMAL(12,2) DEFAULT 10.00,
      is_parent TINYINT(1) DEFAULT 0,
      version INT DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS customers (
      id VARCHAR(64) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255),
      phone VARCHAR(64),
      loyalty_points INT DEFAULT 0,
      tier VARCHAR(32) DEFAULT 'Standard',
      total_spend DECIMAL(12,2) DEFAULT 0.00,
      store_credit DECIMAL(12,2) DEFAULT 0.00,
      gst_number VARCHAR(64),
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS suppliers (
      id VARCHAR(64) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      code VARCHAR(64) NOT NULL UNIQUE,
      contact_person VARCHAR(255),
      email VARCHAR(255),
      phone VARCHAR(64),
      address TEXT,
      gst_number VARCHAR(64),
      payment_terms VARCHAR(64) DEFAULT 'Net 15',
      status VARCHAR(32) DEFAULT 'active',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(64) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      pin VARCHAR(32) NOT NULL,
      role VARCHAR(64) NOT NULL,
      role_title VARCHAR(128),
      user_role VARCHAR(32) DEFAULT 'Staff',
      email VARCHAR(255),
      phone VARCHAR(64),
      initials VARCHAR(16) DEFAULT 'OP',
      status VARCHAR(32) DEFAULT 'active',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id VARCHAR(64) PRIMARY KEY,
      order_number VARCHAR(64) NOT NULL UNIQUE,
      terminal_id VARCHAR(64) DEFAULT 'POS-TERM-01',
      shift_id VARCHAR(64),
      customer_id VARCHAR(64),
      customer_name VARCHAR(255),
      customer_phone VARCHAR(64),
      cashier_id VARCHAR(64),
      cashier_name VARCHAR(255),
      operator_id VARCHAR(64),
      subtotal DECIMAL(12,2) DEFAULT 0.00,
      tax_amount DECIMAL(12,2) DEFAULT 0.00,
      tax_rate DECIMAL(6,4) DEFAULT 0.0000,
      tax_total DECIMAL(12,2) DEFAULT 0.00,
      discount_total DECIMAL(12,2) DEFAULT 0.00,
      rounding_delta DECIMAL(8,2) DEFAULT 0.00,
      total DECIMAL(12,2) DEFAULT 0.00,
      grand_total DECIMAL(12,2) DEFAULT 0.00,
      amount_paid DECIMAL(12,2) DEFAULT 0.00,
      change_due DECIMAL(12,2) DEFAULT 0.00,
      item_count INT DEFAULT 0,
      status VARCHAR(32) DEFAULT 'completed',
      synced TINYINT(1) DEFAULT 1,
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS order_items (
      id VARCHAR(64) PRIMARY KEY,
      order_id VARCHAR(64) NOT NULL,
      product_id VARCHAR(64),
      variant_id VARCHAR(64),
      product_name VARCHAR(255) NOT NULL,
      sku VARCHAR(64),
      barcode VARCHAR(64),
      unit VARCHAR(32) DEFAULT 'kg',
      mrp DECIMAL(12,2) DEFAULT 0.00,
      unit_price DECIMAL(12,2) DEFAULT 0.00,
      quantity DECIMAL(12,3) DEFAULT 1.000,
      discount_amount DECIMAL(12,2) DEFAULT 0.00,
      discount_percent DECIMAL(6,2) DEFAULT 0.00,
      applied_tax_rate DECIMAL(6,4) DEFAULT 0.0000,
      modifiers TEXT,
      pack_size VARCHAR(64),
      line_total DECIMAL(12,2) DEFAULT 0.00
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS payment_splits (
      id VARCHAR(64) PRIMARY KEY,
      order_id VARCHAR(64) NOT NULL,
      tender_type VARCHAR(64) NOT NULL,
      amount DECIMAL(12,2) DEFAULT 0.00,
      reference VARCHAR(255),
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      status VARCHAR(32) DEFAULT 'completed'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS inventory_ledger (
      id VARCHAR(64) PRIMARY KEY,
      sku VARCHAR(64),
      variant_id VARCHAR(64),
      product_id VARCHAR(64),
      product_name VARCHAR(255),
      delta DECIMAL(12,3) DEFAULT 0.000,
      change_delta DECIMAL(12,3) DEFAULT 0.000,
      balance_after DECIMAL(12,3) DEFAULT 0.000,
      resulting_on_hand DECIMAL(12,3) DEFAULT 0.000,
      mutation_type VARCHAR(64) DEFAULT 'SALE',
      reason VARCHAR(255) DEFAULT '',
      reference_id VARCHAR(64),
      operator VARCHAR(255),
      operator_id VARCHAR(64),
      notes TEXT,
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS outlet_profile (
      id VARCHAR(64) PRIMARY KEY,
      outlet_name VARCHAR(255) NOT NULL DEFAULT 'Amma & Appa Kadai',
      branch_name VARCHAR(255) DEFAULT 'Main Market Branch',
      address_line1 VARCHAR(255) DEFAULT 'Shop #12, Mandi Market Complex',
      address_line2 VARCHAR(255) DEFAULT 'Main Road, Gandhi Nagar',
      city VARCHAR(128) DEFAULT 'Chennai',
      state VARCHAR(128) DEFAULT 'Tamil Nadu',
      pincode VARCHAR(32) DEFAULT '600001',
      phone VARCHAR(64) DEFAULT '+91 98200 12345',
      email VARCHAR(255) DEFAULT 'contact@freshkadai.in',
      gstin VARCHAR(64) DEFAULT '33AABCA1234F1Z9',
      pan_number VARCHAR(64) DEFAULT 'AABCA1234F',
      fssai_license VARCHAR(64) DEFAULT '11521018000450',
      currency_symbol VARCHAR(16) DEFAULT 'Rs.',
      receipt_header_note TEXT,
      receipt_footer_note TEXT,
      return_terms TEXT,
      bill_prefix VARCHAR(64) DEFAULT 'INV/',
      bill_suffix VARCHAR(64) DEFAULT '',
      bill_start_number INT DEFAULT 1001,
      bill_increment_step INT DEFAULT 1,
      bill_next_sequence INT DEFAULT 1001,
      bill_number_padding INT DEFAULT 4,
      bill_reset_frequency VARCHAR(32) DEFAULT 'never',
      bill_last_reset_date VARCHAR(32) DEFAULT '',
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS loyalty_settings (
      id VARCHAR(64) PRIMARY KEY,
      enabled TINYINT(1) DEFAULT 1,
      spend_amount_per_point DECIMAL(12,2) DEFAULT 100.00,
      points_earned_per_spend INT DEFAULT 1,
      point_redemption_value DECIMAL(12,2) DEFAULT 1.00,
      min_points_to_redeem INT DEFAULT 10,
      expiry_period_days INT DEFAULT 90,
      auto_enroll_on_registration TINYINT(1) DEFAULT 1,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // Ensure offer columns exist in MySQL products table
  const mysqlOfferColumns = [
    { col: 'is_offer_active', def: 'TINYINT(1) DEFAULT 0' },
    { col: 'offer_type', def: "VARCHAR(32) DEFAULT 'percentage'" },
    { col: 'offer_value', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'offer_title', def: "VARCHAR(255) DEFAULT 'Offer of the Day'" },
    { col: 'offer_start_date', def: 'VARCHAR(64) DEFAULT NULL' },
    { col: 'offer_end_date', def: 'VARCHAR(64) DEFAULT NULL' },
  ];
  for (const c of mysqlOfferColumns) {
    try {
      await p.query(`ALTER TABLE products ADD COLUMN ${c.col} ${c.def}`);
    } catch {
      // Column already exists
    }
  }

  // Ensure customer loyalty & tracking columns exist in MySQL
  const mysqlCustColumns = [
    { col: 'member_tier', def: "VARCHAR(64) DEFAULT 'Standard'" },
    { col: 'is_loyalty_member', def: 'TINYINT(1) DEFAULT 1' },
    { col: 'loyalty_joined_date', def: 'VARCHAR(64) DEFAULT NULL' },
    { col: 'loyalty_expiry_date', def: 'VARCHAR(64) DEFAULT NULL' },
    { col: 'total_spent', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'recent_purchases_count', def: 'INT DEFAULT 0' },
  ];
  for (const cc of mysqlCustColumns) {
    try {
      await p.query(`ALTER TABLE customers ADD COLUMN ${cc.col} ${cc.def}`);
    } catch {
      // Column already exists
    }
  }

  // Ensure orders columns exist in MySQL
  const mysqlOrderColumns = [
    { col: 'cashier_id', def: 'VARCHAR(64) DEFAULT NULL' },
    { col: 'cashier_name', def: 'VARCHAR(255) DEFAULT NULL' },
    { col: 'customer_phone', def: 'VARCHAR(64) DEFAULT NULL' },
    { col: 'tax_amount', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'tax_rate', def: 'DECIMAL(6,4) DEFAULT 0.0000' },
    { col: 'total', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'amount_paid', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'change_due', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'synced', def: 'TINYINT(1) DEFAULT 1' },
    { col: 'notes', def: 'TEXT' },
  ];
  for (const oc of mysqlOrderColumns) {
    try {
      await p.query(`ALTER TABLE orders ADD COLUMN ${oc.col} ${oc.def}`);
    } catch {
      // Column already exists
    }
  }

  // Ensure order_items columns exist in MySQL
  const mysqlOrderItemColumns = [
    { col: 'barcode', def: 'VARCHAR(64) DEFAULT NULL' },
    { col: 'mrp', def: 'DECIMAL(12,2) DEFAULT 0.00' },
    { col: 'discount_percent', def: 'DECIMAL(6,2) DEFAULT 0.00' },
    { col: 'modifiers', def: 'TEXT' },
    { col: 'pack_size', def: 'VARCHAR(64) DEFAULT NULL' },
  ];
  for (const oic of mysqlOrderItemColumns) {
    try {
      await p.query(`ALTER TABLE order_items ADD COLUMN ${oic.col} ${oic.def}`);
    } catch {
      // Column already exists
    }
  }

  // Ensure inventory_ledger columns exist in MySQL
  const mysqlLedgerColumns = [
    { col: 'delta', def: 'DECIMAL(12,3) DEFAULT 0.000' },
    { col: 'balance_after', def: 'DECIMAL(12,3) DEFAULT 0.000' },
    { col: 'mutation_type', def: "VARCHAR(64) DEFAULT 'SALE'" },
    { col: 'operator', def: 'VARCHAR(255) DEFAULT NULL' },
    { col: 'product_name', def: 'VARCHAR(255) DEFAULT NULL' },
    { col: 'notes', def: 'TEXT' },
  ];
  for (const lc of mysqlLedgerColumns) {
    try {
      await p.query(`ALTER TABLE inventory_ledger ADD COLUMN ${lc.col} ${lc.def}`);
    } catch {
      // Column already exists
    }
  }

  await p.query(`
    CREATE TABLE IF NOT EXISTS purchase_orders (
      id VARCHAR(64) PRIMARY KEY,
      po_number VARCHAR(64) NOT NULL UNIQUE,
      supplier_id VARCHAR(64),
      supplier_name VARCHAR(255) NOT NULL,
      order_date VARCHAR(64) DEFAULT NULL,
      expected_delivery_date VARCHAR(64) DEFAULT NULL,
      expected_delivery VARCHAR(64) DEFAULT NULL,
      total_amount DECIMAL(12,2) DEFAULT 0.00,
      status VARCHAR(32) DEFAULT 'DRAFT',
      ai_suggested TINYINT(1) DEFAULT 0,
      ai_reason TEXT,
      safety_stock_trigger DECIMAL(12,3) DEFAULT NULL,
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS purchase_order_items (
      id VARCHAR(64) PRIMARY KEY,
      po_id VARCHAR(64) NOT NULL,
      product_id VARCHAR(64),
      variant_id VARCHAR(64),
      sku VARCHAR(64),
      product_name VARCHAR(255),
      quantity_ordered DECIMAL(12,3) DEFAULT 0.000,
      quantity_received DECIMAL(12,3) DEFAULT 0.000,
      unit VARCHAR(32) DEFAULT 'kg',
      unit_cost DECIMAL(12,2) DEFAULT 0.00,
      total_cost DECIMAL(12,2) DEFAULT 0.00
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await p.query(`
    CREATE TABLE IF NOT EXISTS three_way_matches (
      id VARCHAR(64) PRIMARY KEY,
      po_id VARCHAR(64) NOT NULL,
      po_number VARCHAR(64) NOT NULL,
      grn_number VARCHAR(64) NOT NULL,
      invoice_number VARCHAR(64) NOT NULL,
      supplier_name VARCHAR(255) NOT NULL,
      po_amount DECIMAL(12,2) NOT NULL,
      grn_received_amount DECIMAL(12,2) NOT NULL,
      invoice_amount DECIMAL(12,2) NOT NULL,
      discrepancy_amount DECIMAL(12,2) DEFAULT 0.00,
      status VARCHAR(32) NOT NULL,
      discrepancy_note TEXT,
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);
}

async function initMysqlDatabase(): Promise<void> {
  const p = getMysqlPool();
  await createMysqlTablesOnPool(p);
}

async function createSqliteTablesAndSeed(): Promise<void> {
  await internalSqliteClient.execute('PRAGMA journal_mode = WAL;');
  await internalSqliteClient.execute('PRAGMA foreign_keys = ON;');

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      icon TEXT,
      color TEXT,
      display_order INTEGER DEFAULT 0,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      category TEXT NOT NULL,
      brand TEXT DEFAULT 'Store Brand',
      unit TEXT DEFAULT 'kg',
      base_sku TEXT,
      base_barcode TEXT,
      base_price REAL DEFAULT 0,
      base_mrp REAL DEFAULT 0,
      base_cost REAL DEFAULT 0,
      image_url TEXT,
      taxable INTEGER DEFAULT 0,
      gst_rate REAL DEFAULT 0,
      status TEXT DEFAULT 'active',
      daily_consumption_rate REAL DEFAULT 1.0,
      lead_time_days INTEGER DEFAULT 2,
      supplier_id TEXT DEFAULT 'SUPP-001',
      total_on_hand REAL DEFAULT 50.0,
      total_available REAL DEFAULT 50.0,
      is_offer_active INTEGER DEFAULT 0,
      offer_type TEXT DEFAULT 'percentage',
      offer_value REAL DEFAULT 0,
      offer_title TEXT DEFAULT 'Offer of the Day',
      offer_start_date TEXT,
      offer_end_date TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS product_variants (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL,
      sku TEXT NOT NULL UNIQUE,
      barcode TEXT,
      name TEXT NOT NULL,
      unit TEXT DEFAULT 'kg',
      attributes TEXT,
      mrp REAL DEFAULT 0,
      price REAL DEFAULT 0,
      cost REAL DEFAULT 0,
      margin_percent REAL DEFAULT 0,
      on_hand REAL DEFAULT 50.0,
      available REAL DEFAULT 50.0,
      reserved REAL DEFAULT 0.0,
      reorder_level REAL DEFAULT 10.0,
      is_parent INTEGER DEFAULT 0,
      version INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      loyalty_points INTEGER DEFAULT 0,
      tier TEXT DEFAULT 'Standard',
      total_spend REAL DEFAULT 0.0,
      store_credit REAL DEFAULT 0.0,
      gst_number TEXT,
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      contact_person TEXT,
      email TEXT,
      phone TEXT,
      address TEXT,
      gst_number TEXT,
      payment_terms TEXT DEFAULT 'Net 15',
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      pin TEXT NOT NULL,
      role TEXT NOT NULL,
      role_title TEXT,
      user_role TEXT DEFAULT 'Staff',
      email TEXT,
      phone TEXT,
      initials TEXT DEFAULT 'OP',
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      order_number TEXT NOT NULL UNIQUE,
      terminal_id TEXT DEFAULT 'POS-TERM-01',
      shift_id TEXT,
      customer_id TEXT,
      customer_name TEXT,
      customer_phone TEXT,
      cashier_id TEXT,
      cashier_name TEXT,
      operator_id TEXT,
      subtotal REAL DEFAULT 0.0,
      tax_amount REAL DEFAULT 0.0,
      tax_rate REAL DEFAULT 0.0,
      tax_total REAL DEFAULT 0.0,
      discount_total REAL DEFAULT 0.0,
      rounding_delta REAL DEFAULT 0.0,
      total REAL DEFAULT 0.0,
      grand_total REAL DEFAULT 0.0,
      amount_paid REAL DEFAULT 0.0,
      change_due REAL DEFAULT 0.0,
      item_count INTEGER DEFAULT 0,
      status TEXT DEFAULT 'completed',
      synced INTEGER DEFAULT 1,
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS order_items (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      product_id TEXT,
      variant_id TEXT,
      product_name TEXT NOT NULL,
      sku TEXT,
      barcode TEXT,
      unit TEXT DEFAULT 'kg',
      mrp REAL DEFAULT 0.0,
      unit_price REAL DEFAULT 0.0,
      quantity REAL DEFAULT 1.0,
      discount_amount REAL DEFAULT 0.0,
      discount_percent REAL DEFAULT 0.0,
      applied_tax_rate REAL DEFAULT 0.0,
      modifiers TEXT,
      pack_size TEXT,
      line_total REAL DEFAULT 0.0,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS payment_splits (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      tender_type TEXT NOT NULL,
      amount REAL DEFAULT 0.0,
      reference TEXT,
      timestamp TEXT DEFAULT (datetime('now')),
      status TEXT DEFAULT 'completed',
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS inventory_ledger (
      id TEXT PRIMARY KEY,
      timestamp TEXT DEFAULT (datetime('now')),
      product_id TEXT,
      variant_id TEXT,
      sku TEXT,
      product_name TEXT,
      delta REAL DEFAULT 0.0,
      change_delta REAL DEFAULT 0.0,
      balance_after REAL DEFAULT 0.0,
      resulting_on_hand REAL DEFAULT 0.0,
      mutation_type TEXT DEFAULT 'SALE',
      reason TEXT DEFAULT '',
      reference_id TEXT,
      operator TEXT,
      operator_id TEXT,
      notes TEXT
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS shifts (
      id TEXT PRIMARY KEY,
      terminal_id TEXT DEFAULT 'POS-TERM-01',
      operator_id TEXT,
      operator_name TEXT,
      opened_at TEXT DEFAULT (datetime('now')),
      closed_at TEXT,
      opening_float REAL DEFAULT 5000.0,
      cash_sales REAL DEFAULT 0.0,
      upi_sales REAL DEFAULT 0.0,
      card_sales REAL DEFAULT 0.0,
      store_credit_sales REAL DEFAULT 0.0,
      total_sales REAL DEFAULT 0.0,
      cash_drops REAL DEFAULT 0.0,
      cash_payouts REAL DEFAULT 0.0,
      expected_cash REAL DEFAULT 5000.0,
      counted_cash REAL,
      variance REAL,
      notes TEXT,
      status TEXT DEFAULT 'open'
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS purchase_orders (
      id TEXT PRIMARY KEY,
      po_number TEXT NOT NULL UNIQUE,
      supplier_id TEXT NOT NULL,
      supplier_name TEXT NOT NULL,
      order_date TEXT DEFAULT (datetime('now')),
      expected_delivery_date TEXT,
      expected_delivery TEXT,
      total_amount REAL DEFAULT 0.0,
      status TEXT DEFAULT 'DRAFT',
      ai_suggested INTEGER DEFAULT 0,
      ai_reason TEXT,
      safety_stock_trigger REAL,
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS purchase_order_items (
      id TEXT PRIMARY KEY,
      po_id TEXT NOT NULL,
      product_id TEXT,
      variant_id TEXT,
      sku TEXT NOT NULL,
      product_name TEXT NOT NULL,
      quantity_ordered REAL NOT NULL DEFAULT 0.0,
      quantity_received REAL DEFAULT 0.0,
      unit TEXT DEFAULT 'kg',
      unit_cost REAL NOT NULL DEFAULT 0.0,
      total_cost REAL NOT NULL DEFAULT 0.0,
      FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS three_way_matches (
      id TEXT PRIMARY KEY,
      po_id TEXT NOT NULL,
      po_number TEXT NOT NULL,
      grn_number TEXT NOT NULL,
      invoice_number TEXT NOT NULL,
      supplier_name TEXT NOT NULL,
      po_amount REAL NOT NULL,
      grn_received_amount REAL NOT NULL,
      invoice_amount REAL NOT NULL,
      discrepancy_amount REAL DEFAULT 0.0,
      status TEXT NOT NULL,
      discrepancy_note TEXT,
      timestamp TEXT DEFAULT (datetime('now'))
    );
  `);

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS outlet_profile (
      id TEXT PRIMARY KEY,
      outlet_name TEXT NOT NULL DEFAULT 'Amma & Appa Kadai',
      branch_name TEXT DEFAULT 'Main Market Branch',
      address_line1 TEXT DEFAULT 'Shop #12, Mandi Market Complex',
      address_line2 TEXT DEFAULT 'Main Road, Gandhi Nagar',
      city TEXT DEFAULT 'Chennai',
      state TEXT DEFAULT 'Tamil Nadu',
      pincode TEXT DEFAULT '600001',
      phone TEXT DEFAULT '+91 98200 12345',
      email TEXT DEFAULT 'contact@freshkadai.in',
      gstin TEXT DEFAULT '33AABCA1234F1Z9',
      pan_number TEXT DEFAULT 'AABCA1234F',
      fssai_license TEXT DEFAULT '11521018000450',
      currency_symbol TEXT DEFAULT 'Rs.',
      receipt_header_note TEXT DEFAULT 'AMMA & APPA KADAI - FRESH PRODUCE & PROVISIONS',
      receipt_footer_note TEXT DEFAULT 'Thank you for shopping with us! Visit again.',
      return_terms TEXT DEFAULT 'Goods once sold can be exchanged within 24 hours with original bill receipt.',
      bill_prefix TEXT DEFAULT 'INV/',
      bill_suffix TEXT DEFAULT '',
      bill_start_number INTEGER DEFAULT 1001,
      bill_increment_step INTEGER DEFAULT 1,
      bill_next_sequence INTEGER DEFAULT 1001,
      bill_number_padding INTEGER DEFAULT 4,
      bill_reset_frequency TEXT DEFAULT 'never',
      bill_last_reset_date TEXT DEFAULT '',
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);

  // Ensure bill numbering columns exist in SQLite outlet_profile
  const sqliteOutletBillColumns = [
    { col: 'bill_prefix', def: "TEXT DEFAULT 'INV/'" },
    { col: 'bill_suffix', def: "TEXT DEFAULT ''" },
    { col: 'bill_start_number', def: 'INTEGER DEFAULT 1001' },
    { col: 'bill_increment_step', def: 'INTEGER DEFAULT 1' },
    { col: 'bill_next_sequence', def: 'INTEGER DEFAULT 1001' },
    { col: 'bill_number_padding', def: 'INTEGER DEFAULT 4' },
    { col: 'bill_reset_frequency', def: "TEXT DEFAULT 'never'" },
    { col: 'bill_last_reset_date', def: "TEXT DEFAULT ''" },
  ];
  for (const obc of sqliteOutletBillColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE outlet_profile ADD COLUMN ${obc.col} ${obc.def}`);
    } catch {
      // Column already exists
    }
  }

  await internalSqliteClient.execute(`
    CREATE TABLE IF NOT EXISTS loyalty_settings (
      id TEXT PRIMARY KEY,
      enabled INTEGER DEFAULT 1,
      spend_amount_per_point REAL DEFAULT 100.0,
      points_earned_per_spend INTEGER DEFAULT 1,
      point_redemption_value REAL DEFAULT 1.0,
      min_points_to_redeem INTEGER DEFAULT 10,
      expiry_period_days INTEGER DEFAULT 90,
      auto_enroll_on_registration INTEGER DEFAULT 1,
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);

  // Ensure offer columns exist in SQLite products table for existing databases
  const sqliteOfferColumns = [
    { col: 'is_offer_active', def: 'INTEGER DEFAULT 0' },
    { col: 'offer_type', def: "TEXT DEFAULT 'percentage'" },
    { col: 'offer_value', def: 'REAL DEFAULT 0' },
    { col: 'offer_title', def: "TEXT DEFAULT 'Offer of the Day'" },
    { col: 'offer_start_date', def: 'TEXT' },
    { col: 'offer_end_date', def: 'TEXT' },
  ];
  for (const c of sqliteOfferColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE products ADD COLUMN ${c.col} ${c.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Ensure customer loyalty & tracking columns exist in SQLite
  const sqliteCustColumns = [
    { col: 'member_tier', def: "TEXT DEFAULT 'Standard'" },
    { col: 'is_loyalty_member', def: 'INTEGER DEFAULT 1' },
    { col: 'loyalty_joined_date', def: 'TEXT' },
    { col: 'loyalty_expiry_date', def: 'TEXT' },
    { col: 'total_spent', def: 'REAL DEFAULT 0.0' },
    { col: 'recent_purchases_count', def: 'INTEGER DEFAULT 0' },
  ];
  for (const cc of sqliteCustColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE customers ADD COLUMN ${cc.col} ${cc.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Ensure orders columns exist in SQLite
  const sqliteOrderColumns = [
    { col: 'cashier_id', def: 'TEXT DEFAULT NULL' },
    { col: 'cashier_name', def: 'TEXT DEFAULT NULL' },
    { col: 'customer_phone', def: 'TEXT DEFAULT NULL' },
    { col: 'tax_amount', def: 'REAL DEFAULT 0.0' },
    { col: 'tax_rate', def: 'REAL DEFAULT 0.0' },
    { col: 'total', def: 'REAL DEFAULT 0.0' },
    { col: 'amount_paid', def: 'REAL DEFAULT 0.0' },
    { col: 'change_due', def: 'REAL DEFAULT 0.0' },
    { col: 'synced', def: 'INTEGER DEFAULT 1' },
    { col: 'notes', def: 'TEXT' },
  ];
  for (const oc of sqliteOrderColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE orders ADD COLUMN ${oc.col} ${oc.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Ensure order_items columns exist in SQLite
  const sqliteOrderItemColumns = [
    { col: 'barcode', def: 'TEXT DEFAULT NULL' },
    { col: 'mrp', def: 'REAL DEFAULT 0.0' },
    { col: 'discount_percent', def: 'REAL DEFAULT 0.0' },
    { col: 'modifiers', def: 'TEXT' },
    { col: 'pack_size', def: 'TEXT DEFAULT NULL' },
  ];
  for (const oic of sqliteOrderItemColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE order_items ADD COLUMN ${oic.col} ${oic.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Ensure inventory_ledger columns exist in SQLite
  const sqliteLedgerColumns = [
    { col: 'delta', def: 'REAL DEFAULT 0.0' },
    { col: 'balance_after', def: 'REAL DEFAULT 0.0' },
    { col: 'mutation_type', def: "TEXT DEFAULT 'SALE'" },
    { col: 'operator', def: 'TEXT DEFAULT NULL' },
    { col: 'product_name', def: 'TEXT DEFAULT NULL' },
    { col: 'notes', def: 'TEXT' },
  ];
  for (const lc of sqliteLedgerColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE inventory_ledger ADD COLUMN ${lc.col} ${lc.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Ensure purchase_orders columns exist in SQLite
  const sqlitePoColumns = [
    { col: 'order_date', def: "TEXT DEFAULT (datetime('now'))" },
    { col: 'expected_delivery_date', def: 'TEXT' },
    { col: 'expected_delivery', def: 'TEXT' },
    { col: 'ai_suggested', def: 'INTEGER DEFAULT 0' },
    { col: 'ai_reason', def: 'TEXT' },
    { col: 'safety_stock_trigger', def: 'REAL DEFAULT NULL' },
    { col: 'notes', def: 'TEXT' },
    { col: 'created_at', def: "TEXT DEFAULT (datetime('now'))" },
  ];
  for (const pc of sqlitePoColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE purchase_orders ADD COLUMN ${pc.col} ${pc.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Ensure purchase_order_items columns exist in SQLite
  const sqlitePoItemColumns = [
    { col: 'product_id', def: 'TEXT DEFAULT NULL' },
    { col: 'variant_id', def: 'TEXT DEFAULT NULL' },
    { col: 'sku', def: 'TEXT DEFAULT NULL' },
    { col: 'product_name', def: 'TEXT DEFAULT NULL' },
    { col: 'quantity_ordered', def: 'REAL DEFAULT 0.0' },
    { col: 'quantity_received', def: 'REAL DEFAULT 0.0' },
    { col: 'unit', def: "TEXT DEFAULT 'kg'" },
    { col: 'unit_cost', def: 'REAL DEFAULT 0.0' },
    { col: 'total_cost', def: 'REAL DEFAULT 0.0' },
  ];
  for (const pic of sqlitePoItemColumns) {
    try {
      await internalSqliteClient.execute(`ALTER TABLE purchase_order_items ADD COLUMN ${pic.col} ${pic.def}`);
    } catch {
      // Column already exists, safe to ignore
    }
  }

  // Seed default Outlet Profile if empty
  const outletRes = await internalSqliteClient.execute('SELECT COUNT(*) as count FROM outlet_profile');
  if (Number(outletRes.rows[0]?.count || 0) === 0) {
    const defaultStoreName = process.env.STORE_NAME || 'Plannest Retail POS';
    const defaultHeaderNote = (process.env.STORE_NAME || 'PLANNEST RETAIL POS').toUpperCase() + ' - BILLING COUNTER';
    await internalSqliteClient.execute({
      sql: `INSERT INTO outlet_profile (
        id, outlet_name, branch_name, address_line1, address_line2, city, state, pincode,
        phone, email, gstin, pan_number, fssai_license, currency_symbol,
        receipt_header_note, receipt_footer_note, return_terms
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: [
        'default_outlet',
        defaultStoreName,
        'Main Counter',
        '',
        '',
        'Chennai',
        'Tamil Nadu',
        '600001',
        '',
        '',
        '',
        '',
        '',
        'Rs.',
        defaultHeaderNote,
        'Thank you for shopping with us! Visit again.',
        'Goods once sold can be exchanged within 24 hours with original bill receipt.',
      ],
    });
  }

  // Seed default Loyalty Settings if empty
  const loyaltyRes = await internalSqliteClient.execute('SELECT COUNT(*) as count FROM loyalty_settings');
  if (Number(loyaltyRes.rows[0]?.count || 0) === 0) {
    await internalSqliteClient.execute({
      sql: `INSERT INTO loyalty_settings (
        id, enabled, spend_amount_per_point, points_earned_per_spend,
        point_redemption_value, min_points_to_redeem, expiry_period_days, auto_enroll_on_registration
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      args: ['default_loyalty', 1, 100.0, 1, 1.0, 10, 90, 1],
    });
  }

  // Seed Categories
  const catCountRes = await internalSqliteClient.execute('SELECT COUNT(*) as count FROM categories');
  const catCount = Number(catCountRes.rows[0]?.count || 0);

  if (catCount === 0) {
    console.log('[SQLite DB] Seeding categories, products, suppliers, customers, and operators...');

    // Seed Categories
    const categoryColors = ['emerald', 'blue', 'amber', 'purple', 'rose', 'orange', 'cyan', 'teal'];
    let catIdx = 0;
    for (const catName of INITIAL_CATEGORIES) {
      const catId = `CAT-${String(catIdx + 1).padStart(3, '0')}`;
      await internalSqliteClient.execute({
        sql: `INSERT OR REPLACE INTO categories (id, name, description, icon, color, display_order, status)
              VALUES (?, ?, ?, ?, ?, ?, ?)`,
        args: [catId, catName, `${catName} category`, 'category', categoryColors[catIdx % categoryColors.length], catIdx, 'active'],
      });
      catIdx++;
    }

    if (process.env.SEED_DEMO_PRODUCTS === 'true') {
      for (const prod of INITIAL_PRODUCTS) {
        await internalSqliteClient.execute({
          sql: `INSERT OR REPLACE INTO products (id, name, description, category, brand, unit, base_sku, base_barcode, base_price, base_mrp, base_cost, image_url, taxable, gst_rate, status, daily_consumption_rate, lead_time_days, supplier_id, total_on_hand, total_available, is_offer_active, offer_type, offer_value, offer_title, offer_start_date, offer_end_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          args: [
            prod.id,
            prod.name,
            prod.description || '',
            prod.category,
            prod.brand || 'Store Brand',
            prod.unit || 'kg',
            prod.baseSku,
            prod.baseBarcode || '',
            prod.basePrice || 0,
            prod.baseMrp || prod.basePrice || 0,
            prod.baseCost || 0,
            prod.image || prod.imageUrl || '',
            prod.taxable ? 1 : 0,
            prod.gstRate || 0,
            prod.status || 'active',
            prod.dailyConsumptionRate || 1.5,
            prod.leadTimeDays || 2,
            prod.supplierId || 'SUPP-001',
            prod.totalOnHand || 50,
            prod.totalAvailable || 50,
            prod.isOfferActive ? 1 : 0,
            prod.offerType || 'percentage',
            prod.offerValue || 0,
            prod.offerTitle || 'Offer of the Day',
            prod.offerStartDate || null,
            prod.offerEndDate || null,
          ],
        });

        if (Array.isArray(prod.variants) && prod.variants.length > 0) {
          for (const variant of prod.variants) {
            await internalSqliteClient.execute({
              sql: `INSERT OR REPLACE INTO product_variants (id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, margin_percent, on_hand, available, reserved, reorder_level, is_parent, version)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              args: [
                variant.id,
                prod.id,
                variant.sku || prod.baseSku,
                variant.barcode || prod.baseBarcode || '',
                variant.name || prod.name,
                variant.unit || prod.unit || 'kg',
                JSON.stringify(variant.attributes || {}),
                variant.mrp || prod.baseMrp || prod.basePrice || 0,
                variant.price || prod.basePrice || 0,
                variant.cost || prod.baseCost || 0,
                variant.marginPercent || 0,
                variant.onHand !== undefined ? variant.onHand : 50,
                variant.available !== undefined ? variant.available : 50,
                variant.reserved || 0,
                variant.reorderLevel || 10,
                variant.isParent ? 1 : 0,
                variant.version || 1,
              ],
            });
          }
        }
      }
    }

    for (const cust of INITIAL_CUSTOMERS) {
      await internalSqliteClient.execute({
        sql: `INSERT OR REPLACE INTO customers (id, name, email, phone, loyalty_points, tier, total_spend, store_credit, gst_number, notes)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          cust.id,
          cust.name,
          cust.email || '',
          cust.phone || '',
          cust.loyaltyPoints || 0,
          (cust as any).memberTier || (cust as any).tier || 'Standard',
          (cust as any).totalSpent || (cust as any).totalSpend || 0,
          cust.storeCredit || 0,
          (cust as any).gstNumber || null,
          (cust as any).notes || null,
        ],
      });
    }

    for (const supp of SUPPLIERS) {
      await internalSqliteClient.execute({
        sql: `INSERT OR REPLACE INTO suppliers (id, name, code, contact_person, email, phone, address, gst_number, payment_terms, status)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          supp.id,
          supp.name,
          (supp as any).code || supp.id,
          supp.contactPerson || '',
          (supp as any).contactEmail || (supp as any).email || '',
          supp.phone || '',
          (supp as any).address || '',
          (supp as any).gstNumber || '',
          supp.paymentTerms || 'Net 15',
          'active',
        ],
      });
    }

    for (const po of INITIAL_PURCHASE_ORDERS) {
      await internalSqliteClient.execute({
        sql: `INSERT OR REPLACE INTO purchase_orders (id, po_number, supplier_id, supplier_name, order_date, expected_delivery_date, total_amount, status, notes)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          po.id,
          po.poNumber,
          po.supplierId,
          po.supplierName,
          (po as any).orderDate || new Date().toISOString(),
          (po as any).expectedDelivery || (po as any).expectedDeliveryDate || null,
          po.totalAmount,
          po.status,
          (po as any).notes || null,
        ],
      });

      if (po.items && Array.isArray(po.items)) {
        for (const item of po.items) {
          await internalSqliteClient.execute({
            sql: `INSERT OR REPLACE INTO purchase_order_items (id, po_id, product_id, variant_id, sku, product_name, quantity_ordered, quantity_received, unit, unit_cost, total_cost)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            args: [
              item.id,
              po.id,
              (item as any).productId || item.id,
              item.variantId,
              item.sku,
              item.productName,
              item.quantityOrdered,
              item.quantityReceived || 0,
              item.unit,
              item.unitCost,
              item.totalCost,
            ],
          });
        }
      }
    }

    for (const twm of INITIAL_THREE_WAY_MATCHES) {
      await internalSqliteClient.execute({
        sql: `INSERT OR REPLACE INTO three_way_matches (id, po_id, po_number, grn_number, invoice_number, supplier_name, po_amount, grn_received_amount, invoice_amount, discrepancy_amount, status, discrepancy_note, timestamp)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          twm.id,
          twm.poId,
          twm.poNumber,
          twm.grnNumber,
          twm.invoiceNumber,
          twm.supplierName,
          twm.poAmount,
          twm.grnReceivedAmount,
          twm.invoiceAmount,
          twm.discrepancyAmount,
          twm.status,
          twm.discrepancyNote || null,
          twm.timestamp,
        ],
      });
    }

    for (const op of DEFAULT_OPERATORS) {
      await internalSqliteClient.execute({
        sql: `INSERT OR REPLACE INTO users (id, name, pin, role, role_title, user_role, email, phone, initials, status)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          op.id,
          op.name,
          op.pin,
          op.role,
          op.roleTitle || '',
          op.userRole || 'Staff',
          op.email || '',
          op.phone || '',
          op.initials || 'OP',
          op.status || 'active',
        ],
      });
    }

    console.log('[SQLite DB] Initial database seeding completed successfully!');
  }

  // Ensure purchase orders and 3-way matches are seeded if table is empty
  try {
    const poCountRes = await internalSqliteClient.execute('SELECT COUNT(*) as count FROM purchase_orders');
    const poCount = Number(poCountRes.rows[0]?.count || 0);
    if (poCount === 0 && INITIAL_PURCHASE_ORDERS.length > 0) {
      console.log('[SQLite DB] Purchase orders table is empty. Seeding standard PO dataset...');
      for (const po of INITIAL_PURCHASE_ORDERS) {
        const expDate = po.expectedDelivery || (po as any).expectedDeliveryDate || new Date().toISOString().slice(0, 10);
        await internalSqliteClient.execute({
          sql: `INSERT OR REPLACE INTO purchase_orders (id, po_number, supplier_id, supplier_name, order_date, expected_delivery, expected_delivery_date, total_amount, status, ai_suggested, ai_reason, safety_stock_trigger, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          args: [
            po.id,
            po.poNumber,
            po.supplierId,
            po.supplierName,
            po.createdAt || new Date().toISOString(),
            expDate,
            expDate,
            po.totalAmount,
            po.status,
            po.aiSuggested ? 1 : 0,
            po.aiReason || null,
            po.safetyStockTrigger || null,
            po.createdAt || new Date().toISOString(),
          ],
        });

        if (po.items && Array.isArray(po.items)) {
          for (const item of po.items) {
            await internalSqliteClient.execute({
              sql: `INSERT OR REPLACE INTO purchase_order_items (id, po_id, product_id, variant_id, sku, product_name, quantity_ordered, quantity_received, unit, unit_cost, total_cost)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              args: [
                item.id,
                po.id,
                (item as any).productId || item.id,
                item.variantId,
                item.sku,
                item.productName,
                item.quantityOrdered,
                item.quantityReceived || 0,
                item.unit || 'kg',
                item.unitCost,
                item.totalCost,
              ],
            });
          }
        }
      }

      for (const twm of INITIAL_THREE_WAY_MATCHES) {
        await internalSqliteClient.execute({
          sql: `INSERT OR REPLACE INTO three_way_matches (id, po_id, po_number, grn_number, invoice_number, supplier_name, po_amount, grn_received_amount, invoice_amount, discrepancy_amount, status, discrepancy_note, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          args: [
            twm.id,
            twm.poId,
            twm.poNumber,
            twm.grnNumber,
            twm.invoiceNumber,
            twm.supplierName,
            twm.poAmount,
            twm.grnReceivedAmount,
            twm.invoiceAmount,
            twm.discrepancyAmount,
            twm.status,
            twm.discrepancyNote || null,
            twm.timestamp,
          ],
        });
      }
      console.log('[SQLite DB] Standard Purchase Orders and 3-Way Matches seeded successfully.');
    }
  } catch (seedPoErr) {
    console.warn('[SQLite DB] Note during PO seed check:', seedPoErr);
  }
}

export async function seedPurchaseOrdersAndMatches(force: boolean = false): Promise<{ count: number }> {
  try {
    const [rows]: any = await pool.query('SELECT COUNT(*) as count FROM purchase_orders');
    const poCount = Number(rows[0]?.count || 0);

    if (poCount > 0 && !force) {
      return { count: poCount };
    }

    console.log('[Database] Seeding standard Purchase Orders, GRN line items & 3-way matches...');

    // First ensure suppliers exist
    const [supRows]: any = await pool.query('SELECT COUNT(*) as count FROM suppliers');
    if (Number(supRows[0]?.count || 0) === 0) {
      for (const supp of SUPPLIERS) {
        await pool.query(
          `INSERT INTO suppliers (id, name, code, contact_person, email, phone, address, gst_number, payment_terms, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO NOTHING`,
          [
            supp.id,
            supp.name,
            (supp as any).code || supp.id,
            supp.contactPerson || '',
            (supp as any).contactEmail || (supp as any).email || '',
            supp.phone || '',
            (supp as any).address || '',
            (supp as any).gstNumber || '',
            supp.paymentTerms || 'Net 15',
            'active',
          ]
        );
      }
    }

    for (const po of INITIAL_PURCHASE_ORDERS) {
      const expDate = po.expectedDelivery || (po as any).expectedDeliveryDate || new Date().toISOString().slice(0, 10);
      const createdAt = po.createdAt || new Date().toISOString();

      await pool.query(
        `INSERT INTO purchase_orders (
          id, po_number, supplier_id, supplier_name, total_amount, status,
          expected_delivery, expected_delivery_date, ai_suggested, ai_reason, safety_stock_trigger, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          supplier_name = excluded.supplier_name,
          total_amount = excluded.total_amount,
          status = excluded.status,
          expected_delivery = excluded.expected_delivery,
          created_at = excluded.created_at`,
        [
          po.id,
          po.poNumber,
          po.supplierId,
          po.supplierName,
          po.totalAmount,
          po.status,
          expDate,
          expDate,
          po.aiSuggested ? 1 : 0,
          po.aiReason || null,
          po.safetyStockTrigger || null,
          createdAt,
        ]
      );

      if (po.items && Array.isArray(po.items)) {
        for (const item of po.items) {
          await pool.query(
            `INSERT INTO purchase_order_items (
              id, po_id, product_id, variant_id, sku, product_name, quantity_ordered, quantity_received, unit, unit_cost, total_cost
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
              quantity_ordered = excluded.quantity_ordered,
              quantity_received = excluded.quantity_received,
              unit_cost = excluded.unit_cost,
              total_cost = excluded.total_cost`,
            [
              item.id,
              po.id,
              (item as any).productId || item.id,
              item.variantId,
              item.sku,
              item.productName,
              item.quantityOrdered,
              item.quantityReceived || 0,
              item.unit || 'kg',
              item.unitCost,
              item.totalCost,
            ]
          );
        }
      }
    }

    for (const twm of INITIAL_THREE_WAY_MATCHES) {
      await pool.query(
        `INSERT INTO three_way_matches (
          id, po_id, po_number, grn_number, invoice_number, supplier_name,
          po_amount, grn_received_amount, invoice_amount, discrepancy_amount, status, discrepancy_note, timestamp
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          status = excluded.status,
          grn_received_amount = excluded.grn_received_amount,
          invoice_amount = excluded.invoice_amount,
          discrepancy_amount = excluded.discrepancy_amount`,
        [
          twm.id,
          twm.poId,
          twm.poNumber,
          twm.grnNumber,
          twm.invoiceNumber,
          twm.supplierName,
          twm.poAmount,
          twm.grnReceivedAmount,
          twm.invoiceAmount,
          twm.discrepancyAmount,
          twm.status,
          twm.discrepancyNote || null,
          twm.timestamp,
        ]
      );
    }

    console.log(`[Database] Successfully seeded ${INITIAL_PURCHASE_ORDERS.length} standard Purchase Orders & ${INITIAL_THREE_WAY_MATCHES.length} 3-way matches.`);
    return { count: INITIAL_PURCHASE_ORDERS.length };
  } catch (err) {
    console.error('[Database] Failed to seed purchase orders:', err);
    throw err;
  }
}

export async function initDatabase(): Promise<void> {
  try {
    if (currentConfig.driver === 'supabase') {
      try {
        const client = await getSupabasePool().connect();
        await client.query('SELECT 1');
        client.release();
        const storeId = process.env.STORE_ID || currentConfig.storeId || 'STORE-002';
        console.log(`[Database] Supabase Cloud PostgreSQL connected successfully! (Store ID: ${storeId})`);
        return;
      } catch (err: any) {
        console.warn(`[Database] Supabase init failed (${err.message}). Falling back to Local SQLite.`);
      }
    }

    if (currentConfig.driver === 'mysql') {
      try {
        await initMysqlDatabase();
        console.log('[Database] Remote MySQL connection initialized successfully.');
        return;
      } catch (err: any) {
        console.warn(`[Database] MySQL init failed (${err.message}). Defaulting to SQLite.`);
      }
    }

    try {
      const integrity = await internalSqliteClient.execute('PRAGMA integrity_check;');
      const status = (integrity.rows[0] as any)?.integrity_check || '';
      if (status !== 'ok') {
        console.warn(`[SQLite DB] Integrity check returned '${status}'. Repairing database...`);
        await repairCorruptDatabase();
        return;
      }
    } catch (checkErr: any) {
      if (isCorruptError(checkErr)) {
        console.warn(`[SQLite DB] Integrity check caught corrupt error. Repairing database...`);
        await repairCorruptDatabase();
        return;
      }
      throw checkErr;
    }

    await createSqliteTablesAndSeed();
  } catch (err: any) {
    if (isCorruptError(err)) {
      console.warn(`[SQLite DB] Caught corrupt error during init. Repairing database...`);
      await repairCorruptDatabase();
      return;
    }
    console.error('[SQLite DB] Failed to initialize database:', err);
    throw err;
  }
}

initDatabase().catch((err) => {
  console.error('[Database] Error during auto init:', err);
});

export default pool;
