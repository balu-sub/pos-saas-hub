import pool from './db';

/**
 * Two-way catalog sync between this terminal's local SQLite database and the
 * Plannest cloud (Supabase `Windows_products`), strictly scoped by STORE_ID.
 *
 *  - PULL  (cloud -> local): every 15s. Cloud is the source of truth for catalog fields
 *          (name, price, barcode, category, offers...). Local stock is preserved.
 *  - PUSH  (local -> cloud): products added/edited/deleted on this terminal are written to a
 *          persistent outbox and sent to the cloud as soon as the internet is available.
 */

const SUPABASE_REST_URL = 'https://xcrndfislsbxzzkfrawp.supabase.co/rest/v1';
const SUPABASE_KEY = 'sb_publishable_8eYBVChz4IW8bLEM6IhjaA_aB5HsJkR';
const SYNC_INTERVAL_MS = 15000;

const CATALOG_FIELDS = [
  'name', 'description', 'category', 'brand', 'unit', 'base_sku', 'base_barcode',
  'base_price', 'base_mrp', 'base_cost', 'image_url', 'taxable', 'gst_rate', 'status',
  'daily_consumption_rate', 'lead_time_days', 'supplier_id',
  'is_offer_active', 'offer_type', 'offer_value', 'offer_title', 'offer_start_date', 'offer_end_date',
];

let storeId = process.env.STORE_ID || 'STORE-002';
let invalidateCache: () => void = () => {};
let productsVersion = 0;
let lastSyncAt = '';
let lastError = '';
let online = false;
let running = false;
let rerunRequested = false;
let timer: ReturnType<typeof setInterval> | null = null;
let outboxReady = false;

function authHeaders(extra: Record<string, string> = {}) {
  return {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

function norm(v: any): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'boolean') return v ? '1' : '0';
  const n = Number(v);
  if (typeof v !== 'string' || (v.trim() !== '' && Number.isFinite(n))) {
    return Number.isFinite(n) ? String(n) : String(v);
  }
  return v;
}

async function ensureOutbox() {
  if (outboxReady) return;
  await pool.query(
    `CREATE TABLE IF NOT EXISTS cloud_outbox (
       id INTEGER PRIMARY KEY AUTOINCREMENT,
       op TEXT NOT NULL,
       product_id TEXT NOT NULL,
       created_at TEXT DEFAULT (datetime('now'))
     )`
  );
  outboxReady = true;
}

export async function queueProductPush(productId: string) {
  try {
    await ensureOutbox();
    await pool.query('INSERT INTO cloud_outbox (op, product_id) VALUES (?, ?)', ['upsert', productId]);
    scheduleSoon();
  } catch (err: any) {
    console.warn('[Cloud Sync] Could not queue product push:', err.message);
  }
}

export async function queueProductDelete(productId: string) {
  try {
    await ensureOutbox();
    await pool.query('INSERT INTO cloud_outbox (op, product_id) VALUES (?, ?)', ['delete', productId]);
    scheduleSoon();
  } catch (err: any) {
    console.warn('[Cloud Sync] Could not queue product delete:', err.message);
  }
}

function scheduleSoon() {
  setTimeout(() => {
    runSyncCycle().catch(() => {});
  }, 400);
}

async function flushOutbox() {
  await ensureOutbox();
  const [rows]: any = await pool.query('SELECT id, op, product_id FROM cloud_outbox ORDER BY id ASC');
  if (!rows || rows.length === 0) return;

  // Collapse to the latest operation per product
  const latest = new Map<string, { op: string; maxId: number }>();
  for (const r of rows) {
    latest.set(String(r.product_id), { op: String(r.op), maxId: Number(r.id) });
  }

  for (const [pid, entry] of latest) {
    if (entry.op === 'delete') {
      const res = await fetch(
        `${SUPABASE_REST_URL}/Windows_products?id=eq.${encodeURIComponent(pid)}&store_id=eq.${encodeURIComponent(storeId)}`,
        { method: 'DELETE', headers: authHeaders({ Prefer: 'return=minimal' }) }
      );
      if (!res.ok) throw new Error(`cloud delete failed (${res.status})`);
    } else {
      const [prows]: any = await pool.query('SELECT * FROM products WHERE id = ?', [pid]);
      if (prows && prows.length > 0) {
        const p = prows[0];
        const [vrows]: any = await pool.query(
          'SELECT on_hand, available FROM product_variants WHERE product_id = ?',
          [pid]
        );
        const onHand = vrows && vrows.length > 0
          ? vrows.reduce((s: number, v: any) => s + Number(v.on_hand || 0), 0)
          : Number(p.total_on_hand ?? 50);
        const available = vrows && vrows.length > 0
          ? vrows.reduce((s: number, v: any) => s + Number(v.available || 0), 0)
          : Number(p.total_available ?? onHand);

        const fields: any = { total_on_hand: onHand, total_available: available, updated_at: p.updated_at || new Date().toISOString() };
        for (const f of CATALOG_FIELDS) fields[f] = p[f] === undefined ? null : p[f];

        // Does this store already have this product in the cloud?
        const scope = `id=eq.${encodeURIComponent(pid)}&store_id=eq.${encodeURIComponent(storeId)}`;
        const chk = await fetch(`${SUPABASE_REST_URL}/Windows_products?${scope}&select=id`, { headers: authHeaders() });
        if (!chk.ok) throw new Error(`cloud lookup failed (${chk.status})`);
        const found: any = await chk.json();

        let res: Response;
        if (Array.isArray(found) && found.length > 0) {
          res = await fetch(`${SUPABASE_REST_URL}/Windows_products?${scope}`, {
            method: 'PATCH',
            headers: authHeaders({ Prefer: 'return=minimal' }),
            body: JSON.stringify(fields),
          });
        } else {
          res = await fetch(`${SUPABASE_REST_URL}/Windows_products`, {
            method: 'POST',
            headers: authHeaders({ Prefer: 'return=minimal' }),
            body: JSON.stringify({ id: p.id, store_id: storeId, ...fields }),
          });
        }
        if (!res.ok) {
          const txt = await res.text().catch(() => '');
          if (res.status === 409) {
            // Id already used by another store in the cloud - drop this entry instead of retrying forever
            console.warn(`[Cloud Sync] Product id ${pid} conflicts with another store; skipped. ${txt}`);
          } else {
            throw new Error(`cloud save failed (${res.status}) ${txt}`);
          }
        }      }
    }
    await pool.query('DELETE FROM cloud_outbox WHERE product_id = ? AND id <= ?', [pid, entry.maxId]);
  }
}

async function pullProducts(): Promise<boolean> {
  const res = await fetch(
    `${SUPABASE_REST_URL}/Windows_products?store_id=eq.${encodeURIComponent(storeId)}&select=*`,
    { headers: authHeaders() }
  );
  if (!res.ok) throw new Error(`cloud pull failed (${res.status})`);
  const cloud: any = await res.json();
  if (!Array.isArray(cloud)) throw new Error('unexpected cloud response');

  await ensureOutbox();
  const [pend]: any = await pool.query('SELECT DISTINCT product_id FROM cloud_outbox');
  const pending = new Set<string>((pend || []).map((r: any) => String(r.product_id)));

  const [locals]: any = await pool.query('SELECT * FROM products');
  const localMap = new Map<string, any>((locals || []).map((p: any) => [String(p.id), p]));
  const cloudIds = new Set<string>();
  let changed = false;

  for (const cp of cloud) {
    const id = String(cp.id);
    cloudIds.add(id);
    if (pending.has(id)) continue; // local edit waiting to be pushed

    const existing = localMap.get(id);
    if (!existing) {
      await pool.query(
        `INSERT OR REPLACE INTO products (
           id, name, description, category, brand, unit, base_sku, base_barcode, base_price, base_mrp, base_cost,
           image_url, taxable, gst_rate, status, daily_consumption_rate, lead_time_days, supplier_id,
           total_on_hand, total_available, is_offer_active, offer_type, offer_value, offer_title,
           offer_start_date, offer_end_date
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id, cp.name, cp.description || '', cp.category || 'General', cp.brand || 'Store Brand', cp.unit || 'kg',
          cp.base_sku || `SKU-${id}`, cp.base_barcode || '', cp.base_price || 0, cp.base_mrp || cp.base_price || 0,
          cp.base_cost || 0, cp.image_url || '', cp.taxable ? 1 : 0, cp.gst_rate || 0, cp.status || 'active',
          cp.daily_consumption_rate || 1, cp.lead_time_days || 2, cp.supplier_id || 'SUPP-001',
          cp.total_on_hand ?? 50, cp.total_available ?? cp.total_on_hand ?? 50,
          cp.is_offer_active ? 1 : 0, cp.offer_type || 'percentage', cp.offer_value || 0,
          cp.offer_title || 'Offer of the Day', cp.offer_start_date || null, cp.offer_end_date || null,
        ]
      );
      await pool.query(
        `INSERT OR REPLACE INTO product_variants (
           id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, on_hand, available, reorder_level, is_parent
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 10, 1)`,
        [
          `VAR-${id}-1`, id, cp.base_sku || `SKU-${id}`, cp.base_barcode || '', `${cp.name} (Standard)`,
          cp.unit || 'kg', JSON.stringify({ 'Pack Size': `1 ${cp.unit || 'kg'}` }),
          cp.base_mrp || cp.base_price || 0, cp.base_price || 0, cp.base_cost || 0,
          cp.total_on_hand ?? 50, cp.total_available ?? cp.total_on_hand ?? 50,
        ]
      );
      changed = true;
      continue;
    }

    const differs = CATALOG_FIELDS.some((f) => norm(existing[f]) !== norm(cp[f]));
    if (differs) {
      const cloudTime = cp.updated_at ? new Date(cp.updated_at).getTime() : 0;
      const localTime = existing.updated_at ? new Date(existing.updated_at).getTime() : 0;

      // If local edit is strictly newer than cloud, let local win and push to cloud
      if (localTime > cloudTime && localTime > 0) {
        await queueProductPush(id);
        continue;
      }

      // Catalog fields come from the cloud (whichever is latest); local stock (variants) is left untouched.
      await pool.query(
        `UPDATE products SET
           name = ?, description = ?, category = ?, brand = ?, unit = ?, base_sku = ?, base_barcode = ?,
           base_price = ?, base_mrp = ?, base_cost = ?, image_url = ?, taxable = ?, gst_rate = ?, status = ?,
           is_offer_active = ?, offer_type = ?, offer_value = ?, offer_title = ?, offer_start_date = ?, offer_end_date = ?,
           updated_at = ?
         WHERE id = ?`,
        [
          cp.name, cp.description || '', cp.category || 'General', cp.brand || 'Store Brand', cp.unit || 'kg',
          cp.base_sku || existing.base_sku, cp.base_barcode || '', cp.base_price || 0,
          cp.base_mrp || cp.base_price || 0, cp.base_cost || 0, cp.image_url || '', cp.taxable ? 1 : 0,
          cp.gst_rate || 0, cp.status || 'active', cp.is_offer_active ? 1 : 0, cp.offer_type || 'percentage',
          cp.offer_value || 0, cp.offer_title || 'Offer of the Day', cp.offer_start_date || null,
          cp.offer_end_date || null, cp.updated_at || new Date().toISOString(), id,
        ]
      );
      await pool.query(
        `UPDATE product_variants SET price = ?, mrp = ?, cost = ?, barcode = ?, unit = ?
         WHERE product_id = ?
           AND (is_parent = 1 OR (SELECT COUNT(*) FROM product_variants v2 WHERE v2.product_id = ?) = 1)`,
        [cp.base_price || 0, cp.base_mrp || cp.base_price || 0, cp.base_cost || 0, cp.base_barcode || '', cp.unit || 'kg', id, id]
      );
      changed = true;
    }
  }

  // Products removed from the cloud catalog are removed locally (unless a local push is pending)
  for (const [id] of localMap) {
    if (!cloudIds.has(id) && !pending.has(id)) {
      await pool.query('DELETE FROM product_variants WHERE product_id = ?', [id]);
      await pool.query('DELETE FROM products WHERE id = ?', [id]);
      changed = true;
    }
  }

  return changed;
}

export async function pushOutletProfileToCloud() {
  try {
    const [rows]: any = await pool.query('SELECT * FROM outlet_profile LIMIT 1');
    if (!rows || rows.length === 0) return;
    const p = rows[0];

    await fetch(`${SUPABASE_REST_URL}/Windows_outlet_profile`, {
      method: 'POST',
      headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
      body: JSON.stringify({
        id: p.id || 'default_outlet',
        store_id: storeId,
        outlet_name: p.outlet_name || 'Amma Appa Kadai',
        branch_name: p.branch_name || 'Main Market Branch',
        address_line1: p.address_line1 || '',
        address_line2: p.address_line2 || '',
        city: p.city || 'Chennai',
        state: p.state || 'Tamil Nadu',
        pincode: p.pincode || '600001',
        phone: p.phone || '',
        email: p.email || '',
        gstin: p.gstin || '',
        pan_number: p.pan_number || '',
        fssai_license: p.fssai_license || '',
        receipt_header_note: p.receipt_header_note || '',
        receipt_footer_note: p.receipt_footer_note || '',
        return_terms: p.return_terms || '',
        bill_prefix: p.bill_prefix || 'INV/',
        bill_start_number: Number(p.bill_start_number || 1001),
        bill_increment_step: Number(p.bill_increment_step || 1),
        bill_number_padding: Number(p.bill_number_padding || 4),
        print_branch: p.print_branch !== undefined ? Number(p.print_branch) : 1,
        print_address: p.print_address !== undefined ? Number(p.print_address) : 1,
        print_phone: p.print_phone !== undefined ? Number(p.print_phone) : 1,
        print_email: p.print_email !== undefined ? Number(p.print_email) : 0,
        print_gstin: p.print_gstin !== undefined ? Number(p.print_gstin) : 1,
        print_pan: p.print_pan !== undefined ? Number(p.print_pan) : 1,
        print_fssai: p.print_fssai !== undefined ? Number(p.print_fssai) : 1,
        print_header_note: p.print_header_note !== undefined ? Number(p.print_header_note) : 1,
        print_return_terms: p.print_return_terms !== undefined ? Number(p.print_return_terms) : 1,
        updated_at: new Date().toISOString(),
      }),
    });

    await fetch(`${SUPABASE_REST_URL}/stores?id=eq.${encodeURIComponent(storeId)}`, {
      method: 'PATCH',
      headers: authHeaders({ Prefer: 'return=minimal' }),
      body: JSON.stringify({
        name: p.outlet_name || 'Amma Appa Kadai',
        phone: p.phone || '',
        address_line1: p.address_line1 || '',
        address_line2: p.address_line2 || '',
        gstin: p.gstin || '',
        fssai: p.fssai_license || '',
        bill_prefix: p.bill_prefix || 'INV/',
        starting_bill_no: Number(p.bill_start_number || 1001),
        updated_at: new Date().toISOString(),
      }),
    });
  } catch (err: any) {
    console.warn('[Cloud Sync] Outlet profile push error:', err.message);
  }
}

export async function pushLoyaltyToCloud() {
  try {
    const [rows]: any = await pool.query('SELECT * FROM loyalty_settings LIMIT 1');
    if (!rows || rows.length === 0) return;
    const l = rows[0];
    await fetch(`${SUPABASE_REST_URL}/Windows_loyalty_settings`, {
      method: 'POST',
      headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
      body: JSON.stringify({
        id: l.id || 'default_loyalty',
        store_id: storeId,
        program_name: l.program_name || 'Amma Appa Rewards',
        is_active: l.is_active ? 1 : 0,
        points_per_currency: Number(l.points_per_currency || 1),
        currency_per_point: Number(l.currency_per_point || 0.25),
        min_redemption_points: Number(l.min_redemption_points || 50),
        max_redemption_percentage: Number(l.max_redemption_percentage || 50),
        updated_at: new Date().toISOString(),
      }),
    });
  } catch (err: any) {
    console.warn('[Cloud Sync] Loyalty settings push error:', err.message);
  }
}

export async function pushUsersToCloud() {
  try {
    const [users]: any = await pool.query('SELECT * FROM users');
    if (!users || users.length === 0) return;
    for (const u of users) {
      await fetch(`${SUPABASE_REST_URL}/Windows_users`, {
        method: 'POST',
        headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
        body: JSON.stringify({
          id: u.id,
          store_id: storeId,
          name: u.name,
          pin: u.pin || '1234',
          role: u.role || 'Staff',
          role_title: u.role_title || '',
          user_role: u.user_role || u.role || 'Staff',
          email: u.email || '',
          phone: u.phone || '',
          initials: u.initials || 'OP',
          status: u.status || 'active',
        }),
      });
    }
  } catch (err: any) {
    console.warn('[Cloud Sync] Users push error:', err.message);
  }
}

export async function pushSuppliersToCloud() {
  try {
    const [suppliers]: any = await pool.query('SELECT * FROM suppliers');
    if (!suppliers || suppliers.length === 0) return;
    for (const s of suppliers) {
      await fetch(`${SUPABASE_REST_URL}/Windows_suppliers`, {
        method: 'POST',
        headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
        body: JSON.stringify({
          id: s.id,
          store_id: storeId,
          name: s.name,
          code: s.code || s.id,
          contact_person: s.contact_person || '',
          email: s.email || '',
          phone: s.phone || '',
          address: s.address || '',
          gst_number: s.gst_number || '',
          payment_terms: s.payment_terms || 'Net 15',
          status: s.status || 'active',
        }),
      });
    }
  } catch (err: any) {
    console.warn('[Cloud Sync] Suppliers push error:', err.message);
  }
}

export async function pushPurchaseOrdersToCloud() {
  try {
    const [pos]: any = await pool.query('SELECT * FROM purchase_orders');
    if (!pos || pos.length === 0) return;
    for (const po of pos) {
      await fetch(`${SUPABASE_REST_URL}/Windows_purchase_orders`, {
        method: 'POST',
        headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
        body: JSON.stringify({
          id: po.id,
          store_id: storeId,
          po_number: po.po_number,
          supplier_id: po.supplier_id,
          supplier_name: po.supplier_name,
          order_date: po.order_date || po.created_at || new Date().toISOString(),
          expected_delivery: po.expected_delivery || po.expected_delivery_date || '',
          expected_delivery_date: po.expected_delivery_date || po.expected_delivery || null,
          total_amount: Number(po.total_amount || 0),
          status: po.status || 'ISSUED',
          notes: po.notes || '',
        }),
      });
    }
  } catch (err: any) {
    console.warn('[Cloud Sync] Purchase orders push error:', err.message);
  }
}

export async function pushOrderToCloud(orderId: string) {
  try {
    const [orders]: any = await pool.query('SELECT * FROM orders WHERE id = ?', [orderId]);
    if (!orders || orders.length === 0) return;
    const o = orders[0];

    const orderRes = await fetch(`${SUPABASE_REST_URL}/Windows_orders`, {
      method: 'POST',
      headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
      body: JSON.stringify({
        id: o.id,
        store_id: storeId,
        order_number: o.order_number,
        terminal_id: o.terminal_id || 'TERM-01',
        shift_id: o.shift_id || null,
        customer_id: o.customer_id || null,
        customer_name: o.customer_name || 'Walk-in Customer',
        customer_phone: o.customer_phone || '',
        cashier_id: o.cashier_id || 'Admin',
        cashier_name: o.cashier_name || 'Ramesh Mandi',
        subtotal: Number(o.subtotal || 0),
        tax_amount: Number(o.tax_amount || 0),
        tax_rate: Number(o.tax_rate || 0),
        discount_total: Number(o.discount_total || 0),
        total: Number(o.total || 0),
        grand_total: Number(o.total || 0),
        amount_paid: Number(o.amount_paid || o.total || 0),
        change_due: Number(o.change_due || 0),
        item_count: Number(o.item_count || 1),
        status: o.status || 'completed',
        synced: 1,
        notes: o.notes || '',
        created_at: o.created_at || new Date().toISOString(),
      }),
    });

    if (orderRes.ok) {
      const [items]: any = await pool.query('SELECT * FROM order_items WHERE order_id = ?', [orderId]);
      if (items && items.length > 0) {
        for (const item of items) {
          await fetch(`${SUPABASE_REST_URL}/Windows_order_items`, {
            method: 'POST',
            headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
            body: JSON.stringify({
              id: item.id,
              store_id: storeId,
              order_id: o.id,
              product_id: item.product_id,
              variant_id: item.variant_id,
              product_name: item.product_name,
              sku: item.sku || 'SKU',
              barcode: item.barcode || '',
              unit: item.unit || 'kg',
              mrp: Number(item.mrp || 0),
              unit_price: Number(item.unit_price || 0),
              quantity: Number(item.quantity || 1),
              discount_amount: Number(item.discount_amount || 0),
              discount_percent: Number(item.discount_percent || 0),
              applied_tax_rate: Number(item.applied_tax_rate || 0),
              line_total: Number(item.unit_price || 0) * Number(item.quantity || 1),
            }),
          });
        }
      }
      await pool.query('UPDATE orders SET synced = 1 WHERE id = ?', [orderId]);
      console.log(`[Cloud Sync] Pushed order ${o.order_number} to cloud.`);
    }
  } catch (err: any) {
    console.warn(`[Cloud Sync] Order push error for ${orderId}:`, err.message);
  }
}

export async function pushUnsyncedOrdersToCloud() {
  try {
    const [unsynced]: any = await pool.query('SELECT id FROM orders WHERE synced = 0 OR synced IS NULL');
    if (unsynced && unsynced.length > 0) {
      for (const row of unsynced) {
        await pushOrderToCloud(row.id);
      }
    }
  } catch (err: any) {
    console.warn('[Cloud Sync] Error pushing unsynced orders:', err.message);
  }
}

export async function pushShiftsToCloud() {
  try {
    const [shifts]: any = await pool.query('SELECT * FROM shifts');
    if (!shifts || shifts.length === 0) return;
    for (const sh of shifts) {
      await fetch(`${SUPABASE_REST_URL}/Windows_shifts`, {
        method: 'POST',
        headers: authHeaders({ Prefer: 'return=minimal,resolution=merge-duplicates' }),
        body: JSON.stringify({
          id: sh.id || sh.shift_id,
          store_id: storeId,
          terminal_id: sh.terminal_id || 'POS-01',
          operator_id: sh.operator_id || 'Admin',
          operator_name: sh.operator_name || 'Ramesh Mandi',
          opened_at: sh.opened_at || new Date().toISOString(),
          closed_at: sh.closed_at || null,
          opening_float: Number(sh.opening_float || 0),
          cash_sales: Number(sh.cash_sales || 0),
          upi_sales: Number(sh.upi_sales || 0),
          card_sales: Number(sh.card_sales || 0),
          total_sales: Number(sh.total_sales || 0),
          expected_cash: Number(sh.expected_cash || 0),
          counted_cash: Number(sh.counted_cash || 0),
          variance: Number(sh.variance || 0),
          notes: sh.notes || '',
          status: sh.status || 'open',
        }),
      });
    }
  } catch (err: any) {
    console.warn('[Cloud Sync] Shifts push error:', err.message);
  }
}

export async function runFullStoreSync(): Promise<{ ok: boolean; error?: string }> {
  try {
    console.log(`[Cloud Sync] Running full store sync for Store ID: ${storeId}...`);
    await runSyncCycle();
    await pushOutletProfileToCloud();
    await pushLoyaltyToCloud();
    await pushUsersToCloud();
    await pushSuppliersToCloud();
    await pushPurchaseOrdersToCloud();
    await pushUnsyncedOrdersToCloud();
    await pushShiftsToCloud();
    console.log(`[Cloud Sync] Full store sync completed successfully for ${storeId}.`);
    return { ok: true };
  } catch (err: any) {
    console.warn('[Cloud Sync] Full store sync notice:', err.message);
    return { ok: false, error: err.message };
  }
}

export async function runSyncCycle(): Promise<{ ok: boolean; changed: boolean; error?: string }> {
  if (running) {
    rerunRequested = true;
    return { ok: true, changed: false };
  }
  running = true;
  try {
    try {
      await flushOutbox();
    } catch (err: any) {
      // Keep going: a failed push stays queued and is retried next cycle
      console.warn('[Cloud Sync] Push pending:', err.message);
      lastError = err.message;
    }
    const changed = await pullProducts();
    if (changed) {
      invalidateCache();
      productsVersion++;
      console.log(`[Cloud Sync] Catalog updated from cloud for ${storeId}.`);
    }
    online = true;
    lastSyncAt = new Date().toISOString();
    return { ok: true, changed };
  } catch (err: any) {
    online = false;
    lastError = err.message || String(err);
    return { ok: false, changed: false, error: lastError };
  } finally {
    running = false;
    if (rerunRequested) {
      rerunRequested = false;
      scheduleSoon();
    }
  }
}

export async function getSyncStatus() {
  let pendingChanges = 0;
  try {
    await ensureOutbox();
    const [r]: any = await pool.query('SELECT COUNT(*) as count FROM cloud_outbox');
    pendingChanges = Number(r?.[0]?.count || 0);
  } catch {
    // ignore
  }
  return { storeId, productsVersion, lastSyncAt, online, pendingChanges, lastError };
}

export function startCloudSync(targetStoreId: string | undefined, onCatalogChanged: () => void) {
  storeId = targetStoreId || process.env.STORE_ID || 'STORE-002';
  invalidateCache = onCatalogChanged;
  if (timer) clearInterval(timer);
  setTimeout(() => {
    runSyncCycle().catch(() => {});
  }, 1500);
  timer = setInterval(() => {
    runSyncCycle().catch(() => {});
  }, SYNC_INTERVAL_MS);
  console.log(`[Cloud Sync] Live catalog sync started for ${storeId} (every ${SYNC_INTERVAL_MS / 1000}s).`);
}
