import pool from './db';

/**
 * Two-way catalog sync between this terminal's local SQLite database and the
 * Plannest cloud (Supabase `Windows_products`), strictly scoped by STORE_ID.
 *
 *  - PULL  (cloud -> local): every 15s. Cloud is the source of truth for catalog fields
 *          (name, price, barcode, category, offers...). Local stock is preserved.
 *  - PUSH  (local -> cloud): products added/edited/deleted on this terminal are written to a
 *          persistent outbox and sent to the cloud as soon as the internet is available.
 */

const SUPABASE_REST_URL = 'https://xcrndfislsbxzzkfrawp.supabase.co/rest/v1';
const SUPABASE_KEY = 'sb_publishable_8eYBVChz4IW8bLEM6IhjaA_aB5HsJkR';
const SYNC_INTERVAL_MS = 15000;

const CATALOG_FIELDS = [
  'name', 'description', 'category', 'brand', 'unit', 'base_sku', 'base_barcode',
  'base_price', 'base_mrp', 'base_cost', 'image_url', 'taxable', 'gst_rate', 'status',
  'daily_consumption_rate', 'lead_time_days', 'supplier_id',
  'is_offer_active', 'offer_type', 'offer_value', 'offer_title', 'offer_start_date', 'offer_end_date',
];

let storeId = process.env.STORE_ID || 'STORE-002';
let invalidateCache: () => void = () => {};
let productsVersion = 0;
let lastSyncAt = '';
let lastError = '';
let online = false;
let running = false;
let rerunRequested = false;
let timer: ReturnType<typeof setInterval> | null = null;
let outboxReady = false;

function authHeaders(extra: Record<string, string> = {}) {
  return {
    apikey: SUPABASE_KEY,
    Authorization: `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

function norm(v: any): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'boolean') return v ? '1' : '0';
  const n = Number(v);
  if (typeof v !== 'string' || (v.trim() !== '' && Number.isFinite(n))) {
    return Number.isFinite(n) ? String(n) : String(v);
  }
  return v;
}

async function ensureOutbox() {
  if (outboxReady) return;
  await pool.query(
    `CREATE TABLE IF NOT EXISTS cloud_outbox (
       id INTEGER PRIMARY KEY AUTOINCREMENT,
       op TEXT NOT NULL,
       product_id TEXT NOT NULL,
       created_at TEXT DEFAULT (datetime('now'))
     )`
  );
  outboxReady = true;
}

export async function queueProductPush(productId: string) {
  try {
    await ensureOutbox();
    await pool.query('INSERT INTO cloud_outbox (op, product_id) VALUES (?, ?)', ['upsert', productId]);
    scheduleSoon();
  } catch (err: any) {
    console.warn('[Cloud Sync] Could not queue product push:', err.message);
  }
}

export async function queueProductDelete(productId: string) {
  try {
    await ensureOutbox();
    await pool.query('INSERT INTO cloud_outbox (op, product_id) VALUES (?, ?)', ['delete', productId]);
    scheduleSoon();
  } catch (err: any) {
    console.warn('[Cloud Sync] Could not queue product delete:', err.message);
  }
}

function scheduleSoon() {
  setTimeout(() => {
    runSyncCycle().catch(() => {});
  }, 400);
}

async function flushOutbox() {
  await ensureOutbox();
  const [rows]: any = await pool.query('SELECT id, op, product_id FROM cloud_outbox ORDER BY id ASC');
  if (!rows || rows.length === 0) return;

  // Collapse to the latest operation per product
  const latest = new Map<string, { op: string; maxId: number }>();
  for (const r of rows) {
    latest.set(String(r.product_id), { op: String(r.op), maxId: Number(r.id) });
  }

  for (const [pid, entry] of latest) {
    if (entry.op === 'delete') {
      const res = await fetch(
        `${SUPABASE_REST_URL}/Windows_products?id=eq.${encodeURIComponent(pid)}&store_id=eq.${encodeURIComponent(storeId)}`,
        { method: 'DELETE', headers: authHeaders({ Prefer: 'return=minimal' }) }
      );
      if (!res.ok) throw new Error(`cloud delete failed (${res.status})`);
    } else {
      const [prows]: any = await pool.query('SELECT * FROM products WHERE id = ?', [pid]);
      if (prows && prows.length > 0) {
        const p = prows[0];
        const [vrows]: any = await pool.query(
          'SELECT on_hand, available FROM product_variants WHERE product_id = ?',
          [pid]
        );
        const onHand = vrows && vrows.length > 0
          ? vrows.reduce((s: number, v: any) => s + Number(v.on_hand || 0), 0)
          : Number(p.total_on_hand ?? 50);
        const available = vrows && vrows.length > 0
          ? vrows.reduce((s: number, v: any) => s + Number(v.available || 0), 0)
          : Number(p.total_available ?? onHand);

        const fields: any = { total_on_hand: onHand, total_available: available };
        for (const f of CATALOG_FIELDS) fields[f] = p[f] === undefined ? null : p[f];

        // Does this store already have this product in the cloud?
        const scope = `id=eq.${encodeURIComponent(pid)}&store_id=eq.${encodeURIComponent(storeId)}`;
        const chk = await fetch(`${SUPABASE_REST_URL}/Windows_products?${scope}&select=id`, { headers: authHeaders() });
        if (!chk.ok) throw new Error(`cloud lookup failed (${chk.status})`);
        const found: any = await chk.json();

        let res: Response;
        if (Array.isArray(found) && found.length > 0) {
          res = await fetch(`${SUPABASE_REST_URL}/Windows_products?${scope}`, {
            method: 'PATCH',
            headers: authHeaders({ Prefer: 'return=minimal' }),
            body: JSON.stringify(fields),
          });
        } else {
          res = await fetch(`${SUPABASE_REST_URL}/Windows_products`, {
            method: 'POST',
            headers: authHeaders({ Prefer: 'return=minimal' }),
            body: JSON.stringify({ id: p.id, store_id: storeId, ...fields }),
          });
        }
        if (!res.ok) {
          const txt = await res.text().catch(() => '');
          if (res.status === 409) {
            // Id already used by another store in the cloud - drop this entry instead of retrying forever
            console.warn(`[Cloud Sync] Product id ${pid} conflicts with another store; skipped. ${txt}`);
          } else {
            throw new Error(`cloud save failed (${res.status}) ${txt}`);
          }
        }      }
    }
    await pool.query('DELETE FROM cloud_outbox WHERE product_id = ? AND id <= ?', [pid, entry.maxId]);
  }
}

async function pullProducts(): Promise<boolean> {
  const res = await fetch(
    `${SUPABASE_REST_URL}/Windows_products?store_id=eq.${encodeURIComponent(storeId)}&select=*`,
    { headers: authHeaders() }
  );
  if (!res.ok) throw new Error(`cloud pull failed (${res.status})`);
  const cloud: any = await res.json();
  if (!Array.isArray(cloud)) throw new Error('unexpected cloud response');

  await ensureOutbox();
  const [pend]: any = await pool.query('SELECT DISTINCT product_id FROM cloud_outbox');
  const pending = new Set<string>((pend || []).map((r: any) => String(r.product_id)));

  const [locals]: any = await pool.query('SELECT * FROM products');
  const localMap = new Map<string, any>((locals || []).map((p: any) => [String(p.id), p]));
  const cloudIds = new Set<string>();
  let changed = false;

  for (const cp of cloud) {
    const id = String(cp.id);
    cloudIds.add(id);
    if (pending.has(id)) continue; // local edit waiting to be pushed

    const existing = localMap.get(id);
    if (!existing) {
      await pool.query(
        `INSERT OR REPLACE INTO products (
           id, name, description, category, brand, unit, base_sku, base_barcode, base_price, base_mrp, base_cost,
           image_url, taxable, gst_rate, status, daily_consumption_rate, lead_time_days, supplier_id,
           total_on_hand, total_available, is_offer_active, offer_type, offer_value, offer_title,
           offer_start_date, offer_end_date
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id, cp.name, cp.description || '', cp.category || 'General', cp.brand || 'Store Brand', cp.unit || 'kg',
          cp.base_sku || `SKU-${id}`, cp.base_barcode || '', cp.base_price || 0, cp.base_mrp || cp.base_price || 0,
          cp.base_cost || 0, cp.image_url || '', cp.taxable ? 1 : 0, cp.gst_rate || 0, cp.status || 'active',
          cp.daily_consumption_rate || 1, cp.lead_time_days || 2, cp.supplier_id || 'SUPP-001',
          cp.total_on_hand ?? 50, cp.total_available ?? cp.total_on_hand ?? 50,
          cp.is_offer_active ? 1 : 0, cp.offer_type || 'percentage', cp.offer_value || 0,
          cp.offer_title || 'Offer of the Day', cp.offer_start_date || null, cp.offer_end_date || null,
        ]
      );
      await pool.query(
        `INSERT OR REPLACE INTO product_variants (
           id, product_id, sku, barcode, name, unit, attributes, mrp, price, cost, on_hand, available, reorder_level, is_parent
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 10, 1)`,
        [
          `VAR-${id}-1`, id, cp.base_sku || `SKU-${id}`, cp.base_barcode || '', `${cp.name} (Standard)`,
          cp.unit || 'kg', JSON.stringify({ 'Pack Size': `1 ${cp.unit || 'kg'}` }),
          cp.base_mrp || cp.base_price || 0, cp.base_price || 0, cp.base_cost || 0,
          cp.total_on_hand ?? 50, cp.total_available ?? cp.total_on_hand ?? 50,
        ]
      );
      changed = true;
      continue;
    }

    const differs = CATALOG_FIELDS.some((f) => norm(existing[f]) !== norm(cp[f]));
    if (differs) {
      // Catalog fields come from the cloud; local stock (variants) is left untouched.
      await pool.query(
        `UPDATE products SET
           name = ?, description = ?, category = ?, brand = ?, unit = ?, base_sku = ?, base_barcode = ?,
           base_price = ?, base_mrp = ?, base_cost = ?, image_url = ?, taxable = ?, gst_rate = ?, status = ?,
           is_offer_active = ?, offer_type = ?, offer_value = ?, offer_title = ?, offer_start_date = ?, offer_end_date = ?
         WHERE id = ?`,
        [
          cp.name, cp.description || '', cp.category || 'General', cp.brand || 'Store Brand', cp.unit || 'kg',
          cp.base_sku || existing.base_sku, cp.base_barcode || '', cp.base_price || 0,
          cp.base_mrp || cp.base_price || 0, cp.base_cost || 0, cp.image_url || '', cp.taxable ? 1 : 0,
          cp.gst_rate || 0, cp.status || 'active', cp.is_offer_active ? 1 : 0, cp.offer_type || 'percentage',
          cp.offer_value || 0, cp.offer_title || 'Offer of the Day', cp.offer_start_date || null,
          cp.offer_end_date || null, id,
        ]
      );
      await pool.query(
        `UPDATE product_variants SET price = ?, mrp = ?, cost = ?, barcode = ?, unit = ?
         WHERE product_id = ?
           AND (is_parent = 1 OR (SELECT COUNT(*) FROM product_variants v2 WHERE v2.product_id = ?) = 1)`,
        [cp.base_price || 0, cp.base_mrp || cp.base_price || 0, cp.base_cost || 0, cp.base_barcode || '', cp.unit || 'kg', id, id]
      );
      changed = true;
    }
  }

  // Products removed from the cloud catalog are removed locally (unless a local push is pending)
  for (const [id] of localMap) {
    if (!cloudIds.has(id) && !pending.has(id)) {
      await pool.query('DELETE FROM product_variants WHERE product_id = ?', [id]);
      await pool.query('DELETE FROM products WHERE id = ?', [id]);
      changed = true;
    }
  }

  return changed;
}

export async function runSyncCycle(): Promise<{ ok: boolean; changed: boolean; error?: string }> {
  if (running) {
    rerunRequested = true;
    return { ok: true, changed: false };
  }
  running = true;
  try {
    try {
      await flushOutbox();
    } catch (err: any) {
      // Keep going: a failed push stays queued and is retried next cycle
      console.warn('[Cloud Sync] Push pending:', err.message);
      lastError = err.message;
    }
    const changed = await pullProducts();
    if (changed) {
      invalidateCache();
      productsVersion++;
      console.log(`[Cloud Sync] Catalog updated from cloud for ${storeId}.`);
    }
    online = true;
    lastSyncAt = new Date().toISOString();
    return { ok: true, changed };
  } catch (err: any) {
    online = false;
    lastError = err.message || String(err);
    return { ok: false, changed: false, error: lastError };
  } finally {
    running = false;
    if (rerunRequested) {
      rerunRequested = false;
      scheduleSoon();
    }
  }
}

export async function getSyncStatus() {
  let pendingChanges = 0;
  try {
    await ensureOutbox();
    const [r]: any = await pool.query('SELECT COUNT(*) as count FROM cloud_outbox');
    pendingChanges = Number(r?.[0]?.count || 0);
  } catch {
    // ignore
  }
  return { storeId, productsVersion, lastSyncAt, online, pendingChanges, lastError };
}

export function startCloudSync(targetStoreId: string | undefined, onCatalogChanged: () => void) {
  storeId = targetStoreId || process.env.STORE_ID || 'STORE-002';
  invalidateCache = onCatalogChanged;
  if (timer) clearInterval(timer);
  setTimeout(() => {
    runSyncCycle().catch(() => {});
  }, 1500);
  timer = setInterval(() => {
    runSyncCycle().catch(() => {});
  }, SYNC_INTERVAL_MS);
  console.log(`[Cloud Sync] Live catalog sync started for ${storeId} (every ${SYNC_INTERVAL_MS / 1000}s).`);
}
