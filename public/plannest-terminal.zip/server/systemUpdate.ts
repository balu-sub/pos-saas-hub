import fs from 'fs';
import path from 'path';
import os from 'os';
import https from 'https';
import http from 'http';
import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

export async function downloadFile(url: string, destPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const client = url.startsWith('https') ? https : http;
    client.get(url, { headers: { 'User-Agent': 'Plannest-POS-Updater' } }, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        fs.unlink(destPath, () => {});
        return downloadFile(res.headers.location, destPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        file.close();
        fs.unlink(destPath, () => {});
        return reject(new Error(`Download failed with HTTP status ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => {
        file.close(() => resolve());
      });
    }).on('error', (err) => {
      file.close();
      fs.unlink(destPath, () => {});
      reject(err);
    });
  });
}

function copyDirectorySafe(srcDir: string, destDir: string) {
  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }

  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);

    // CRITICAL: Protect existing database, env, node_modules, and setup exe
    if (
      entry.name.endsWith('.db') ||
      entry.name.endsWith('.db-wal') ||
      entry.name.endsWith('.db-shm') ||
      entry.name === '.env' ||
      entry.name === 'node_modules' ||
      entry.name === 'PlannestPOS-Setup.exe'
    ) {
      continue;
    }

    if (entry.isDirectory()) {
      copyDirectorySafe(srcPath, destPath);
    } else {
      try {
        fs.copyFileSync(srcPath, destPath);
      } catch (err) {
        console.warn(`[Updater] Could not overwrite ${entry.name}:`, err);
      }
    }
  }
}

export async function applySystemUpdate(downloadUrl: string): Promise<{ success: boolean; message: string }> {
  const tempDir = os.tmpdir();
  const zipPath = path.join(tempDir, `plannest-update-${Date.now()}.zip`);
  const extractDir = path.join(tempDir, `plannest-extract-${Date.now()}`);

  try {
    console.log(`[Updater] Downloading update from: ${downloadUrl}`);
    await downloadFile(downloadUrl, zipPath);

    fs.mkdirSync(extractDir, { recursive: true });
    console.log(`[Updater] Extracting package to: ${extractDir}`);

    try {
      await execPromise(`tar -xf "${zipPath}" -C "${extractDir}"`);
    } catch {
      await execPromise(`powershell -NoProfile -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${extractDir}' -Force"`);
    }

    console.log(`[Updater] Applying files safely to root directory: ${process.cwd()}`);
    copyDirectorySafe(extractDir, process.cwd());

    // Clean up temp files
    try { fs.unlinkSync(zipPath); } catch {}
    try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch {}

    return {
      success: true,
      message: 'Update applied successfully. Refreshing terminal...',
    };
  } catch (err: any) {
    console.error('[Updater] Failed to apply update:', err);
    try { fs.unlinkSync(zipPath); } catch {}
    try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch {}
    throw new Error(err.message || 'Failed to apply software update');
  }
}
