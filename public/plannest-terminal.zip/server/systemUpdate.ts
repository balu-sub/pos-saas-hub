import fs from 'fs';
import path from 'path';
import os from 'os';
import https from 'https';
import http from 'http';
import { exec, spawn } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

export async function downloadFile(url: string, destPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const client = url.startsWith('https') ? https : http;
    client.get(url, { headers: { 'User-Agent': 'Plannest-POS-Updater' } }, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        try { fs.unlinkSync(destPath); } catch {}
        return downloadFile(res.headers.location, destPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        file.close();
        try { fs.unlinkSync(destPath); } catch {}
        return reject(new Error(`Download failed with HTTP status ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => {
        file.close(() => resolve());
      });
    }).on('error', (err) => {
      file.close();
      try { fs.unlinkSync(destPath); } catch {}
      reject(err);
    });
  });
}

export async function applySystemUpdate(downloadUrl: string): Promise<{ success: boolean; message: string; restarting: boolean }> {
  const tempDir = os.tmpdir();
  const timestamp = Date.now();
  const zipPath = path.join(tempDir, `plannest-update-${timestamp}.zip`);
  const extractDir = path.join(tempDir, `plannest-extract-${timestamp}`);
  const appDir = process.cwd();

  try {
    console.log(`[Updater] Downloading update package from: ${downloadUrl}`);
    await downloadFile(downloadUrl, zipPath);

    fs.mkdirSync(extractDir, { recursive: true });
    console.log(`[Updater] Extracting package to: ${extractDir}`);

    try {
      await execPromise(`tar -xf "${zipPath}" -C "${extractDir}"`);
    } catch {
      await execPromise(`powershell -NoProfile -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${extractDir}' -Force"`);
    }

    // Verify extraction succeeded
    if (!fs.existsSync(path.join(extractDir, 'src')) && !fs.existsSync(path.join(extractDir, 'package.json'))) {
      throw new Error('Update package verification failed: invalid archive structure');
    }

    // Create standalone updater batch script that runs independently after Node exits
    const updaterBatPath = path.join(tempDir, `plannest-apply-${timestamp}.bat`);
    const batContent = [
      '@echo off',
      'title Plannest POS Update Service',
      'echo ========================================================',
      'echo   Plannest POS Software Update in Progress',
      'echo   Please wait while updates are applied...',
      'echo ========================================================',
      'timeout /t 2 /nobreak >nul',
      '',
      ':: Terminate previous launcher and browser processes',
      'taskkill /F /IM PlannestPOS.exe >nul 2>&1',
      'taskkill /F /IM msedge.exe /FI "WINDOWTITLE eq Complete Plannest POS*" >nul 2>&1',
      'taskkill /F /IM chrome.exe /FI "WINDOWTITLE eq Complete Plannest POS*" >nul 2>&1',
      'taskkill /F /IM msedge.exe /FI "WINDOWTITLE eq Plannest POS*" >nul 2>&1',
      'taskkill /F /IM chrome.exe /FI "WINDOWTITLE eq Plannest POS*" >nul 2>&1',
      'timeout /t 1 /nobreak >nul',
      '',
      ':: Copy updated files using robocopy (preserves data, .env, and node_modules)',
      `robocopy "${extractDir}" "${appDir}" /E /XD "${path.join(appDir, 'data')}" "${path.join(appDir, 'node_modules')}" "${path.join(appDir, 'browser-profile')}" /XF "${path.join(appDir, '.env')}" "${path.join(appDir, 'PlannestPOS-Setup.exe')}" /R:3 /W:1 >nul`,
      '',
      ':: Clean up temporary download and extraction directories',
      `rmdir /S /Q "${extractDir}" >nul 2>&1`,
      `del /F /Q "${zipPath}" >nul 2>&1`,
      '',
      ':: Relaunch Plannest POS via launcher',
      `cd /d "${appDir}"`,
      `start "" "${path.join(appDir, 'PlannestPOS.exe')}"`,
      '',
      ':: Self-delete batch file',
      `del "%~f0" >nul 2>&1`,
      'exit /b',
    ].join('\r\n');

    fs.writeFileSync(updaterBatPath, batContent, 'utf8');

    // Launch updater batch file detached
    const child = spawn('cmd.exe', ['/c', updaterBatPath], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    child.unref();

    // Schedule graceful Node.js exit in 1.2 seconds so batch file takes over
    setTimeout(() => {
      console.log('[Updater] Process exiting to allow updater script to apply files...');
      process.exit(0);
    }, 1200);

    return {
      success: true,
      restarting: true,
      message: 'Update verified and ready. Plannest POS is restarting now...',
    };
  } catch (err: any) {
    console.error('[Updater] Failed to apply update:', err);
    try { fs.unlinkSync(zipPath); } catch {}
    try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch {}
    throw new Error(err.message || 'Failed to apply software update');
  }
}
