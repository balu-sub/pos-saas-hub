@echo off
title Plannest POS - Local Billing Terminal
cd /d "%~dp0"

echo ========================================================
echo             PLANNEST POS - BILLING TERMINAL
echo ========================================================
echo.

rem Step 1: Check Node.js
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not found on your computer.
    echo Node.js is required to run the local offline engine.
    echo.
    echo Please download and install Node.js LTS version from:
    echo   https://nodejs.org/
    echo.
    echo After installing Node.js, run this shortcut again.
    echo ========================================================
    pause
    exit /b 1
)

rem Step 2: Check package.json
if not exist "package.json" (
    echo [ERROR] package.json is missing in: %~dp0
    echo The installation files appear incomplete.
    echo Please re-run PlannestPOS-Setup.exe to restore terminal files.
    echo ========================================================
    pause
    exit /b 1
)

rem Step 3: Check dependencies
if not exist "node_modules\" (
    echo [SETUP] Initializing Plannest POS on this computer...
    echo [SETUP] Installing required dependencies - first run only.
    echo [SETUP] Please wait a few moments...
    echo.
    call npm install
    if not exist "node_modules\" (
        echo.
        echo [ERROR] Dependency installation encountered an issue.
        echo Please ensure your computer is connected to the internet.
        echo Try running "npm install" manually in: %~dp0
        echo ========================================================
        pause
        exit /b 1
    )
    echo [SETUP] Dependencies installed successfully!
    echo.
)

rem Step 4: Launch Local POS Server
echo [STATUS] Starting local offline billing server on http://localhost:3000 ...
echo [STATUS] Browser will open automatically in 3 seconds.
echo [INFO] DO NOT close this terminal window while billing.
echo --------------------------------------------------------
echo.

start "" cmd /c "ping 127.0.0.1 -n 5 >nul && start http://localhost:3000"

call npm run dev

echo.
echo ========================================================
echo Server has stopped.
echo ========================================================
pause
