@echo off
start "" "%~dp0PlannestPOS.exe"
exit /b
