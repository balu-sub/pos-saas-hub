@echo off
title Plannest POS - Local Billing Terminal
cd /d "%~dp0"

echo ========================================================
echo             PLANNEST POS - LOCAL WEB TERMINAL
echo ========================================================
echo.

where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is not installed or not in system PATH.
    echo Please install Node.js (LTS version) from:
    echo   https://nodejs.org/
    echo.
    echo After installing Node.js, run this shortcut again.
    echo.
    pause
    exit /b 1
)

if not exist "node_modules\" (
    echo [SETUP] First run detected. Installing dependencies...
    echo This may take 1-2 minutes depending on your internet connection.
    echo Please wait...
    call npm install
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Failed to install dependencies.
        pause
        exit /b 1
    )
    echo [SETUP] Installation complete!
)

echo Starting local POS terminal engine...
start "" cmd /c "ping 127.0.0.1 -n 4 >nul && start http://localhost:3000"
call npm run dev
pause
