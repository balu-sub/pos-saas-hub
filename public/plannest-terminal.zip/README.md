# Plannest POS - Local Tablet & Web Terminal

An offline-first retail POS and intelligent matrix inventory system with integrated SaaS Hub, barcode scanning, thermal printing, and optional Gemini AI multimodal scanning.

---

## 🚀 Running Locally

### Prerequisites
- **Node.js**: v18 or higher (v22 recommended)
- **npm**: v9 or higher

### Quick Start

1. **One-Click Launch (Windows)**:
   - Double-click [`launch.bat`](file:///E:/Plannest/Local_Web_POS/launch.bat) to start the server and automatically open the application in your default browser.

2. **Configuration (Optional)**:
   A `.env` file is already provided. If you want to use the AI Voice Assistant or Camera Object Detection, add your Google Gemini API key:
   ```env
   GEMINI_API_KEY="your_api_key_here"
   ```
   *(Get your free key from [Google AI Studio](https://aistudio.google.com/app/apikey))*

2. **Run in Development Mode**:
   ```bash
   npm run dev
   ```
   Opens at `http://localhost:3000`. Full hot-reloading (HMR) enabled for frontend and Express backend.

3. **Or Run in Production Mode**:
   ```bash
   npm run build
   npm start
   ```
   Serves the optimized build directly via Express at `http://localhost:3000`.

---

## 🗄️ Local Database & Storage

- **Database**: Embedded SQLite via LibSQL (`data/plannest_pos.db`).
- **Initial Data**: Auto-seeded with 170 products, categories, suppliers, customers, and default operators.
- **Offline Sync**: Dexie.js (IndexedDB) browser-side caching for offline operations.
- **MySQL Option**: Can be connected to a remote or local MySQL instance via Admin Database Settings.

---

## 🛠️ Available Scripts

- `npm run dev`: Launch Vite dev server with integrated Express API (`http://localhost:3000`)
- `npm run build`: Compile React frontend and generate PWA service worker
- `npm start`: Start production Node/Express server on port 3000
- `npm run lint`: Run TypeScript type-checker (`tsc --noEmit`)
- `npm run clean`: Clean build artifacts
